drop table "FacProd" purge;

create table "FacProd" (
  "ProdNo" varchar2(5),
  "ProdName" nvarchar2(60),
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "AgreementFg" varchar2(1),
  "CurrencyCode" varchar2(3),
  "BaseRateCode" varchar2(2),
  "ProdIncr" decimal(6, 4) default 0 not null,
  "LowLimitRate" decimal(6, 4) default 0 not null,
  "IncrFlag" varchar2(1),
  "RateCode" varchar2(1),
  "GovOfferFlag" varchar2(1),
  "FinancialFlag" varchar2(1),
  "EmpFlag" varchar2(1),
  "BreachFlag" varchar2(1),
  "BreachCode" varchar2(3),
  "BreachGetCode" varchar2(1),
  "ProhibitMonth" decimal(3, 0) default 0 not null,
  "BreachPercent" decimal(5, 2) default 0 not null,
  "BreachDecreaseMonth" decimal(3, 0) default 0 not null,
  "BreachDecrease" decimal(5, 2) default 0 not null,
  "BreachStartPercent" decimal(3, 0) default 0 not null,
  "IfrsStepProdCode" varchar2(1),
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProd" add constraint "FacProd_PK" primary key("ProdNo");

comment on table "FacProd" is '商品參數主檔';
comment on column "FacProd"."ProdNo" is '商品代碼';
comment on column "FacProd"."ProdName" is '商品名稱';
comment on column "FacProd"."StartDate" is '商品生效日期';
comment on column "FacProd"."EndDate" is '商品截止日期';
comment on column "FacProd"."StatusCode" is '商品狀態';
comment on column "FacProd"."AgreementFg" is '是否為協議商品';
comment on column "FacProd"."CurrencyCode" is '幣別';
comment on column "FacProd"."BaseRateCode" is '指標利率代碼';
comment on column "FacProd"."ProdIncr" is '商品加碼利率';
comment on column "FacProd"."LowLimitRate" is '利率下限';
comment on column "FacProd"."IncrFlag" is '加減碼是否依合約';
comment on column "FacProd"."RateCode" is '利率區分';
comment on column "FacProd"."GovOfferFlag" is '政府優惠房貸';
comment on column "FacProd"."FinancialFlag" is '理財型房貸';
comment on column "FacProd"."EmpFlag" is '員工優惠貸款';
comment on column "FacProd"."BreachFlag" is '是否限制清償';
comment on column "FacProd"."BreachCode" is '違約適用方式';
comment on column "FacProd"."BreachGetCode" is '違約金收取方式';
comment on column "FacProd"."ProhibitMonth" is '限制清償期限';
comment on column "FacProd"."BreachPercent" is '違約金百分比';
comment on column "FacProd"."BreachDecreaseMonth" is '違約金分段月數';
comment on column "FacProd"."BreachDecrease" is '分段遞減百分比';
comment on column "FacProd"."BreachStartPercent" is '還款起算比例%';
comment on column "FacProd"."IfrsStepProdCode" is 'IFRS階梯商品別';
comment on column "FacProd"."IfrsProdCode" is 'IFRS產品別';
comment on column "FacProd"."CreateDate" is '建檔日期時間';
comment on column "FacProd"."CreateEmpNo" is '建檔人員';
comment on column "FacProd"."LastUpdate" is '最後更新日期時間';
comment on column "FacProd"."LastUpdateEmpNo" is '最後更新人員';
