drop table "BatxHead" purge;

create table "BatxHead" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "BatxTotAmt" decimal(14, 0) default 0 not null,
  "BatxTotCnt" decimal(6, 0) default 0 not null,
  "UnfinishCnt" decimal(6, 0) default 0 not null,
  "BatxExeCode" varchar2(1),
  "BatxStsCode" varchar2(1),
  "TitaTlrNo" varchar2(6),
  "TitaTxCd" varchar2(5),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxHead" add constraint "BatxHead_PK" primary key("AcDate", "BatchNo");

comment on table "BatxHead" is '整批入帳總數檔';
comment on column "BatxHead"."AcDate" is '會計日期';
comment on column "BatxHead"."BatchNo" is '批號';
comment on column "BatxHead"."BatxTotAmt" is '總金額';
comment on column "BatxHead"."BatxTotCnt" is '總筆數';
comment on column "BatxHead"."UnfinishCnt" is '未完筆數';
comment on column "BatxHead"."BatxExeCode" is '作業狀態';
comment on column "BatxHead"."BatxStsCode" is '整批作業狀態';
comment on column "BatxHead"."TitaTlrNo" is '經辦';
comment on column "BatxHead"."TitaTxCd" is '交易代號';
comment on column "BatxHead"."CreateDate" is '建檔日期時間';
comment on column "BatxHead"."CreateEmpNo" is '建檔人員';
comment on column "BatxHead"."LastUpdate" is '最後更新日期時間';
comment on column "BatxHead"."LastUpdateEmpNo" is '最後更新人員';
