drop table "CustCross" purge;

create table "CustCross" (
  "CustUKey" varchar2(32),
  "SubCompanyCode" varchar2(2),
  "CrossUse" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustCross" add constraint "CustCross_PK" primary key("CustUKey", "SubCompanyCode");

alter table "CustCross" add constraint "CustCross_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

comment on table "CustCross" is '客戶交互運用檔';
comment on column "CustCross"."CustUKey" is '客戶識別碼';
comment on column "CustCross"."SubCompanyCode" is '子公司代碼';
comment on column "CustCross"."CrossUse" is '交互運用';
comment on column "CustCross"."CreateDate" is '建檔日期時間';
comment on column "CustCross"."CreateEmpNo" is '建檔人員';
comment on column "CustCross"."LastUpdate" is '最後更新日期時間';
comment on column "CustCross"."LastUpdateEmpNo" is '最後更新人員';
