drop table "PostAuthLog" purge;

create table "PostAuthLog" (
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "AuthApplCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "AuthCode" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "RepayAcctSeq" varchar2(2),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "StampCancelDate" decimal(8, 0) default 0 not null,
  "StampCode" varchar2(1),
  "PostMediaCode" varchar2(1),
  "AuthErrorCode" varchar2(2),
  "FileSeq" decimal(6, 0) default 0 not null,
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "TitaTxCd" varchar2(5),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "PostAuthLog" add constraint "PostAuthLog_PK" primary key("AuthCreateDate", "AuthApplCode", "CustNo", "PostDepCode", "RepayAcct", "AuthCode");

create index "PostAuthLog_Index1" on "PostAuthLog"("AuthCreateDate" asc);

create index "PostAuthLog_Index2" on "PostAuthLog"("PostMediaCode" asc, "AuthErrorCode" asc);

create index "PostAuthLog_Index3" on "PostAuthLog"("PropDate" asc);

create index "PostAuthLog_Index4" on "PostAuthLog"("RetrDate" asc);

comment on table "PostAuthLog" is '郵局授權記錄檔';
comment on column "PostAuthLog"."AuthCreateDate" is '建檔日期';
comment on column "PostAuthLog"."AuthApplCode" is '申請代號，狀態碼';
comment on column "PostAuthLog"."CustNo" is '戶號';
comment on column "PostAuthLog"."PostDepCode" is '帳戶別';
comment on column "PostAuthLog"."RepayAcct" is '儲金帳號';
comment on column "PostAuthLog"."AuthCode" is '授權方式';
comment on column "PostAuthLog"."FacmNo" is '額度';
comment on column "PostAuthLog"."CustId" is '統一編號';
comment on column "PostAuthLog"."RepayAcctSeq" is '帳號碼';
comment on column "PostAuthLog"."ProcessDate" is '處理日期';
comment on column "PostAuthLog"."StampFinishDate" is '核印完成日期';
comment on column "PostAuthLog"."StampCancelDate" is '核印取消日期';
comment on column "PostAuthLog"."StampCode" is '核印註記';
comment on column "PostAuthLog"."PostMediaCode" is '媒體碼';
comment on column "PostAuthLog"."AuthErrorCode" is '狀況代號，授權狀態';
comment on column "PostAuthLog"."FileSeq" is '媒體檔流水編號';
comment on column "PostAuthLog"."PropDate" is '提出日期';
comment on column "PostAuthLog"."RetrDate" is '提回日期';
comment on column "PostAuthLog"."DeleteDate" is '暫停授權日期';
comment on column "PostAuthLog"."RelationCode" is '與借款人關係';
comment on column "PostAuthLog"."RelAcctName" is '第三人帳戶戶名';
comment on column "PostAuthLog"."RelationId" is '第三人身分證字號';
comment on column "PostAuthLog"."RelAcctBirthday" is '第三人出生日期';
comment on column "PostAuthLog"."RelAcctGender" is '第三人性別';
comment on column "PostAuthLog"."AmlRsp" is 'AML回應碼';
comment on column "PostAuthLog"."TitaTxCd" is '交易代號';
comment on column "PostAuthLog"."CreateEmpNo" is '建立者櫃員編號';
comment on column "PostAuthLog"."CreateDate" is '建檔日期';
comment on column "PostAuthLog"."LastUpdateEmpNo" is '修改者櫃員編號';
comment on column "PostAuthLog"."LastUpdate" is '異動日期';
