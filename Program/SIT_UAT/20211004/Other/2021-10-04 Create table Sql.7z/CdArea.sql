drop table "CdArea" purge;

create table "CdArea" (
  "CityCode" varchar2(2),
  "AreaCode" varchar2(2),
  "AreaItem" nvarchar2(12),
  "CityShort" nvarchar2(6),
  "AreaShort" nvarchar2(8),
  "JcicCityCode" varchar2(1),
  "JcicAreaCode" varchar2(2),
  "CityType" varchar2(2),
  "Zip3" varchar2(3),
  "DepartCode" varchar2(6),
  "CityGroup" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdArea" add constraint "CdArea_PK" primary key("CityCode", "AreaCode");

alter table "CdArea" add constraint "CdArea_CdCity_FK1" foreign key ("CityCode") references "CdCity" ("CityCode") on delete cascade;

create index "CdArea_Index1" on "CdArea"("Zip3" asc);

comment on table "CdArea" is '縣市與鄉鎮區對照檔';
comment on column "CdArea"."CityCode" is '縣市別代碼';
comment on column "CdArea"."AreaCode" is '鄉鎮區代碼';
comment on column "CdArea"."AreaItem" is '鄉鎮區名稱';
comment on column "CdArea"."CityShort" is '縣市簡稱';
comment on column "CdArea"."AreaShort" is '鄉鎮簡稱';
comment on column "CdArea"."JcicCityCode" is 'JCIC縣市碼';
comment on column "CdArea"."JcicAreaCode" is 'JCIC鄉鎮碼';
comment on column "CdArea"."CityType" is '地區類別';
comment on column "CdArea"."Zip3" is '郵遞區號';
comment on column "CdArea"."DepartCode" is '部室代號';
comment on column "CdArea"."CityGroup" is '組合地區別';
comment on column "CdArea"."CreateDate" is '建檔日期時間';
comment on column "CdArea"."CreateEmpNo" is '建檔人員';
comment on column "CdArea"."LastUpdate" is '最後更新日期時間';
comment on column "CdArea"."LastUpdateEmpNo" is '最後更新人員';
