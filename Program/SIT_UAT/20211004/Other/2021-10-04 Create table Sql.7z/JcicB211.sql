drop table "JcicB211" purge;

create table "JcicB211" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "CustId" varchar2(10),
  "SubTranCode" varchar2(1),
  "AcDate" decimal(7, 0) default 0 not null,
  "AcctNo" varchar2(50),
  "BorxNo" decimal(4, 0) default 0 not null,
  "TxAmt" decimal(10, 0) default 0 not null,
  "LoanBal" decimal(10, 0) default 0 not null,
  "RepayCode" varchar2(1),
  "NegStatus" varchar2(3),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "BadDebtDate" decimal(5, 0) default 0 not null,
  "ConsumeFg" varchar2(1),
  "FinCode" varchar2(1),
  "UsageCode" varchar2(1),
  "Filler18" varchar2(130),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB211" add constraint "JcicB211_PK" primary key("DataYMD", "BankItem", "BranchItem", "CustId", "AcDate", "AcctNo", "BorxNo");

comment on table "JcicB211" is '聯徵每日授信餘額變動資料檔';
comment on column "JcicB211"."DataYMD" is '資料日期';
comment on column "JcicB211"."BankItem" is '總行代號';
comment on column "JcicB211"."BranchItem" is '分行代號';
comment on column "JcicB211"."TranCode" is '交易代碼';
comment on column "JcicB211"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB211"."SubTranCode" is '交易屬性';
comment on column "JcicB211"."AcDate" is '交易日期';
comment on column "JcicB211"."AcctNo" is '本筆撥款／還款帳號';
comment on column "JcicB211"."BorxNo" is '交易內容檔序號';
comment on column "JcicB211"."TxAmt" is '本筆撥款／還款金額';
comment on column "JcicB211"."LoanBal" is '本筆撥款／還款餘額';
comment on column "JcicB211"."RepayCode" is '本筆還款後之還款紀錄';
comment on column "JcicB211"."NegStatus" is '本筆還款後之債權結案註記';
comment on column "JcicB211"."AcctCode" is '科目別';
comment on column "JcicB211"."SubAcctCode" is '科目別註記';
comment on column "JcicB211"."BadDebtDate" is '呆帳轉銷年月';
comment on column "JcicB211"."ConsumeFg" is '個人消費性貸款註記';
comment on column "JcicB211"."FinCode" is '融資業務分類';
comment on column "JcicB211"."UsageCode" is '用途別';
comment on column "JcicB211"."Filler18" is '空白';
comment on column "JcicB211"."CreateDate" is '建檔日期時間';
comment on column "JcicB211"."CreateEmpNo" is '建檔人員';
comment on column "JcicB211"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB211"."LastUpdateEmpNo" is '最後更新人員';
