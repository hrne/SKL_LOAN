drop table "BankAuthAct" purge;

create table "BankAuthAct" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthType" varchar2(2),
  "RepayBank" varchar2(3),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "Status" varchar2(1),
  "LimitAmt" decimal(14, 0) default 0 not null,
  "AcctSeq" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankAuthAct" add constraint "BankAuthAct_PK" primary key("CustNo", "FacmNo", "AuthType");

create index "BankAuthAct_Index1" on "BankAuthAct"("CustNo" asc, "FacmNo" asc, "RepayAcct" asc);

comment on table "BankAuthAct" is '銀扣授權帳號檔';
comment on column "BankAuthAct"."CustNo" is '戶號';
comment on column "BankAuthAct"."FacmNo" is '額度';
comment on column "BankAuthAct"."AuthType" is '授權類別';
comment on column "BankAuthAct"."RepayBank" is '扣款銀行';
comment on column "BankAuthAct"."PostDepCode" is '郵局存款別';
comment on column "BankAuthAct"."RepayAcct" is '扣款帳號';
comment on column "BankAuthAct"."Status" is '狀態碼';
comment on column "BankAuthAct"."LimitAmt" is '每筆扣款限額';
comment on column "BankAuthAct"."AcctSeq" is '帳號碼';
comment on column "BankAuthAct"."CreateDate" is '建檔日期時間';
comment on column "BankAuthAct"."CreateEmpNo" is '建檔人員';
comment on column "BankAuthAct"."LastUpdate" is '最後更新日期時間';
comment on column "BankAuthAct"."LastUpdateEmpNo" is '最後更新人員';
