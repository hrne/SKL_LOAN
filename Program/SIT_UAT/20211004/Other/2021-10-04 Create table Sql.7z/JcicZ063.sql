drop table "JcicZ063" purge;

create table "JcicZ063" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "ClosedDate" decimal(8, 0) default 0 not null,
  "ClosedResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ063" add constraint "JcicZ063_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate");

create index "JcicZ063_Index1" on "JcicZ063"("SubmitKey" asc);

create index "JcicZ063_Index2" on "JcicZ063"("CustId" asc);

create index "JcicZ063_Index3" on "JcicZ063"("RcDate" asc);

create index "JcicZ063_Index4" on "JcicZ063"("ChangePayDate" asc);

comment on table "JcicZ063" is '變更還款方案結案通知資料';
comment on column "JcicZ063"."TranKey" is '交易代碼';
comment on column "JcicZ063"."CustId" is '債務人IDN';
comment on column "JcicZ063"."SubmitKey" is '報送單位代號';
comment on column "JcicZ063"."RcDate" is '原前置協商申請日';
comment on column "JcicZ063"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ063"."ClosedDate" is '變更還款條件結案日期';
comment on column "JcicZ063"."ClosedResult" is '結案原因';
comment on column "JcicZ063"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ063"."Ukey" is '流水號';
comment on column "JcicZ063"."CreateDate" is '建檔日期時間';
comment on column "JcicZ063"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ063"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ063"."LastUpdateEmpNo" is '最後更新人員';
