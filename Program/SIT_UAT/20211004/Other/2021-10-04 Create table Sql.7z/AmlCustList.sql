drop table "AmlCustList" purge;

create table "AmlCustList" (
  "CustNo" decimal(7, 0) default 0 not null,
  "Note1" varchar2(1),
  "Note2" varchar2(1),
  "Note3" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AmlCustList" add constraint "AmlCustList_PK" primary key("CustNo");

comment on table "AmlCustList" is 'AML每日有效客戶名單';
comment on column "AmlCustList"."CustNo" is '借款人戶號';
comment on column "AmlCustList"."Note1" is '註記1';
comment on column "AmlCustList"."Note2" is '註記2';
comment on column "AmlCustList"."Note3" is '註記3';
comment on column "AmlCustList"."CreateDate" is '建檔日期時間';
comment on column "AmlCustList"."CreateEmpNo" is '建檔人員';
comment on column "AmlCustList"."LastUpdate" is '最後更新日期時間';
comment on column "AmlCustList"."LastUpdateEmpNo" is '最後更新人員';
