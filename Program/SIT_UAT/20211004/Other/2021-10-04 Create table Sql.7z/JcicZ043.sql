drop table "JcicZ043" purge;

create table "JcicZ043" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" varchar2(3),
  "Account" varchar2(50),
  "CollateralType" varchar2(2),
  "OriginLoanAmt" decimal(12, 0) default 0 not null,
  "CreditBalance" decimal(12, 0) default 0 not null,
  "PerPeriordAmt" decimal(10, 0) default 0 not null,
  "LastPayAmt" decimal(10, 0) default 0 not null,
  "LastPayDate" decimal(8, 0) default 0 not null,
  "OutstandAmt" decimal(10, 0) default 0 not null,
  "RepayPerMonDay" decimal(2, 0) default 0 not null,
  "ContractStartYM" decimal(6, 0) default 0 not null,
  "ContractEndYM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ043" add constraint "JcicZ043_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode", "Account");

create index "JcicZ043_Index1" on "JcicZ043"("SubmitKey" asc);

create index "JcicZ043_Index2" on "JcicZ043"("CustId" asc);

create index "JcicZ043_Index3" on "JcicZ043"("RcDate" asc);

create index "JcicZ043_Index4" on "JcicZ043"("MaxMainCode" asc);

create index "JcicZ043_Index5" on "JcicZ043"("Account" asc);

comment on table "JcicZ043" is '回報有擔保債權金額資料';
comment on column "JcicZ043"."TranKey" is '交易代碼';
comment on column "JcicZ043"."SubmitKey" is '報送單位代號';
comment on column "JcicZ043"."CustId" is '債務人IDN';
comment on column "JcicZ043"."RcDate" is '協商申請日';
comment on column "JcicZ043"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ043"."Account" is '帳號';
comment on column "JcicZ043"."CollateralType" is '擔保品類別';
comment on column "JcicZ043"."OriginLoanAmt" is '原借款金額';
comment on column "JcicZ043"."CreditBalance" is '授信餘額';
comment on column "JcicZ043"."PerPeriordAmt" is '每期應付金額';
comment on column "JcicZ043"."LastPayAmt" is '最近一期繳款金額';
comment on column "JcicZ043"."LastPayDate" is '最後繳息日';
comment on column "JcicZ043"."OutstandAmt" is '已到期尚未償還金額';
comment on column "JcicZ043"."RepayPerMonDay" is '每月應還款日';
comment on column "JcicZ043"."ContractStartYM" is '契約起始年月';
comment on column "JcicZ043"."ContractEndYM" is '契約截止年月';
comment on column "JcicZ043"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ043"."Ukey" is '流水號';
comment on column "JcicZ043"."CreateDate" is '建檔日期時間';
comment on column "JcicZ043"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ043"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ043"."LastUpdateEmpNo" is '最後更新人員';
