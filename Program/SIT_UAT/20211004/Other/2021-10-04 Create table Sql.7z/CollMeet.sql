drop table "CollMeet" purge;

create table "CollMeet" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MeetDate" decimal(8, 0) default 0 not null,
  "MeetTime" varchar2(4),
  "ContactCode" varchar2(1),
  "MeetPsnCode" varchar2(1),
  "CollPsnCode" varchar2(1),
  "CollPsnName" nvarchar2(8),
  "MeetPlaceCode" decimal(1, 0) default 0 not null,
  "MeetPlace" nvarchar2(60),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollMeet" add constraint "CollMeet_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollMeet" is '法催紀錄面催檔';
comment on column "CollMeet"."CaseCode" is '案件種類';
comment on column "CollMeet"."CustNo" is '借款人戶號';
comment on column "CollMeet"."FacmNo" is '額度編號';
comment on column "CollMeet"."AcDate" is '作業日期';
comment on column "CollMeet"."TitaTlrNo" is '經辦';
comment on column "CollMeet"."TitaTxtNo" is '交易序號';
comment on column "CollMeet"."MeetDate" is '面催日期';
comment on column "CollMeet"."MeetTime" is '面催時間';
comment on column "CollMeet"."ContactCode" is '聯絡對象';
comment on column "CollMeet"."MeetPsnCode" is '面晤人';
comment on column "CollMeet"."CollPsnCode" is '催收人員';
comment on column "CollMeet"."CollPsnName" is '催收人員姓名';
comment on column "CollMeet"."MeetPlaceCode" is '面催地點選項';
comment on column "CollMeet"."MeetPlace" is '面催地點';
comment on column "CollMeet"."Remark" is '其他記錄';
comment on column "CollMeet"."CreateDate" is '建檔日期時間';
comment on column "CollMeet"."CreateEmpNo" is '建檔人員';
comment on column "CollMeet"."LastUpdate" is '最後更新日期時間';
comment on column "CollMeet"."LastUpdateEmpNo" is '最後更新人員';
