drop table "JcicZ570Log" purge;

create table "JcicZ570Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AdjudicateDate" decimal(8, 0) default 0 not null,
  "BankCount" decimal(2, 0) default 0 not null,
  "Bank1" nvarchar2(3),
  "Bank2" nvarchar2(3),
  "Bank3" nvarchar2(3),
  "Bank4" nvarchar2(3),
  "Bank5" nvarchar2(3),
  "Bank6" nvarchar2(3),
  "Bank7" nvarchar2(3),
  "Bank8" nvarchar2(3),
  "Bank9" nvarchar2(3),
  "Bank10" nvarchar2(3),
  "Bank11" nvarchar2(3),
  "Bank12" nvarchar2(3),
  "Bank13" nvarchar2(3),
  "Bank14" nvarchar2(3),
  "Bank15" nvarchar2(3),
  "Bank16" nvarchar2(3),
  "Bank17" nvarchar2(3),
  "Bank18" nvarchar2(3),
  "Bank19" nvarchar2(3),
  "Bank20" nvarchar2(3),
  "Bank21" nvarchar2(3),
  "Bank22" nvarchar2(3),
  "Bank23" nvarchar2(3),
  "Bank24" nvarchar2(3),
  "Bank25" nvarchar2(3),
  "Bank26" nvarchar2(3),
  "Bank27" nvarchar2(3),
  "Bank28" nvarchar2(3),
  "Bank29" nvarchar2(3),
  "Bank30" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ570Log" add constraint "JcicZ570Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ570Log" is '受理更生款項統一收付通知資料';
comment on column "JcicZ570Log"."Ukey" is '流水號';
comment on column "JcicZ570Log"."TxSeq" is '交易序號';
comment on column "JcicZ570Log"."TranKey" is '交易代碼';
comment on column "JcicZ570Log"."AdjudicateDate" is '更生方案認可裁定日';
comment on column "JcicZ570Log"."BankCount" is '更生債權金融機構家數';
comment on column "JcicZ570Log"."Bank1" is '債權金融機構代號1';
comment on column "JcicZ570Log"."Bank2" is '債權金融機構代號2';
comment on column "JcicZ570Log"."Bank3" is '債權金融機構代號3';
comment on column "JcicZ570Log"."Bank4" is '債權金融機構代號4';
comment on column "JcicZ570Log"."Bank5" is '債權金融機構代號5';
comment on column "JcicZ570Log"."Bank6" is '債權金融機構代號6';
comment on column "JcicZ570Log"."Bank7" is '債權金融機構代號7';
comment on column "JcicZ570Log"."Bank8" is '債權金融機構代號8';
comment on column "JcicZ570Log"."Bank9" is '債權金融機構代號9';
comment on column "JcicZ570Log"."Bank10" is '債權金融機構代號10';
comment on column "JcicZ570Log"."Bank11" is '債權金融機構代號11';
comment on column "JcicZ570Log"."Bank12" is '債權金融機構代號12';
comment on column "JcicZ570Log"."Bank13" is '債權金融機構代號13';
comment on column "JcicZ570Log"."Bank14" is '債權金融機構代號14';
comment on column "JcicZ570Log"."Bank15" is '債權金融機構代號15';
comment on column "JcicZ570Log"."Bank16" is '債權金融機構代號16';
comment on column "JcicZ570Log"."Bank17" is '債權金融機構代號17';
comment on column "JcicZ570Log"."Bank18" is '債權金融機構代號18';
comment on column "JcicZ570Log"."Bank19" is '債權金融機構代號19';
comment on column "JcicZ570Log"."Bank20" is '債權金融機構代號20';
comment on column "JcicZ570Log"."Bank21" is '債權金融機構代號21';
comment on column "JcicZ570Log"."Bank22" is '債權金融機構代號22';
comment on column "JcicZ570Log"."Bank23" is '債權金融機構代號23';
comment on column "JcicZ570Log"."Bank24" is '債權金融機構代號24';
comment on column "JcicZ570Log"."Bank25" is '債權金融機構代號25';
comment on column "JcicZ570Log"."Bank26" is '債權金融機構代號26';
comment on column "JcicZ570Log"."Bank27" is '債權金融機構代號27';
comment on column "JcicZ570Log"."Bank28" is '債權金融機構代號28';
comment on column "JcicZ570Log"."Bank29" is '債權金融機構代號29';
comment on column "JcicZ570Log"."Bank30" is '債權金融機構代號30';
comment on column "JcicZ570Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ570Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ570Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ570Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ570Log"."LastUpdateEmpNo" is '最後更新人員';
