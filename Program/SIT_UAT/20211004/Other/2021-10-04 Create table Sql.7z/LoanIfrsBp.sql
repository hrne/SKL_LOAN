drop table "LoanIfrsBp" purge;

create table "LoanIfrsBp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LoanRate" decimal(8, 6) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsBp" add constraint "LoanIfrsBp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "LoanIfrsBp" is 'IFRS9欄位清單2';
comment on column "LoanIfrsBp"."DataYM" is '年月份';
comment on column "LoanIfrsBp"."CustNo" is '戶號';
comment on column "LoanIfrsBp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsBp"."FacmNo" is '額度編號';
comment on column "LoanIfrsBp"."BormNo" is '撥款序號';
comment on column "LoanIfrsBp"."LoanRate" is '貸放利率';
comment on column "LoanIfrsBp"."RateCode" is '利率調整方式';
comment on column "LoanIfrsBp"."EffectDate" is '利率欄位生效日';
comment on column "LoanIfrsBp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsBp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsBp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsBp"."LastUpdateEmpNo" is '最後更新人員';
