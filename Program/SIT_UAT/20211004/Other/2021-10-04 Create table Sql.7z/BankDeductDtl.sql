drop table "BankDeductDtl" purge;

create table "BankDeductDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "PayIntDate" decimal(8, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "RepayBank" varchar2(3),
  "RepayAcctNo" varchar2(14),
  "RepayAcctSeq" varchar2(2),
  "UnpaidAmt" decimal(14, 0) default 0 not null,
  "TempAmt" decimal(14, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "PostCode" varchar2(1),
  "MediaCode" varchar2(1),
  "RelationCode" varchar2(2),
  "RelCustName" nvarchar2(100),
  "RelCustId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "AmlRsp" varchar2(1),
  "ReturnCode" varchar2(2),
  "JsonFields" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankDeductDtl" add constraint "BankDeductDtl_PK" primary key("EntryDate", "CustNo", "FacmNo", "BormNo", "RepayType", "PayIntDate");

create index "BankDeductDtl_Index1" on "BankDeductDtl"("CustNo" asc, "EntryDate" asc);

create index "BankDeductDtl_Index2" on "BankDeductDtl"("MediaDate" asc, "MediaKind" asc, "MediaSeq" asc);

comment on table "BankDeductDtl" is '銀行扣款明細檔';
comment on column "BankDeductDtl"."EntryDate" is '入帳日期';
comment on column "BankDeductDtl"."CustNo" is '戶號';
comment on column "BankDeductDtl"."FacmNo" is '額度';
comment on column "BankDeductDtl"."BormNo" is '撥款';
comment on column "BankDeductDtl"."RepayType" is '還款類別';
comment on column "BankDeductDtl"."PayIntDate" is '應繳日';
comment on column "BankDeductDtl"."PrevIntDate" is '繳息迄日';
comment on column "BankDeductDtl"."AcctCode" is '科目';
comment on column "BankDeductDtl"."RepayBank" is '扣款銀行';
comment on column "BankDeductDtl"."RepayAcctNo" is '扣款帳號';
comment on column "BankDeductDtl"."RepayAcctSeq" is '帳號碼';
comment on column "BankDeductDtl"."UnpaidAmt" is '應扣金額';
comment on column "BankDeductDtl"."TempAmt" is '暫收款抵繳金額';
comment on column "BankDeductDtl"."RepayAmt" is '扣款金額';
comment on column "BankDeductDtl"."IntStartDate" is '計息起日';
comment on column "BankDeductDtl"."IntEndDate" is '計息迄日';
comment on column "BankDeductDtl"."PostCode" is '郵局存款別';
comment on column "BankDeductDtl"."MediaCode" is '媒體碼';
comment on column "BankDeductDtl"."RelationCode" is '與借款人關係';
comment on column "BankDeductDtl"."RelCustName" is '第三人帳戶戶名';
comment on column "BankDeductDtl"."RelCustId" is '第三人身分證字號';
comment on column "BankDeductDtl"."RelAcctBirthday" is '第三人出生日期';
comment on column "BankDeductDtl"."RelAcctGender" is '第三人性別';
comment on column "BankDeductDtl"."MediaDate" is '媒體日期';
comment on column "BankDeductDtl"."MediaKind" is '媒體別';
comment on column "BankDeductDtl"."MediaSeq" is '媒體序號';
comment on column "BankDeductDtl"."AcDate" is '會計日期';
comment on column "BankDeductDtl"."TitaTlrNo" is '經辦';
comment on column "BankDeductDtl"."TitaTxtNo" is '交易序號';
comment on column "BankDeductDtl"."AmlRsp" is 'AML回應碼';
comment on column "BankDeductDtl"."ReturnCode" is '回應代碼';
comment on column "BankDeductDtl"."JsonFields" is 'jason格式紀錄欄';
comment on column "BankDeductDtl"."CreateDate" is '建檔日期時間';
comment on column "BankDeductDtl"."CreateEmpNo" is '建檔人員';
comment on column "BankDeductDtl"."LastUpdate" is '最後更新日期時間';
comment on column "BankDeductDtl"."LastUpdateEmpNo" is '最後更新人員';
