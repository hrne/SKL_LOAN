drop table "JcicZ060" purge;

create table "JcicZ060" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "YM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ060" add constraint "JcicZ060_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate");

create index "JcicZ060_Index1" on "JcicZ060"("SubmitKey" asc);

create index "JcicZ060_Index2" on "JcicZ060"("CustId" asc);

create index "JcicZ060_Index3" on "JcicZ060"("RcDate" asc);

create index "JcicZ060_Index4" on "JcicZ060"("ChangePayDate" asc);

comment on table "JcicZ060" is '債務人繳款資料檔案';
comment on column "JcicZ060"."TranKey" is '交易代碼';
comment on column "JcicZ060"."SubmitKey" is '報送單位代號';
comment on column "JcicZ060"."CustId" is '債務人IDN';
comment on column "JcicZ060"."RcDate" is '原前置協商申請日';
comment on column "JcicZ060"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ060"."YM" is '已清分足月期付金年月';
comment on column "JcicZ060"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ060"."Ukey" is '流水號';
comment on column "JcicZ060"."CreateDate" is '建檔日期時間';
comment on column "JcicZ060"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ060"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ060"."LastUpdateEmpNo" is '最後更新人員';
