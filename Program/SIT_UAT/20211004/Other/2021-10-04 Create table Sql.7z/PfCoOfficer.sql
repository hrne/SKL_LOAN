drop table "PfCoOfficer" purge;

create table "PfCoOfficer" (
  "EmpNo" varchar2(6),
  "EffectiveDate" decimal(8, 0) default 0 not null,
  "IneffectiveDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "AreaItem" varchar2(20),
  "DistItem" varchar2(20),
  "DeptItem" varchar2(20),
  "EmpClass" varchar2(1),
  "ClassPass" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfCoOfficer" add constraint "PfCoOfficer_PK" primary key("EmpNo", "EffectiveDate");

comment on table "PfCoOfficer" is '協辦人員等級檔';
comment on column "PfCoOfficer"."EmpNo" is '員工代號';
comment on column "PfCoOfficer"."EffectiveDate" is '生效日期';
comment on column "PfCoOfficer"."IneffectiveDate" is '停效日期';
comment on column "PfCoOfficer"."AreaCode" is '單位代號';
comment on column "PfCoOfficer"."DistCode" is '區部代號';
comment on column "PfCoOfficer"."DeptCode" is '部室代號';
comment on column "PfCoOfficer"."AreaItem" is '單位中文';
comment on column "PfCoOfficer"."DistItem" is '區部中文';
comment on column "PfCoOfficer"."DeptItem" is '部室中文';
comment on column "PfCoOfficer"."EmpClass" is '協辦等級';
comment on column "PfCoOfficer"."ClassPass" is '初階授信通過';
comment on column "PfCoOfficer"."CreateDate" is '建檔日期時間';
comment on column "PfCoOfficer"."CreateEmpNo" is '建檔人員';
comment on column "PfCoOfficer"."LastUpdate" is '最後更新日期時間';
comment on column "PfCoOfficer"."LastUpdateEmpNo" is '最後更新人員';
