drop table "AcReceivable" purge;

create table "AcReceivable" (
  "AcctCode" varchar2(3),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RvNo" varchar2(30),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "ClsFlag" decimal(1, 0) default 0 not null,
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "RvAmt" decimal(16, 2) default 0 not null,
  "RvBal" decimal(16, 2) default 0 not null,
  "AcBal" decimal(16, 2) default 0 not null,
  "SlipNote" nvarchar2(80),
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "OpenAcDate" decimal(8, 0) default 0 not null,
  "LastAcDate" decimal(8, 0) default 0 not null,
  "LastTxDate" decimal(8, 0) default 0 not null,
  "TitaTxCd" varchar2(5),
  "TitaKinBr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "JsonFields" varchar2(300),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AcReceivable" add constraint "AcReceivable_PK" primary key("AcctCode", "CustNo", "FacmNo", "RvNo");

create index "AcReceivable_Index1" on "AcReceivable"("AcctCode" asc, "CustNo" asc, "FacmNo" asc, "RvNo" asc);

create index "AcReceivable_Index2" on "AcReceivable"("ClsFlag" asc, "BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc, "CustNo" asc, "FacmNo" asc, "RvNo" asc);

create index "AcReceivable_Index3" on "AcReceivable"("ClsFlag" asc, "CustNo" asc, "AcctFlag" asc, "FacmNo" asc, "AcDtlCode" asc, "RvNo" asc);

comment on table "AcReceivable" is '會計銷帳檔';
comment on column "AcReceivable"."AcctCode" is '業務科目代號';
comment on column "AcReceivable"."CustNo" is '戶號';
comment on column "AcReceivable"."FacmNo" is '額度編號';
comment on column "AcReceivable"."RvNo" is '銷帳編號';
comment on column "AcReceivable"."AcNoCode" is '科目代號';
comment on column "AcReceivable"."AcSubCode" is '子目代號';
comment on column "AcReceivable"."AcDtlCode" is '細目代號';
comment on column "AcReceivable"."BranchNo" is '單位別';
comment on column "AcReceivable"."CurrencyCode" is '幣別';
comment on column "AcReceivable"."ClsFlag" is '銷帳記號';
comment on column "AcReceivable"."AcctFlag" is '業務科目記號';
comment on column "AcReceivable"."ReceivableFlag" is '銷帳科目記號';
comment on column "AcReceivable"."RvAmt" is '起帳總額';
comment on column "AcReceivable"."RvBal" is '未銷餘額';
comment on column "AcReceivable"."AcBal" is '會計日餘額';
comment on column "AcReceivable"."SlipNote" is '傳票摘要';
comment on column "AcReceivable"."AcBookCode" is '帳冊別';
comment on column "AcReceivable"."AcSubBookCode" is '區隔帳冊';
comment on column "AcReceivable"."OpenAcDate" is '起帳日期';
comment on column "AcReceivable"."LastAcDate" is '最後作帳日';
comment on column "AcReceivable"."LastTxDate" is '最後交易日';
comment on column "AcReceivable"."TitaTxCd" is '交易代號';
comment on column "AcReceivable"."TitaKinBr" is '單位別';
comment on column "AcReceivable"."TitaTlrNo" is '經辦';
comment on column "AcReceivable"."TitaTxtNo" is '交易序號';
comment on column "AcReceivable"."JsonFields" is 'jason格式紀錄欄';
comment on column "AcReceivable"."CreateEmpNo" is '建檔人員';
comment on column "AcReceivable"."CreateDate" is '建檔日期';
comment on column "AcReceivable"."LastUpdateEmpNo" is '最後維護人員';
comment on column "AcReceivable"."LastUpdate" is '最後維護日期';
