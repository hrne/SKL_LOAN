drop table "CreditRating" purge;

create table "CreditRating" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreditRatingCode" varchar2(1),
  "OriModel" varchar2(1),
  "OriRatingDate" decimal(8, 0) default 0 not null,
  "OriRating" varchar2(1),
  "Model" varchar2(1),
  "RatingDate" decimal(8, 0) default 0 not null,
  "Rating" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CreditRating" add constraint "CreditRating_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "CreditRating" is '信用評等檔';
comment on column "CreditRating"."DataYM" is '資料年月';
comment on column "CreditRating"."CustNo" is '戶號';
comment on column "CreditRating"."FacmNo" is '額度編號';
comment on column "CreditRating"."BormNo" is '撥款序號';
comment on column "CreditRating"."CreditRatingCode" is '企業戶/個人戶';
comment on column "CreditRating"."OriModel" is '原始認列時信用評等模型';
comment on column "CreditRating"."OriRatingDate" is '原始認列信用評等日期';
comment on column "CreditRating"."OriRating" is '原始認列時時信用評等';
comment on column "CreditRating"."Model" is '財務報導日時信用評等模型';
comment on column "CreditRating"."RatingDate" is '財務報導日信用評等評定日期';
comment on column "CreditRating"."Rating" is '財務報導日時信用評等';
comment on column "CreditRating"."CreateDate" is '建檔日期時間';
comment on column "CreditRating"."CreateEmpNo" is '建檔人員';
comment on column "CreditRating"."LastUpdate" is '最後更新日期時間';
comment on column "CreditRating"."LastUpdateEmpNo" is '最後更新人員';
