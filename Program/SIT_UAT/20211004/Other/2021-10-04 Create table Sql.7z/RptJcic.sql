drop table "RptJcic" purge;

create table "RptJcic" (
  "BranchNo" varchar2(4),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "JcicName" nvarchar2(100),
  "JcicStatus" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptJcic" add constraint "RptJcic_PK" primary key("BranchNo", "CustNo", "FacmNo");

comment on table "RptJcic" is '呆帳不報送檔';
comment on column "RptJcic"."BranchNo" is '單位別';
comment on column "RptJcic"."CustNo" is '戶號';
comment on column "RptJcic"."FacmNo" is '額度號碼';
comment on column "RptJcic"."JcicName" is 'Jcic名稱';
comment on column "RptJcic"."JcicStatus" is 'Jcic戶況';
comment on column "RptJcic"."CreateDate" is '建檔日期時間';
comment on column "RptJcic"."CreateEmpNo" is '建檔人員';
comment on column "RptJcic"."LastUpdate" is '最後更新日期時間';
comment on column "RptJcic"."LastUpdateEmpNo" is '最後更新人員';
