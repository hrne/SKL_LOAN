drop table "NegAppr" purge;

create table "NegAppr" (
  "YyyyMm" decimal(6, 0) default 0 not null,
  "KindCode" decimal(1, 0) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ApprAcDate" decimal(8, 0) default 0 not null,
  "BringUpDate" decimal(8, 0) default 0 not null,
  "ExportMark" decimal(1, 0) default 0 not null,
  "ApprAcMark" decimal(1, 0) default 0 not null,
  "BringUpMark" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegAppr" add constraint "NegAppr_PK" primary key("YyyyMm", "KindCode");

comment on table "NegAppr" is '撥付日期設定';
comment on column "NegAppr"."YyyyMm" is '年月';
comment on column "NegAppr"."KindCode" is '類別';
comment on column "NegAppr"."ExportDate" is '製檔日';
comment on column "NegAppr"."ApprAcDate" is '傳票日';
comment on column "NegAppr"."BringUpDate" is '提兌日';
comment on column "NegAppr"."ExportMark" is '製檔日記號';
comment on column "NegAppr"."ApprAcMark" is '傳票日記號';
comment on column "NegAppr"."BringUpMark" is '提兌日記號';
comment on column "NegAppr"."CreateDate" is '建檔日期時間';
comment on column "NegAppr"."CreateEmpNo" is '建檔人員';
comment on column "NegAppr"."LastUpdate" is '最後更新日期時間';
comment on column "NegAppr"."LastUpdateEmpNo" is '最後更新人員';
