drop table "MonthlyFacBal" purge;

create table "MonthlyFacBal" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "DueDate" decimal(8, 0) default 0 not null,
  "OvduTerm" decimal(3, 0) default 0 not null,
  "OvduDays" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "AccCollPsn" varchar2(6),
  "LegalPsn" varchar2(6),
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "ProdNo" varchar2(5),
  "AcBookCode" varchar2(3),
  "EntCode" varchar2(1),
  "RelsCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "UnpaidPrincipal" decimal(16, 2) default 0 not null,
  "UnpaidInterest" decimal(16, 2) default 0 not null,
  "UnpaidBreachAmt" decimal(16, 2) default 0 not null,
  "UnpaidDelayInt" decimal(16, 2) default 0 not null,
  "AcdrPrincipal" decimal(16, 2) default 0 not null,
  "AcdrInterest" decimal(16, 2) default 0 not null,
  "AcdrBreachAmt" decimal(16, 2) default 0 not null,
  "AcdrDelayInt" decimal(16, 2) default 0 not null,
  "FireFee" decimal(16, 2) default 0 not null,
  "LawFee" decimal(16, 2) default 0 not null,
  "ModifyFee" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "ShortfallPrin" decimal(16, 2) default 0 not null,
  "ShortfallInt" decimal(16, 2) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "OvduDate" decimal(8, 0) default 0 not null,
  "OvduPrinBal" decimal(16, 2) default 0 not null,
  "OvduIntBal" decimal(16, 2) default 0 not null,
  "OvduBreachBal" decimal(16, 2) default 0 not null,
  "OvduBal" decimal(16, 2) default 0 not null,
  "LawAmount" decimal(16, 2) default 0 not null,
  "AssetClass" varchar2(2),
  "StoreRate" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "AcSubBookCode" varchar2(3)
);

alter table "MonthlyFacBal" add constraint "MonthlyFacBal_PK" primary key("YearMonth", "CustNo", "FacmNo");

comment on table "MonthlyFacBal" is '額度月報工作檔';
comment on column "MonthlyFacBal"."YearMonth" is '資料年月';
comment on column "MonthlyFacBal"."CustNo" is '戶號';
comment on column "MonthlyFacBal"."FacmNo" is '額度';
comment on column "MonthlyFacBal"."PrevIntDate" is '繳息迄日';
comment on column "MonthlyFacBal"."NextIntDate" is '應繳息日';
comment on column "MonthlyFacBal"."DueDate" is '最近應繳日';
comment on column "MonthlyFacBal"."OvduTerm" is '逾期期數';
comment on column "MonthlyFacBal"."OvduDays" is '逾期天數';
comment on column "MonthlyFacBal"."CurrencyCode" is '幣別';
comment on column "MonthlyFacBal"."PrinBalance" is '本金餘額';
comment on column "MonthlyFacBal"."BadDebtBal" is '呆帳餘額';
comment on column "MonthlyFacBal"."AccCollPsn" is '催收人員';
comment on column "MonthlyFacBal"."LegalPsn" is '法務人員';
comment on column "MonthlyFacBal"."Status" is '戶況';
comment on column "MonthlyFacBal"."AcctCode" is '業務科目代號';
comment on column "MonthlyFacBal"."FacAcctCode" is '額度業務科目';
comment on column "MonthlyFacBal"."ClCustNo" is '同擔保品戶號';
comment on column "MonthlyFacBal"."ClFacmNo" is '同擔保品額度';
comment on column "MonthlyFacBal"."ClRowNo" is '同擔保品序列號';
comment on column "MonthlyFacBal"."RenewCode" is '展期記號';
comment on column "MonthlyFacBal"."ProdNo" is '商品代碼';
comment on column "MonthlyFacBal"."AcBookCode" is '帳冊別';
comment on column "MonthlyFacBal"."EntCode" is '企金別';
comment on column "MonthlyFacBal"."RelsCode" is '(準)利害關係人職稱';
comment on column "MonthlyFacBal"."DepartmentCode" is '案件隸屬單位';
comment on column "MonthlyFacBal"."UnpaidPrincipal" is '已到期本金/轉催收本金';
comment on column "MonthlyFacBal"."UnpaidInterest" is '已到期利息/轉催收利息';
comment on column "MonthlyFacBal"."UnpaidBreachAmt" is '已到期違約金/轉催收違約金';
comment on column "MonthlyFacBal"."UnpaidDelayInt" is '已到期延滯息';
comment on column "MonthlyFacBal"."AcdrPrincipal" is '未到期回收本金';
comment on column "MonthlyFacBal"."AcdrInterest" is '未到期利息';
comment on column "MonthlyFacBal"."AcdrBreachAmt" is '未到期違約金';
comment on column "MonthlyFacBal"."AcdrDelayInt" is '未到期延滯息';
comment on column "MonthlyFacBal"."FireFee" is '火險費用';
comment on column "MonthlyFacBal"."LawFee" is '法務費用';
comment on column "MonthlyFacBal"."ModifyFee" is '契變手續費';
comment on column "MonthlyFacBal"."AcctFee" is '帳管費用';
comment on column "MonthlyFacBal"."ShortfallPrin" is '短繳本金';
comment on column "MonthlyFacBal"."ShortfallInt" is '短繳利息';
comment on column "MonthlyFacBal"."TempAmt" is '暫收金額';
comment on column "MonthlyFacBal"."ClCode1" is '主要擔保品代號1';
comment on column "MonthlyFacBal"."ClCode2" is '主要擔保品代號2';
comment on column "MonthlyFacBal"."ClNo" is '主要擔保品編號';
comment on column "MonthlyFacBal"."CityCode" is '主要擔保品地區別';
comment on column "MonthlyFacBal"."OvduDate" is '轉催收日期';
comment on column "MonthlyFacBal"."OvduPrinBal" is '催收本金餘額';
comment on column "MonthlyFacBal"."OvduIntBal" is '催收利息餘額';
comment on column "MonthlyFacBal"."OvduBreachBal" is '催收違約金餘額';
comment on column "MonthlyFacBal"."OvduBal" is '催收餘額';
comment on column "MonthlyFacBal"."LawAmount" is '無擔保債權設定金額(法務進度:901)';
comment on column "MonthlyFacBal"."AssetClass" is '資產五分類代號(有擔保部分)';
comment on column "MonthlyFacBal"."StoreRate" is '計息利率';
comment on column "MonthlyFacBal"."CreateDate" is '建檔日期時間';
comment on column "MonthlyFacBal"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyFacBal"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyFacBal"."LastUpdateEmpNo" is '最後更新人員';
comment on column "MonthlyFacBal"."AcSubBookCode" is '區隔帳冊';
