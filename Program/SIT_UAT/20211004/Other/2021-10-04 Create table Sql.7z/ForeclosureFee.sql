drop table "ForeclosureFee" purge;

create table "ForeclosureFee" (
  "RecordNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "DocDate" decimal(8, 0) default 0 not null,
  "OpenAcDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "FeeCode" varchar2(2),
  "LegalStaff" varchar2(6),
  "CloseNo" decimal(7, 0) default 0 not null,
  "Rmk" nvarchar2(60),
  "CaseCode" decimal(1, 0) default 0 not null,
  "RemitBranch" varchar2(3),
  "Remitter" varchar2(10),
  "CaseNo" varchar2(3),
  "OverdueDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ForeclosureFee" add constraint "ForeclosureFee_PK" primary key("RecordNo");

create index "ForeclosureFee_Index1" on "ForeclosureFee"("CustNo" asc, "ReceiveDate" asc);

comment on table "ForeclosureFee" is '法拍費用檔';
comment on column "ForeclosureFee"."RecordNo" is '記錄號碼';
comment on column "ForeclosureFee"."CustNo" is '借款人戶號';
comment on column "ForeclosureFee"."FacmNo" is '額度編號';
comment on column "ForeclosureFee"."ReceiveDate" is '收件日期';
comment on column "ForeclosureFee"."DocDate" is '單據日期';
comment on column "ForeclosureFee"."OpenAcDate" is '起帳日期';
comment on column "ForeclosureFee"."CloseDate" is '銷號日期';
comment on column "ForeclosureFee"."Fee" is '法拍費用';
comment on column "ForeclosureFee"."FeeCode" is '科目';
comment on column "ForeclosureFee"."LegalStaff" is '法務人員';
comment on column "ForeclosureFee"."CloseNo" is '銷帳編號';
comment on column "ForeclosureFee"."Rmk" is '備註';
comment on column "ForeclosureFee"."CaseCode" is '件別';
comment on column "ForeclosureFee"."RemitBranch" is '匯款單位';
comment on column "ForeclosureFee"."Remitter" is '匯款人';
comment on column "ForeclosureFee"."CaseNo" is '案號';
comment on column "ForeclosureFee"."OverdueDate" is '轉催收日';
comment on column "ForeclosureFee"."CreateDate" is '建檔日期時間';
comment on column "ForeclosureFee"."CreateEmpNo" is '建檔人員';
comment on column "ForeclosureFee"."LastUpdate" is '最後更新日期時間';
comment on column "ForeclosureFee"."LastUpdateEmpNo" is '最後更新人員';
