drop table "JcicZ053Log" purge;

create table "JcicZ053Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeSend" varchar2(1),
  "AgreeSendData1" nvarchar2(2),
  "AgreeSendData2" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ053Log" add constraint "JcicZ053Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ053Log" is '同意報送例外處理檔案';
comment on column "JcicZ053Log"."Ukey" is '流水號';
comment on column "JcicZ053Log"."TxSeq" is '交易序號';
comment on column "JcicZ053Log"."TranKey" is '交易代碼';
comment on column "JcicZ053Log"."AgreeSend" is '是否同意報送例外處理檔案格式';
comment on column "JcicZ053Log"."AgreeSendData1" is '同意補報送檔案格式資料別1';
comment on column "JcicZ053Log"."AgreeSendData2" is '同意補報送檔案格式資料別2';
comment on column "JcicZ053Log"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ053Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ053Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ053Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ053Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ053Log"."LastUpdateEmpNo" is '最後更新人員';
