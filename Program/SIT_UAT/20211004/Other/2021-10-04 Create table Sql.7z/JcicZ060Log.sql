drop table "JcicZ060Log" purge;

create table "JcicZ060Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "YM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ060Log" add constraint "JcicZ060Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ060Log" is '債務人繳款資料檔案';
comment on column "JcicZ060Log"."Ukey" is '流水號';
comment on column "JcicZ060Log"."TxSeq" is '交易序號';
comment on column "JcicZ060Log"."TranKey" is '交易代碼';
comment on column "JcicZ060Log"."YM" is '已清分足月期付金年月';
comment on column "JcicZ060Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ060Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ060Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ060Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ060Log"."LastUpdateEmpNo" is '最後更新人員';
