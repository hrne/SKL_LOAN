drop table "CdBonus" purge;

create table "CdBonus" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(1, 0) default 0 not null,
  "Condition" varchar2(5),
  "AmtStartRange" decimal(16, 2) default 0 not null,
  "AmtEndRange" decimal(16, 2) default 0 not null,
  "Bonus" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBonus" add constraint "CdBonus_PK" primary key("WorkMonth", "ConditionCode", "Condition");

create index "CdBonus_Index1" on "CdBonus"("WorkMonth" asc, "ConditionCode" asc);

comment on table "CdBonus" is '介紹人加碼獎勵津貼標準設定';
comment on column "CdBonus"."WorkMonth" is '工作年月';
comment on column "CdBonus"."ConditionCode" is '條件記號';
comment on column "CdBonus"."Condition" is '標準條件';
comment on column "CdBonus"."AmtStartRange" is '新貸案件撥貸金額級距-起';
comment on column "CdBonus"."AmtEndRange" is '新貸案件撥貸金額級距-止';
comment on column "CdBonus"."Bonus" is '獎勵津貼';
comment on column "CdBonus"."CreateDate" is '建檔日期時間';
comment on column "CdBonus"."CreateEmpNo" is '建檔人員';
comment on column "CdBonus"."LastUpdate" is '最後更新日期時間';
comment on column "CdBonus"."LastUpdateEmpNo" is '最後更新人員';
