for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L1/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L1/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L2/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L2/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L3/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L3/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L4/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L4/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L5/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L5/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L6/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L6/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L7/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L7/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L8/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L8/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L9/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/L9/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LC/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LC/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LD/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LD/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LH/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LH/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LM/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LM/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LP/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LP/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LQ/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LQ/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LW/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LW/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done

for file in /home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LY/*
do
if test -f $file
then
var1=${file##/home/weblogic/ifxDoc/ifxfolder/Dev/var/tran/LY/}
var1=${var1%.var}
var1=${var1%.VAR}
node gen/make.js $var1
fi
done