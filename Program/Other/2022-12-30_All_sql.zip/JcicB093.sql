drop table "JcicB093" purge;

create table "JcicB093" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(5, 0) default 0 not null,
  "LoanLimitAmt" decimal(8, 0) default 0 not null,
  "SettingDate" decimal(5, 0) default 0 not null,
  "MonthSettingAmt" decimal(8, 0) default 0 not null,
  "SettingSeq" decimal(1, 0) default 0 not null,
  "SettingAmt" decimal(8, 0) default 0 not null,
  "PreSettingAmt" decimal(8, 0) default 0 not null,
  "DispPrice" decimal(8, 0) default 0 not null,
  "IssueEndDate" decimal(5, 0) default 0 not null,
  "InsuFg" varchar2(1),
  "Filler19" varchar2(17),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB093" add constraint "JcicB093_PK" primary key("DataYM", "ClActNo");

comment on table "JcicB093" is '聯徵動產及貴重物品擔保品明細檔';
comment on column "JcicB093"."DataYM" is '資料日期';
comment on column "JcicB093"."DataType" is '資料別';
comment on column "JcicB093"."BankItem" is '總行代號';
comment on column "JcicB093"."BranchItem" is '分行代號';
comment on column "JcicB093"."Filler4" is '空白';
comment on column "JcicB093"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB093"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB093"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB093"."EvaAmt" is '鑑估值';
comment on column "JcicB093"."EvaDate" is '鑑估日期';
comment on column "JcicB093"."LoanLimitAmt" is '可放款值';
comment on column "JcicB093"."SettingDate" is '設定日期';
comment on column "JcicB093"."MonthSettingAmt" is '本行本月設定金額';
comment on column "JcicB093"."SettingSeq" is '本月設定抵押順位';
comment on column "JcicB093"."SettingAmt" is '本行累計已設定總金額';
comment on column "JcicB093"."PreSettingAmt" is '其他債權人前已設定金額';
comment on column "JcicB093"."DispPrice" is '處分價格';
comment on column "JcicB093"."IssueEndDate" is '權利到期年月';
comment on column "JcicB093"."InsuFg" is '是否有保險';
comment on column "JcicB093"."Filler19" is '空白';
comment on column "JcicB093"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB093"."CreateDate" is '建檔日期時間';
comment on column "JcicB093"."CreateEmpNo" is '建檔人員';
comment on column "JcicB093"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB093"."LastUpdateEmpNo" is '最後更新人員';
