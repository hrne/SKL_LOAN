drop table "BankRmtf" purge;

create table "BankRmtf" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayType" varchar2(2),
  "RepayAmt" decimal(14, 0) default 0 not null,
  "DepAcctNo" varchar2(14),
  "EntryDate" decimal(8, 0) default 0 not null,
  "DscptCode" varchar2(4),
  "VirtualAcctNo" nvarchar2(14),
  "WithdrawAmt" decimal(14, 0) default 0 not null,
  "DepositAmt" decimal(14, 0) default 0 not null,
  "Balance" decimal(14, 0) default 0 not null,
  "RemintBank" varchar2(7),
  "TraderInfo" nvarchar2(20),
  "AmlRsp" varchar2(1),
  "ReconCode" varchar2(3),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRmtf" add constraint "BankRmtf_PK" primary key("AcDate", "BatchNo", "DetailSeq");

comment on table "BankRmtf" is '匯款轉帳檔';
comment on column "BankRmtf"."AcDate" is '會計日';
comment on column "BankRmtf"."BatchNo" is '批號';
comment on column "BankRmtf"."DetailSeq" is '明細序號';
comment on column "BankRmtf"."CustNo" is '戶號';
comment on column "BankRmtf"."RepayType" is '還款類別';
comment on column "BankRmtf"."RepayAmt" is '還款金額';
comment on column "BankRmtf"."DepAcctNo" is '存摺帳號';
comment on column "BankRmtf"."EntryDate" is '入帳日期';
comment on column "BankRmtf"."DscptCode" is '摘要代碼';
comment on column "BankRmtf"."VirtualAcctNo" is '虛擬帳號';
comment on column "BankRmtf"."WithdrawAmt" is '提款';
comment on column "BankRmtf"."DepositAmt" is '存款';
comment on column "BankRmtf"."Balance" is '結餘';
comment on column "BankRmtf"."RemintBank" is '匯款銀行代碼';
comment on column "BankRmtf"."TraderInfo" is '交易人資料';
comment on column "BankRmtf"."AmlRsp" is 'AML回應碼';
comment on column "BankRmtf"."ReconCode" is '對帳類別';
comment on column "BankRmtf"."TitaTlrNo" is '經辦';
comment on column "BankRmtf"."TitaTxtNo" is '交易序號';
comment on column "BankRmtf"."CreateDate" is '建檔日期時間';
comment on column "BankRmtf"."CreateEmpNo" is '建檔人員';
comment on column "BankRmtf"."LastUpdate" is '最後更新日期時間';
comment on column "BankRmtf"."LastUpdateEmpNo" is '最後更新人員';
