drop table "JcicZ056" purge;

create table "JcicZ056" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "CaseStatus" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "Approve" varchar2(1),
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "AdminName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ056" add constraint "JcicZ056_PK" primary key("SubmitKey", "CustId", "CaseStatus", "ClaimDate", "CourtCode");

create index "JcicZ056_Index1" on "JcicZ056"("SubmitKey" asc);

create index "JcicZ056_Index2" on "JcicZ056"("CustId" asc);

create index "JcicZ056_Index3" on "JcicZ056"("CaseStatus" asc);

create index "JcicZ056_Index4" on "JcicZ056"("ClaimDate" asc);

create index "JcicZ056_Index5" on "JcicZ056"("CourtCode" asc);

comment on table "JcicZ056" is '清算案件資料報送';
comment on column "JcicZ056"."TranKey" is '交易代碼';
comment on column "JcicZ056"."CustId" is '債務人IDN';
comment on column "JcicZ056"."SubmitKey" is '報送單位代號';
comment on column "JcicZ056"."CaseStatus" is '案件狀態';
comment on column "JcicZ056"."ClaimDate" is '裁定日期或發文日期';
comment on column "JcicZ056"."CourtCode" is '承審法院代碼';
comment on column "JcicZ056"."Year" is '年度別';
comment on column "JcicZ056"."CourtDiv" is '法院承審股別';
comment on column "JcicZ056"."CourtCaseNo" is '法院案號';
comment on column "JcicZ056"."Approve" is '法院裁定免責確定';
comment on column "JcicZ056"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ056"."SubAmt" is '清算損失金額';
comment on column "JcicZ056"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ056"."SaveDate" is '保全處分起始日';
comment on column "JcicZ056"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ056"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ056"."AdminName" is '管理人姓名';
comment on column "JcicZ056"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ056"."Ukey" is '流水號';
comment on column "JcicZ056"."CreateDate" is '建檔日期時間';
comment on column "JcicZ056"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ056"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ056"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ056"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ056"."ActualFilingMark" is '實際報送記號';
