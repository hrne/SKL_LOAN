drop table "JcicZ054" purge;

create table "JcicZ054" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ054" add constraint "JcicZ054_PK" primary key("CustId", "SubmitKey", "RcDate", "MaxMainCode", "PayOffDate");

create index "JcicZ054_Index1" on "JcicZ054"("CustId" asc);

create index "JcicZ054_Index2" on "JcicZ054"("SubmitKey" asc);

create index "JcicZ054_Index3" on "JcicZ054"("RcDate" asc);

create index "JcicZ054_Index4" on "JcicZ054"("MaxMainCode" asc);

create index "JcicZ054_Index5" on "JcicZ054"("PayOffDate" asc);

comment on table "JcicZ054" is '單獨全數受清償資料檔案';
comment on column "JcicZ054"."TranKey" is '交易代碼';
comment on column "JcicZ054"."CustId" is '債務人IDN';
comment on column "JcicZ054"."SubmitKey" is '報送單位代號';
comment on column "JcicZ054"."RcDate" is '協商申請日';
comment on column "JcicZ054"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ054"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ054"."PayOffDate" is '單獨全數受清償日期';
comment on column "JcicZ054"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ054"."Ukey" is '流水號';
comment on column "JcicZ054"."CreateDate" is '建檔日期時間';
comment on column "JcicZ054"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ054"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ054"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ054"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ054"."ActualFilingMark" is '實際報送記號';
