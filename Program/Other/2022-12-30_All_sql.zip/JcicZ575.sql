drop table "JcicZ575" purge;

create table "JcicZ575" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "BankId" nvarchar2(3),
  "ModifyType" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ575" add constraint "JcicZ575_PK" primary key("SubmitKey", "CustId", "ApplyDate", "BankId");

create index "JcicZ575_Index1" on "JcicZ575"("SubmitKey" asc);

create index "JcicZ575_Index2" on "JcicZ575"("CustId" asc);

create index "JcicZ575_Index3" on "JcicZ575"("ApplyDate" asc);

create index "JcicZ575_Index4" on "JcicZ575"("BankId" asc);

comment on table "JcicZ575" is '更生債權金額異動通知資料';
comment on column "JcicZ575"."TranKey" is '交易代碼';
comment on column "JcicZ575"."CustId" is '債務人IDN';
comment on column "JcicZ575"."SubmitKey" is '報送單位代號';
comment on column "JcicZ575"."ApplyDate" is '申請日期';
comment on column "JcicZ575"."BankId" is '異動債權金機構代號';
comment on column "JcicZ575"."ModifyType" is '債權異動類別';
comment on column "JcicZ575"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ575"."Ukey" is '流水號';
comment on column "JcicZ575"."CreateDate" is '建檔日期時間';
comment on column "JcicZ575"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ575"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ575"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ575"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ575"."ActualFilingMark" is '實際報送記號';
