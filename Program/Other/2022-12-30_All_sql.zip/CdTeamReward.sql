drop table "CdTeamReward" purge;

create table "CdTeamReward" (
  "WorkMonthStart" decimal(6, 0) default 0 not null,
  "WorkMonthEnd" decimal(6, 0) default 0 not null,
  "TeamLevel" decimal(1, 0) default 0 not null,
  "RewardType" decimal(1, 0) default 0 not null,
  "RewardStandard" decimal(16, 2) default 0 not null,
  "RewardAmt" decimal(16, 2) default 0 not null,
  "MinimumStandard" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdTeamReward" add constraint "CdTeamReward_PK" primary key("WorkMonthStart", "WorkMonthEnd", "TeamLevel", "RewardType", "RewardStandard");

create index "CdTeamReward_Index1" on "CdTeamReward"("WorkMonthStart ASC" asc, "WorkMonthEnd ASC" asc, "TeamLevel ASC" asc, "RewardType ASC" asc, "RewardStandard ASC" asc);

comment on table "CdTeamReward" is '團康獎勵津貼標準設定';
comment on column "CdTeamReward"."WorkMonthStart" is '工作月起月';
comment on column "CdTeamReward"."WorkMonthEnd" is '工作月迄月';
comment on column "CdTeamReward"."TeamLevel" is '團隊級別';
comment on column "CdTeamReward"."RewardType" is '獎勵種類';
comment on column "CdTeamReward"."RewardStandard" is '獎勵標準';
comment on column "CdTeamReward"."RewardAmt" is '獎勵金額';
comment on column "CdTeamReward"."MinimumStandard" is '最低標準';
comment on column "CdTeamReward"."CreateDate" is '建檔日期時間';
comment on column "CdTeamReward"."CreateEmpNo" is '建檔人員';
comment on column "CdTeamReward"."LastUpdate" is '最後更新日期時間';
comment on column "CdTeamReward"."LastUpdateEmpNo" is '最後更新人員';
