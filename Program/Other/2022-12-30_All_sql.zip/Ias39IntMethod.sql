drop table "Ias39IntMethod" purge;

create table "Ias39IntMethod" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "Principal" decimal(16, 4) default 0 not null,
  "BookValue" decimal(16, 4) default 0 not null,
  "AccumDPAmortized" decimal(16, 4) default 0 not null,
  "AccumDPunAmortized" decimal(16, 4) default 0 not null,
  "DPAmortized" decimal(16, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39IntMethod" add constraint "Ias39IntMethod_PK" primary key("YearMonth", "CustNo", "FacmNo", "BormNo");

comment on table "Ias39IntMethod" is '利息法帳面資料檔';
comment on column "Ias39IntMethod"."YearMonth" is '年月份';
comment on column "Ias39IntMethod"."CustNo" is '戶號';
comment on column "Ias39IntMethod"."FacmNo" is '額度編號';
comment on column "Ias39IntMethod"."BormNo" is '撥款序號';
comment on column "Ias39IntMethod"."Principal" is '本期本金餘額';
comment on column "Ias39IntMethod"."BookValue" is '本期帳面價值';
comment on column "Ias39IntMethod"."AccumDPAmortized" is '本期累應攤銷折溢價';
comment on column "Ias39IntMethod"."AccumDPunAmortized" is '本期累未攤銷折溢價';
comment on column "Ias39IntMethod"."DPAmortized" is '本期折溢價攤銷數';
comment on column "Ias39IntMethod"."CreateDate" is '建檔日期時間';
comment on column "Ias39IntMethod"."CreateEmpNo" is '建檔人員';
comment on column "Ias39IntMethod"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39IntMethod"."LastUpdateEmpNo" is '最後更新人員';
