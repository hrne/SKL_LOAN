drop table "InsuOrignal" purge;

create table "InsuOrignal" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OrigInsuNo" varchar2(17),
  "EndoInsuNo" varchar2(17),
  "InsuCompany" varchar2(2),
  "InsuTypeCode" varchar2(2),
  "FireInsuCovrg" decimal(16, 2) default 0 not null,
  "EthqInsuCovrg" decimal(16, 2) default 0 not null,
  "FireInsuPrem" decimal(16, 2) default 0 not null,
  "EthqInsuPrem" decimal(16, 2) default 0 not null,
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "CommericalFlag" varchar2(2),
  "Remark" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InsuOrignal" add constraint "InsuOrignal_PK" primary key("ClCode1", "ClCode2", "ClNo", "OrigInsuNo", "EndoInsuNo");

comment on table "InsuOrignal" is '火險初保檔';
comment on column "InsuOrignal"."ClCode1" is '擔保品-代號1';
comment on column "InsuOrignal"."ClCode2" is '擔保品-代號2';
comment on column "InsuOrignal"."ClNo" is '擔保品編號';
comment on column "InsuOrignal"."OrigInsuNo" is '原始保險單號碼';
comment on column "InsuOrignal"."EndoInsuNo" is '批單號碼';
comment on column "InsuOrignal"."InsuCompany" is '保險公司';
comment on column "InsuOrignal"."InsuTypeCode" is '保險類別';
comment on column "InsuOrignal"."FireInsuCovrg" is '火災險保險金額';
comment on column "InsuOrignal"."EthqInsuCovrg" is '地震險保險金額';
comment on column "InsuOrignal"."FireInsuPrem" is '火災險保費';
comment on column "InsuOrignal"."EthqInsuPrem" is '地震險保費';
comment on column "InsuOrignal"."InsuStartDate" is '保險起日';
comment on column "InsuOrignal"."InsuEndDate" is '保險迄日';
comment on column "InsuOrignal"."CommericalFlag" is '住宅險改商業險註記';
comment on column "InsuOrignal"."Remark" is '備註';
comment on column "InsuOrignal"."CreateDate" is '建檔日期時間';
comment on column "InsuOrignal"."CreateEmpNo" is '建檔人員';
comment on column "InsuOrignal"."LastUpdate" is '最後更新日期時間';
comment on column "InsuOrignal"."LastUpdateEmpNo" is '最後更新人員';
