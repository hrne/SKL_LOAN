drop table "JcicZ045" purge;

create table "JcicZ045" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "AgreeCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ045" add constraint "JcicZ045_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode");

create index "JcicZ045_Index1" on "JcicZ045"("SubmitKey" asc);

create index "JcicZ045_Index2" on "JcicZ045"("CustId" asc);

create index "JcicZ045_Index3" on "JcicZ045"("RcDate" asc);

create index "JcicZ045_Index4" on "JcicZ045"("MaxMainCode" asc);

comment on table "JcicZ045" is '回報是否同意債務清償方案資料';
comment on column "JcicZ045"."TranKey" is '交易代碼';
comment on column "JcicZ045"."SubmitKey" is '報送單位代號';
comment on column "JcicZ045"."CustId" is '債務人IDN';
comment on column "JcicZ045"."RcDate" is '協商申請日';
comment on column "JcicZ045"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ045"."AgreeCode" is '是否同意債務清償方案';
comment on column "JcicZ045"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ045"."Ukey" is '流水號';
comment on column "JcicZ045"."CreateDate" is '建檔日期時間';
comment on column "JcicZ045"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ045"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ045"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ045"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ045"."ActualFilingMark" is '實際報送記號';
