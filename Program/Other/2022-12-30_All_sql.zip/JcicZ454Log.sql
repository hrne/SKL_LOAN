drop table "JcicZ454Log" purge;

create table "JcicZ454Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ454Log" add constraint "JcicZ454Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ454Log" is '前置調解單獨全數受清償資料';
comment on column "JcicZ454Log"."Ukey" is '流水號';
comment on column "JcicZ454Log"."TxSeq" is '交易序號';
comment on column "JcicZ454Log"."TranKey" is '交易代碼';
comment on column "JcicZ454Log"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ454Log"."PayOffDate" is '單獨全數受清償日期';
comment on column "JcicZ454Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ454Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ454Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ454Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ454Log"."LastUpdateEmpNo" is '最後更新人員';
