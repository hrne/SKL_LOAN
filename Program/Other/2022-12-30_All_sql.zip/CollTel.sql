drop table "CollTel" purge;

create table "CollTel" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "TelDate" decimal(8, 0) default 0 not null,
  "TelTime" varchar2(4),
  "ContactCode" varchar2(1),
  "RecvrCode" varchar2(1),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "ResultCode" varchar2(1),
  "Remark" nvarchar2(500),
  "CallDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollTel" add constraint "CollTel_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollTel" is '法催紀錄電催檔';
comment on column "CollTel"."CaseCode" is '案件種類';
comment on column "CollTel"."CustNo" is '借款人戶號';
comment on column "CollTel"."FacmNo" is '額度編號';
comment on column "CollTel"."AcDate" is '作業日期';
comment on column "CollTel"."TitaTlrNo" is '經辦';
comment on column "CollTel"."TitaTxtNo" is '交易序號';
comment on column "CollTel"."TelDate" is '電催日期';
comment on column "CollTel"."TelTime" is '電催時間';
comment on column "CollTel"."ContactCode" is '聯絡對象';
comment on column "CollTel"."RecvrCode" is '接話人';
comment on column "CollTel"."TelArea" is '連絡電話';
comment on column "CollTel"."TelNo" is '連絡電話';
comment on column "CollTel"."TelExt" is '連絡電話';
comment on column "CollTel"."ResultCode" is '通話結果';
comment on column "CollTel"."Remark" is '其他記錄';
comment on column "CollTel"."CallDate" is '通話日期';
comment on column "CollTel"."CreateDate" is '建檔日期時間';
comment on column "CollTel"."CreateEmpNo" is '建檔人員';
comment on column "CollTel"."LastUpdate" is '最後更新日期時間';
comment on column "CollTel"."LastUpdateEmpNo" is '最後更新人員';
