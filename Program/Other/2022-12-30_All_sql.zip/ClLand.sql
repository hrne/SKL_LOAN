drop table "ClLand" purge;

create table "ClLand" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "LandSeq" decimal(3, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "LandNo1" varchar2(4),
  "LandNo2" varchar2(4),
  "LandLocation" nvarchar2(150),
  "LandCode" varchar2(2),
  "Area" decimal(9, 2) default 0 not null,
  "LandZoningCode" varchar2(2),
  "LandUsageType" varchar2(2),
  "LandUsageCode" varchar2(2),
  "PostedLandValue" decimal(16, 2) default 0 not null,
  "PostedLandValueYearMonth" decimal(6, 0) default 0 not null,
  "TransferedYear" decimal(4, 0) default 0 not null,
  "LastTransferedAmt" decimal(16, 2) default 0 not null,
  "LVITax" decimal(16, 2) default 0 not null,
  "LVITaxYearMonth" decimal(6, 0) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "LandRentStartDate" decimal(8, 0) default 0 not null,
  "LandRentEndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClLand" add constraint "ClLand_PK" primary key("ClCode1", "ClCode2", "ClNo", "LandSeq");

alter table "ClLand" add constraint "ClLand_ClImm_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClImm" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClLand_Index1" on "ClLand"("ClCode1" asc);

create index "ClLand_Index2" on "ClLand"("ClCode1" asc, "ClCode2" asc);

comment on table "ClLand" is '擔保品不動產土地檔';
comment on column "ClLand"."ClCode1" is '擔保品代號1';
comment on column "ClLand"."ClCode2" is '擔保品代號2';
comment on column "ClLand"."ClNo" is '擔保品編號';
comment on column "ClLand"."LandSeq" is '土地序號';
comment on column "ClLand"."CityCode" is '縣市';
comment on column "ClLand"."AreaCode" is '鄉鎮市區';
comment on column "ClLand"."IrCode" is '段小段代碼';
comment on column "ClLand"."LandNo1" is '地號';
comment on column "ClLand"."LandNo2" is '地號(子號)';
comment on column "ClLand"."LandLocation" is '土地座落';
comment on column "ClLand"."LandCode" is '地目';
comment on column "ClLand"."Area" is '面積';
comment on column "ClLand"."LandZoningCode" is '土地使用區分';
comment on column "ClLand"."LandUsageType" is '使用地類別';
comment on column "ClLand"."LandUsageCode" is '土地使用別';
comment on column "ClLand"."PostedLandValue" is '公告土地現值';
comment on column "ClLand"."PostedLandValueYearMonth" is '公告土地現值年月';
comment on column "ClLand"."TransferedYear" is '移轉年度';
comment on column "ClLand"."LastTransferedAmt" is '前次移轉金額';
comment on column "ClLand"."LVITax" is '土地增值稅';
comment on column "ClLand"."LVITaxYearMonth" is '土地增值稅年月';
comment on column "ClLand"."EvaUnitPrice" is '鑑價單價/坪';
comment on column "ClLand"."LandRentStartDate" is '土地租約起日';
comment on column "ClLand"."LandRentEndDate" is '土地租約到期日';
comment on column "ClLand"."CreateDate" is '建檔日期時間';
comment on column "ClLand"."CreateEmpNo" is '建檔人員';
comment on column "ClLand"."LastUpdate" is '最後更新日期時間';
comment on column "ClLand"."LastUpdateEmpNo" is '最後更新人員';
