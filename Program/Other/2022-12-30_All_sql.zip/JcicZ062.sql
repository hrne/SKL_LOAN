drop table "JcicZ062" purge;

create table "JcicZ062" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "CompletePeriod" decimal(3, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "ChaRepayAmt" decimal(10, 0) default 0 not null,
  "ChaRepayAgreeDate" decimal(8, 0) default 0 not null,
  "ChaRepayViewDate" decimal(8, 0) default 0 not null,
  "ChaRepayEndDate" decimal(8, 0) default 0 not null,
  "ChaRepayFirstDate" decimal(8, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(76),
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "GradeType" varchar2(1),
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ062" add constraint "JcicZ062_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate");

create index "JcicZ062_Index1" on "JcicZ062"("SubmitKey" asc);

create index "JcicZ062_Index2" on "JcicZ062"("CustId" asc);

create index "JcicZ062_Index3" on "JcicZ062"("RcDate" asc);

create index "JcicZ062_Index4" on "JcicZ062"("ChangePayDate" asc);

comment on table "JcicZ062" is '金融機構無擔保債務變更還款條件協議資料';
comment on column "JcicZ062"."TranKey" is '交易代碼';
comment on column "JcicZ062"."CustId" is '債務人IDN';
comment on column "JcicZ062"."SubmitKey" is '報送單位代號';
comment on column "JcicZ062"."RcDate" is '協商申請日';
comment on column "JcicZ062"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ062"."CompletePeriod" is '變更還款條件已履約期數';
comment on column "JcicZ062"."Period" is '(第一階梯)期數';
comment on column "JcicZ062"."Rate" is '(第一階梯)利率';
comment on column "JcicZ062"."ExpBalanceAmt" is '信用貸款協商剩餘債務簽約餘額';
comment on column "JcicZ062"."CashBalanceAmt" is '現金卡協商剩餘債務簽約餘額';
comment on column "JcicZ062"."CreditBalanceAmt" is '信用卡協商剩餘債務簽約餘額';
comment on column "JcicZ062"."ChaRepayAmt" is '變更還款條件簽約總債務金額';
comment on column "JcicZ062"."ChaRepayAgreeDate" is '變更還款條件協議完成日';
comment on column "JcicZ062"."ChaRepayViewDate" is '變更還款條件面談日期';
comment on column "JcicZ062"."ChaRepayEndDate" is '變更還款條件簽約完成日期';
comment on column "JcicZ062"."ChaRepayFirstDate" is '變更還款條件首期應繳款日';
comment on column "JcicZ062"."PayAccount" is '繳款帳號';
comment on column "JcicZ062"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ062"."MonthPayAmt" is '月付金';
comment on column "JcicZ062"."GradeType" is '屬階梯式還款註記';
comment on column "JcicZ062"."Period2" is '第二階梯期數';
comment on column "JcicZ062"."Rate2" is '第二階梯利率';
comment on column "JcicZ062"."MonthPayAmt2" is '第二階段月付金';
comment on column "JcicZ062"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ062"."Ukey" is '流水號';
comment on column "JcicZ062"."CreateDate" is '建檔日期時間';
comment on column "JcicZ062"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ062"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ062"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ062"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ062"."ActualFilingMark" is '實際報送記號';
