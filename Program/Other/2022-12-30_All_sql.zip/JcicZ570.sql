drop table "JcicZ570" purge;

create table "JcicZ570" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "AdjudicateDate" decimal(8, 0) default 0 not null,
  "BankCount" decimal(2, 0) default 0 not null,
  "Bank1" nvarchar2(3),
  "Bank2" nvarchar2(3),
  "Bank3" nvarchar2(3),
  "Bank4" nvarchar2(3),
  "Bank5" nvarchar2(3),
  "Bank6" nvarchar2(3),
  "Bank7" nvarchar2(3),
  "Bank8" nvarchar2(3),
  "Bank9" nvarchar2(3),
  "Bank10" nvarchar2(3),
  "Bank11" nvarchar2(3),
  "Bank12" nvarchar2(3),
  "Bank13" nvarchar2(3),
  "Bank14" nvarchar2(3),
  "Bank15" nvarchar2(3),
  "Bank16" nvarchar2(3),
  "Bank17" nvarchar2(3),
  "Bank18" nvarchar2(3),
  "Bank19" nvarchar2(3),
  "Bank20" nvarchar2(3),
  "Bank21" nvarchar2(3),
  "Bank22" nvarchar2(3),
  "Bank23" nvarchar2(3),
  "Bank24" nvarchar2(3),
  "Bank25" nvarchar2(3),
  "Bank26" nvarchar2(3),
  "Bank27" nvarchar2(3),
  "Bank28" nvarchar2(3),
  "Bank29" nvarchar2(3),
  "Bank30" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ570" add constraint "JcicZ570_PK" primary key("SubmitKey", "CustId", "ApplyDate");

create index "JcicZ570_Index1" on "JcicZ570"("SubmitKey" asc);

create index "JcicZ570_Index2" on "JcicZ570"("CustId" asc);

create index "JcicZ570_Index3" on "JcicZ570"("ApplyDate" asc);

comment on table "JcicZ570" is '受理更生款項統一收付通知資料';
comment on column "JcicZ570"."TranKey" is '交易代碼';
comment on column "JcicZ570"."CustId" is '債務人IDN';
comment on column "JcicZ570"."SubmitKey" is '報送單位代號';
comment on column "JcicZ570"."ApplyDate" is '申請日期';
comment on column "JcicZ570"."AdjudicateDate" is '更生方案認可裁定日';
comment on column "JcicZ570"."BankCount" is '更生債權金融機構家數';
comment on column "JcicZ570"."Bank1" is '債權金融機構代號1';
comment on column "JcicZ570"."Bank2" is '債權金融機構代號2';
comment on column "JcicZ570"."Bank3" is '債權金融機構代號3';
comment on column "JcicZ570"."Bank4" is '債權金融機構代號4';
comment on column "JcicZ570"."Bank5" is '債權金融機構代號5';
comment on column "JcicZ570"."Bank6" is '債權金融機構代號6';
comment on column "JcicZ570"."Bank7" is '債權金融機構代號7';
comment on column "JcicZ570"."Bank8" is '債權金融機構代號8';
comment on column "JcicZ570"."Bank9" is '債權金融機構代號9';
comment on column "JcicZ570"."Bank10" is '債權金融機構代號10';
comment on column "JcicZ570"."Bank11" is '債權金融機構代號11';
comment on column "JcicZ570"."Bank12" is '債權金融機構代號12';
comment on column "JcicZ570"."Bank13" is '債權金融機構代號13';
comment on column "JcicZ570"."Bank14" is '債權金融機構代號14';
comment on column "JcicZ570"."Bank15" is '債權金融機構代號15';
comment on column "JcicZ570"."Bank16" is '債權金融機構代號16';
comment on column "JcicZ570"."Bank17" is '債權金融機構代號17';
comment on column "JcicZ570"."Bank18" is '債權金融機構代號18';
comment on column "JcicZ570"."Bank19" is '債權金融機構代號19';
comment on column "JcicZ570"."Bank20" is '債權金融機構代號20';
comment on column "JcicZ570"."Bank21" is '債權金融機構代號21';
comment on column "JcicZ570"."Bank22" is '債權金融機構代號22';
comment on column "JcicZ570"."Bank23" is '債權金融機構代號23';
comment on column "JcicZ570"."Bank24" is '債權金融機構代號24';
comment on column "JcicZ570"."Bank25" is '債權金融機構代號25';
comment on column "JcicZ570"."Bank26" is '債權金融機構代號26';
comment on column "JcicZ570"."Bank27" is '債權金融機構代號27';
comment on column "JcicZ570"."Bank28" is '債權金融機構代號28';
comment on column "JcicZ570"."Bank29" is '債權金融機構代號29';
comment on column "JcicZ570"."Bank30" is '債權金融機構代號30';
comment on column "JcicZ570"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ570"."Ukey" is '流水號';
comment on column "JcicZ570"."CreateDate" is '建檔日期時間';
comment on column "JcicZ570"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ570"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ570"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ570"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ570"."ActualFilingMark" is '實際報送記號';
