drop table "FacCaseAppl" purge;

create table "FacCaseAppl" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ApplDate" decimal(8, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "SyndNo" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ApplAmt" decimal(16, 2) default 0 not null,
  "ProdNo" varchar2(5),
  "Estimate" varchar2(6),
  "DepartmentCode" varchar2(1),
  "PieceCode" varchar2(1),
  "CreditOfficer" varchar2(6),
  "LoanOfficer" varchar2(6),
  "Introducer" varchar2(6),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "Supervisor" varchar2(6),
  "ProcessCode" varchar2(1),
  "ApproveDate" decimal(8, 0) default 0 not null,
  "GroupUKey" varchar2(32),
  "BranchNo" varchar2(4),
  "IsLimit" varchar2(1),
  "IsRelated" varchar2(1),
  "IsLnrelNear" varchar2(1),
  "IsSuspected" varchar2(1),
  "IsSuspectedCheck" varchar2(1),
  "IsSuspectedCheckType" varchar2(1),
  "IsDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacCaseAppl" add constraint "FacCaseAppl_PK" primary key("ApplNo");

alter table "FacCaseAppl" add constraint "FacCaseAppl_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

alter table "FacCaseAppl" add constraint "FacCaseAppl_FacProd_FK2" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

comment on table "FacCaseAppl" is '案件申請檔';
comment on column "FacCaseAppl"."ApplNo" is '申請號碼';
comment on column "FacCaseAppl"."CustUKey" is '客戶識別碼';
comment on column "FacCaseAppl"."ApplDate" is '申請日期';
comment on column "FacCaseAppl"."CreditSysNo" is '案件編號';
comment on column "FacCaseAppl"."SyndNo" is '聯貸案編號';
comment on column "FacCaseAppl"."CurrencyCode" is '申請幣別';
comment on column "FacCaseAppl"."ApplAmt" is '申請金額';
comment on column "FacCaseAppl"."ProdNo" is '申請商品代碼';
comment on column "FacCaseAppl"."Estimate" is '估價';
comment on column "FacCaseAppl"."DepartmentCode" is '案件隸屬單位';
comment on column "FacCaseAppl"."PieceCode" is '計件代碼';
comment on column "FacCaseAppl"."CreditOfficer" is '授信';
comment on column "FacCaseAppl"."LoanOfficer" is '放款專員';
comment on column "FacCaseAppl"."Introducer" is '介紹人';
comment on column "FacCaseAppl"."Coorgnizer" is '協辦人';
comment on column "FacCaseAppl"."InterviewerA" is '晤談一';
comment on column "FacCaseAppl"."InterviewerB" is '晤談二';
comment on column "FacCaseAppl"."Supervisor" is '核決主管';
comment on column "FacCaseAppl"."ProcessCode" is '處理情形';
comment on column "FacCaseAppl"."ApproveDate" is '准駁日期';
comment on column "FacCaseAppl"."GroupUKey" is '團體戶識別碼';
comment on column "FacCaseAppl"."BranchNo" is '單位別';
comment on column "FacCaseAppl"."IsLimit" is '是否為授信限制對象';
comment on column "FacCaseAppl"."IsRelated" is '是否為利害關係人';
comment on column "FacCaseAppl"."IsLnrelNear" is '是否為準利害關係人';
comment on column "FacCaseAppl"."IsSuspected" is '是否為金控「疑似準利害關係人」名單';
comment on column "FacCaseAppl"."IsSuspectedCheck" is '是否為金控疑似利害關係人';
comment on column "FacCaseAppl"."IsSuspectedCheckType" is '是否為金控疑似利害關係人_確認狀態';
comment on column "FacCaseAppl"."IsDate" is '是否資訊日期';
comment on column "FacCaseAppl"."CreateDate" is '建檔日期時間';
comment on column "FacCaseAppl"."CreateEmpNo" is '建檔人員';
comment on column "FacCaseAppl"."LastUpdate" is '最後更新日期時間';
comment on column "FacCaseAppl"."LastUpdateEmpNo" is '最後更新人員';
