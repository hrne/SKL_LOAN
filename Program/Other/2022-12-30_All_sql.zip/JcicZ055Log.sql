drop table "JcicZ055Log" purge;

create table "JcicZ055Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayEndDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "IsImplement" varchar2(1),
  "InspectName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ055Log" add constraint "JcicZ055Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ055Log" is '消債條例更生案件資料報送';
comment on column "JcicZ055Log"."Ukey" is '流水號';
comment on column "JcicZ055Log"."TxSeq" is '交易序號';
comment on column "JcicZ055Log"."TranKey" is '交易代碼';
comment on column "JcicZ055Log"."Year" is '年度別';
comment on column "JcicZ055Log"."CourtDiv" is '法院承審股別';
comment on column "JcicZ055Log"."CourtCaseNo" is '法院案號';
comment on column "JcicZ055Log"."PayDate" is '更生方案首期應繳款日';
comment on column "JcicZ055Log"."PayEndDate" is '更生方案末期應繳款日';
comment on column "JcicZ055Log"."Period" is '更生條件(期數)';
comment on column "JcicZ055Log"."Rate" is '更生條件(利率)';
comment on column "JcicZ055Log"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ055Log"."SubAmt" is '更生損失金額';
comment on column "JcicZ055Log"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ055Log"."SaveDate" is '保全處分起始日';
comment on column "JcicZ055Log"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ055Log"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ055Log"."IsImplement" is '是否依更生條件履行';
comment on column "JcicZ055Log"."InspectName" is '監督人姓名';
comment on column "JcicZ055Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ055Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ055Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ055Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ055Log"."LastUpdateEmpNo" is '最後更新人員';
