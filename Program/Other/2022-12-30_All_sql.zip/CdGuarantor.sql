drop table "CdGuarantor" purge;

create table "CdGuarantor" (
  "GuaRelCode" varchar2(2),
  "GuaRelItem" nvarchar2(30),
  "GuaRelJcic" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdGuarantor" add constraint "CdGuarantor_PK" primary key("GuaRelCode");

create index "CdGuarantor_Index1" on "CdGuarantor"("GuaRelJcic" asc);

comment on table "CdGuarantor" is '保證人關係代碼檔';
comment on column "CdGuarantor"."GuaRelCode" is '保證人關係代碼';
comment on column "CdGuarantor"."GuaRelItem" is '保證人關係說明';
comment on column "CdGuarantor"."GuaRelJcic" is '保證人關係ＪＣＩＣ代碼';
comment on column "CdGuarantor"."CreateDate" is '建檔日期時間';
comment on column "CdGuarantor"."CreateEmpNo" is '建檔人員';
comment on column "CdGuarantor"."LastUpdate" is '最後更新日期時間';
comment on column "CdGuarantor"."LastUpdateEmpNo" is '最後更新人員';
