drop table "NegQueryCust" purge;

create table "NegQueryCust" (
  "AcDate" decimal(8, 0) default 0 not null,
  "CustId" varchar2(10),
  "FileYN" varchar2(1),
  "SeqNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegQueryCust" add constraint "NegQueryCust_PK" primary key("AcDate", "CustId");

comment on table "NegQueryCust" is '債協客戶請求資料';
comment on column "NegQueryCust"."AcDate" is '會計日期';
comment on column "NegQueryCust"."CustId" is '身份證字號/統一編號';
comment on column "NegQueryCust"."FileYN" is '是否已製檔';
comment on column "NegQueryCust"."SeqNo" is '批號';
comment on column "NegQueryCust"."CreateDate" is '建檔日期時間';
comment on column "NegQueryCust"."CreateEmpNo" is '建檔人員';
comment on column "NegQueryCust"."LastUpdate" is '最後更新日期時間';
comment on column "NegQueryCust"."LastUpdateEmpNo" is '最後更新人員';
