drop table "DailyLoanBal" purge;

create table "DailyLoanBal" (
  "DataDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LatestFlag" decimal(1, 0) default 0 not null,
  "MonthEndYm" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ProdNo" varchar2(5),
  "LoanBalance" decimal(16, 2) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtAcc" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "DailyLoanBal" add constraint "DailyLoanBal_PK" primary key("DataDate", "CustNo", "FacmNo", "BormNo");

create index "DailyLoanBal_Index1" on "DailyLoanBal"("LatestFlag" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "DataDate" asc);

comment on table "DailyLoanBal" is '每日放款餘額檔';
comment on column "DailyLoanBal"."DataDate" is '資料日期';
comment on column "DailyLoanBal"."CustNo" is '戶號';
comment on column "DailyLoanBal"."FacmNo" is '額度編號';
comment on column "DailyLoanBal"."BormNo" is '撥款序號';
comment on column "DailyLoanBal"."LatestFlag" is '資料是否為最新';
comment on column "DailyLoanBal"."MonthEndYm" is '月底年月';
comment on column "DailyLoanBal"."CurrencyCode" is '幣別';
comment on column "DailyLoanBal"."AcctCode" is '業務科目代號';
comment on column "DailyLoanBal"."FacAcctCode" is '額度業務科目';
comment on column "DailyLoanBal"."ProdNo" is '商品代碼';
comment on column "DailyLoanBal"."LoanBalance" is '放款餘額';
comment on column "DailyLoanBal"."StoreRate" is '計息利率';
comment on column "DailyLoanBal"."IntAmtRcv" is '實收利息';
comment on column "DailyLoanBal"."IntAmtAcc" is '提存利息';
comment on column "DailyLoanBal"."CreateDate" is '建檔日期時間';
comment on column "DailyLoanBal"."CreateEmpNo" is '建檔人員';
comment on column "DailyLoanBal"."LastUpdate" is '最後更新日期時間';
comment on column "DailyLoanBal"."LastUpdateEmpNo" is '最後更新人員';
