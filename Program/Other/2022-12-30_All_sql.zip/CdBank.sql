drop table "CdBank" purge;

create table "CdBank" (
  "BankCode" varchar2(3),
  "BranchCode" varchar2(4),
  "BankItem" nvarchar2(50),
  "BranchItem" nvarchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBank" add constraint "CdBank_PK" primary key("BankCode", "BranchCode");

comment on table "CdBank" is '行庫資料檔';
comment on column "CdBank"."BankCode" is '行庫代號';
comment on column "CdBank"."BranchCode" is '分行代號';
comment on column "CdBank"."BankItem" is '行庫名稱';
comment on column "CdBank"."BranchItem" is '分行名稱';
comment on column "CdBank"."CreateDate" is '建檔日期時間';
comment on column "CdBank"."CreateEmpNo" is '建檔人員';
comment on column "CdBank"."LastUpdate" is '最後更新日期時間';
comment on column "CdBank"."LastUpdateEmpNo" is '最後更新人員';
