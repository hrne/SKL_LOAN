drop table "CdBonusCo" purge;

create table "CdBonusCo" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(1, 0) default 0 not null,
  "Condition" varchar2(5),
  "ConditionAmt" decimal(16, 2) default 0 not null,
  "Bonus" decimal(16, 2) default 0 not null,
  "ClassPassBonus" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBonusCo" add constraint "CdBonusCo_PK" primary key("WorkMonth", "ConditionCode", "Condition");

comment on table "CdBonusCo" is '協辦獎勵津貼標準設定';
comment on column "CdBonusCo"."WorkMonth" is '工作年月';
comment on column "CdBonusCo"."ConditionCode" is '條件記號';
comment on column "CdBonusCo"."Condition" is '標準條件';
comment on column "CdBonusCo"."ConditionAmt" is '標準金額';
comment on column "CdBonusCo"."Bonus" is '獎勵津貼';
comment on column "CdBonusCo"."ClassPassBonus" is '獎勵津貼-初階授信通過';
comment on column "CdBonusCo"."CreateDate" is '建檔日期時間';
comment on column "CdBonusCo"."CreateEmpNo" is '建檔人員';
comment on column "CdBonusCo"."LastUpdate" is '最後更新日期時間';
comment on column "CdBonusCo"."LastUpdateEmpNo" is '最後更新人員';
