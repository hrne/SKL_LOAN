drop table "LoanRateChange" purge;

create table "LoanRateChange" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "RateCode" varchar2(1),
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "IncrFlag" varchar2(1),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "FitRate" decimal(6, 4) default 0 not null,
  "Remark" nvarchar2(60),
  "AcDate" decimal(8, 0) default 0 not null,
  "TellerNo" varchar2(6),
  "TxtNo" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "OtherFields" varchar2(2000)
);

alter table "LoanRateChange" add constraint "LoanRateChange_PK" primary key("CustNo", "FacmNo", "BormNo", "EffectDate");

alter table "LoanRateChange" add constraint "LoanRateChange_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

create index "LoanRateChange_Index1" on "LoanRateChange"("AcDate" asc, "TellerNo" asc, "TxtNo" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "EffectDate" asc);

comment on table "LoanRateChange" is '放款利率變動檔';
comment on column "LoanRateChange"."CustNo" is '借款人戶號';
comment on column "LoanRateChange"."FacmNo" is '額度編號';
comment on column "LoanRateChange"."BormNo" is '撥款序號';
comment on column "LoanRateChange"."EffectDate" is '生效日期';
comment on column "LoanRateChange"."Status" is '狀態';
comment on column "LoanRateChange"."RateCode" is '利率區分';
comment on column "LoanRateChange"."ProdNo" is '商品代碼';
comment on column "LoanRateChange"."BaseRateCode" is '指標利率代碼';
comment on column "LoanRateChange"."IncrFlag" is '加減碼是否依合約';
comment on column "LoanRateChange"."RateIncr" is '加碼利率';
comment on column "LoanRateChange"."IndividualIncr" is '個別加碼利率';
comment on column "LoanRateChange"."FitRate" is '適用利率';
comment on column "LoanRateChange"."Remark" is '備註';
comment on column "LoanRateChange"."AcDate" is '交易序號-會計日期';
comment on column "LoanRateChange"."TellerNo" is '交易序號-櫃員別';
comment on column "LoanRateChange"."TxtNo" is '交易序號-流水號';
comment on column "LoanRateChange"."CreateDate" is '建檔日期時間';
comment on column "LoanRateChange"."CreateEmpNo" is '建檔人員';
comment on column "LoanRateChange"."LastUpdate" is '最後更新日期時間';
comment on column "LoanRateChange"."LastUpdateEmpNo" is '最後更新人員';
comment on column "LoanRateChange"."OtherFields" is 'JsonFields';
