drop table "JcicZ051Log" purge;

create table "JcicZ051Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DelayCode" nvarchar2(1),
  "DelayDesc" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ051Log" add constraint "JcicZ051Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ051Log" is '延期繳款（喘息期）資料檔案';
comment on column "JcicZ051Log"."Ukey" is '流水號';
comment on column "JcicZ051Log"."TxSeq" is '交易序號';
comment on column "JcicZ051Log"."TranKey" is '交易代碼';
comment on column "JcicZ051Log"."DelayCode" is '延期繳款原因';
comment on column "JcicZ051Log"."DelayDesc" is '延期繳款案情說明';
comment on column "JcicZ051Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ051Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ051Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ051Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ051Log"."LastUpdateEmpNo" is '最後更新人員';
