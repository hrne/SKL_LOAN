drop table "MonthlyLoanBal" purge;

create table "MonthlyLoanBal" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "LoanBalance" decimal(16, 2) default 0 not null,
  "MaxLoanBal" decimal(16, 2) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtAcc" decimal(16, 2) default 0 not null,
  "UnpaidInt" decimal(16, 2) default 0 not null,
  "UnexpiredInt" decimal(16, 2) default 0 not null,
  "SumRcvInt" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "ProdNo" varchar2(5),
  "AcBookCode" varchar2(3),
  "EntCode" varchar2(1),
  "RelsCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "OvduPrinAmt" decimal(16, 2) default 0 not null,
  "OvduIntAmt" decimal(16, 2) default 0 not null,
  "SumRcvPrin" decimal(16, 2) default 0 not null,
  "OvduRcvAmt" decimal(16, 2) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "AcSubBookCode" varchar2(3)
);

alter table "MonthlyLoanBal" add constraint "MonthlyLoanBal_PK" primary key("YearMonth", "CustNo", "FacmNo", "BormNo");

comment on table "MonthlyLoanBal" is '每月放款餘額檔';
comment on column "MonthlyLoanBal"."YearMonth" is '資料年月';
comment on column "MonthlyLoanBal"."CustNo" is '戶號';
comment on column "MonthlyLoanBal"."FacmNo" is '額度編號';
comment on column "MonthlyLoanBal"."BormNo" is '撥款序號';
comment on column "MonthlyLoanBal"."AcctCode" is '業務科目代號';
comment on column "MonthlyLoanBal"."FacAcctCode" is '額度業務科目';
comment on column "MonthlyLoanBal"."CurrencyCode" is '幣別';
comment on column "MonthlyLoanBal"."LoanBalance" is '放款餘額';
comment on column "MonthlyLoanBal"."MaxLoanBal" is '當月最高放款餘額';
comment on column "MonthlyLoanBal"."StoreRate" is '計息利率';
comment on column "MonthlyLoanBal"."IntAmtRcv" is '實收利息';
comment on column "MonthlyLoanBal"."IntAmtAcc" is '提存利息';
comment on column "MonthlyLoanBal"."UnpaidInt" is '已到期未繳息';
comment on column "MonthlyLoanBal"."UnexpiredInt" is '未到期應收息';
comment on column "MonthlyLoanBal"."SumRcvInt" is '累計回收利息';
comment on column "MonthlyLoanBal"."IntAmt" is '本月利息';
comment on column "MonthlyLoanBal"."ProdNo" is '商品代碼';
comment on column "MonthlyLoanBal"."AcBookCode" is '帳冊別';
comment on column "MonthlyLoanBal"."EntCode" is '企金別';
comment on column "MonthlyLoanBal"."RelsCode" is '(準)利害關係人職稱';
comment on column "MonthlyLoanBal"."DepartmentCode" is '案件隸屬單位';
comment on column "MonthlyLoanBal"."ClCode1" is '主要擔保品代號1';
comment on column "MonthlyLoanBal"."ClCode2" is '主要擔保品代號2';
comment on column "MonthlyLoanBal"."ClNo" is '主要擔保品編號';
comment on column "MonthlyLoanBal"."CityCode" is '主要擔保品地區別';
comment on column "MonthlyLoanBal"."OvduPrinAmt" is '轉催收本金';
comment on column "MonthlyLoanBal"."OvduIntAmt" is '轉催收利息';
comment on column "MonthlyLoanBal"."SumRcvPrin" is '累計回收本金';
comment on column "MonthlyLoanBal"."OvduRcvAmt" is '催收還款金額';
comment on column "MonthlyLoanBal"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "MonthlyLoanBal"."PrevPayIntDate" is '繳息迄日';
comment on column "MonthlyLoanBal"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLoanBal"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLoanBal"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLoanBal"."LastUpdateEmpNo" is '最後更新人員';
comment on column "MonthlyLoanBal"."AcSubBookCode" is '區隔帳冊';
