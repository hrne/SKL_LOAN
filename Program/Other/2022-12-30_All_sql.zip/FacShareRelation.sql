drop table "FacShareRelation" purge;

create table "FacShareRelation" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "RelApplNo" decimal(7, 0) default 0 not null,
  "RelCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacShareRelation" add constraint "FacShareRelation_PK" primary key("ApplNo", "RelApplNo");

comment on table "FacShareRelation" is '共同借款人闗係檔';
comment on column "FacShareRelation"."ApplNo" is '核准號碼';
comment on column "FacShareRelation"."RelApplNo" is '共同借款人核准號碼';
comment on column "FacShareRelation"."RelCode" is '與共同借款人關係';
comment on column "FacShareRelation"."CreateDate" is '建檔日期時間';
comment on column "FacShareRelation"."CreateEmpNo" is '建檔人員';
comment on column "FacShareRelation"."LastUpdate" is '最後更新日期時間';
comment on column "FacShareRelation"."LastUpdateEmpNo" is '最後更新人員';
