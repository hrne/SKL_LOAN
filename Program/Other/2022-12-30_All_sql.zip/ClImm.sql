drop table "ClImm" purge;

create table "ClImm" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "EvaNetWorth" decimal(16, 2) default 0 not null,
  "LVITax" decimal(16, 2) default 0 not null,
  "RentEvaValue" decimal(16, 2) default 0 not null,
  "RentPrice" decimal(16, 2) default 0 not null,
  "OwnershipCode" varchar2(1),
  "MtgCode" varchar2(1),
  "MtgCheck" varchar2(1),
  "MtgLoan" varchar2(1),
  "MtgPledge" varchar2(1),
  "Agreement" varchar2(1),
  "EvaCompanyCode" varchar2(2),
  "LimitCancelDate" decimal(8, 0) default 0 not null,
  "ClCode" varchar2(1),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "OtherOwnerTotal" decimal(16, 2) default 0 not null,
  "CompensationCopy" varchar2(1),
  "BdRmk" nvarchar2(60),
  "MtgReasonCode" varchar2(1),
  "ReceivedDate" decimal(8, 0) default 0 not null,
  "ReceivedNo" nvarchar2(20),
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelNo" nvarchar2(20),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "ClaimDate" decimal(8, 0) default 0 not null,
  "SettingSeq" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClImm" add constraint "ClImm_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClImm" add constraint "ClImm_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClImm_Index1" on "ClImm"("ClCode1" asc);

create index "ClImm_Index2" on "ClImm"("ClCode1" asc, "ClCode2" asc);

comment on table "ClImm" is '擔保品不動產檔';
comment on column "ClImm"."ClCode1" is '擔保品代號1';
comment on column "ClImm"."ClCode2" is '擔保品代號2';
comment on column "ClImm"."ClNo" is '擔保品編號';
comment on column "ClImm"."EvaNetWorth" is '評估淨值';
comment on column "ClImm"."LVITax" is '土地增值稅';
comment on column "ClImm"."RentEvaValue" is '出租評估淨值';
comment on column "ClImm"."RentPrice" is '押租金';
comment on column "ClImm"."OwnershipCode" is '權利種類';
comment on column "ClImm"."MtgCode" is '抵押權註記';
comment on column "ClImm"."MtgCheck" is '最高限額抵押權之擔保債權種類-票據';
comment on column "ClImm"."MtgLoan" is '最高限額抵押權之擔保債權種類-借款';
comment on column "ClImm"."MtgPledge" is '最高限額抵押權之擔保債權種類-保證債務';
comment on column "ClImm"."Agreement" is '檢附同意書';
comment on column "ClImm"."EvaCompanyCode" is '鑑價公司';
comment on column "ClImm"."LimitCancelDate" is '限制塗銷日期';
comment on column "ClImm"."ClCode" is '擔保註記';
comment on column "ClImm"."LoanToValue" is '貸放成數(%)';
comment on column "ClImm"."OtherOwnerTotal" is '其他債權人設定總額';
comment on column "ClImm"."CompensationCopy" is '代償後謄本';
comment on column "ClImm"."BdRmk" is '建物標示備註';
comment on column "ClImm"."MtgReasonCode" is '最高抵押權確定事由';
comment on column "ClImm"."ReceivedDate" is '收文日期';
comment on column "ClImm"."ReceivedNo" is '收文案號';
comment on column "ClImm"."CancelDate" is '撤銷日期';
comment on column "ClImm"."CancelNo" is '撤銷案號';
comment on column "ClImm"."SettingStat" is '設定狀態';
comment on column "ClImm"."ClStat" is '擔保品狀態';
comment on column "ClImm"."SettingDate" is '設定日期';
comment on column "ClImm"."SettingAmt" is '設定金額';
comment on column "ClImm"."ClaimDate" is '擔保債權確定日期';
comment on column "ClImm"."SettingSeq" is '設定順位(1~9)';
comment on column "ClImm"."CreateDate" is '建檔日期時間';
comment on column "ClImm"."CreateEmpNo" is '建檔人員';
comment on column "ClImm"."LastUpdate" is '最後更新日期時間';
comment on column "ClImm"."LastUpdateEmpNo" is '最後更新人員';
