drop table "FacProdStepRate" purge;

create table "FacProdStepRate" (
  "ProdNo" varchar2(10),
  "MonthStart" decimal(3, 0) default 0 not null,
  "MonthEnd" decimal(3, 0) default 0 not null,
  "RateType" varchar2(1),
  "RateIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProdStepRate" add constraint "FacProdStepRate_PK" primary key("ProdNo", "MonthStart");

comment on table "FacProdStepRate" is '商品參數副檔階梯式利率';
comment on column "FacProdStepRate"."ProdNo" is '商品代碼或戶號+額度編號';
comment on column "FacProdStepRate"."MonthStart" is '月數(含)以上';
comment on column "FacProdStepRate"."MonthEnd" is '月數(含)以下';
comment on column "FacProdStepRate"."RateType" is '利率型態';
comment on column "FacProdStepRate"."RateIncr" is '加碼利率';
comment on column "FacProdStepRate"."CreateDate" is '建檔日期時間';
comment on column "FacProdStepRate"."CreateEmpNo" is '建檔人員';
comment on column "FacProdStepRate"."LastUpdate" is '最後更新日期時間';
comment on column "FacProdStepRate"."LastUpdateEmpNo" is '最後更新人員';
