drop table "CustNotice" purge;

create table "CustNotice" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FormNo" varchar2(10),
  "PaperNotice" varchar2(1),
  "MsgNotice" varchar2(1),
  "EmailNotice" varchar2(1),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustNotice" add constraint "CustNotice_PK" primary key("CustNo", "FacmNo", "FormNo");

alter table "CustNotice" add constraint "CustNotice_CdReport_FK1" foreign key ("FormNo") references "CdReport" ("FormNo") on delete cascade;

create index "CustNotice_Index1" on "CustNotice"("CustNo" asc);

create index "CustNotice_Index2" on "CustNotice"("FormNo" asc);

create index "CustNotice_Index3" on "CustNotice"("CustNo" asc, "FacmNo" asc);

comment on table "CustNotice" is '客戶通知設定檔';
comment on column "CustNotice"."CustNo" is '戶號';
comment on column "CustNotice"."FacmNo" is '額度編號';
comment on column "CustNotice"."FormNo" is '報表代號';
comment on column "CustNotice"."PaperNotice" is '書面通知與否';
comment on column "CustNotice"."MsgNotice" is '簡訊發送與否';
comment on column "CustNotice"."EmailNotice" is '電子郵件發送與否';
comment on column "CustNotice"."ApplyDate" is '申請日期';
comment on column "CustNotice"."CreateDate" is '建檔日期時間';
comment on column "CustNotice"."CreateEmpNo" is '建檔人員';
comment on column "CustNotice"."LastUpdate" is '最後更新日期時間';
comment on column "CustNotice"."LastUpdateEmpNo" is '最後更新人員';
