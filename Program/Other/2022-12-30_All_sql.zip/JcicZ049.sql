drop table "JcicZ049" purge;

create table "JcicZ049" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ClaimStatus" decimal(1, 0) default 0 not null,
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(6),
  "CourtCaseNo" nvarchar2(20),
  "Approve" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ049" add constraint "JcicZ049_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ049_Index1" on "JcicZ049"("SubmitKey" asc);

create index "JcicZ049_Index2" on "JcicZ049"("CustId" asc);

create index "JcicZ049_Index3" on "JcicZ049"("RcDate" asc);

comment on table "JcicZ049" is '債務清償方案法院認可資料檔案';
comment on column "JcicZ049"."TranKey" is '交易代碼';
comment on column "JcicZ049"."SubmitKey" is '報送單位代號';
comment on column "JcicZ049"."CustId" is '債務人IDN';
comment on column "JcicZ049"."RcDate" is '協商申請日';
comment on column "JcicZ049"."ClaimStatus" is '案件進度';
comment on column "JcicZ049"."ApplyDate" is '遞狀日';
comment on column "JcicZ049"."CourtCode" is '承審法院代碼';
comment on column "JcicZ049"."Year" is '年度別';
comment on column "JcicZ049"."CourtDiv" is '法院承審股別';
comment on column "JcicZ049"."CourtCaseNo" is '法院案號';
comment on column "JcicZ049"."Approve" is '法院認可與否';
comment on column "JcicZ049"."ClaimDate" is '法院裁定日期';
comment on column "JcicZ049"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ049"."Ukey" is '流水號';
comment on column "JcicZ049"."CreateDate" is '建檔日期時間';
comment on column "JcicZ049"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ049"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ049"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ049"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ049"."ActualFilingMark" is '實際報送記號';
