drop table "MonthlyQ53" purge;

create table "MonthlyQ53" (
  "DataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyQ53" add constraint "MonthlyQ53_PK" primary key("DataYM");

comment on table "MonthlyQ53" is 'Q53工作檔';
comment on column "MonthlyQ53"."DataYM" is '日期年月';
comment on column "MonthlyQ53"."CreateDate" is '建檔日期時間';
comment on column "MonthlyQ53"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyQ53"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyQ53"."LastUpdateEmpNo" is '最後更新人員';
