drop table "EmpDeductDtl" purge;

create table "EmpDeductDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "AchRepayCode" decimal(2, 0) default 0 not null,
  "PerfMonth" decimal(6, 0) default 0 not null,
  "ProcCode" varchar2(1),
  "RepayCode" varchar2(1),
  "AcctCode" varchar2(12),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "EmpNo" varchar2(6),
  "CustId" varchar2(10),
  "TxAmt" decimal(14, 0) default 0 not null,
  "ErrMsg" nvarchar2(20),
  "Acdate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "BatchNo" varchar2(6),
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ResignCode" varchar2(2),
  "DeptCode" varchar2(6),
  "UnitCode" varchar2(6),
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "PositCode" varchar2(2),
  "Principal" decimal(14, 0) default 0 not null,
  "Interest" decimal(14, 0) default 0 not null,
  "SumOvpayAmt" decimal(14, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "CurrIntAmt" decimal(14, 0) default 0 not null,
  "CurrPrinAmt" decimal(14, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "EmpDeductDtl" add constraint "EmpDeductDtl_PK" primary key("EntryDate", "CustNo", "AchRepayCode", "PerfMonth", "ProcCode", "RepayCode", "AcctCode", "FacmNo", "BormNo");

comment on table "EmpDeductDtl" is '員工扣薪明細檔';
comment on column "EmpDeductDtl"."EntryDate" is '入帳日期';
comment on column "EmpDeductDtl"."CustNo" is '戶號';
comment on column "EmpDeductDtl"."AchRepayCode" is '入帳扣款別';
comment on column "EmpDeductDtl"."PerfMonth" is '業績年月';
comment on column "EmpDeductDtl"."ProcCode" is '流程別';
comment on column "EmpDeductDtl"."RepayCode" is '扣款代碼';
comment on column "EmpDeductDtl"."AcctCode" is '科目';
comment on column "EmpDeductDtl"."FacmNo" is '額度編號';
comment on column "EmpDeductDtl"."BormNo" is '撥款編號';
comment on column "EmpDeductDtl"."EmpNo" is '員工代號';
comment on column "EmpDeductDtl"."CustId" is '統一編號';
comment on column "EmpDeductDtl"."TxAmt" is '交易金額(實扣金額)';
comment on column "EmpDeductDtl"."ErrMsg" is '失敗原因';
comment on column "EmpDeductDtl"."Acdate" is '會計日期';
comment on column "EmpDeductDtl"."TitaTlrNo" is '經辦';
comment on column "EmpDeductDtl"."TitaTxtNo" is '交易序號';
comment on column "EmpDeductDtl"."BatchNo" is '批次號碼';
comment on column "EmpDeductDtl"."RepayAmt" is '應扣金額';
comment on column "EmpDeductDtl"."ResignCode" is '離職代碼';
comment on column "EmpDeductDtl"."DeptCode" is '部室代號';
comment on column "EmpDeductDtl"."UnitCode" is '單位代號';
comment on column "EmpDeductDtl"."IntStartDate" is '計息起日';
comment on column "EmpDeductDtl"."IntEndDate" is '計息迄日';
comment on column "EmpDeductDtl"."PositCode" is '職務代號';
comment on column "EmpDeductDtl"."Principal" is '本金';
comment on column "EmpDeductDtl"."Interest" is '利息';
comment on column "EmpDeductDtl"."SumOvpayAmt" is '累溢短收';
comment on column "EmpDeductDtl"."JsonFields" is 'jason格式紀錄欄';
comment on column "EmpDeductDtl"."CurrIntAmt" is '當期利息';
comment on column "EmpDeductDtl"."CurrPrinAmt" is '當期本金';
comment on column "EmpDeductDtl"."MediaDate" is '媒體日期';
comment on column "EmpDeductDtl"."MediaKind" is '媒體別';
comment on column "EmpDeductDtl"."MediaSeq" is '媒體序號';
comment on column "EmpDeductDtl"."CreateDate" is '建檔日期時間';
comment on column "EmpDeductDtl"."CreateEmpNo" is '建檔人員';
comment on column "EmpDeductDtl"."LastUpdate" is '最後更新日期時間';
comment on column "EmpDeductDtl"."LastUpdateEmpNo" is '最後更新人員';
