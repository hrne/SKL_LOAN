drop table "JcicRel" purge;

create table "JcicRel" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "RelYM" decimal(5, 0) default 0 not null,
  "TranCode" varchar2(1),
  "CustId" varchar2(8),
  "Filler6" varchar2(1),
  "RelId" varchar2(8),
  "Filler8" varchar2(1),
  "RelationCode" varchar2(3),
  "Filler10" varchar2(5),
  "EndCode" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicRel" add constraint "JcicRel_PK" primary key("DataYMD", "BankItem", "BranchItem", "CustId", "RelId", "TranCode");

comment on table "JcicRel" is '聯徵授信「同一關係企業及集團企業」資料報送檔';
comment on column "JcicRel"."DataYMD" is '資料年月日';
comment on column "JcicRel"."BankItem" is '總行代號';
comment on column "JcicRel"."BranchItem" is '分行代號';
comment on column "JcicRel"."RelYM" is '客戶填表年月';
comment on column "JcicRel"."TranCode" is '報送時機';
comment on column "JcicRel"."CustId" is '授信企業統編';
comment on column "JcicRel"."Filler6" is '空白';
comment on column "JcicRel"."RelId" is '關係企業統編';
comment on column "JcicRel"."Filler8" is '空白';
comment on column "JcicRel"."RelationCode" is '關係企業關係代號';
comment on column "JcicRel"."Filler10" is '空白';
comment on column "JcicRel"."EndCode" is '結束註記碼';
comment on column "JcicRel"."CreateDate" is '建檔日期時間';
comment on column "JcicRel"."CreateEmpNo" is '建檔人員';
comment on column "JcicRel"."LastUpdate" is '最後更新日期時間';
comment on column "JcicRel"."LastUpdateEmpNo" is '最後更新人員';
