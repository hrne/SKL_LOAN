drop table "LoanBorMain" purge;

create table "LoanBorMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LastBorxNo" decimal(4, 0) default 0 not null,
  "LastOvduNo" decimal(3, 0) default 0 not null,
  "Status" decimal(2, 0) default 0 not null,
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "RateCode" varchar2(1),
  "RateAdjFreq" decimal(2, 0) default 0 not null,
  "DrawdownCode" varchar2(1),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "IntCalcCode" varchar2(1),
  "AmortizedCode" varchar2(1),
  "FreqBase" decimal(1, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "PaidTerms" decimal(3, 0) default 0 not null,
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "PrevRepaidDate" decimal(8, 0) default 0 not null,
  "NextPayIntDate" decimal(8, 0) default 0 not null,
  "NextRepayDate" decimal(8, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "GraceDate" decimal(8, 0) default 0 not null,
  "SpecificDd" decimal(2, 0) default 0 not null,
  "SpecificDate" decimal(8, 0) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "FirstAdjRateDate" decimal(8, 0) default 0 not null,
  "NextAdjRateDate" decimal(8, 0) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "HandlingFee" decimal(16, 2) default 0 not null,
  "FinalBal" decimal(16, 2) default 0 not null,
  "NotYetFlag" varchar2(1),
  "RenewFlag" varchar2(1),
  "PieceCode" varchar2(1),
  "PieceCodeSecond" varchar2(1),
  "PieceCodeSecondAmt" decimal(16, 2) default 0 not null,
  "UsageCode" varchar2(2),
  "SyndNo" decimal(6, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelationName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelationBirthday" decimal(8, 0) default 0 not null,
  "RelationGender" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "LastEntDy" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "RemitBank" varchar2(3),
  "RemitBranch" varchar2(4),
  "RemitAcctNo" decimal(14, 0) default 0 not null,
  "CompensateAcct" nvarchar2(60),
  "PaymentBank" varchar2(7),
  "Remark" nvarchar2(40),
  "AcDate" decimal(8, 0) default 0 not null,
  "NextAcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "GraceFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanBorMain" add constraint "LoanBorMain_PK" primary key("CustNo", "FacmNo", "BormNo");

alter table "LoanBorMain" add constraint "LoanBorMain_FacMain_FK1" foreign key ("CustNo", "FacmNo") references "FacMain" ("CustNo", "FacmNo") on delete cascade;

create index "LoanBorMain_Index1" on "LoanBorMain"("Status" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc);

comment on table "LoanBorMain" is '放款主檔';
comment on column "LoanBorMain"."CustNo" is '借款人戶號';
comment on column "LoanBorMain"."FacmNo" is '額度編號';
comment on column "LoanBorMain"."BormNo" is '撥款序號, 預約序號';
comment on column "LoanBorMain"."LastBorxNo" is '已編BorTx流水號';
comment on column "LoanBorMain"."LastOvduNo" is '已編Overdue流水號';
comment on column "LoanBorMain"."Status" is '戶況';
comment on column "LoanBorMain"."RateIncr" is '加碼利率';
comment on column "LoanBorMain"."IndividualIncr" is '個別加碼利率';
comment on column "LoanBorMain"."ApproveRate" is '核准利率';
comment on column "LoanBorMain"."StoreRate" is '實際計息利率';
comment on column "LoanBorMain"."RateCode" is '利率區分';
comment on column "LoanBorMain"."RateAdjFreq" is '利率調整週期';
comment on column "LoanBorMain"."DrawdownCode" is '撥款方式';
comment on column "LoanBorMain"."CurrencyCode" is '幣別';
comment on column "LoanBorMain"."DrawdownAmt" is '撥款金額';
comment on column "LoanBorMain"."LoanBal" is '放款餘額';
comment on column "LoanBorMain"."DrawdownDate" is '撥款日期, 預約日期';
comment on column "LoanBorMain"."LoanTermYy" is '貸款期間年';
comment on column "LoanBorMain"."LoanTermMm" is '貸款期間月';
comment on column "LoanBorMain"."LoanTermDd" is '貸款期間日';
comment on column "LoanBorMain"."MaturityDate" is '到期日';
comment on column "LoanBorMain"."IntCalcCode" is '計息方式';
comment on column "LoanBorMain"."AmortizedCode" is '攤還方式';
comment on column "LoanBorMain"."FreqBase" is '週期基準';
comment on column "LoanBorMain"."PayIntFreq" is '繳息週期';
comment on column "LoanBorMain"."RepayFreq" is '還本週期';
comment on column "LoanBorMain"."TotalPeriod" is '總期數';
comment on column "LoanBorMain"."RepaidPeriod" is '已還本期數';
comment on column "LoanBorMain"."PaidTerms" is '已繳息期數';
comment on column "LoanBorMain"."PrevPayIntDate" is '上次繳息日,繳息迄日';
comment on column "LoanBorMain"."PrevRepaidDate" is '上次還本日,最後還本日';
comment on column "LoanBorMain"."NextPayIntDate" is '下次繳息日,應繳息日';
comment on column "LoanBorMain"."NextRepayDate" is '下次還本日,應還本日';
comment on column "LoanBorMain"."DueAmt" is '每期攤還金額';
comment on column "LoanBorMain"."GracePeriod" is '寬限期';
comment on column "LoanBorMain"."GraceDate" is '寬限到期日';
comment on column "LoanBorMain"."SpecificDd" is '指定應繳日';
comment on column "LoanBorMain"."SpecificDate" is '指定基準日期';
comment on column "LoanBorMain"."FirstDueDate" is '首次應繳日';
comment on column "LoanBorMain"."FirstAdjRateDate" is '首次利率調整日期';
comment on column "LoanBorMain"."NextAdjRateDate" is '下次利率調整日期';
comment on column "LoanBorMain"."AcctFee" is '帳管費';
comment on column "LoanBorMain"."HandlingFee" is '手續費';
comment on column "LoanBorMain"."FinalBal" is '最後一期本金餘額';
comment on column "LoanBorMain"."NotYetFlag" is '未齊件';
comment on column "LoanBorMain"."RenewFlag" is '展期/借新還舊';
comment on column "LoanBorMain"."PieceCode" is '計件代碼';
comment on column "LoanBorMain"."PieceCodeSecond" is '計件代碼2';
comment on column "LoanBorMain"."PieceCodeSecondAmt" is '計件代碼2金額';
comment on column "LoanBorMain"."UsageCode" is '資金用途別';
comment on column "LoanBorMain"."SyndNo" is '聯貸案序號';
comment on column "LoanBorMain"."RelationCode" is '與借款人關係';
comment on column "LoanBorMain"."RelationName" is '第三人帳戶戶名';
comment on column "LoanBorMain"."RelationId" is '第三人身份證字號';
comment on column "LoanBorMain"."RelationBirthday" is '第三人生日';
comment on column "LoanBorMain"."RelationGender" is '第三人性別';
comment on column "LoanBorMain"."ActFg" is '交易進行記號';
comment on column "LoanBorMain"."LastEntDy" is '上次交易日';
comment on column "LoanBorMain"."LastKinbr" is '上次交易行別';
comment on column "LoanBorMain"."LastTlrNo" is '上次櫃員編號';
comment on column "LoanBorMain"."LastTxtNo" is '上次交易序號';
comment on column "LoanBorMain"."RemitBank" is '匯款銀行';
comment on column "LoanBorMain"."RemitBranch" is '匯款分行';
comment on column "LoanBorMain"."RemitAcctNo" is '匯款帳號';
comment on column "LoanBorMain"."CompensateAcct" is '匯款戶名(代償專戶)';
comment on column "LoanBorMain"."PaymentBank" is '解付單位代號';
comment on column "LoanBorMain"."Remark" is '附言';
comment on column "LoanBorMain"."AcDate" is '會計日期';
comment on column "LoanBorMain"."NextAcDate" is '次日交易會計日期';
comment on column "LoanBorMain"."BranchNo" is '單位別';
comment on column "LoanBorMain"."GraceFlag" is '額度寬限區分';
comment on column "LoanBorMain"."CreateDate" is '建檔日期時間';
comment on column "LoanBorMain"."CreateEmpNo" is '建檔人員';
comment on column "LoanBorMain"."LastUpdate" is '最後更新日期時間';
comment on column "LoanBorMain"."LastUpdateEmpNo" is '最後更新人員';
