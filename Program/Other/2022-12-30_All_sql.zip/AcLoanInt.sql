drop table "AcLoanInt" purge;

create table "AcLoanInt" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "TermNo" decimal(3, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "Amount" decimal(16, 2) default 0 not null,
  "IntRate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "AcctCode" varchar2(3),
  "PayIntDate" decimal(8, 0) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "Aging" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "BranchNo" varchar2(4),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcLoanInt" add constraint "AcLoanInt_PK" primary key("YearMonth", "CustNo", "FacmNo", "BormNo", "TermNo");

comment on table "AcLoanInt" is '提息明細檔';
comment on column "AcLoanInt"."YearMonth" is '提息年月';
comment on column "AcLoanInt"."CustNo" is '借款人戶號';
comment on column "AcLoanInt"."FacmNo" is '額度編號';
comment on column "AcLoanInt"."BormNo" is '撥款序號';
comment on column "AcLoanInt"."TermNo" is '期數編號';
comment on column "AcLoanInt"."IntStartDate" is '計息起日';
comment on column "AcLoanInt"."IntEndDate" is '計息止日';
comment on column "AcLoanInt"."Amount" is '計息本金';
comment on column "AcLoanInt"."IntRate" is '計息利率';
comment on column "AcLoanInt"."Principal" is '回收本金';
comment on column "AcLoanInt"."Interest" is '利息';
comment on column "AcLoanInt"."DelayInt" is '延滯息';
comment on column "AcLoanInt"."BreachAmt" is '違約金';
comment on column "AcLoanInt"."RateIncr" is '加碼利率';
comment on column "AcLoanInt"."IndividualIncr" is '個別加碼利率';
comment on column "AcLoanInt"."AcctCode" is '業務科目代號';
comment on column "AcLoanInt"."PayIntDate" is '應繳息日';
comment on column "AcLoanInt"."LoanBal" is '放款餘額';
comment on column "AcLoanInt"."Aging" is '帳齡';
comment on column "AcLoanInt"."AcBookCode" is '帳冊別';
comment on column "AcLoanInt"."AcSubBookCode" is '區隔帳冊';
comment on column "AcLoanInt"."BranchNo" is '單位別';
comment on column "AcLoanInt"."CreateDate" is '建檔日期時間';
comment on column "AcLoanInt"."CreateEmpNo" is '建檔人員';
comment on column "AcLoanInt"."LastUpdate" is '最後更新日期時間';
comment on column "AcLoanInt"."LastUpdateEmpNo" is '最後更新人員';
