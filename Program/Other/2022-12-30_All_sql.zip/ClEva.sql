drop table "ClEva" purge;

create table "ClEva" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "EvaNo" decimal(2, 0) default 0 not null,
  "EvaDate" decimal(8, 0) default 0 not null,
  "EvaAmt" decimal(16, 2) default 0 not null,
  "EvaNetWorth" decimal(16, 2) default 0 not null,
  "RentEvaValue" decimal(16, 2) default 0 not null,
  "EvaCompanyId" varchar2(2),
  "EvaCompanyName" nvarchar2(100),
  "EvaEmpno" varchar2(6),
  "EvaReason" decimal(2, 0) default 0 not null,
  "OtherReason" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClEva" add constraint "ClEva_PK" primary key("ClCode1", "ClCode2", "ClNo", "EvaNo");

alter table "ClEva" add constraint "ClEva_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClEva_Index1" on "ClEva"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

comment on table "ClEva" is '擔保品重評資料檔';
comment on column "ClEva"."ClCode1" is '擔保品代號1';
comment on column "ClEva"."ClCode2" is '擔保品代號2';
comment on column "ClEva"."ClNo" is '擔保品編號';
comment on column "ClEva"."EvaNo" is '鑑估序號';
comment on column "ClEva"."EvaDate" is '鑑價日期';
comment on column "ClEva"."EvaAmt" is '評估總價';
comment on column "ClEva"."EvaNetWorth" is '評估淨值';
comment on column "ClEva"."RentEvaValue" is '出租評估淨值';
comment on column "ClEva"."EvaCompanyId" is '估價公司代碼';
comment on column "ClEva"."EvaCompanyName" is '估價公司名稱';
comment on column "ClEva"."EvaEmpno" is '估價人員';
comment on column "ClEva"."EvaReason" is '重評原因';
comment on column "ClEva"."OtherReason" is '其他重評原因';
comment on column "ClEva"."CreateDate" is '建檔日期時間';
comment on column "ClEva"."CreateEmpNo" is '建檔人員';
comment on column "ClEva"."LastUpdate" is '最後更新日期時間';
comment on column "ClEva"."LastUpdateEmpNo" is '最後更新人員';
