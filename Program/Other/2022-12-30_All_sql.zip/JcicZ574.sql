drop table "JcicZ574" purge;

create table "JcicZ574" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseMark" varchar2(2),
  "PhoneNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ574" add constraint "JcicZ574_PK" primary key("CustId", "SubmitKey", "ApplyDate");

create index "JcicZ574_Index1" on "JcicZ574"("CustId" asc);

create index "JcicZ574_Index2" on "JcicZ574"("SubmitKey" asc);

create index "JcicZ574_Index3" on "JcicZ574"("ApplyDate" asc);

comment on table "JcicZ574" is '更生款項統一收付結案通知資料';
comment on column "JcicZ574"."TranKey" is '交易代碼';
comment on column "JcicZ574"."CustId" is '債務人IDN';
comment on column "JcicZ574"."SubmitKey" is '報送單位代號';
comment on column "JcicZ574"."ApplyDate" is '申請日期';
comment on column "JcicZ574"."CloseDate" is '結案日期';
comment on column "JcicZ574"."CloseMark" is '結案原因';
comment on column "JcicZ574"."PhoneNo" is '通訊電話';
comment on column "JcicZ574"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ574"."Ukey" is '流水號';
comment on column "JcicZ574"."CreateDate" is '建檔日期時間';
comment on column "JcicZ574"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ574"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ574"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ574"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ574"."ActualFilingMark" is '實際報送記號';
