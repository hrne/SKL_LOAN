drop table "Ias34Ap" purge;

create table "Ias34Ap" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "Rate" decimal(8, 6) default 0 not null,
  "OvduDays" decimal(4, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerCode" decimal(2, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "AmortizedCode" decimal(1, 0) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetClass" decimal(1, 0) default 0 not null,
  "Ifrs9ProdCode" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Ap" add constraint "Ias34Ap_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "Ias34Ap" is 'IAS34欄位清單A檔';
comment on column "Ias34Ap"."DataYM" is '年月份';
comment on column "Ias34Ap"."CustNo" is '戶號';
comment on column "Ias34Ap"."CustId" is '借款人ID / 統編';
comment on column "Ias34Ap"."FacmNo" is '額度編號';
comment on column "Ias34Ap"."ApplNo" is '核准號碼';
comment on column "Ias34Ap"."BormNo" is '撥款序號';
comment on column "Ias34Ap"."AcCode" is '會計科目';
comment on column "Ias34Ap"."Status" is '戶況';
comment on column "Ias34Ap"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias34Ap"."DrawdownDate" is '撥款日期';
comment on column "Ias34Ap"."FacLineDate" is '到期日(額度)';
comment on column "Ias34Ap"."MaturityDate" is '到期日(撥款)';
comment on column "Ias34Ap"."LineAmt" is '核准金額';
comment on column "Ias34Ap"."DrawdownAmt" is '撥款金額';
comment on column "Ias34Ap"."AcctFee" is '帳管費';
comment on column "Ias34Ap"."LoanBal" is '本金餘額(撥款)';
comment on column "Ias34Ap"."IntAmt" is '應收利息';
comment on column "Ias34Ap"."Fee" is '法拍及火險費用';
comment on column "Ias34Ap"."Rate" is '利率(撥款)';
comment on column "Ias34Ap"."OvduDays" is '逾期繳款天數';
comment on column "Ias34Ap"."OvduDate" is '轉催收款日期';
comment on column "Ias34Ap"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ias34Ap"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ias34Ap"."DerCode" is '符合減損客觀證據之條件';
comment on column "Ias34Ap"."GracePeriod" is '初貸時約定還本寬限期';
comment on column "Ias34Ap"."ApproveRate" is '核准利率';
comment on column "Ias34Ap"."AmortizedCode" is '契約當時還款方式';
comment on column "Ias34Ap"."RateCode" is '契約當時利率調整方式';
comment on column "Ias34Ap"."RepayFreq" is '契約約定當時還本週期';
comment on column "Ias34Ap"."PayIntFreq" is '契約約定當時繳息週期';
comment on column "Ias34Ap"."IndustryCode" is '授信行業別';
comment on column "Ias34Ap"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias34Ap"."Zip3" is '擔保品地區別';
comment on column "Ias34Ap"."ProdNo" is '商品利率代碼';
comment on column "Ias34Ap"."CustKind" is '企業戶/個人戶';
comment on column "Ias34Ap"."AssetClass" is '五類資產分類';
comment on column "Ias34Ap"."Ifrs9ProdCode" is '產品別';
comment on column "Ias34Ap"."EvaAmt" is '原始鑑價金額';
comment on column "Ias34Ap"."FirstDueDate" is '首次應繳日';
comment on column "Ias34Ap"."TotalPeriod" is '總期數';
comment on column "Ias34Ap"."CreateDate" is '建檔日期時間';
comment on column "Ias34Ap"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Ap"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Ap"."LastUpdateEmpNo" is '最後更新人員';
