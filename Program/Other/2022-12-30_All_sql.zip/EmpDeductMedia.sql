drop table "EmpDeductMedia" purge;

create table "EmpDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "PerfRepayCode" decimal(1, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "PerfMonth" decimal(6, 0) default 0 not null,
  "FlowCode" varchar2(1),
  "UnitCode" varchar2(6),
  "CustId" varchar2(10),
  "EntryDate" decimal(8, 0) default 0 not null,
  "TxAmt" decimal(14, 0) default 0 not null,
  "ErrorCode" varchar2(2),
  "AcctCode" varchar2(3),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "EmpDeductMedia" add constraint "EmpDeductMedia_PK" primary key("MediaDate", "MediaKind", "MediaSeq");

create index "EmpDeductMedia_Index1" on "EmpDeductMedia"("AcDate" asc, "BatchNo" asc, "DetailSeq" asc);

create index "EmpDeductMedia_Index2" on "EmpDeductMedia"("AcDate" asc, "PerfMonth" asc, "FlowCode" asc);

comment on table "EmpDeductMedia" is '員工扣薪媒體檔';
comment on column "EmpDeductMedia"."MediaDate" is '媒體日期';
comment on column "EmpDeductMedia"."MediaKind" is '媒體別';
comment on column "EmpDeductMedia"."MediaSeq" is '媒體序號';
comment on column "EmpDeductMedia"."CustNo" is '戶號';
comment on column "EmpDeductMedia"."RepayCode" is '還款類別';
comment on column "EmpDeductMedia"."PerfRepayCode" is '扣款代碼';
comment on column "EmpDeductMedia"."RepayAmt" is '還款金額(扣款金額)';
comment on column "EmpDeductMedia"."PerfMonth" is '業績年月';
comment on column "EmpDeductMedia"."FlowCode" is '流程別';
comment on column "EmpDeductMedia"."UnitCode" is '單位代號';
comment on column "EmpDeductMedia"."CustId" is '身分證統一編號';
comment on column "EmpDeductMedia"."EntryDate" is '入帳日期';
comment on column "EmpDeductMedia"."TxAmt" is '交易金額(實扣金額)';
comment on column "EmpDeductMedia"."ErrorCode" is '失敗原因';
comment on column "EmpDeductMedia"."AcctCode" is '科目';
comment on column "EmpDeductMedia"."AcDate" is '會計日期';
comment on column "EmpDeductMedia"."BatchNo" is '批號';
comment on column "EmpDeductMedia"."DetailSeq" is '明細序號';
comment on column "EmpDeductMedia"."CreateDate" is '建檔日期時間';
comment on column "EmpDeductMedia"."CreateEmpNo" is '建檔人員';
comment on column "EmpDeductMedia"."LastUpdate" is '最後更新日期時間';
comment on column "EmpDeductMedia"."LastUpdateEmpNo" is '最後更新人員';
