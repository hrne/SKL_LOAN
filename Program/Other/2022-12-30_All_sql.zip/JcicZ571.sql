drop table "JcicZ571" purge;

create table "JcicZ571" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "BankId" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "OwnerYn" varchar2(1),
  "PayYn" varchar2(1),
  "OwnerAmt" decimal(9, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "UnallotAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ571" add constraint "JcicZ571_PK" primary key("SubmitKey", "CustId", "ApplyDate", "BankId");

create index "JcicZ571_Index1" on "JcicZ571"("SubmitKey" asc);

create index "JcicZ571_Index2" on "JcicZ571"("CustId" asc);

create index "JcicZ571_Index3" on "JcicZ571"("ApplyDate" asc);

create index "JcicZ571_Index4" on "JcicZ571"("BankId" asc);

comment on table "JcicZ571" is '更生款項統一收付回報債權資料';
comment on column "JcicZ571"."TranKey" is '交易代碼';
comment on column "JcicZ571"."CustId" is '債務人IDN';
comment on column "JcicZ571"."SubmitKey" is '報送單位代號';
comment on column "JcicZ571"."BankId" is '受理款項統一收付之債權金融機構代號';
comment on column "JcicZ571"."ApplyDate" is '申請日期';
comment on column "JcicZ571"."OwnerYn" is '是否為更生債權人';
comment on column "JcicZ571"."PayYn" is '債務人是否仍依更生方案正常還款予本金融機構';
comment on column "JcicZ571"."OwnerAmt" is '本金融機構更生債權總金額';
comment on column "JcicZ571"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ571"."UnallotAmt" is '未參與分配債權金額';
comment on column "JcicZ571"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ571"."Ukey" is '流水號';
comment on column "JcicZ571"."CreateDate" is '建檔日期時間';
comment on column "JcicZ571"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ571"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ571"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ571"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ571"."ActualFilingMark" is '實際報送記號';
