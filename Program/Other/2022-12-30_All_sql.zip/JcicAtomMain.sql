drop table "JcicAtomMain" purge;

create table "JcicAtomMain" (
  "FunctionCode" varchar2(6),
  "DataType" nvarchar2(45),
  "Remark" nvarchar2(300),
  "SearchPoint" varchar2(3),
  "FunctionKey" nvarchar2(200),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicAtomMain" add constraint "JcicAtomMain_PK" primary key("FunctionCode");

comment on table "JcicAtomMain" is '債務匯入資料功能主檔';
comment on column "JcicAtomMain"."FunctionCode" is '功能代碼';
comment on column "JcicAtomMain"."DataType" is '功能類別';
comment on column "JcicAtomMain"."Remark" is '功能說明';
comment on column "JcicAtomMain"."SearchPoint" is '查詢點數';
comment on column "JcicAtomMain"."FunctionKey" is '輸入鍵值';
comment on column "JcicAtomMain"."CreateDate" is '建檔日期時間';
comment on column "JcicAtomMain"."CreateEmpNo" is '建檔人員';
comment on column "JcicAtomMain"."LastUpdate" is '最後更新日期時間';
comment on column "JcicAtomMain"."LastUpdateEmpNo" is '最後更新人員';
