drop table "RptRelationSelf" purge;

create table "RptRelationSelf" (
  "CusId" nvarchar2(20),
  "CusName" nvarchar2(30),
  "STSCD" nvarchar2(2),
  "CusCCD" nvarchar2(1),
  "CusSCD" nvarchar2(2),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "Mark" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptRelationSelf" add constraint "RptRelationSelf_PK" primary key("CusId", "STSCD", "CusSCD");

comment on table "RptRelationSelf" is '報表用_金控利害關係人_關係人資料';
comment on column "RptRelationSelf"."CusId" is 'CusId';
comment on column "RptRelationSelf"."CusName" is 'CusName';
comment on column "RptRelationSelf"."STSCD" is 'STSCD';
comment on column "RptRelationSelf"."CusCCD" is 'CusCCD';
comment on column "RptRelationSelf"."CusSCD" is 'CusSCD';
comment on column "RptRelationSelf"."LAW001" is 'LAW001';
comment on column "RptRelationSelf"."LAW002" is 'LAW002';
comment on column "RptRelationSelf"."LAW003" is 'LAW003';
comment on column "RptRelationSelf"."LAW004" is 'LAW004';
comment on column "RptRelationSelf"."LAW005" is 'LAW005';
comment on column "RptRelationSelf"."LAW006" is 'LAW006';
comment on column "RptRelationSelf"."LAW007" is 'LAW007';
comment on column "RptRelationSelf"."LAW008" is 'LAW008';
comment on column "RptRelationSelf"."LAW009" is 'LAW009';
comment on column "RptRelationSelf"."LAW010" is 'LAW010';
comment on column "RptRelationSelf"."Mark" is 'Mark';
comment on column "RptRelationSelf"."CreateDate" is '建檔日期時間';
comment on column "RptRelationSelf"."CreateEmpNo" is '建檔人員';
comment on column "RptRelationSelf"."LastUpdate" is '最後更新日期時間';
comment on column "RptRelationSelf"."LastUpdateEmpNo" is '最後更新人員';
