drop table "JcicZ042Log" purge;

create table "JcicZ042Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ReceExpAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "ReceCashAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "ReceCreditAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ042Log" add constraint "JcicZ042Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ042Log" is '回報無擔保債權金額資料';
comment on column "JcicZ042Log"."Ukey" is '流水號';
comment on column "JcicZ042Log"."TxSeq" is '交易序號';
comment on column "JcicZ042Log"."TranKey" is '交易代碼';
comment on column "JcicZ042Log"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ042Log"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ042Log"."ExpLoanAmt" is '信用貸款對內本息餘額';
comment on column "JcicZ042Log"."Civil323ExpAmt" is '依民法第323條計算之信用貸款本息餘額';
comment on column "JcicZ042Log"."ReceExpAmt" is '信用貸款最近一期繳款金額';
comment on column "JcicZ042Log"."CashCardAmt" is '現金卡放款對內本息餘額';
comment on column "JcicZ042Log"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ042Log"."ReceCashAmt" is '現金卡最近一期繳款金額';
comment on column "JcicZ042Log"."CreditCardAmt" is '信用卡對內本息餘額';
comment on column "JcicZ042Log"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ042Log"."ReceCreditAmt" is '信用卡最近一期繳款金額';
comment on column "JcicZ042Log"."ReceExpPrin" is '信用貸款本金';
comment on column "JcicZ042Log"."ReceExpInte" is '信用貸款利息';
comment on column "JcicZ042Log"."ReceExpPena" is '信用貸款違約金';
comment on column "JcicZ042Log"."ReceExpOther" is '信用貸款其他費用';
comment on column "JcicZ042Log"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ042Log"."CashCardInte" is '信金卡利息';
comment on column "JcicZ042Log"."CashCardPena" is '信金卡違約金';
comment on column "JcicZ042Log"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ042Log"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ042Log"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ042Log"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ042Log"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ042Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ042Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ042Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ042Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ042Log"."LastUpdateEmpNo" is '最後更新人員';
