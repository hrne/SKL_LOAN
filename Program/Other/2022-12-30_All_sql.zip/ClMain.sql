drop table "ClMain" purge;

create table "ClMain" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ClTypeCode" varchar2(3),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "ClStatus" varchar2(1),
  "EvaDate" decimal(8, 0) default 0 not null,
  "EvaAmt" decimal(16, 2) default 0 not null,
  "ShareTotal" decimal(16, 2) default 0 not null,
  "Synd" varchar2(1),
  "SyndCode" varchar2(1),
  "DispPrice" decimal(16, 2) default 0 not null,
  "DispDate" decimal(8, 0) default 0 not null,
  "NewNote" varchar2(1),
  "LastClOtherSeq" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClMain" add constraint "ClMain_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClMain" add constraint "ClMain_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "ClMain_Index1" on "ClMain"("ClCode1" asc);

create index "ClMain_Index2" on "ClMain"("ClCode1" asc, "ClCode2" asc);

create index "ClMain_Index3" on "ClMain"("ClNo" asc);

create index "ClMain_Index4" on "ClMain"("CustUKey" asc);

comment on table "ClMain" is '擔保品主檔';
comment on column "ClMain"."ClCode1" is '擔保品代號1';
comment on column "ClMain"."ClCode2" is '擔保品代號2';
comment on column "ClMain"."ClNo" is '擔保品編號';
comment on column "ClMain"."CustUKey" is '客戶識別碼';
comment on column "ClMain"."ClTypeCode" is '擔保品類別代碼';
comment on column "ClMain"."CityCode" is '地區別';
comment on column "ClMain"."AreaCode" is '鄉鎮區';
comment on column "ClMain"."ClStatus" is '擔保品狀況碼';
comment on column "ClMain"."EvaDate" is '鑑估日期';
comment on column "ClMain"."EvaAmt" is '鑑估總值';
comment on column "ClMain"."ShareTotal" is '可分配金額';
comment on column "ClMain"."Synd" is '是否為聯貸案';
comment on column "ClMain"."SyndCode" is '聯貸案類型';
comment on column "ClMain"."DispPrice" is '處分價格';
comment on column "ClMain"."DispDate" is '處分日期';
comment on column "ClMain"."NewNote" is '最新註記';
comment on column "ClMain"."LastClOtherSeq" is '他項權利最後序號';
comment on column "ClMain"."CreateDate" is '建檔日期時間';
comment on column "ClMain"."CreateEmpNo" is '建檔人員';
comment on column "ClMain"."LastUpdate" is '最後更新日期時間';
comment on column "ClMain"."LastUpdateEmpNo" is '最後更新人員';
