drop table "CustTelNo" purge;

create table "CustTelNo" (
  "TelNoUKey" varchar2(32),
  "CustUKey" varchar2(32),
  "TelTypeCode" varchar2(2),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "TelChgRsnCode" varchar2(2),
  "RelationCode" varchar2(2),
  "LiaisonName" nvarchar2(100),
  "Rmk" nvarchar2(40),
  "StopReason" nvarchar2(40),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustTelNo" add constraint "CustTelNo_PK" primary key("TelNoUKey");

alter table "CustTelNo" add constraint "CustTelNo_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "CustTelNo_Index1" on "CustTelNo"("CustUKey" asc);

comment on table "CustTelNo" is '客戶聯絡電話檔';
comment on column "CustTelNo"."TelNoUKey" is '電話識別碼';
comment on column "CustTelNo"."CustUKey" is '客戶識別碼';
comment on column "CustTelNo"."TelTypeCode" is '電話種類';
comment on column "CustTelNo"."TelArea" is '電話區碼';
comment on column "CustTelNo"."TelNo" is '電話號碼';
comment on column "CustTelNo"."TelExt" is '分機號碼';
comment on column "CustTelNo"."TelChgRsnCode" is '異動原因';
comment on column "CustTelNo"."RelationCode" is '與借款人關係';
comment on column "CustTelNo"."LiaisonName" is '聯絡人姓名';
comment on column "CustTelNo"."Rmk" is '備註';
comment on column "CustTelNo"."StopReason" is '停用原因';
comment on column "CustTelNo"."Enable" is '啟用記號';
comment on column "CustTelNo"."CreateDate" is '建檔日期時間';
comment on column "CustTelNo"."CreateEmpNo" is '建檔人員';
comment on column "CustTelNo"."LastUpdate" is '最後更新日期時間';
comment on column "CustTelNo"."LastUpdateEmpNo" is '最後更新人員';
