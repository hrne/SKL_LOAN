drop table "CollLetter" purge;

create table "CollLetter" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MailTypeCode" varchar2(1),
  "MailDate" decimal(8, 0) default 0 not null,
  "MailObj" varchar2(1),
  "CustName" nvarchar2(100),
  "DelvrYet" varchar2(1),
  "DelvrCode" varchar2(1),
  "AddressCode" decimal(1, 0) default 0 not null,
  "Address" nvarchar2(60),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollLetter" add constraint "CollLetter_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollLetter" is '法催紀錄函催檔';
comment on column "CollLetter"."CaseCode" is '案件種類';
comment on column "CollLetter"."CustNo" is '借款人戶號';
comment on column "CollLetter"."FacmNo" is '額度編號';
comment on column "CollLetter"."AcDate" is '作業日期';
comment on column "CollLetter"."TitaTlrNo" is '經辦';
comment on column "CollLetter"."TitaTxtNo" is '交易序號';
comment on column "CollLetter"."MailTypeCode" is '發函種類';
comment on column "CollLetter"."MailDate" is '發函日期';
comment on column "CollLetter"."MailObj" is '發函對象';
comment on column "CollLetter"."CustName" is '姓名';
comment on column "CollLetter"."DelvrYet" is '送達否';
comment on column "CollLetter"."DelvrCode" is '送達方式';
comment on column "CollLetter"."AddressCode" is '寄送地點選項';
comment on column "CollLetter"."Address" is '寄送地點';
comment on column "CollLetter"."Remark" is '其他記錄';
comment on column "CollLetter"."CreateDate" is '建檔日期時間';
comment on column "CollLetter"."CreateEmpNo" is '建檔人員';
comment on column "CollLetter"."LastUpdate" is '最後更新日期時間';
comment on column "CollLetter"."LastUpdateEmpNo" is '最後更新人員';
