drop table "PfSpecParms" purge;

create table "PfSpecParms" (
  "ConditionCode" varchar2(1),
  "Condition" varchar2(6),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfSpecParms" add constraint "PfSpecParms_PK" primary key("ConditionCode", "Condition");

comment on table "PfSpecParms" is '業績計算特殊參數設定檔';
comment on column "PfSpecParms"."ConditionCode" is '條件記號';
comment on column "PfSpecParms"."Condition" is '標準條件';
comment on column "PfSpecParms"."CreateDate" is '建檔日期時間';
comment on column "PfSpecParms"."CreateEmpNo" is '建檔人員';
comment on column "PfSpecParms"."LastUpdate" is '最後更新日期時間';
comment on column "PfSpecParms"."LastUpdateEmpNo" is '最後更新人員';
