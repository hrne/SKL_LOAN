drop table "CdPerformance" purge;

create table "CdPerformance" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "PieceCode" varchar2(1),
  "UnitCnt" decimal(4, 2) default 0 not null,
  "UnitAmtCond" decimal(16, 2) default 0 not null,
  "UnitPercent" decimal(9, 6) default 0 not null,
  "IntrodPerccent" decimal(9, 6) default 0 not null,
  "IntrodAmtCond" decimal(16, 2) default 0 not null,
  "IntrodPfEqBase" decimal(16, 2) default 0 not null,
  "IntrodPfEqAmt" decimal(16, 2) default 0 not null,
  "IntrodRewardBase" decimal(16, 2) default 0 not null,
  "IntrodReward" decimal(16, 2) default 0 not null,
  "BsOffrCnt" decimal(4, 2) default 0 not null,
  "BsOffrCntLimit" decimal(4, 2) default 0 not null,
  "BsOffrAmtCond" decimal(16, 2) default 0 not null,
  "BsOffrPerccent" decimal(9, 6) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdPerformance" add constraint "CdPerformance_PK" primary key("WorkMonth", "PieceCode");

comment on table "CdPerformance" is '業績件數及金額核算標準設定檔';
comment on column "CdPerformance"."WorkMonth" is '工作年月';
comment on column "CdPerformance"."PieceCode" is '計件代碼';
comment on column "CdPerformance"."UnitCnt" is '介紹單位_件數';
comment on column "CdPerformance"."UnitAmtCond" is '介紹單位_計件金額門檻';
comment on column "CdPerformance"."UnitPercent" is '介紹單位_撥款業績_比例';
comment on column "CdPerformance"."IntrodPerccent" is '介紹人_介紹獎金_比例';
comment on column "CdPerformance"."IntrodAmtCond" is '介紹人_介紹獎金_門檻(新增額度)';
comment on column "CdPerformance"."IntrodPfEqBase" is '介紹人_換算業績率(分母)';
comment on column "CdPerformance"."IntrodPfEqAmt" is '介紹人_換算業績率(分子)';
comment on column "CdPerformance"."IntrodRewardBase" is '介紹人_業務報酬率(分母)';
comment on column "CdPerformance"."IntrodReward" is '介紹人_業務報酬率(分子)';
comment on column "CdPerformance"."BsOffrCnt" is '房貸專員_件數';
comment on column "CdPerformance"."BsOffrCntLimit" is '房貸專員_件數上限';
comment on column "CdPerformance"."BsOffrAmtCond" is '房貸專員_計件金額門檻';
comment on column "CdPerformance"."BsOffrPerccent" is '房貸專員_撥款業績_比例';
comment on column "CdPerformance"."CreateDate" is '建檔日期時間';
comment on column "CdPerformance"."CreateEmpNo" is '建檔人員';
comment on column "CdPerformance"."LastUpdate" is '最後更新日期時間';
comment on column "CdPerformance"."LastUpdateEmpNo" is '最後更新人員';
