drop table "CdAppraisalCompany" purge;

create table "CdAppraisalCompany" (
  "AppraisalCompany" varchar2(30),
  "Company" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAppraisalCompany" add constraint "CdAppraisalCompany_PK" primary key("AppraisalCompany");

comment on table "CdAppraisalCompany" is '估價公司檔';
comment on column "CdAppraisalCompany"."AppraisalCompany" is '估價公司代號';
comment on column "CdAppraisalCompany"."Company" is '公司名稱';
comment on column "CdAppraisalCompany"."CreateDate" is '建檔日期時間';
comment on column "CdAppraisalCompany"."CreateEmpNo" is '建檔人員';
comment on column "CdAppraisalCompany"."LastUpdate" is '最後更新日期時間';
comment on column "CdAppraisalCompany"."LastUpdateEmpNo" is '最後更新人員';
