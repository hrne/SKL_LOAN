drop table "CdBranch" purge;

create table "CdBranch" (
  "BranchNo" varchar2(4),
  "AcBranchNo" varchar2(4),
  "CRH" varchar2(2),
  "BranchStatusCode" varchar2(1),
  "BranchShort" nvarchar2(14),
  "BranchItem" nvarchar2(40),
  "BranchAddress1" nvarchar2(30),
  "BranchAddress2" nvarchar2(30),
  "Zip3" varchar2(3),
  "Zip2" varchar2(2),
  "Owner" nvarchar2(14),
  "BusinessID" varchar2(10),
  "RSOCode" varchar2(3),
  "MediaUnitCode" varchar2(4),
  "CIFKey" varchar2(6),
  "LastestCustNo" varchar2(7),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBranch" add constraint "CdBranch_PK" primary key("BranchNo");

comment on table "CdBranch" is '營業單位資料檔';
comment on column "CdBranch"."BranchNo" is '單位別';
comment on column "CdBranch"."AcBranchNo" is '核心會計單位別';
comment on column "CdBranch"."CRH" is '總分處';
comment on column "CdBranch"."BranchStatusCode" is '單位控制碼';
comment on column "CdBranch"."BranchShort" is '單位簡稱';
comment on column "CdBranch"."BranchItem" is '單位全名';
comment on column "CdBranch"."BranchAddress1" is '單位住址1';
comment on column "CdBranch"."BranchAddress2" is '單位住址2';
comment on column "CdBranch"."Zip3" is '郵遞區號前三碼';
comment on column "CdBranch"."Zip2" is '郵遞區號後兩碼';
comment on column "CdBranch"."Owner" is '負責人';
comment on column "CdBranch"."BusinessID" is '營利統一編號';
comment on column "CdBranch"."RSOCode" is '稽徵機關代號';
comment on column "CdBranch"."MediaUnitCode" is '媒體單位代號';
comment on column "CdBranch"."CIFKey" is 'CIF KEY';
comment on column "CdBranch"."LastestCustNo" is '最終戶號';
comment on column "CdBranch"."CreateDate" is '建檔日期時間';
comment on column "CdBranch"."CreateEmpNo" is '建檔人員';
comment on column "CdBranch"."LastUpdate" is '最後更新日期時間';
comment on column "CdBranch"."LastUpdateEmpNo" is '最後更新人員';
