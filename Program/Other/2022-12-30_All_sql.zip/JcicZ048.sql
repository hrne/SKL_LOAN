drop table "JcicZ048" purge;

create table "JcicZ048" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "CustRegAddr" nvarchar2(114),
  "CustComAddr" nvarchar2(114),
  "CustRegTelNo" varchar2(16),
  "CustComTelNo" varchar2(16),
  "CustMobilNo" varchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ048" add constraint "JcicZ048_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ048_Index1" on "JcicZ048"("SubmitKey" asc);

create index "JcicZ048_Index2" on "JcicZ048"("CustId" asc);

create index "JcicZ048_Index3" on "JcicZ048"("RcDate" asc);

comment on table "JcicZ048" is '債務人基本資料';
comment on column "JcicZ048"."TranKey" is '交易代碼';
comment on column "JcicZ048"."SubmitKey" is '報送單位代號';
comment on column "JcicZ048"."CustId" is '債務人IDN';
comment on column "JcicZ048"."RcDate" is '協商申請日';
comment on column "JcicZ048"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ048"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ048"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ048"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ048"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ048"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ048"."Ukey" is '流水號';
comment on column "JcicZ048"."CreateDate" is '建檔日期時間';
comment on column "JcicZ048"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ048"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ048"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ048"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ048"."ActualFilingMark" is '實際報送記號';
