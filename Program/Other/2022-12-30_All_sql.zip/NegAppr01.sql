drop table "NegAppr01" purge;

create table "NegAppr01" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "FinCode" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "CaseKindCode" varchar2(1),
  "ApprAmt" decimal(16, 2) default 0 not null,
  "AccuApprAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ApprDate" decimal(8, 0) default 0 not null,
  "BringUpDate" decimal(8, 0) default 0 not null,
  "RemitBank" varchar2(7),
  "RemitAcct" varchar2(16),
  "DataSendUnit" varchar2(8),
  "ApprAcDate" decimal(8, 0) default 0 not null,
  "ReplyCode" varchar2(4),
  "BatchTxtNo" varchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegAppr01" add constraint "NegAppr01_PK" primary key("AcDate", "TitaTlrNo", "TitaTxtNo", "FinCode");

comment on table "NegAppr01" is '最大債權撥付資料檔';
comment on column "NegAppr01"."AcDate" is '會計日期';
comment on column "NegAppr01"."TitaTlrNo" is '經辦';
comment on column "NegAppr01"."TitaTxtNo" is '交易序號';
comment on column "NegAppr01"."FinCode" is '債權機構代號';
comment on column "NegAppr01"."CustNo" is '戶號';
comment on column "NegAppr01"."CaseSeq" is '案件序號';
comment on column "NegAppr01"."CaseKindCode" is '案件種類';
comment on column "NegAppr01"."ApprAmt" is '撥付金額';
comment on column "NegAppr01"."AccuApprAmt" is '累計撥付金額';
comment on column "NegAppr01"."AmtRatio" is '撥付比例';
comment on column "NegAppr01"."ExportDate" is '製檔日期';
comment on column "NegAppr01"."ApprDate" is '撥付日期';
comment on column "NegAppr01"."BringUpDate" is '提兌日';
comment on column "NegAppr01"."RemitBank" is '匯款銀行';
comment on column "NegAppr01"."RemitAcct" is '匯款帳號';
comment on column "NegAppr01"."DataSendUnit" is '資料傳送單位';
comment on column "NegAppr01"."ApprAcDate" is '撥付傳票日';
comment on column "NegAppr01"."ReplyCode" is '回應代碼';
comment on column "NegAppr01"."BatchTxtNo" is 'Batch交易序號';
comment on column "NegAppr01"."CreateDate" is '建檔日期時間';
comment on column "NegAppr01"."CreateEmpNo" is '建檔人員';
comment on column "NegAppr01"."LastUpdate" is '最後更新日期時間';
comment on column "NegAppr01"."LastUpdateEmpNo" is '最後更新人員';
