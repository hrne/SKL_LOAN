drop table "MonthlyLM032" purge;

create table "MonthlyLM032" (
  "ADTYMT" decimal(6, 0) default 0 not null,
  "GDRID1" decimal(1, 0) default 0 not null,
  "W08PPR" decimal(5, 0) default 0 not null,
  "LMSACN" decimal(7, 0) default 0 not null,
  "LMSAPN" decimal(3, 0) default 0 not null,
  "W08LBL" decimal(16, 2) default 0 not null,
  "W08DLY" decimal(5, 0) default 0 not null,
  "STATUS" nvarchar2(2),
  "ADTYMT01" decimal(6, 0) default 0 not null,
  "GDRID101" decimal(1, 0) default 0 not null,
  "W08PPR01" decimal(5, 0) default 0 not null,
  "LMSACN01" decimal(7, 0) default 0 not null,
  "LMSAPN01" decimal(3, 0) default 0 not null,
  "W08LBL01" decimal(16, 2) default 0 not null,
  "W08DLY01" decimal(5, 0) default 0 not null,
  "ACTACT" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM032" add constraint "MonthlyLM032_PK" primary key("ADTYMT", "LMSACN", "LMSAPN");

comment on table "MonthlyLM032" is '逾期案件滾動率明細月報工作檔';
comment on column "MonthlyLM032"."ADTYMT" is '前期資料年月';
comment on column "MonthlyLM032"."GDRID1" is '前期擔保品代號1';
comment on column "MonthlyLM032"."W08PPR" is '前期逾期期數';
comment on column "MonthlyLM032"."LMSACN" is '前期戶號';
comment on column "MonthlyLM032"."LMSAPN" is '前期額度號碼';
comment on column "MonthlyLM032"."W08LBL" is '前期本金餘額';
comment on column "MonthlyLM032"."W08DLY" is '前期逾期天數';
comment on column "MonthlyLM032"."STATUS" is '當期戶況';
comment on column "MonthlyLM032"."ADTYMT01" is '當期資料年月';
comment on column "MonthlyLM032"."GDRID101" is '當期擔保品代號1';
comment on column "MonthlyLM032"."W08PPR01" is '當期逾期期數';
comment on column "MonthlyLM032"."LMSACN01" is '當期戶號';
comment on column "MonthlyLM032"."LMSAPN01" is '當期額度號碼';
comment on column "MonthlyLM032"."W08LBL01" is '當期本金餘額';
comment on column "MonthlyLM032"."W08DLY01" is '當期逾期天數';
comment on column "MonthlyLM032"."ACTACT" is '當期業務科目';
comment on column "MonthlyLM032"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM032"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM032"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM032"."LastUpdateEmpNo" is '最後更新人員';
