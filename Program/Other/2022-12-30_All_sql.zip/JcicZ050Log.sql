drop table "JcicZ050Log" purge;

create table "JcicZ050Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "Status" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "SecondRepayYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ050Log" add constraint "JcicZ050Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ050Log" is '債務人繳款資料檔案';
comment on column "JcicZ050Log"."Ukey" is '流水號';
comment on column "JcicZ050Log"."TxSeq" is '交易序號';
comment on column "JcicZ050Log"."TranKey" is '交易代碼';
comment on column "JcicZ050Log"."PayAmt" is '本次繳款金額';
comment on column "JcicZ050Log"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ050Log"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ050Log"."Status" is '債權結案註記';
comment on column "JcicZ050Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ050Log"."SecondRepayYM" is '進入第二階梯還款年月';
comment on column "JcicZ050Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ050Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ050Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ050Log"."LastUpdateEmpNo" is '最後更新人員';
