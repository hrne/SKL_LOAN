drop table "JcicZ063Log" purge;

create table "JcicZ063Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ClosedDate" decimal(8, 0) default 0 not null,
  "ClosedResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ063Log" add constraint "JcicZ063Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ063Log" is '變更還款方案結案通知資料';
comment on column "JcicZ063Log"."Ukey" is '流水號';
comment on column "JcicZ063Log"."TxSeq" is '交易序號';
comment on column "JcicZ063Log"."TranKey" is '交易代碼';
comment on column "JcicZ063Log"."ClosedDate" is '變更還款條件結案日期';
comment on column "JcicZ063Log"."ClosedResult" is '結案原因';
comment on column "JcicZ063Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ063Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ063Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ063Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ063Log"."LastUpdateEmpNo" is '最後更新人員';
