drop table "MlaundryParas" purge;

create table "MlaundryParas" (
  "BusinessType" varchar2(2),
  "Factor1TotLimit" decimal(16, 2) default 0 not null,
  "Factor2Count" decimal(4, 0) default 0 not null,
  "Factor2AmtStart" decimal(16, 2) default 0 not null,
  "Factor2AmtEnd" decimal(16, 2) default 0 not null,
  "Factor3TotLimit" decimal(16, 2) default 0 not null,
  "FactorDays" decimal(3, 0) default 0 not null,
  "FactorDays3" decimal(3, 0) default 0 not null,
  "FactorDays2" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryParas" add constraint "MlaundryParas_PK" primary key("BusinessType");

comment on table "MlaundryParas" is '疑似洗錢樣態條件設定檔';
comment on column "MlaundryParas"."BusinessType" is '業務類型';
comment on column "MlaundryParas"."Factor1TotLimit" is '洗錢樣態一金額合計超過';
comment on column "MlaundryParas"."Factor2Count" is '洗錢樣態二次數';
comment on column "MlaundryParas"."Factor2AmtStart" is '洗錢樣態二單筆起始金額';
comment on column "MlaundryParas"."Factor2AmtEnd" is '洗錢樣態二單筆迄止金額';
comment on column "MlaundryParas"."Factor3TotLimit" is '洗錢樣態三金額合計超過';
comment on column "MlaundryParas"."FactorDays" is '樣態一統計期間天數';
comment on column "MlaundryParas"."FactorDays3" is '樣態三統計期間天數';
comment on column "MlaundryParas"."FactorDays2" is '樣態二統計期間天數';
comment on column "MlaundryParas"."CreateDate" is '建檔日期時間';
comment on column "MlaundryParas"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryParas"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryParas"."LastUpdateEmpNo" is '最後更新人員';
