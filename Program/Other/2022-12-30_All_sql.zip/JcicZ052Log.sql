drop table "JcicZ052Log" purge;

create table "JcicZ052Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "BankCode1" nvarchar2(3),
  "DataCode1" nvarchar2(2),
  "BankCode2" nvarchar2(3),
  "DataCode2" nvarchar2(2),
  "BankCode3" nvarchar2(3),
  "DataCode3" nvarchar2(2),
  "BankCode4" nvarchar2(3),
  "DataCode4" nvarchar2(2),
  "BankCode5" nvarchar2(3),
  "DataCode5" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ052Log" add constraint "JcicZ052Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ052Log" is '前置協商相關資料報送例外處理';
comment on column "JcicZ052Log"."Ukey" is '流水號';
comment on column "JcicZ052Log"."TxSeq" is '交易序號';
comment on column "JcicZ052Log"."TranKey" is '交易代碼';
comment on column "JcicZ052Log"."BankCode1" is '補報送債權機構代號1';
comment on column "JcicZ052Log"."DataCode1" is '補報送檔案格式資料別1';
comment on column "JcicZ052Log"."BankCode2" is '補報送債權機構代號2';
comment on column "JcicZ052Log"."DataCode2" is '補報送檔案格式資料別2';
comment on column "JcicZ052Log"."BankCode3" is '補報送債權機構代號3';
comment on column "JcicZ052Log"."DataCode3" is '補報送檔案格式資料別3';
comment on column "JcicZ052Log"."BankCode4" is '補報送債權機構代號4';
comment on column "JcicZ052Log"."DataCode4" is '補報送檔案格式資料別4';
comment on column "JcicZ052Log"."BankCode5" is '補報送債權機構代號5';
comment on column "JcicZ052Log"."DataCode5" is '補報送檔案格式資料別5';
comment on column "JcicZ052Log"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ052Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ052Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ052Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ052Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ052Log"."LastUpdateEmpNo" is '最後更新人員';
