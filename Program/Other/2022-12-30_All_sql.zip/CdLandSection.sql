drop table "CdLandSection" purge;

create table "CdLandSection" (
  "CityCode" varchar2(2),
  "AreaCode" varchar2(2),
  "IrCode" varchar2(5),
  "IrItem" nvarchar2(30),
  "LandOfficeCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdLandSection" add constraint "CdLandSection_PK" primary key("CityCode", "AreaCode", "IrCode");

alter table "CdLandSection" add constraint "CdLandSection_CdArea_FK1" foreign key ("CityCode", "AreaCode") references "CdArea" ("CityCode", "AreaCode") on delete cascade;

create index "CdLandSection_Index1" on "CdLandSection"("CityCode" asc);

create index "CdLandSection_Index2" on "CdLandSection"("CityCode" asc, "AreaCode" asc);

comment on table "CdLandSection" is '地段代碼檔';
comment on column "CdLandSection"."CityCode" is '地區別';
comment on column "CdLandSection"."AreaCode" is '鄉鎮區';
comment on column "CdLandSection"."IrCode" is '段小段代碼';
comment on column "CdLandSection"."IrItem" is '段小段名稱';
comment on column "CdLandSection"."LandOfficeCode" is '地所代碼';
comment on column "CdLandSection"."CreateDate" is '建檔日期時間';
comment on column "CdLandSection"."CreateEmpNo" is '建檔人員';
comment on column "CdLandSection"."LastUpdate" is '最後更新日期時間';
comment on column "CdLandSection"."LastUpdateEmpNo" is '最後更新人員';
