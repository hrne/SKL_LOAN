drop table "ClBuildingPublic" purge;

create table "ClBuildingPublic" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PublicSeq" decimal(5, 0) default 0 not null,
  "PublicBdNo1" decimal(5, 0) default 0 not null,
  "PublicBdNo2" decimal(3, 0) default 0 not null,
  "Area" decimal(16, 2) default 0 not null,
  "OwnerId" varchar2(10),
  "OwnerName" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClBuildingPublic" add constraint "ClBuildingPublic_PK" primary key("ClCode1", "ClCode2", "ClNo", "PublicSeq");

alter table "ClBuildingPublic" add constraint "ClBuildingPublic_ClBuilding_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClBuilding" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClBuildingPublic_Index1" on "ClBuildingPublic"("PublicBdNo1" asc);

create index "ClBuildingPublic_Index2" on "ClBuildingPublic"("PublicBdNo1" asc, "PublicBdNo2" asc);

comment on table "ClBuildingPublic" is '擔保品-建物公設建號檔';
comment on column "ClBuildingPublic"."ClCode1" is '擔保品-代號1';
comment on column "ClBuildingPublic"."ClCode2" is '擔保品-代號2';
comment on column "ClBuildingPublic"."ClNo" is '擔保品編號';
comment on column "ClBuildingPublic"."PublicSeq" is '公設資料序號';
comment on column "ClBuildingPublic"."PublicBdNo1" is '公設建號';
comment on column "ClBuildingPublic"."PublicBdNo2" is '公設建號(子號)';
comment on column "ClBuildingPublic"."Area" is '登記面積(坪)';
comment on column "ClBuildingPublic"."OwnerId" is '所有權人統編';
comment on column "ClBuildingPublic"."OwnerName" is '所有權人姓名';
comment on column "ClBuildingPublic"."CreateDate" is '建檔日期時間';
comment on column "ClBuildingPublic"."CreateEmpNo" is '建檔人員';
comment on column "ClBuildingPublic"."LastUpdate" is '最後更新日期時間';
comment on column "ClBuildingPublic"."LastUpdateEmpNo" is '最後更新人員';
