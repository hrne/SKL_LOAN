drop table "AchDeductMedia" purge;

create table "AchDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ReturnCode" varchar2(2),
  "EntryDate" decimal(8, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcctNo" varchar2(14),
  "AchRepayCode" varchar2(1),
  "AcctCode" varchar2(3),
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "DepCode" varchar2(2),
  "RelationCode" varchar2(2),
  "RelCustName" nvarchar2(100),
  "RelCustId" varchar2(10),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AchDeductMedia" add constraint "AchDeductMedia_PK" primary key("MediaDate", "MediaKind", "MediaSeq");

create index "AchDeductMedia_Index1" on "AchDeductMedia"("AcDate" asc, "BatchNo" asc, "DetailSeq" asc);

create index "AchDeductMedia_Index2" on "AchDeductMedia"("CustNo" asc, "FacmNo" asc);

comment on table "AchDeductMedia" is 'ACH扣款媒體檔';
comment on column "AchDeductMedia"."MediaDate" is '媒體日期';
comment on column "AchDeductMedia"."MediaKind" is '媒體別';
comment on column "AchDeductMedia"."MediaSeq" is '媒體序號';
comment on column "AchDeductMedia"."CustNo" is '戶號';
comment on column "AchDeductMedia"."FacmNo" is '額度號碼';
comment on column "AchDeductMedia"."RepayType" is '還款類別';
comment on column "AchDeductMedia"."RepayAmt" is '扣款金額,還款金額';
comment on column "AchDeductMedia"."ReturnCode" is '退件理由代號';
comment on column "AchDeductMedia"."EntryDate" is '入帳日期';
comment on column "AchDeductMedia"."PrevIntDate" is '繳息迄日';
comment on column "AchDeductMedia"."RepayBank" is '扣款銀行';
comment on column "AchDeductMedia"."RepayAcctNo" is '扣款帳號';
comment on column "AchDeductMedia"."AchRepayCode" is '入帳扣款別';
comment on column "AchDeductMedia"."AcctCode" is '科目';
comment on column "AchDeductMedia"."IntStartDate" is '計息起日';
comment on column "AchDeductMedia"."IntEndDate" is '計息迄日';
comment on column "AchDeductMedia"."DepCode" is '存摺代號';
comment on column "AchDeductMedia"."RelationCode" is '與借款人關係';
comment on column "AchDeductMedia"."RelCustName" is '帳戶戶名';
comment on column "AchDeductMedia"."RelCustId" is '身分證字號';
comment on column "AchDeductMedia"."AcDate" is '會計日期';
comment on column "AchDeductMedia"."BatchNo" is '批號';
comment on column "AchDeductMedia"."DetailSeq" is '明細序號';
comment on column "AchDeductMedia"."CreateDate" is '建檔日期時間';
comment on column "AchDeductMedia"."CreateEmpNo" is '建檔人員';
comment on column "AchDeductMedia"."LastUpdate" is '最後更新日期時間';
comment on column "AchDeductMedia"."LastUpdateEmpNo" is '最後更新人員';
