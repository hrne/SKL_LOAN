drop table "CdLand" purge;

create table "CdLand" (
  "CityCode" varchar2(4),
  "LandOfficeCode" varchar2(2),
  "LandOfficeItem" nvarchar2(30),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdLand" add constraint "CdLand_PK" primary key("CityCode", "LandOfficeCode");

comment on table "CdLand" is '縣市地政檔';
comment on column "CdLand"."CityCode" is '縣市代碼';
comment on column "CdLand"."LandOfficeCode" is '地政所代碼';
comment on column "CdLand"."LandOfficeItem" is '地政所說明';
comment on column "CdLand"."CreateDate" is '建檔日期時間';
comment on column "CdLand"."CreateEmpNo" is '建檔人員';
comment on column "CdLand"."LastUpdate" is '最後更新日期時間';
comment on column "CdLand"."LastUpdateEmpNo" is '最後更新人員';
