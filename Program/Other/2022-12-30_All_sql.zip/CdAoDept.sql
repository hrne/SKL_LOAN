drop table "CdAoDept" purge;

create table "CdAoDept" (
  "EmployeeNo" varchar2(6),
  "DeptCode" varchar2(6),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAoDept" add constraint "CdAoDept_PK" primary key("EmployeeNo");

comment on table "CdAoDept" is '放款專員所屬業務部室對照檔';
comment on column "CdAoDept"."EmployeeNo" is '員工編號';
comment on column "CdAoDept"."DeptCode" is '部室代號';
comment on column "CdAoDept"."CreateDate" is '建檔日期時間';
comment on column "CdAoDept"."CreateEmpNo" is '建檔人員';
comment on column "CdAoDept"."LastUpdate" is '最後更新日期時間';
comment on column "CdAoDept"."LastUpdateEmpNo" is '最後更新人員';
