drop table "JcicZ050" purge;

create table "JcicZ050" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "Status" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "SecondRepayYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ050" add constraint "JcicZ050_PK" primary key("CustId", "RcDate", "PayDate", "SubmitKey");

create index "JcicZ050_Index1" on "JcicZ050"("CustId" asc);

create index "JcicZ050_Index2" on "JcicZ050"("RcDate" asc);

create index "JcicZ050_Index3" on "JcicZ050"("PayDate" asc);

create index "JcicZ050_Index4" on "JcicZ050"("SubmitKey" asc);

comment on table "JcicZ050" is '債務人繳款資料檔案';
comment on column "JcicZ050"."TranKey" is '交易代碼';
comment on column "JcicZ050"."SubmitKey" is '報送單位代號';
comment on column "JcicZ050"."CustId" is '債務人IDN';
comment on column "JcicZ050"."RcDate" is '協商申請日';
comment on column "JcicZ050"."PayDate" is '繳款日期';
comment on column "JcicZ050"."PayAmt" is '本次繳款金額';
comment on column "JcicZ050"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ050"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ050"."Status" is '債權結案註記';
comment on column "JcicZ050"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ050"."Ukey" is '流水號';
comment on column "JcicZ050"."SecondRepayYM" is '進入第二階梯還款年月';
comment on column "JcicZ050"."CreateDate" is '建檔日期時間';
comment on column "JcicZ050"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ050"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ050"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ050"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ050"."ActualFilingMark" is '實際報送記號';
