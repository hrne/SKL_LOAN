drop table "CdAcBook" purge;

create table "CdAcBook" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "TargetAmt" decimal(16, 2) default 0 not null,
  "ActualAmt" decimal(16, 2) default 0 not null,
  "AssignSeq" decimal(2, 0) default 0 not null,
  "AcctSource" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAcBook" add constraint "CdAcBook_PK" primary key("AcBookCode", "AcSubBookCode");

comment on table "CdAcBook" is '帳冊別金額設定檔';
comment on column "CdAcBook"."AcBookCode" is '帳冊別';
comment on column "CdAcBook"."AcSubBookCode" is '區隔帳冊';
comment on column "CdAcBook"."CurrencyCode" is '幣別';
comment on column "CdAcBook"."TargetAmt" is '放款目標金額';
comment on column "CdAcBook"."ActualAmt" is '放款實際金額';
comment on column "CdAcBook"."AssignSeq" is '分配順序';
comment on column "CdAcBook"."AcctSource" is '資金來源';
comment on column "CdAcBook"."CreateDate" is '建檔日期時間';
comment on column "CdAcBook"."CreateEmpNo" is '建檔人員';
comment on column "CdAcBook"."LastUpdate" is '最後更新日期時間';
comment on column "CdAcBook"."LastUpdateEmpNo" is '最後更新人員';
