drop table "Ias34Ep" purge;

create table "Ias34Ep" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "DerFg" varchar2(1),
  "Ifrs9ProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Ep" add constraint "Ias34Ep_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "AcCode", "Status");

comment on table "Ias34Ep" is 'IAS34欄位清單E檔';
comment on column "Ias34Ep"."DataYM" is '資料時點(年月)';
comment on column "Ias34Ep"."CustNo" is '戶號';
comment on column "Ias34Ep"."CustId" is '借款人ID / 統編';
comment on column "Ias34Ep"."FacmNo" is '額度編號(核准號碼)';
comment on column "Ias34Ep"."BormNo" is '撥款序號';
comment on column "Ias34Ep"."AcCode" is '會計科目';
comment on column "Ias34Ep"."Status" is '狀態';
comment on column "Ias34Ep"."IndustryCode" is '授信行業別';
comment on column "Ias34Ep"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias34Ep"."Zip3" is '擔保品地區別(郵遞區號)';
comment on column "Ias34Ep"."ProdNo" is '商品利率代碼';
comment on column "Ias34Ep"."CustKind" is '企業戶/個人戶';
comment on column "Ias34Ep"."DerFg" is '資料時點是否符合減損客觀證據';
comment on column "Ias34Ep"."Ifrs9ProdCode" is '產品別';
comment on column "Ias34Ep"."CreateDate" is '建檔日期時間';
comment on column "Ias34Ep"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Ep"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Ep"."LastUpdateEmpNo" is '最後更新人員';
