drop table "JcicZ061" purge;

create table "JcicZ061" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "MaxMainNote" varchar2(1),
  "IsGuarantor" varchar2(1),
  "IsChangePayment" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ061" add constraint "JcicZ061_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate", "MaxMainCode");

create index "JcicZ061_Index1" on "JcicZ061"("SubmitKey" asc);

create index "JcicZ061_Index2" on "JcicZ061"("CustId" asc);

create index "JcicZ061_Index3" on "JcicZ061"("RcDate" asc);

create index "JcicZ061_Index4" on "JcicZ061"("ChangePayDate" asc);

create index "JcicZ061_Index5" on "JcicZ061"("MaxMainCode" asc);

comment on table "JcicZ061" is '回報協商剩餘債權金額資料';
comment on column "JcicZ061"."TranKey" is '交易代碼';
comment on column "JcicZ061"."SubmitKey" is '債權金融機構代號';
comment on column "JcicZ061"."CustId" is '債務人IDN';
comment on column "JcicZ061"."RcDate" is '原前置協商申請日';
comment on column "JcicZ061"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ061"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ061"."ExpBalanceAmt" is '信用貸款協商剩餘債權餘額';
comment on column "JcicZ061"."CashBalanceAmt" is '現金卡協商剩餘債權餘額';
comment on column "JcicZ061"."CreditBalanceAmt" is '信用卡協商剩餘債權餘額';
comment on column "JcicZ061"."MaxMainNote" is '最大債權金融機構報送註記';
comment on column "JcicZ061"."IsGuarantor" is '是否有保證人';
comment on column "JcicZ061"."IsChangePayment" is '是否同意債務人申請變更還款條件方案';
comment on column "JcicZ061"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ061"."Ukey" is '流水號';
comment on column "JcicZ061"."CreateDate" is '建檔日期時間';
comment on column "JcicZ061"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ061"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ061"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ061"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ061"."ActualFilingMark" is '實際報送記號';
