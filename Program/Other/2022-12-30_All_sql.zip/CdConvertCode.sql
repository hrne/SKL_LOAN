drop table "CdConvertCode" purge;

create table "CdConvertCode" (
  "CodeType" varchar2(20),
  "orgCode" varchar2(20),
  "orgItem" nvarchar2(50),
  "newCode" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdConvertCode" add constraint "CdConvertCode_PK" primary key("CodeType", "orgCode");

comment on table "CdConvertCode" is '代碼轉換檔';
comment on column "CdConvertCode"."CodeType" is '代碼轉換類別';
comment on column "CdConvertCode"."orgCode" is '原始代碼';
comment on column "CdConvertCode"."orgItem" is '原始代碼說明';
comment on column "CdConvertCode"."newCode" is '新貸中代碼';
comment on column "CdConvertCode"."CreateDate" is '建檔日期時間';
comment on column "CdConvertCode"."CreateEmpNo" is '建檔人員';
comment on column "CdConvertCode"."LastUpdate" is '最後更新日期時間';
comment on column "CdConvertCode"."LastUpdateEmpNo" is '最後更新人員';
