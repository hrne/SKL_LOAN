drop table "TbJcicW020" purge;

create table "TbJcicW020" (
  "QueryYm" varchar2(5),
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "TbJcicW020" add constraint "TbJcicW020_PK" primary key("QueryYm");

comment on table "TbJcicW020" is '聯徵稽查產品';
comment on column "TbJcicW020"."QueryYm" is '查詢年月';
comment on column "TbJcicW020"."OutJcictxtDate" is '轉出JCIC文字檔日期';
comment on column "TbJcicW020"."CreateDate" is '建檔日期時間';
comment on column "TbJcicW020"."CreateEmpNo" is '建檔人員';
comment on column "TbJcicW020"."LastUpdate" is '最後更新日期時間';
comment on column "TbJcicW020"."LastUpdateEmpNo" is '最後更新人員';
