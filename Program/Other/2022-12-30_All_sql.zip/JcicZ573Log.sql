drop table "JcicZ573Log" purge;

create table "JcicZ573Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "TotalPayAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ573Log" add constraint "JcicZ573Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ573Log" is '更生債務人繳款資料';
comment on column "JcicZ573Log"."Ukey" is '流水號';
comment on column "JcicZ573Log"."TxSeq" is '交易序號';
comment on column "JcicZ573Log"."TranKey" is '交易代碼';
comment on column "JcicZ573Log"."PayAmt" is '本日繳款金額';
comment on column "JcicZ573Log"."TotalPayAmt" is '累計繳款金額';
comment on column "JcicZ573Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ573Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ573Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ573Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ573Log"."LastUpdateEmpNo" is '最後更新人員';
