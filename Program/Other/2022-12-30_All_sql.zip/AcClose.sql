drop table "AcClose" purge;

create table "AcClose" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "SecNo" varchar2(2),
  "ClsFg" decimal(1, 0) default 0 not null,
  "BatNo" decimal(2, 0) default 0 not null,
  "ClsNo" decimal(2, 0) default 0 not null,
  "SlipNo" decimal(6, 0) default 0 not null,
  "CoreSeqNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcClose" add constraint "AcClose_PK" primary key("AcDate", "BranchNo", "SecNo");

comment on table "AcClose" is '會計業務關帳控制檔';
comment on column "AcClose"."AcDate" is '會計日期';
comment on column "AcClose"."BranchNo" is '單位別';
comment on column "AcClose"."SecNo" is '業務類別';
comment on column "AcClose"."ClsFg" is '關帳狀態';
comment on column "AcClose"."BatNo" is '業務批號';
comment on column "AcClose"."ClsNo" is '業務關帳次數';
comment on column "AcClose"."SlipNo" is '傳票號碼';
comment on column "AcClose"."CoreSeqNo" is '上傳核心序號';
comment on column "AcClose"."CreateDate" is '建檔日期時間';
comment on column "AcClose"."CreateEmpNo" is '建檔人員';
comment on column "AcClose"."LastUpdate" is '最後更新日期時間';
comment on column "AcClose"."LastUpdateEmpNo" is '最後更新人員';
