drop table "CdAppraiser" purge;

create table "CdAppraiser" (
  "AppraiserCode" varchar2(6),
  "AppraiserItem" nvarchar2(100),
  "Company" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAppraiser" add constraint "CdAppraiser_PK" primary key("AppraiserCode");

comment on table "CdAppraiser" is '估價人員檔';
comment on column "CdAppraiser"."AppraiserCode" is '估價人員代號';
comment on column "CdAppraiser"."AppraiserItem" is '估價人員姓名';
comment on column "CdAppraiser"."Company" is '公司名稱';
comment on column "CdAppraiser"."CreateDate" is '建檔日期時間';
comment on column "CdAppraiser"."CreateEmpNo" is '建檔人員';
comment on column "CdAppraiser"."LastUpdate" is '最後更新日期時間';
comment on column "CdAppraiser"."LastUpdateEmpNo" is '最後更新人員';
