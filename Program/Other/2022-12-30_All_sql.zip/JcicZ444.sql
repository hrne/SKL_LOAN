drop table "JcicZ444" purge;

create table "JcicZ444" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "CustRegAddr" nvarchar2(76),
  "CustComAddr" nvarchar2(76),
  "CustRegTelNo" nvarchar2(16),
  "CustComTelNo" nvarchar2(16),
  "CustMobilNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ444" add constraint "JcicZ444_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ444_Index1" on "JcicZ444"("SubmitKey" asc);

create index "JcicZ444_Index2" on "JcicZ444"("CustId" asc);

create index "JcicZ444_Index3" on "JcicZ444"("ApplyDate" asc);

create index "JcicZ444_Index4" on "JcicZ444"("CourtCode" asc);

comment on table "JcicZ444" is '前置調解債務人基本資料';
comment on column "JcicZ444"."TranKey" is '交易代碼';
comment on column "JcicZ444"."CustId" is '債務人IDN';
comment on column "JcicZ444"."SubmitKey" is '報送單位代號';
comment on column "JcicZ444"."ApplyDate" is '調解申請日';
comment on column "JcicZ444"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ444"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ444"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ444"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ444"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ444"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ444"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ444"."Ukey" is '流水號';
comment on column "JcicZ444"."CreateDate" is '建檔日期時間';
comment on column "JcicZ444"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ444"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ444"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ444"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ444"."ActualFilingMark" is '實際報送記號';
