drop table "FacRelation" purge;

create table "FacRelation" (
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "FacRelationCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacRelation" add constraint "FacRelation_PK" primary key("CreditSysNo", "CustUKey");

comment on table "FacRelation" is '交易關係人檔';
comment on column "FacRelation"."CreditSysNo" is '案件編號';
comment on column "FacRelation"."CustUKey" is '客戶識別碼';
comment on column "FacRelation"."FacRelationCode" is '掃描類別';
comment on column "FacRelation"."CreateDate" is '建檔日期時間';
comment on column "FacRelation"."CreateEmpNo" is '建檔人員';
comment on column "FacRelation"."LastUpdate" is '最後更新日期時間';
comment on column "FacRelation"."LastUpdateEmpNo" is '最後更新人員';
