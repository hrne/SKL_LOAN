drop table "CdBudget" purge;

create table "CdBudget" (
  "Year" decimal(4, 0) default 0 not null,
  "Month" decimal(2, 0) default 0 not null,
  "Budget" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBudget" add constraint "CdBudget_PK" primary key("Year", "Month");

comment on table "CdBudget" is '利息收入預算檔';
comment on column "CdBudget"."Year" is '預算年度';
comment on column "CdBudget"."Month" is '預算月份';
comment on column "CdBudget"."Budget" is '預算數';
comment on column "CdBudget"."CreateDate" is '建檔日期時間';
comment on column "CdBudget"."CreateEmpNo" is '建檔人員';
comment on column "CdBudget"."LastUpdate" is '最後更新日期時間';
comment on column "CdBudget"."LastUpdateEmpNo" is '最後更新人員';
