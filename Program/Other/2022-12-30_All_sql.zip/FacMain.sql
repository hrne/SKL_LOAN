drop table "FacMain" purge;

create table "FacMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "LastBormNo" decimal(3, 0) default 0 not null,
  "LastBormRvNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AnnualIncr" decimal(6, 4) default 0 not null,
  "EmailIncr" decimal(6, 4) default 0 not null,
  "GraceIncr" decimal(6, 4) default 0 not null,
  "RateCode" varchar2(1),
  "FirstRateAdjFreq" decimal(2, 0) default 0 not null,
  "RateAdjFreq" decimal(2, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "LineAmt" decimal(16, 2) default 0 not null,
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "AcctCode" varchar2(3),
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "IntCalcCode" varchar2(1),
  "AmortizedCode" varchar2(1),
  "FreqBase" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "HandlingFee" decimal(16, 2) default 0 not null,
  "RuleCode" varchar2(2),
  "ExtraRepayCode" varchar2(1),
  "CustTypeCode" varchar2(2),
  "RecycleCode" varchar2(1),
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "UsageCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "IncomeTaxFlag" varchar2(1),
  "CompensateFlag" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "RateAdjNoticeCode" varchar2(1),
  "PieceCode" varchar2(1),
  "RepayCode" decimal(2, 0) default 0 not null,
  "Introducer" varchar2(6),
  "District" varchar2(6),
  "FireOfficer" varchar2(6),
  "Estimate" varchar2(6),
  "CreditOfficer" varchar2(6),
  "LoanOfficer" varchar2(6),
  "BusinessOfficer" varchar2(6),
  "Supervisor" varchar2(6),
  "InvestigateOfficer" varchar2(6),
  "EstimateReview" varchar2(6),
  "Coorgnizer" varchar2(6),
  "AdvanceCloseCode" decimal(2, 0) default 0 not null,
  "ProdBreachFlag" varchar2(1),
  "BreachFlag" varchar2(1),
  "BreachCode" varchar2(3),
  "BreachGetCode" varchar2(1),
  "ProhibitMonth" decimal(3, 0) default 0 not null,
  "BreachPercent" decimal(5, 2) default 0 not null,
  "BreachDecreaseMonth" decimal(3, 0) default 0 not null,
  "BreachDecrease" decimal(5, 2) default 0 not null,
  "BreachStartPercent" decimal(3, 0) default 0 not null,
  "BreachDescription" nvarchar2(200),
  "CreditScore" decimal(3, 0) default 0 not null,
  "GuaranteeDate" decimal(8, 0) default 0 not null,
  "ContractNo" varchar2(10),
  "ColSetFlag" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "LastAcctDate" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "AcDate" decimal(8, 0) default 0 not null,
  "L9110Flag" varchar2(1),
  "BranchNo" varchar2(4),
  "ApprovedLevel" varchar2(1),
  "Grcd" varchar2(1),
  "GrKind" varchar2(1),
  "EsGcd" varchar2(1),
  "EsGKind" varchar2(1),
  "EsGcnl" varchar2(1),
  "RenewCnt" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "SettingDate" decimal(8, 0) default 0 not null,
  "PreStarBuildingYM" decimal(6, 0) default 0 not null,
  "StarBuildingYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacMain" add constraint "FacMain_PK" primary key("CustNo", "FacmNo");

alter table "FacMain" add constraint "FacMain_FacCaseAppl_FK1" foreign key ("ApplNo") references "FacCaseAppl" ("ApplNo") on delete cascade;

alter table "FacMain" add constraint "FacMain_FacProd_FK2" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

create index "FacMain_Index1" on "FacMain"("ApplNo" asc);

create index "FacMain_Index2" on "FacMain"("CreditSysNo" asc);

comment on table "FacMain" is '額度主檔';
comment on column "FacMain"."CustNo" is '借款人戶號';
comment on column "FacMain"."FacmNo" is '額度編號';
comment on column "FacMain"."LastBormNo" is '已撥款序號';
comment on column "FacMain"."LastBormRvNo" is '已預約序號';
comment on column "FacMain"."ApplNo" is '核准號碼';
comment on column "FacMain"."CreditSysNo" is '案件編號';
comment on column "FacMain"."ProdNo" is '商品代碼';
comment on column "FacMain"."BaseRateCode" is '指標利率代碼';
comment on column "FacMain"."RateIncr" is '加碼利率';
comment on column "FacMain"."IndividualIncr" is '個別加碼';
comment on column "FacMain"."ApproveRate" is '核准利率';
comment on column "FacMain"."AnnualIncr" is '年繳比重優惠加減碼';
comment on column "FacMain"."EmailIncr" is '提供EMAIL優惠減碼';
comment on column "FacMain"."GraceIncr" is '寬限逾一年利率加碼';
comment on column "FacMain"."RateCode" is '利率區分';
comment on column "FacMain"."FirstRateAdjFreq" is '首次利率調整週期(月)';
comment on column "FacMain"."RateAdjFreq" is '利率調整週期(月)';
comment on column "FacMain"."CurrencyCode" is '核准幣別';
comment on column "FacMain"."LineAmt" is '核准額度';
comment on column "FacMain"."UtilAmt" is '貸出金額(放款餘額)';
comment on column "FacMain"."UtilBal" is '已動用額度餘額';
comment on column "FacMain"."AcctCode" is '核准科目';
comment on column "FacMain"."LoanTermYy" is '貸款期間年';
comment on column "FacMain"."LoanTermMm" is '貸款期間月';
comment on column "FacMain"."LoanTermDd" is '貸款期間日';
comment on column "FacMain"."FirstDrawdownDate" is '初貸日';
comment on column "FacMain"."MaturityDate" is '到期日';
comment on column "FacMain"."IntCalcCode" is '計息方式';
comment on column "FacMain"."AmortizedCode" is '攤還方式';
comment on column "FacMain"."FreqBase" is '週期基準';
comment on column "FacMain"."PayIntFreq" is '繳息週期';
comment on column "FacMain"."RepayFreq" is '還本週期';
comment on column "FacMain"."UtilDeadline" is '動支期限';
comment on column "FacMain"."GracePeriod" is '寬限總月數';
comment on column "FacMain"."AcctFee" is '帳管費';
comment on column "FacMain"."HandlingFee" is '手續費';
comment on column "FacMain"."RuleCode" is '規定管制代碼';
comment on column "FacMain"."ExtraRepayCode" is '攤還額異動碼';
comment on column "FacMain"."CustTypeCode" is '客戶別';
comment on column "FacMain"."RecycleCode" is '循環動用';
comment on column "FacMain"."RecycleDeadline" is '循環動用期限';
comment on column "FacMain"."UsageCode" is '資金用途別';
comment on column "FacMain"."DepartmentCode" is '案件隸屬單位';
comment on column "FacMain"."IncomeTaxFlag" is '代繳所得稅';
comment on column "FacMain"."CompensateFlag" is '代償碼';
comment on column "FacMain"."IrrevocableFlag" is '不可撤銷';
comment on column "FacMain"."RateAdjNoticeCode" is '利率調整通知';
comment on column "FacMain"."PieceCode" is '計件代碼';
comment on column "FacMain"."RepayCode" is '繳款方式';
comment on column "FacMain"."Introducer" is '介紹人';
comment on column "FacMain"."District" is '區部';
comment on column "FacMain"."FireOfficer" is '火險服務';
comment on column "FacMain"."Estimate" is '估價';
comment on column "FacMain"."CreditOfficer" is '授信';
comment on column "FacMain"."LoanOfficer" is '放款業務專員';
comment on column "FacMain"."BusinessOfficer" is '放款專員/房貸專員/企金人員';
comment on column "FacMain"."Supervisor" is '核決主管';
comment on column "FacMain"."InvestigateOfficer" is '徵信';
comment on column "FacMain"."EstimateReview" is '估價覆核';
comment on column "FacMain"."Coorgnizer" is '協辦人';
comment on column "FacMain"."AdvanceCloseCode" is '提前清償原因';
comment on column "FacMain"."ProdBreachFlag" is '是否適用違約設定方式';
comment on column "FacMain"."BreachFlag" is '是否綁約';
comment on column "FacMain"."BreachCode" is '違約適用方式';
comment on column "FacMain"."BreachGetCode" is '違約金收取方式';
comment on column "FacMain"."ProhibitMonth" is '限制清償期限';
comment on column "FacMain"."BreachPercent" is '違約金百分比';
comment on column "FacMain"."BreachDecreaseMonth" is '違約金分段月數';
comment on column "FacMain"."BreachDecrease" is '分段遞減百分比';
comment on column "FacMain"."BreachStartPercent" is '還款起算比例%';
comment on column "FacMain"."BreachDescription" is '違約適用說明';
comment on column "FacMain"."CreditScore" is '信用評分';
comment on column "FacMain"."GuaranteeDate" is '對保日期';
comment on column "FacMain"."ContractNo" is '合約編號';
comment on column "FacMain"."ColSetFlag" is '擔保品設定記號';
comment on column "FacMain"."ActFg" is '交易進行記號';
comment on column "FacMain"."LastAcctDate" is '上次會計日';
comment on column "FacMain"."LastKinbr" is '上次交易行別';
comment on column "FacMain"."LastTlrNo" is '上次櫃員編號';
comment on column "FacMain"."LastTxtNo" is '上次交易序號';
comment on column "FacMain"."AcDate" is '會計日期';
comment on column "FacMain"."L9110Flag" is '是否已列印[撥款審核資料表]';
comment on column "FacMain"."BranchNo" is '單位別';
comment on column "FacMain"."ApprovedLevel" is '核准層級';
comment on column "FacMain"."Grcd" is '綠色授信註記';
comment on column "FacMain"."GrKind" is '綠色支出類別';
comment on column "FacMain"."EsGcd" is '永續績效連結授信註記';
comment on column "FacMain"."EsGKind" is '永續績效連結授信類別';
comment on column "FacMain"."EsGcnl" is '永續績效連結授信約定條件全部未達成通報';
comment on column "FacMain"."RenewCnt" is '展期次數';
comment on column "FacMain"."OldFacmNo" is '原額度編號';
comment on column "FacMain"."SettingDate" is '額度設定日';
comment on column "FacMain"."PreStarBuildingYM" is '約定動工年月';
comment on column "FacMain"."StarBuildingYM" is '實際興建年月';
comment on column "FacMain"."CreateDate" is '建檔日期時間';
comment on column "FacMain"."CreateEmpNo" is '建檔人員';
comment on column "FacMain"."LastUpdate" is '最後更新日期時間';
comment on column "FacMain"."LastUpdateEmpNo" is '最後更新人員';
