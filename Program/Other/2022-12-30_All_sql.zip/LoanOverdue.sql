drop table "LoanOverdue" purge;

create table "LoanOverdue" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "OvduNo" decimal(3, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "ReplyDate" decimal(8, 0) default 0 not null,
  "OvduPrinAmt" decimal(16, 2) default 0 not null,
  "OvduIntAmt" decimal(16, 2) default 0 not null,
  "OvduBreachAmt" decimal(16, 2) default 0 not null,
  "OvduAmt" decimal(16, 2) default 0 not null,
  "OvduPrinBal" decimal(16, 2) default 0 not null,
  "OvduIntBal" decimal(16, 2) default 0 not null,
  "OvduBreachBal" decimal(16, 2) default 0 not null,
  "OvduBal" decimal(16, 2) default 0 not null,
  "ReduceInt" decimal(16, 2) default 0 not null,
  "ReduceBreach" decimal(16, 2) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "ReplyReduceAmt" decimal(16, 2) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "OvduSituaction" nvarchar2(30),
  "Remark" nvarchar2(60),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanOverdue" add constraint "LoanOverdue_PK" primary key("CustNo", "FacmNo", "BormNo", "OvduNo");

alter table "LoanOverdue" add constraint "LoanOverdue_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

comment on table "LoanOverdue" is '催收呆帳檔';
comment on column "LoanOverdue"."CustNo" is '借款人戶號';
comment on column "LoanOverdue"."FacmNo" is '額度編號';
comment on column "LoanOverdue"."BormNo" is '撥款序號';
comment on column "LoanOverdue"."OvduNo" is '催收序號';
comment on column "LoanOverdue"."Status" is '狀態';
comment on column "LoanOverdue"."AcctCode" is '帳務科目';
comment on column "LoanOverdue"."OvduDate" is '轉催收日期';
comment on column "LoanOverdue"."BadDebtDate" is '轉呆帳日期';
comment on column "LoanOverdue"."ReplyDate" is '催收回復日期';
comment on column "LoanOverdue"."OvduPrinAmt" is '轉催收本金';
comment on column "LoanOverdue"."OvduIntAmt" is '轉催收利息';
comment on column "LoanOverdue"."OvduBreachAmt" is '轉催收違約金';
comment on column "LoanOverdue"."OvduAmt" is '轉催收金額';
comment on column "LoanOverdue"."OvduPrinBal" is '催收本金餘額';
comment on column "LoanOverdue"."OvduIntBal" is '催收利息餘額';
comment on column "LoanOverdue"."OvduBreachBal" is '催收違約金餘額';
comment on column "LoanOverdue"."OvduBal" is '催收餘額';
comment on column "LoanOverdue"."ReduceInt" is '減免利息金額';
comment on column "LoanOverdue"."ReduceBreach" is '減免違約金金額';
comment on column "LoanOverdue"."BadDebtAmt" is '轉呆帳金額';
comment on column "LoanOverdue"."BadDebtBal" is '呆帳餘額';
comment on column "LoanOverdue"."ReplyReduceAmt" is '催收回復減免金額';
comment on column "LoanOverdue"."ProcessDate" is '處理日期';
comment on column "LoanOverdue"."OvduSituaction" is '催收處理情形';
comment on column "LoanOverdue"."Remark" is '附言';
comment on column "LoanOverdue"."AcDate" is '會計日期';
comment on column "LoanOverdue"."CreateDate" is '建檔日期時間';
comment on column "LoanOverdue"."CreateEmpNo" is '建檔人員';
comment on column "LoanOverdue"."LastUpdate" is '最後更新日期時間';
comment on column "LoanOverdue"."LastUpdateEmpNo" is '最後更新人員';
