drop table "JcicZ443" purge;

create table "JcicZ443" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "IsMaxMain" varchar2(1),
  "Account" nvarchar2(50),
  "GuarantyType" nvarchar2(2),
  "LoanAmt" decimal(12, 0) default 0 not null,
  "CreditAmt" decimal(12, 0) default 0 not null,
  "Principal" decimal(10, 0) default 0 not null,
  "Interest" decimal(10, 0) default 0 not null,
  "Penalty" decimal(10, 0) default 0 not null,
  "Other" decimal(10, 0) default 0 not null,
  "TerminalPayAmt" decimal(10, 0) default 0 not null,
  "LatestPayAmt" decimal(10, 0) default 0 not null,
  "FinalPayDay" decimal(8, 0) default 0 not null,
  "NotyetacQuit" decimal(10, 0) default 0 not null,
  "MothPayDay" decimal(2, 0) default 0 not null,
  "BeginDate" decimal(6, 0) default 0 not null,
  "EndDate" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ443" add constraint "JcicZ443_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode", "Account");

create index "JcicZ443_Index1" on "JcicZ443"("SubmitKey" asc);

create index "JcicZ443_Index2" on "JcicZ443"("CustId" asc);

create index "JcicZ443_Index3" on "JcicZ443"("ApplyDate" asc);

create index "JcicZ443_Index4" on "JcicZ443"("CourtCode" asc);

create index "JcicZ443_Index5" on "JcicZ443"("MaxMainCode" asc);

create index "JcicZ443_Index6" on "JcicZ443"("Account" asc);

comment on table "JcicZ443" is '前置調解回報有擔保債權金額資料';
comment on column "JcicZ443"."TranKey" is '交易代碼';
comment on column "JcicZ443"."CustId" is '債務人IDN';
comment on column "JcicZ443"."SubmitKey" is '報送單位代號';
comment on column "JcicZ443"."ApplyDate" is '調解申請日';
comment on column "JcicZ443"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ443"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ443"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ443"."Account" is '帳號';
comment on column "JcicZ443"."GuarantyType" is '擔保品類別';
comment on column "JcicZ443"."LoanAmt" is '原借款金額';
comment on column "JcicZ443"."CreditAmt" is '授信餘額';
comment on column "JcicZ443"."Principal" is '本金';
comment on column "JcicZ443"."Interest" is '利息';
comment on column "JcicZ443"."Penalty" is '違約金';
comment on column "JcicZ443"."Other" is '其他費用';
comment on column "JcicZ443"."TerminalPayAmt" is '每期應付金額';
comment on column "JcicZ443"."LatestPayAmt" is '最近一期繳款金額';
comment on column "JcicZ443"."FinalPayDay" is '最後繳息日';
comment on column "JcicZ443"."NotyetacQuit" is '已到期尚未清償金額';
comment on column "JcicZ443"."MothPayDay" is '每月應還款日';
comment on column "JcicZ443"."BeginDate" is '契約起始年月';
comment on column "JcicZ443"."EndDate" is '契約截止年月';
comment on column "JcicZ443"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ443"."Ukey" is '流水號';
comment on column "JcicZ443"."CreateDate" is '建檔日期時間';
comment on column "JcicZ443"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ443"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ443"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ443"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ443"."ActualFilingMark" is '實際報送記號';
