drop table "JcicZ040" purge;

create table "JcicZ040" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "RbDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "RefBankId" nvarchar2(3),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3),
  "JcicReportDate" decimal(8, 0) default 0 not null
);

alter table "JcicZ040" add constraint "JcicZ040_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ040_Index1" on "JcicZ040"("SubmitKey" asc);

create index "JcicZ040_Index2" on "JcicZ040"("CustId" asc);

create index "JcicZ040_Index3" on "JcicZ040"("RcDate" asc);

comment on table "JcicZ040" is '前置協商受理申請暨請求回報償權通知資料';
comment on column "JcicZ040"."TranKey" is '交易代碼';
comment on column "JcicZ040"."SubmitKey" is '報送單位代號';
comment on column "JcicZ040"."CustId" is '債務人IDN';
comment on column "JcicZ040"."RcDate" is '協商申請日';
comment on column "JcicZ040"."RbDate" is '止息基準日';
comment on column "JcicZ040"."ApplyType" is '受理方式';
comment on column "JcicZ040"."RefBankId" is '轉介金融機構代號';
comment on column "JcicZ040"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ040"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ040"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ040"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ040"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ040"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ040"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ040"."Ukey" is '流水號';
comment on column "JcicZ040"."CreateDate" is '建檔日期時間';
comment on column "JcicZ040"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ040"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ040"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ040"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ040"."ActualFilingMark" is '實際報送記號';
comment on column "JcicZ040"."JcicReportDate" is '回傳JCIC日期';
