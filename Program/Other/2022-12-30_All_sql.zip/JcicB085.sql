drop table "JcicB085" purge;

create table "JcicB085" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "RenewYM" decimal(5, 0) default 0 not null,
  "CustId" varchar2(10),
  "BefBankItem" varchar2(3),
  "BefBranchItem" varchar2(4),
  "Filler6" varchar2(2),
  "BefAcctNo" varchar2(50),
  "AftBankItem" varchar2(3),
  "AftBranchItem" varchar2(4),
  "Filler10" varchar2(2),
  "AftAcctNo" varchar2(50),
  "Filler12" varchar2(25),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB085" add constraint "JcicB085_PK" primary key("DataYM", "BefAcctNo", "AftAcctNo");

comment on table "JcicB085" is '聯徵帳號轉換資料檔';
comment on column "JcicB085"."DataYM" is '資料日期';
comment on column "JcicB085"."DataType" is '資料別';
comment on column "JcicB085"."RenewYM" is '轉換帳號年月';
comment on column "JcicB085"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB085"."BefBankItem" is '轉換前總行代號';
comment on column "JcicB085"."BefBranchItem" is '轉換前分行代號';
comment on column "JcicB085"."Filler6" is '空白';
comment on column "JcicB085"."BefAcctNo" is '轉換前帳號';
comment on column "JcicB085"."AftBankItem" is '轉換後總行代號';
comment on column "JcicB085"."AftBranchItem" is '轉換後分行代號';
comment on column "JcicB085"."Filler10" is '空白';
comment on column "JcicB085"."AftAcctNo" is '轉換後帳號';
comment on column "JcicB085"."Filler12" is '空白';
comment on column "JcicB085"."CreateDate" is '建檔日期時間';
comment on column "JcicB085"."CreateEmpNo" is '建檔人員';
comment on column "JcicB085"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB085"."LastUpdateEmpNo" is '最後更新人員';
