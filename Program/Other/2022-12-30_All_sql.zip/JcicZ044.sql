drop table "JcicZ044" purge;

create table "JcicZ044" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "DebtCode" varchar2(2),
  "NonGageAmt" decimal(9, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "ReceYearIncome" decimal(9, 0) default 0 not null,
  "ReceYear" decimal(4, 0) default 0 not null,
  "ReceYear2Income" decimal(9, 0) default 0 not null,
  "ReceYear2" decimal(4, 0) default 0 not null,
  "CurrentMonthIncome" decimal(9, 0) default 0 not null,
  "LivingCost" decimal(9, 0) default 0 not null,
  "CompName" nvarchar2(40),
  "CompId" varchar2(8),
  "CarCnt" decimal(2, 0) default 0 not null,
  "HouseCnt" decimal(2, 0) default 0 not null,
  "LandCnt" decimal(2, 0) default 0 not null,
  "ChildCnt" decimal(2, 0) default 0 not null,
  "ChildRate" decimal(5, 1) default 0 not null,
  "ParentCnt" decimal(2, 0) default 0 not null,
  "ParentRate" decimal(5, 1) default 0 not null,
  "MouthCnt" decimal(2, 0) default 0 not null,
  "MouthRate" decimal(5, 1) default 0 not null,
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ044" add constraint "JcicZ044_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ044_Index1" on "JcicZ044"("SubmitKey" asc);

create index "JcicZ044_Index2" on "JcicZ044"("CustId" asc);

create index "JcicZ044_Index3" on "JcicZ044"("RcDate" asc);

comment on table "JcicZ044" is '請求同意債務清償方案通知資料';
comment on column "JcicZ044"."TranKey" is '交易代碼';
comment on column "JcicZ044"."SubmitKey" is '報送單位代號';
comment on column "JcicZ044"."CustId" is '債務人IDN';
comment on column "JcicZ044"."RcDate" is '協商申請日';
comment on column "JcicZ044"."DebtCode" is '負債主因';
comment on column "JcicZ044"."NonGageAmt" is '無擔保金融債務協商總金額';
comment on column "JcicZ044"."Period" is '期數';
comment on column "JcicZ044"."Rate" is '利率';
comment on column "JcicZ044"."MonthPayAmt" is '協商方案估計月付金';
comment on column "JcicZ044"."ReceYearIncome" is '最近年度綜合所得總額';
comment on column "JcicZ044"."ReceYear" is '最近年度別';
comment on column "JcicZ044"."ReceYear2Income" is '前二年度綜合所得總額';
comment on column "JcicZ044"."ReceYear2" is '前二年度別';
comment on column "JcicZ044"."CurrentMonthIncome" is '目前每月收入';
comment on column "JcicZ044"."LivingCost" is '生活支出總額';
comment on column "JcicZ044"."CompName" is '目前主要所得來源公司名稱';
comment on column "JcicZ044"."CompId" is '目前主要所得公司統編';
comment on column "JcicZ044"."CarCnt" is '債務人名下車輛數量';
comment on column "JcicZ044"."HouseCnt" is '債務人名下建物筆數';
comment on column "JcicZ044"."LandCnt" is '債務人名下土地筆數';
comment on column "JcicZ044"."ChildCnt" is '撫養子女數';
comment on column "JcicZ044"."ChildRate" is '撫養子女責任比率';
comment on column "JcicZ044"."ParentCnt" is '撫養父母人數';
comment on column "JcicZ044"."ParentRate" is '撫養父母責任比率';
comment on column "JcicZ044"."MouthCnt" is '其他法定撫養人數';
comment on column "JcicZ044"."MouthRate" is '其他法定撫養人之責任比率';
comment on column "JcicZ044"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ044"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ044"."Period2" is '第二段期數';
comment on column "JcicZ044"."Rate2" is '第二階段利率';
comment on column "JcicZ044"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ044"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ044"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ044"."Ukey" is '流水號';
comment on column "JcicZ044"."CreateDate" is '建檔日期時間';
comment on column "JcicZ044"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ044"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ044"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ044"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ044"."ActualFilingMark" is '實際報送記號';
