drop table "CollRemind" purge;

create table "CollRemind" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "CondCode" varchar2(1),
  "RemindDate" decimal(8, 0) default 0 not null,
  "EditDate" decimal(8, 0) default 0 not null,
  "EditTime" varchar2(4),
  "RemindCode" varchar2(2),
  "Remark" varchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollRemind" add constraint "CollRemind_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollRemind" is '法催紀錄提醒事項檔';
comment on column "CollRemind"."CaseCode" is '案件種類';
comment on column "CollRemind"."CustNo" is '借款人戶號';
comment on column "CollRemind"."FacmNo" is '額度編號';
comment on column "CollRemind"."AcDate" is '作業日期';
comment on column "CollRemind"."TitaTlrNo" is '經辦';
comment on column "CollRemind"."TitaTxtNo" is '交易序號';
comment on column "CollRemind"."CondCode" is '狀態';
comment on column "CollRemind"."RemindDate" is '提醒日期';
comment on column "CollRemind"."EditDate" is '維護日期';
comment on column "CollRemind"."EditTime" is '維護時間';
comment on column "CollRemind"."RemindCode" is '提醒項目';
comment on column "CollRemind"."Remark" is '其他記錄';
comment on column "CollRemind"."CreateDate" is '建檔日期時間';
comment on column "CollRemind"."CreateEmpNo" is '建檔人員';
comment on column "CollRemind"."LastUpdate" is '最後更新日期時間';
comment on column "CollRemind"."LastUpdateEmpNo" is '最後更新人員';
