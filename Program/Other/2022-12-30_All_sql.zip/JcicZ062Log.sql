drop table "JcicZ062Log" purge;

create table "JcicZ062Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CompletePeriod" decimal(3, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "ChaRepayAmt" decimal(10, 0) default 0 not null,
  "ChaRepayAgreeDate" decimal(8, 0) default 0 not null,
  "ChaRepayViewDate" decimal(8, 0) default 0 not null,
  "ChaRepayEndDate" decimal(8, 0) default 0 not null,
  "ChaRepayFirstDate" decimal(8, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(76),
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "GradeType" varchar2(1),
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ062Log" add constraint "JcicZ062Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ062Log" is '金融機構無擔保債務變更還款條件協議資料';
comment on column "JcicZ062Log"."Ukey" is '流水號';
comment on column "JcicZ062Log"."TxSeq" is '交易序號';
comment on column "JcicZ062Log"."TranKey" is '交易代碼';
comment on column "JcicZ062Log"."CompletePeriod" is '變更還款條件已履約期數';
comment on column "JcicZ062Log"."Period" is '(第一階梯)期數';
comment on column "JcicZ062Log"."Rate" is '(第一階梯)利率';
comment on column "JcicZ062Log"."ExpBalanceAmt" is '信用貸款協商剩餘債務簽約餘額';
comment on column "JcicZ062Log"."CashBalanceAmt" is '現金卡協商剩餘債務簽約餘額';
comment on column "JcicZ062Log"."CreditBalanceAmt" is '信用卡協商剩餘債務簽約餘額';
comment on column "JcicZ062Log"."ChaRepayAmt" is '變更還款條件簽約總債務金額';
comment on column "JcicZ062Log"."ChaRepayAgreeDate" is '變更還款條件協議完成日';
comment on column "JcicZ062Log"."ChaRepayViewDate" is '變更還款條件面談日期';
comment on column "JcicZ062Log"."ChaRepayEndDate" is '變更還款條件簽約完成日期';
comment on column "JcicZ062Log"."ChaRepayFirstDate" is '變更還款條件首期應繳款日';
comment on column "JcicZ062Log"."PayAccount" is '繳款帳號';
comment on column "JcicZ062Log"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ062Log"."MonthPayAmt" is '月付金';
comment on column "JcicZ062Log"."GradeType" is '屬階梯式還款註記';
comment on column "JcicZ062Log"."Period2" is '第二階梯期數';
comment on column "JcicZ062Log"."Rate2" is '第二階梯利率';
comment on column "JcicZ062Log"."MonthPayAmt2" is '第二階段月付金';
comment on column "JcicZ062Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ062Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ062Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ062Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ062Log"."LastUpdateEmpNo" is '最後更新人員';
