drop table "CustMain" purge;

create table "CustMain" (
  "CustUKey" varchar2(32),
  "CustId" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CustName" nvarchar2(100),
  "Birthday" decimal(8, 0) default 0 not null,
  "Sex" varchar2(1),
  "CustTypeCode" varchar2(2),
  "IndustryCode" varchar2(6),
  "NationalityCode" varchar2(2),
  "BussNationalityCode" varchar2(2),
  "SpouseId" varchar2(10),
  "SpouseName" nvarchar2(100),
  "RegZip3" varchar2(3),
  "RegZip2" varchar2(3),
  "RegCityCode" varchar2(2),
  "RegAreaCode" varchar2(3),
  "RegRoad" nvarchar2(40),
  "RegSection" nvarchar2(5),
  "RegAlley" nvarchar2(5),
  "RegLane" nvarchar2(5),
  "RegNum" nvarchar2(5),
  "RegNumDash" nvarchar2(5),
  "RegFloor" nvarchar2(5),
  "RegFloorDash" nvarchar2(5),
  "CurrZip3" varchar2(3),
  "CurrZip2" varchar2(3),
  "CurrCityCode" varchar2(2),
  "CurrAreaCode" varchar2(3),
  "CurrRoad" nvarchar2(40),
  "CurrSection" nvarchar2(5),
  "CurrAlley" nvarchar2(5),
  "CurrLane" nvarchar2(5),
  "CurrNum" nvarchar2(5),
  "CurrNumDash" nvarchar2(5),
  "CurrFloor" nvarchar2(5),
  "CurrFloorDash" nvarchar2(5),
  "CuscCd" varchar2(1),
  "EntCode" varchar2(1),
  "EmpNo" varchar2(6),
  "EName" varchar2(50),
  "EduCode" varchar2(1),
  "OwnedHome" varchar2(1),
  "CurrCompName" nvarchar2(60),
  "CurrCompId" varchar2(8),
  "CurrCompTel" varchar2(16),
  "JobTitle" nvarchar2(20),
  "JobTenure" varchar2(2),
  "IncomeOfYearly" decimal(9, 0) default 0 not null,
  "IncomeDataDate" varchar2(6),
  "PassportNo" varchar2(20),
  "AMLJobCode" varchar2(3),
  "AMLGroup" varchar2(3),
  "IndigenousName" nvarchar2(100),
  "LastFacmNo" decimal(3, 0) default 0 not null,
  "LastSyndNo" decimal(3, 0) default 0 not null,
  "AllowInquire" varchar2(1),
  "Email" varchar2(50),
  "ActFg" decimal(1, 0) default 0 not null,
  "Introducer" varchar2(6),
  "BusinessOfficer" varchar2(6),
  "IsSuspected" varchar2(1),
  "IsSuspectedCheck" varchar2(1),
  "IsSuspectedCheckType" varchar2(1),
  "IsLimit" varchar2(1),
  "IsRelated" varchar2(1),
  "IsLnrelNear" varchar2(1),
  "IsDate" decimal(8, 0) default 0 not null,
  "DataStatus" decimal(1, 0) default 0 not null,
  "TypeCode" decimal(1, 0) default 0 not null,
  "Station" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustMain" add constraint "CustMain_PK" primary key("CustUKey");

create unique index "CustMain_Index1" on "CustMain"("CustId" asc);

create index "CustMain_Index2" on "CustMain"("CustNo" asc);

create index "CustMain_Index3" on "CustMain"("EmpNo" asc);

comment on table "CustMain" is '客戶資料主檔';
comment on column "CustMain"."CustUKey" is '客戶識別碼';
comment on column "CustMain"."CustId" is '身份證字號/統一編號';
comment on column "CustMain"."CustNo" is '戶號';
comment on column "CustMain"."BranchNo" is '單位別';
comment on column "CustMain"."CustName" is '戶名/公司名稱';
comment on column "CustMain"."Birthday" is '出生年月日/設立日期';
comment on column "CustMain"."Sex" is '性別';
comment on column "CustMain"."CustTypeCode" is '客戶別';
comment on column "CustMain"."IndustryCode" is '行業別';
comment on column "CustMain"."NationalityCode" is '自然人:出生地國籍/法人:註冊地國籍';
comment on column "CustMain"."BussNationalityCode" is '自然人:居住地國籍/法人:營業地國籍';
comment on column "CustMain"."SpouseId" is '配偶身份證號/負責人身分證';
comment on column "CustMain"."SpouseName" is '配偶姓名/負責人姓名';
comment on column "CustMain"."RegZip3" is '戶籍/公司-郵遞區號前三碼';
comment on column "CustMain"."RegZip2" is '戶籍/公司-郵遞區號後三碼';
comment on column "CustMain"."RegCityCode" is '戶籍/公司-縣市代碼';
comment on column "CustMain"."RegAreaCode" is '戶籍/公司-鄉鎮市區代碼';
comment on column "CustMain"."RegRoad" is '戶籍/公司-路名';
comment on column "CustMain"."RegSection" is '戶籍/公司-段';
comment on column "CustMain"."RegAlley" is '戶籍/公司-巷';
comment on column "CustMain"."RegLane" is '戶籍/公司-弄';
comment on column "CustMain"."RegNum" is '戶籍/公司-號';
comment on column "CustMain"."RegNumDash" is '戶籍/公司-號之';
comment on column "CustMain"."RegFloor" is '戶籍/公司-樓';
comment on column "CustMain"."RegFloorDash" is '戶籍/公司-樓之';
comment on column "CustMain"."CurrZip3" is '通訊-郵遞區號前三碼';
comment on column "CustMain"."CurrZip2" is '通訊-郵遞區號後三碼';
comment on column "CustMain"."CurrCityCode" is '通訊-縣市代碼';
comment on column "CustMain"."CurrAreaCode" is '通訊-鄉鎮市區代碼';
comment on column "CustMain"."CurrRoad" is '通訊-路名';
comment on column "CustMain"."CurrSection" is '通訊-段';
comment on column "CustMain"."CurrAlley" is '通訊-巷';
comment on column "CustMain"."CurrLane" is '通訊-弄';
comment on column "CustMain"."CurrNum" is '通訊-號';
comment on column "CustMain"."CurrNumDash" is '通訊-號之';
comment on column "CustMain"."CurrFloor" is '通訊-樓';
comment on column "CustMain"."CurrFloorDash" is '通訊-樓之';
comment on column "CustMain"."CuscCd" is '身份別';
comment on column "CustMain"."EntCode" is '企金別';
comment on column "CustMain"."EmpNo" is '員工代號';
comment on column "CustMain"."EName" is '英文姓名';
comment on column "CustMain"."EduCode" is '教育程度代號';
comment on column "CustMain"."OwnedHome" is '自有住宅有無';
comment on column "CustMain"."CurrCompName" is '任職機構名稱';
comment on column "CustMain"."CurrCompId" is '任職機構統編';
comment on column "CustMain"."CurrCompTel" is '任職機構電話';
comment on column "CustMain"."JobTitle" is '職位名稱';
comment on column "CustMain"."JobTenure" is '服務年資';
comment on column "CustMain"."IncomeOfYearly" is '年收入';
comment on column "CustMain"."IncomeDataDate" is '年收入資料年月';
comment on column "CustMain"."PassportNo" is '護照號碼';
comment on column "CustMain"."AMLJobCode" is 'AML職業別';
comment on column "CustMain"."AMLGroup" is 'AML組織';
comment on column "CustMain"."IndigenousName" is '原住民姓名';
comment on column "CustMain"."LastFacmNo" is '已編額度編號';
comment on column "CustMain"."LastSyndNo" is '已編聯貸案序號';
comment on column "CustMain"."AllowInquire" is '開放查詢';
comment on column "CustMain"."Email" is '電子信箱';
comment on column "CustMain"."ActFg" is '交易進行記號';
comment on column "CustMain"."Introducer" is '介紹人';
comment on column "CustMain"."BusinessOfficer" is '房貸專員/企金人員';
comment on column "CustMain"."IsSuspected" is '是否為金控「疑似準利害關係人」名單';
comment on column "CustMain"."IsSuspectedCheck" is '是否為金控疑似利害關係人';
comment on column "CustMain"."IsSuspectedCheckType" is '是否為金控疑似利害關係人_確認狀態';
comment on column "CustMain"."IsLimit" is '是否為授信限制對象';
comment on column "CustMain"."IsRelated" is '是否為利害關係人';
comment on column "CustMain"."IsLnrelNear" is '是否為準利害關係人';
comment on column "CustMain"."IsDate" is '是否資訊日期';
comment on column "CustMain"."DataStatus" is '資料狀態';
comment on column "CustMain"."TypeCode" is '建檔身分別';
comment on column "CustMain"."Station" is '站別';
comment on column "CustMain"."CreateDate" is '建檔日期時間';
comment on column "CustMain"."CreateEmpNo" is '建檔人員';
comment on column "CustMain"."LastUpdate" is '最後更新日期時間';
comment on column "CustMain"."LastUpdateEmpNo" is '最後更新人員';
