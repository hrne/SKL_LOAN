drop table "CdGseq" purge;

create table "CdGseq" (
  "GseqDate" decimal(8, 0) default 0 not null,
  "GseqCode" decimal(1, 0) default 0 not null,
  "GseqType" varchar2(2),
  "GseqKind" varchar2(4),
  "Offset" decimal(8, 0) default 0 not null,
  "SeqNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdGseq" add constraint "CdGseq_PK" primary key("GseqDate", "GseqCode", "GseqType", "GseqKind");

comment on table "CdGseq" is '編號編碼檔';
comment on column "CdGseq"."GseqDate" is '編號日期';
comment on column "CdGseq"."GseqCode" is '編號方式';
comment on column "CdGseq"."GseqType" is '業務類別';
comment on column "CdGseq"."GseqKind" is '交易種類';
comment on column "CdGseq"."Offset" is '有效值';
comment on column "CdGseq"."SeqNo" is '流水號';
comment on column "CdGseq"."CreateDate" is '建檔日期時間';
comment on column "CdGseq"."CreateEmpNo" is '建檔人員';
comment on column "CdGseq"."LastUpdate" is '最後更新日期時間';
comment on column "CdGseq"."LastUpdateEmpNo" is '最後更新人員';
