drop table "LoanIntDetail" purge;

create table "LoanIntDetail" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TlrNo" varchar2(6),
  "TxtNo" varchar2(8),
  "IntSeq" decimal(3, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "IntDays" decimal(5, 0) default 0 not null,
  "BreachDays" decimal(5, 0) default 0 not null,
  "MonthLimit" decimal(2, 0) default 0 not null,
  "IntFlag" decimal(1, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "Amount" decimal(16, 2) default 0 not null,
  "IntRate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "CloseBreachAmt" decimal(16, 2) default 0 not null,
  "BreachGetCode" varchar2(1),
  "LoanBal" decimal(16, 2) default 0 not null,
  "ExtraRepayFlag" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIntDetail" add constraint "LoanIntDetail_PK" primary key("CustNo", "FacmNo", "BormNo", "AcDate", "TlrNo", "TxtNo", "IntSeq");

alter table "LoanIntDetail" add constraint "LoanIntDetail_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

comment on table "LoanIntDetail" is '計息明細檔';
comment on column "LoanIntDetail"."CustNo" is '借款人戶號';
comment on column "LoanIntDetail"."FacmNo" is '額度編號';
comment on column "LoanIntDetail"."BormNo" is '撥款序號';
comment on column "LoanIntDetail"."AcDate" is '交易序號-會計日期';
comment on column "LoanIntDetail"."TlrNo" is '交易序號-櫃員別';
comment on column "LoanIntDetail"."TxtNo" is '交易序號-流水號';
comment on column "LoanIntDetail"."IntSeq" is '計息流水號';
comment on column "LoanIntDetail"."IntStartDate" is '計息起日';
comment on column "LoanIntDetail"."IntEndDate" is '計息止日';
comment on column "LoanIntDetail"."IntDays" is '計息日數';
comment on column "LoanIntDetail"."BreachDays" is '違約金日數';
comment on column "LoanIntDetail"."MonthLimit" is '當月日數';
comment on column "LoanIntDetail"."IntFlag" is '計息記號';
comment on column "LoanIntDetail"."CurrencyCode" is '幣別';
comment on column "LoanIntDetail"."Amount" is '計息本金';
comment on column "LoanIntDetail"."IntRate" is '計息利率';
comment on column "LoanIntDetail"."Principal" is '回收本金';
comment on column "LoanIntDetail"."Interest" is '利息';
comment on column "LoanIntDetail"."DelayInt" is '延滯息';
comment on column "LoanIntDetail"."BreachAmt" is '違約金';
comment on column "LoanIntDetail"."CloseBreachAmt" is '清償違約金';
comment on column "LoanIntDetail"."BreachGetCode" is '清償違約金收取方式';
comment on column "LoanIntDetail"."LoanBal" is '放款餘額';
comment on column "LoanIntDetail"."ExtraRepayFlag" is '部分償還記號';
comment on column "LoanIntDetail"."ProdNo" is '商品代碼';
comment on column "LoanIntDetail"."BaseRateCode" is '指標利率代碼';
comment on column "LoanIntDetail"."RateIncr" is '加碼利率';
comment on column "LoanIntDetail"."IndividualIncr" is '個別加碼利率';
comment on column "LoanIntDetail"."CreateDate" is '建檔日期時間';
comment on column "LoanIntDetail"."CreateEmpNo" is '建檔人員';
comment on column "LoanIntDetail"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIntDetail"."LastUpdateEmpNo" is '最後更新人員';
