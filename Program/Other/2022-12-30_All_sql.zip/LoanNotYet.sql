drop table "LoanNotYet" purge;

create table "LoanNotYet" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "NotYetCode" varchar2(2),
  "YetDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "ReMark" nvarchar2(80),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanNotYet" add constraint "LoanNotYet_PK" primary key("CustNo", "FacmNo", "NotYetCode");

alter table "LoanNotYet" add constraint "LoanNotYet_FacMain_FK1" foreign key ("CustNo", "FacmNo") references "FacMain" ("CustNo", "FacmNo") on delete cascade;

comment on table "LoanNotYet" is '未齊件管理檔';
comment on column "LoanNotYet"."CustNo" is '借款人戶號';
comment on column "LoanNotYet"."FacmNo" is '額度編號';
comment on column "LoanNotYet"."NotYetCode" is '未齊件代碼';
comment on column "LoanNotYet"."YetDate" is '齊件日期';
comment on column "LoanNotYet"."CloseDate" is '銷號日期';
comment on column "LoanNotYet"."ReMark" is '備註';
comment on column "LoanNotYet"."CreateDate" is '建檔日期時間';
comment on column "LoanNotYet"."CreateEmpNo" is '建檔人員';
comment on column "LoanNotYet"."LastUpdate" is '最後更新日期時間';
comment on column "LoanNotYet"."LastUpdateEmpNo" is '最後更新人員';
