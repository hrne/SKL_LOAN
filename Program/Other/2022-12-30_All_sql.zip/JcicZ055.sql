drop table "JcicZ055" purge;

create table "JcicZ055" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "CaseStatus" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayEndDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "IsImplement" varchar2(1),
  "InspectName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ055" add constraint "JcicZ055_PK" primary key("SubmitKey", "CustId", "CaseStatus", "ClaimDate", "CourtCode");

create index "JcicZ055_Index1" on "JcicZ055"("SubmitKey" asc);

create index "JcicZ055_Index2" on "JcicZ055"("CustId" asc);

create index "JcicZ055_Index3" on "JcicZ055"("CaseStatus" asc);

create index "JcicZ055_Index4" on "JcicZ055"("ClaimDate" asc);

create index "JcicZ055_Index5" on "JcicZ055"("CourtCode" asc);

comment on table "JcicZ055" is '消債條例更生案件資料報送';
comment on column "JcicZ055"."TranKey" is '交易代碼';
comment on column "JcicZ055"."CustId" is '債務人IDN';
comment on column "JcicZ055"."SubmitKey" is '報送單位代號';
comment on column "JcicZ055"."CaseStatus" is '案件狀態';
comment on column "JcicZ055"."ClaimDate" is '裁定日或履行完畢日或發文日';
comment on column "JcicZ055"."CourtCode" is '承審法院代碼';
comment on column "JcicZ055"."Year" is '年度別';
comment on column "JcicZ055"."CourtDiv" is '法院承審股別';
comment on column "JcicZ055"."CourtCaseNo" is '法院案號';
comment on column "JcicZ055"."PayDate" is '更生方案首期應繳款日';
comment on column "JcicZ055"."PayEndDate" is '更生方案末期應繳款日';
comment on column "JcicZ055"."Period" is '更生條件(期數)';
comment on column "JcicZ055"."Rate" is '更生條件(利率)';
comment on column "JcicZ055"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ055"."SubAmt" is '更生損失金額';
comment on column "JcicZ055"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ055"."SaveDate" is '保全處分起始日';
comment on column "JcicZ055"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ055"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ055"."IsImplement" is '是否依更生條件履行';
comment on column "JcicZ055"."InspectName" is '監督人姓名';
comment on column "JcicZ055"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ055"."Ukey" is '流水號';
comment on column "JcicZ055"."CreateDate" is '建檔日期時間';
comment on column "JcicZ055"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ055"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ055"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ055"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ055"."ActualFilingMark" is '實際報送記號';
