drop table "JcicZ044Log" purge;

create table "JcicZ044Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DebtCode" varchar2(2),
  "NonGageAmt" decimal(9, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "ReceYearIncome" decimal(9, 0) default 0 not null,
  "ReceYear" decimal(4, 0) default 0 not null,
  "ReceYear2Income" decimal(9, 0) default 0 not null,
  "ReceYear2" decimal(4, 0) default 0 not null,
  "CurrentMonthIncome" decimal(9, 0) default 0 not null,
  "LivingCost" decimal(9, 0) default 0 not null,
  "CompName" nvarchar2(40),
  "CompId" varchar2(8),
  "CarCnt" decimal(2, 0) default 0 not null,
  "HouseCnt" decimal(2, 0) default 0 not null,
  "LandCnt" decimal(2, 0) default 0 not null,
  "ChildCnt" decimal(2, 0) default 0 not null,
  "ChildRate" decimal(5, 1) default 0 not null,
  "ParentCnt" decimal(2, 0) default 0 not null,
  "ParentRate" decimal(5, 1) default 0 not null,
  "MouthCnt" decimal(2, 0) default 0 not null,
  "MouthRate" decimal(5, 1) default 0 not null,
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ044Log" add constraint "JcicZ044Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ044Log" is '請求同意債務清償方案通知資料';
comment on column "JcicZ044Log"."Ukey" is '流水號';
comment on column "JcicZ044Log"."TxSeq" is '交易序號';
comment on column "JcicZ044Log"."TranKey" is '交易代碼';
comment on column "JcicZ044Log"."DebtCode" is '負債主因';
comment on column "JcicZ044Log"."NonGageAmt" is '無擔保金融債務協商總金額';
comment on column "JcicZ044Log"."Period" is '期數';
comment on column "JcicZ044Log"."Rate" is '利率';
comment on column "JcicZ044Log"."MonthPayAmt" is '協商方案估計月付金';
comment on column "JcicZ044Log"."ReceYearIncome" is '最近年度綜合所得總額';
comment on column "JcicZ044Log"."ReceYear" is '最近年度別';
comment on column "JcicZ044Log"."ReceYear2Income" is '前二年度綜合所得總額';
comment on column "JcicZ044Log"."ReceYear2" is '前二年度別';
comment on column "JcicZ044Log"."CurrentMonthIncome" is '目前每月收入';
comment on column "JcicZ044Log"."LivingCost" is '生活支出總額';
comment on column "JcicZ044Log"."CompName" is '目前主要所得來源公司名稱';
comment on column "JcicZ044Log"."CompId" is '目前主要所得公司統編';
comment on column "JcicZ044Log"."CarCnt" is '債務人名下車輛數量';
comment on column "JcicZ044Log"."HouseCnt" is '債務人名下建物筆數';
comment on column "JcicZ044Log"."LandCnt" is '債務人名下土地筆數';
comment on column "JcicZ044Log"."ChildCnt" is '撫養子女數';
comment on column "JcicZ044Log"."ChildRate" is '撫養子女責任比率';
comment on column "JcicZ044Log"."ParentCnt" is '撫養父母人數';
comment on column "JcicZ044Log"."ParentRate" is '撫養父母責任比率';
comment on column "JcicZ044Log"."MouthCnt" is '其他法定撫養人數';
comment on column "JcicZ044Log"."MouthRate" is '其他法定撫養人之責任比率';
comment on column "JcicZ044Log"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ044Log"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ044Log"."Period2" is '第二段期數';
comment on column "JcicZ044Log"."Rate2" is '第二階段利率';
comment on column "JcicZ044Log"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ044Log"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ044Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ044Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ044Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ044Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ044Log"."LastUpdateEmpNo" is '最後更新人員';
