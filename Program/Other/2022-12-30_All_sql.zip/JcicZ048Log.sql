drop table "JcicZ048Log" purge;

create table "JcicZ048Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CustRegAddr" nvarchar2(114),
  "CustComAddr" nvarchar2(114),
  "CustRegTelNo" varchar2(16),
  "CustComTelNo" varchar2(16),
  "CustMobilNo" varchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ048Log" add constraint "JcicZ048Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ048Log" is '債務人基本資料';
comment on column "JcicZ048Log"."Ukey" is '流水號';
comment on column "JcicZ048Log"."TxSeq" is '交易序號';
comment on column "JcicZ048Log"."TranKey" is '交易代碼';
comment on column "JcicZ048Log"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ048Log"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ048Log"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ048Log"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ048Log"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ048Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ048Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ048Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ048Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ048Log"."LastUpdateEmpNo" is '最後更新人員';
