drop table "JcicZ046Log" purge;

create table "JcicZ046Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "BreakCode" varchar2(2),
  "CloseCode" varchar2(2),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ046Log" add constraint "JcicZ046Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ046Log" is '結案通知資料檔案格式';
comment on column "JcicZ046Log"."Ukey" is '流水號';
comment on column "JcicZ046Log"."TxSeq" is '交易序號';
comment on column "JcicZ046Log"."TranKey" is '交易代碼';
comment on column "JcicZ046Log"."BreakCode" is '毀諾原因代號';
comment on column "JcicZ046Log"."CloseCode" is '結案原因代號';
comment on column "JcicZ046Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ046Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ046Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ046Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ046Log"."LastUpdateEmpNo" is '最後更新人員';
