drop table "CollList" purge;

create table "CollList" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CaseCode" varchar2(1),
  "TxDate" decimal(8, 0) default 0 not null,
  "TxCode" varchar2(1),
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "OvduTerm" decimal(3, 0) default 0 not null,
  "OvduDays" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "AccCollPsn" varchar2(6),
  "LegalPsn" varchar2(6),
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "IsSpecify" varchar2(1),
  "CityCode" varchar2(2),
  "AccTelArea" varchar2(5),
  "AccTelNo" varchar2(10),
  "AccTelExt" varchar2(5),
  "LegalArea" varchar2(5),
  "LegalNo" varchar2(10),
  "LegalExt" varchar2(5),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollList" add constraint "CollList_PK" primary key("CustNo", "FacmNo");

create index "CollList_Index1" on "CollList"("CustNo" asc, "FacmNo" asc, "Status" asc);

comment on table "CollList" is '法催紀錄清單檔';
comment on column "CollList"."CustNo" is '戶號';
comment on column "CollList"."FacmNo" is '額度';
comment on column "CollList"."CaseCode" is '案件種類';
comment on column "CollList"."TxDate" is '作業日期';
comment on column "CollList"."TxCode" is '作業項目';
comment on column "CollList"."PrevIntDate" is '繳息迄日';
comment on column "CollList"."NextIntDate" is '應繳息日';
comment on column "CollList"."OvduTerm" is '逾期期數';
comment on column "CollList"."OvduDays" is '逾期天數';
comment on column "CollList"."CurrencyCode" is '幣別';
comment on column "CollList"."PrinBalance" is '本金餘額';
comment on column "CollList"."BadDebtBal" is '呆帳餘額';
comment on column "CollList"."AccCollPsn" is '催收員';
comment on column "CollList"."LegalPsn" is '法務人員';
comment on column "CollList"."Status" is '戶況';
comment on column "CollList"."AcctCode" is '業務科目代號';
comment on column "CollList"."FacAcctCode" is '額度業務科目';
comment on column "CollList"."ClCustNo" is '同擔保品戶號';
comment on column "CollList"."ClFacmNo" is '同擔保品額度';
comment on column "CollList"."ClRowNo" is '同擔保品序列號';
comment on column "CollList"."ClCode1" is '擔保品代號1';
comment on column "CollList"."ClCode2" is '擔保品代號2';
comment on column "CollList"."ClNo" is '擔保品號碼';
comment on column "CollList"."RenewCode" is '展期記號';
comment on column "CollList"."AcDate" is '會計日期';
comment on column "CollList"."IsSpecify" is '是否指定';
comment on column "CollList"."CityCode" is '擔保品地區別';
comment on column "CollList"."AccTelArea" is '催收人員電話-區碼';
comment on column "CollList"."AccTelNo" is '催收人員電話';
comment on column "CollList"."AccTelExt" is '催收人員電話-分機';
comment on column "CollList"."LegalArea" is '法務人員電話-區碼';
comment on column "CollList"."LegalNo" is '法務人員電話';
comment on column "CollList"."LegalExt" is '法務人員電話-分機';
comment on column "CollList"."CreateDate" is '建檔日期時間';
comment on column "CollList"."CreateEmpNo" is '建檔人員';
comment on column "CollList"."LastUpdate" is '最後更新日期時間';
comment on column "CollList"."LastUpdateEmpNo" is '最後更新人員';
