drop table "BankRelationCompany" purge;

create table "BankRelationCompany" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "CompanyId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationCompany" add constraint "BankRelationCompany_PK" primary key("CustName", "CustId", "CompanyId");

comment on table "BankRelationCompany" is '金控利害關係人_關係企業資料';
comment on column "BankRelationCompany"."CustName" is '借款戶所屬公司名稱';
comment on column "BankRelationCompany"."CustId" is '借款戶統編/親屬統編';
comment on column "BankRelationCompany"."CompanyId" is '關係企業統編';
comment on column "BankRelationCompany"."LAW001" is '金控法第44條';
comment on column "BankRelationCompany"."LAW002" is '金控法第44條(列項)';
comment on column "BankRelationCompany"."LAW003" is '金控法第45條';
comment on column "BankRelationCompany"."LAW005" is '保險法(放款)';
comment on column "BankRelationCompany"."LAW008" is '準利害關係人';
comment on column "BankRelationCompany"."CreateDate" is '建檔日期時間';
comment on column "BankRelationCompany"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationCompany"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationCompany"."LastUpdateEmpNo" is '最後更新人員';
