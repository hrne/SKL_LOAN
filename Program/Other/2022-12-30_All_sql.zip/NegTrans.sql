drop table "NegTrans" purge;

create table "NegTrans" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "TxStatus" decimal(1, 0) default 0 not null,
  "TxKind" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "PrincipalBal" decimal(16, 2) default 0 not null,
  "ReturnAmt" decimal(16, 2) default 0 not null,
  "SklShareAmt" decimal(16, 2) default 0 not null,
  "ApprAmt" decimal(16, 2) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ExportAcDate" decimal(8, 0) default 0 not null,
  "TempRepayAmt" decimal(16, 2) default 0 not null,
  "OverRepayAmt" decimal(16, 2) default 0 not null,
  "PrincipalAmt" decimal(16, 2) default 0 not null,
  "InterestAmt" decimal(16, 2) default 0 not null,
  "OverAmt" decimal(16, 2) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "RepayPeriod" decimal(3, 0) default 0 not null,
  "RepayDate" decimal(8, 0) default 0 not null,
  "OrgAccuOverAmt" decimal(16, 2) default 0 not null,
  "AccuOverAmt" decimal(16, 2) default 0 not null,
  "ShouldPayPeriod" decimal(3, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "ThisEntdy" decimal(8, 0) default 0 not null,
  "ThisKinbr" varchar2(4),
  "ThisTlrNo" varchar2(6),
  "ThisTxtNo" varchar2(8),
  "ThisSeqNo" varchar2(30),
  "LastEntdy" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "LastSeqNo" varchar2(30),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegTrans" add constraint "NegTrans_PK" primary key("AcDate", "TitaTlrNo", "TitaTxtNo");

create index "NegTrans_Index1" on "NegTrans"("CustNo" asc, "CaseSeq" asc, "AcDate" asc, "TitaTlrNo" asc, "TitaTxtNo" asc);

comment on table "NegTrans" is '債務協商交易檔';
comment on column "NegTrans"."AcDate" is '會計日期';
comment on column "NegTrans"."TitaTlrNo" is '經辦';
comment on column "NegTrans"."TitaTxtNo" is '交易序號';
comment on column "NegTrans"."CustNo" is '戶號';
comment on column "NegTrans"."CaseSeq" is '案件序號';
comment on column "NegTrans"."EntryDate" is '入帳日期';
comment on column "NegTrans"."TxStatus" is '交易狀態';
comment on column "NegTrans"."TxKind" is '交易別';
comment on column "NegTrans"."TxAmt" is '交易金額';
comment on column "NegTrans"."PrincipalBal" is '本金餘額';
comment on column "NegTrans"."ReturnAmt" is '退還金額';
comment on column "NegTrans"."SklShareAmt" is '新壽攤分';
comment on column "NegTrans"."ApprAmt" is '撥付金額';
comment on column "NegTrans"."ExportDate" is '撥付製檔日';
comment on column "NegTrans"."ExportAcDate" is '撥付出帳日';
comment on column "NegTrans"."TempRepayAmt" is '暫收抵繳金額';
comment on column "NegTrans"."OverRepayAmt" is '溢收抵繳金額';
comment on column "NegTrans"."PrincipalAmt" is '本金金額';
comment on column "NegTrans"."InterestAmt" is '利息金額';
comment on column "NegTrans"."OverAmt" is '轉入溢收金額';
comment on column "NegTrans"."IntStartDate" is '繳息起日';
comment on column "NegTrans"."IntEndDate" is '繳息迄日';
comment on column "NegTrans"."RepayPeriod" is '還款期數';
comment on column "NegTrans"."RepayDate" is '入帳還款日期';
comment on column "NegTrans"."OrgAccuOverAmt" is '累溢繳款(交易前)';
comment on column "NegTrans"."AccuOverAmt" is '累溢繳款(交易後)';
comment on column "NegTrans"."ShouldPayPeriod" is '本次應還期數';
comment on column "NegTrans"."DueAmt" is '期金';
comment on column "NegTrans"."ThisEntdy" is '本次交易日';
comment on column "NegTrans"."ThisKinbr" is '本次分行別';
comment on column "NegTrans"."ThisTlrNo" is '本次交易員代號';
comment on column "NegTrans"."ThisTxtNo" is '本次交易序號';
comment on column "NegTrans"."ThisSeqNo" is '本次序號';
comment on column "NegTrans"."LastEntdy" is '上次交易日';
comment on column "NegTrans"."LastKinbr" is '上次分行別';
comment on column "NegTrans"."LastTlrNo" is '上次交易員代號';
comment on column "NegTrans"."LastTxtNo" is '上次交易序號';
comment on column "NegTrans"."LastSeqNo" is '上次序號';
comment on column "NegTrans"."CreateDate" is '建檔日期時間';
comment on column "NegTrans"."CreateEmpNo" is '建檔人員';
comment on column "NegTrans"."LastUpdate" is '最後更新日期時間';
comment on column "NegTrans"."LastUpdateEmpNo" is '最後更新人員';
