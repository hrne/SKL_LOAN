drop table "JcicZ052" purge;

create table "JcicZ052" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "BankCode1" nvarchar2(3),
  "DataCode1" nvarchar2(2),
  "BankCode2" nvarchar2(3),
  "DataCode2" nvarchar2(2),
  "BankCode3" nvarchar2(3),
  "DataCode3" nvarchar2(2),
  "BankCode4" nvarchar2(3),
  "DataCode4" nvarchar2(2),
  "BankCode5" nvarchar2(3),
  "DataCode5" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ052" add constraint "JcicZ052_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ052_Index1" on "JcicZ052"("SubmitKey" asc);

create index "JcicZ052_Index2" on "JcicZ052"("CustId" asc);

create index "JcicZ052_Index3" on "JcicZ052"("RcDate" asc);

comment on table "JcicZ052" is '前置協商相關資料報送例外處理';
comment on column "JcicZ052"."TranKey" is '交易代碼';
comment on column "JcicZ052"."SubmitKey" is '報送單位代號';
comment on column "JcicZ052"."CustId" is '債務人IDN';
comment on column "JcicZ052"."RcDate" is '協商申請日';
comment on column "JcicZ052"."BankCode1" is '補報送債權機構代號1';
comment on column "JcicZ052"."DataCode1" is '補報送檔案格式資料別1';
comment on column "JcicZ052"."BankCode2" is '補報送債權機構代號2';
comment on column "JcicZ052"."DataCode2" is '補報送檔案格式資料別2';
comment on column "JcicZ052"."BankCode3" is '補報送債權機構代號3';
comment on column "JcicZ052"."DataCode3" is '補報送檔案格式資料別3';
comment on column "JcicZ052"."BankCode4" is '補報送債權機構代號4';
comment on column "JcicZ052"."DataCode4" is '補報送檔案格式資料別4';
comment on column "JcicZ052"."BankCode5" is '補報送債權機構代號5';
comment on column "JcicZ052"."DataCode5" is '補報送檔案格式資料別5';
comment on column "JcicZ052"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ052"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ052"."Ukey" is '流水號';
comment on column "JcicZ052"."CreateDate" is '建檔日期時間';
comment on column "JcicZ052"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ052"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ052"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ052"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ052"."ActualFilingMark" is '實際報送記號';
