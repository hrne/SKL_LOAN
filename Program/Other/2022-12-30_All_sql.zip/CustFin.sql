drop table "CustFin" purge;

create table "CustFin" (
  "CustUKey" varchar2(32),
  "DataYear" decimal(4, 0) default 0 not null,
  "AssetTotal" decimal(16, 2) default 0 not null,
  "Cash" decimal(16, 2) default 0 not null,
  "ShortInv" decimal(16, 2) default 0 not null,
  "AR" decimal(16, 2) default 0 not null,
  "Inventory" decimal(16, 2) default 0 not null,
  "LongInv" decimal(16, 2) default 0 not null,
  "FixedAsset" decimal(16, 2) default 0 not null,
  "OtherAsset" decimal(16, 2) default 0 not null,
  "LiabTotal" decimal(16, 2) default 0 not null,
  "BankLoan" decimal(16, 2) default 0 not null,
  "OtherCurrLiab" decimal(16, 2) default 0 not null,
  "LongLiab" decimal(16, 2) default 0 not null,
  "OtherLiab" decimal(16, 2) default 0 not null,
  "NetWorthTotal" decimal(16, 2) default 0 not null,
  "Capital" decimal(16, 2) default 0 not null,
  "RetainEarning" decimal(16, 2) default 0 not null,
  "OpIncome" decimal(16, 2) default 0 not null,
  "OpCost" decimal(16, 2) default 0 not null,
  "OpProfit" decimal(16, 2) default 0 not null,
  "OpExpense" decimal(16, 2) default 0 not null,
  "OpRevenue" decimal(16, 2) default 0 not null,
  "NopIncome" decimal(16, 2) default 0 not null,
  "FinExpense" decimal(16, 2) default 0 not null,
  "NopExpense" decimal(16, 2) default 0 not null,
  "NetIncome" decimal(16, 2) default 0 not null,
  "Accountant" nvarchar2(14),
  "AccountDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustFin" add constraint "CustFin_PK" primary key("CustUKey", "DataYear");

alter table "CustFin" add constraint "CustFin_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "CustFin_Index1" on "CustFin"("CustUKey" asc);

comment on table "CustFin" is '公司戶財務狀況檔';
comment on column "CustFin"."CustUKey" is '客戶識別碼';
comment on column "CustFin"."DataYear" is '年度';
comment on column "CustFin"."AssetTotal" is '資產總額';
comment on column "CustFin"."Cash" is '現金/銀存';
comment on column "CustFin"."ShortInv" is '短期投資';
comment on column "CustFin"."AR" is '應收帳款票據';
comment on column "CustFin"."Inventory" is '存貨';
comment on column "CustFin"."LongInv" is '長期投資';
comment on column "CustFin"."FixedAsset" is '固定資產';
comment on column "CustFin"."OtherAsset" is '其他資產';
comment on column "CustFin"."LiabTotal" is '負債總額';
comment on column "CustFin"."BankLoan" is '銀行借款';
comment on column "CustFin"."OtherCurrLiab" is '其他流動負債';
comment on column "CustFin"."LongLiab" is '長期負債';
comment on column "CustFin"."OtherLiab" is '其他負債';
comment on column "CustFin"."NetWorthTotal" is '淨值總額';
comment on column "CustFin"."Capital" is '資本';
comment on column "CustFin"."RetainEarning" is '公積保留盈餘';
comment on column "CustFin"."OpIncome" is '營業收入';
comment on column "CustFin"."OpCost" is '營業成本';
comment on column "CustFin"."OpProfit" is '營業毛利';
comment on column "CustFin"."OpExpense" is '管銷費用';
comment on column "CustFin"."OpRevenue" is '營業利益';
comment on column "CustFin"."NopIncome" is '營業外收入';
comment on column "CustFin"."FinExpense" is '財務支出';
comment on column "CustFin"."NopExpense" is '其他營業外支';
comment on column "CustFin"."NetIncome" is '稅後淨利';
comment on column "CustFin"."Accountant" is '簽證會計師';
comment on column "CustFin"."AccountDate" is '簽證日期';
comment on column "CustFin"."CreateDate" is '建檔日期時間';
comment on column "CustFin"."CreateEmpNo" is '建檔人員';
comment on column "CustFin"."LastUpdate" is '最後更新日期時間';
comment on column "CustFin"."LastUpdateEmpNo" is '最後更新人員';
