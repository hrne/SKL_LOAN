drop table "FacShareLimit" purge;

create table "FacShareLimit" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "MainApplNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "KeyinSeq" decimal(2, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "LineAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacShareLimit" add constraint "FacShareLimit_PK" primary key("ApplNo");

comment on table "FacShareLimit" is '合併額度控管資料檔';
comment on column "FacShareLimit"."ApplNo" is '核准號碼';
comment on column "FacShareLimit"."MainApplNo" is '主核准號碼(登錄順序=1)';
comment on column "FacShareLimit"."CustNo" is '戶號';
comment on column "FacShareLimit"."FacmNo" is '額度';
comment on column "FacShareLimit"."KeyinSeq" is '登錄順序(由1起編)';
comment on column "FacShareLimit"."CurrencyCode" is '幣別';
comment on column "FacShareLimit"."LineAmt" is '總額度';
comment on column "FacShareLimit"."CreateDate" is '建檔日期時間';
comment on column "FacShareLimit"."CreateEmpNo" is '建檔人員';
comment on column "FacShareLimit"."LastUpdate" is '最後更新日期時間';
comment on column "FacShareLimit"."LastUpdateEmpNo" is '最後更新人員';
