drop table "JcicZ046" purge;

create table "JcicZ046" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "CloseCode" varchar2(2),
  "BreakCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ046" add constraint "JcicZ046_PK" primary key("SubmitKey", "CustId", "RcDate", "CloseDate");

create index "JcicZ046_Index1" on "JcicZ046"("SubmitKey" asc);

create index "JcicZ046_Index2" on "JcicZ046"("CustId" asc);

create index "JcicZ046_Index3" on "JcicZ046"("RcDate" asc);

create index "JcicZ046_Index4" on "JcicZ046"("CloseDate" asc);

comment on table "JcicZ046" is '結案通知資料檔案格式';
comment on column "JcicZ046"."TranKey" is '交易代碼';
comment on column "JcicZ046"."SubmitKey" is '報送單位代號';
comment on column "JcicZ046"."CustId" is '債務人IDN';
comment on column "JcicZ046"."RcDate" is '協商申請日';
comment on column "JcicZ046"."CloseCode" is '結案原因代號';
comment on column "JcicZ046"."BreakCode" is '毀諾原因代號';
comment on column "JcicZ046"."CloseDate" is '結案日期';
comment on column "JcicZ046"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ046"."Ukey" is '流水號';
comment on column "JcicZ046"."CreateDate" is '建檔日期時間';
comment on column "JcicZ046"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ046"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ046"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ046"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ046"."ActualFilingMark" is '實際報送記號';
