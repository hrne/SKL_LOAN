drop table "JcicZ443Log" purge;

create table "JcicZ443Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsMaxMain" varchar2(1),
  "Account" nvarchar2(50),
  "GuarantyType" nvarchar2(2),
  "LoanAmt" decimal(12, 0) default 0 not null,
  "CreditAmt" decimal(12, 0) default 0 not null,
  "Principal" decimal(10, 0) default 0 not null,
  "Interest" decimal(10, 0) default 0 not null,
  "Penalty" decimal(10, 0) default 0 not null,
  "Other" decimal(10, 0) default 0 not null,
  "TerminalPayAmt" decimal(10, 0) default 0 not null,
  "LatestPayAmt" decimal(10, 0) default 0 not null,
  "FinalPayDay" decimal(8, 0) default 0 not null,
  "NotyetacQuit" decimal(10, 0) default 0 not null,
  "MothPayDay" decimal(2, 0) default 0 not null,
  "BeginDate" decimal(6, 0) default 0 not null,
  "EndDate" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ443Log" add constraint "JcicZ443Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ443Log" is '前置調解回報有擔保債權金額資料';
comment on column "JcicZ443Log"."Ukey" is '流水號';
comment on column "JcicZ443Log"."TxSeq" is '交易序號';
comment on column "JcicZ443Log"."TranKey" is '交易代碼';
comment on column "JcicZ443Log"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ443Log"."Account" is '帳號';
comment on column "JcicZ443Log"."GuarantyType" is '擔保品類別';
comment on column "JcicZ443Log"."LoanAmt" is '原借款金額';
comment on column "JcicZ443Log"."CreditAmt" is '授信餘額';
comment on column "JcicZ443Log"."Principal" is '本金';
comment on column "JcicZ443Log"."Interest" is '利息';
comment on column "JcicZ443Log"."Penalty" is '違約金';
comment on column "JcicZ443Log"."Other" is '其他費用';
comment on column "JcicZ443Log"."TerminalPayAmt" is '每期應付金額';
comment on column "JcicZ443Log"."LatestPayAmt" is '最近一期繳款金額';
comment on column "JcicZ443Log"."FinalPayDay" is '最後繳息日';
comment on column "JcicZ443Log"."NotyetacQuit" is '已到期尚未清償金額';
comment on column "JcicZ443Log"."MothPayDay" is '每月應還款日';
comment on column "JcicZ443Log"."BeginDate" is '契約起始年月';
comment on column "JcicZ443Log"."EndDate" is '契約截止年月';
comment on column "JcicZ443Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ443Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ443Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ443Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ443Log"."LastUpdateEmpNo" is '最後更新人員';
