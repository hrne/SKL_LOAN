drop table "JcicB207" purge;

create table "JcicB207" (
  "DataYM" decimal(6, 0) default 0 not null,
  "TranCode" varchar2(1),
  "BankItem" varchar2(3),
  "Filler3" varchar2(4),
  "DataDate" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "CustName" varchar2(30),
  "EName" varchar2(20),
  "Birthday" decimal(7, 0) default 0 not null,
  "RegAddr" varchar2(99),
  "CurrZip" varchar2(5),
  "CurrAddr" varchar2(99),
  "Tel" varchar2(30),
  "Mobile" varchar2(16),
  "Filler14" varchar2(5),
  "EduCode" varchar2(1),
  "OwnedHome" varchar2(1),
  "CurrCompName" varchar2(45),
  "CurrCompId" varchar2(8),
  "JobCode" varchar2(6),
  "CurrCompTel" varchar2(16),
  "JobTitle" varchar2(15),
  "JobTenure" varchar2(2),
  "IncomeOfYearly" decimal(6, 0) default 0 not null,
  "IncomeDataDate" decimal(5, 0) default 0 not null,
  "Sex" varchar2(1),
  "NationalityCode" varchar2(2),
  "PassportNo" varchar2(20),
  "PreTaxNo" varchar2(10),
  "FullCustName" varchar2(300),
  "Filler30" varchar2(36),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB207" add constraint "JcicB207_PK" primary key("DataYM", "BankItem", "CustId");

comment on table "JcicB207" is '聯徵授信戶基本資料檔';
comment on column "JcicB207"."DataYM" is '資料年月';
comment on column "JcicB207"."TranCode" is '交易代碼';
comment on column "JcicB207"."BankItem" is '總行代號';
comment on column "JcicB207"."Filler3" is '空白';
comment on column "JcicB207"."DataDate" is '資料日期';
comment on column "JcicB207"."CustId" is '授信戶IDN';
comment on column "JcicB207"."CustName" is '中文姓名';
comment on column "JcicB207"."EName" is '英文姓名';
comment on column "JcicB207"."Birthday" is '出生日期';
comment on column "JcicB207"."RegAddr" is '戶籍地址';
comment on column "JcicB207"."CurrZip" is '聯絡地址郵遞區號';
comment on column "JcicB207"."CurrAddr" is '聯絡地址';
comment on column "JcicB207"."Tel" is '聯絡電話';
comment on column "JcicB207"."Mobile" is '行動電話';
comment on column "JcicB207"."Filler14" is '空白';
comment on column "JcicB207"."EduCode" is '教育程度代號';
comment on column "JcicB207"."OwnedHome" is '自有住宅有無';
comment on column "JcicB207"."CurrCompName" is '任職機構名稱';
comment on column "JcicB207"."CurrCompId" is '任職機構統一編號';
comment on column "JcicB207"."JobCode" is '職業類別';
comment on column "JcicB207"."CurrCompTel" is '任職機構電話';
comment on column "JcicB207"."JobTitle" is '職位名稱';
comment on column "JcicB207"."JobTenure" is '服務年資';
comment on column "JcicB207"."IncomeOfYearly" is '年收入';
comment on column "JcicB207"."IncomeDataDate" is '年收入資料年月';
comment on column "JcicB207"."Sex" is '性別';
comment on column "JcicB207"."NationalityCode" is '國籍';
comment on column "JcicB207"."PassportNo" is '護照號碼';
comment on column "JcicB207"."PreTaxNo" is '舊有稅籍編號';
comment on column "JcicB207"."FullCustName" is '中文姓名超逾10個字之全名';
comment on column "JcicB207"."Filler30" is '空白';
comment on column "JcicB207"."CreateDate" is '建檔日期時間';
comment on column "JcicB207"."CreateEmpNo" is '建檔人員';
comment on column "JcicB207"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB207"."LastUpdateEmpNo" is '最後更新人員';
