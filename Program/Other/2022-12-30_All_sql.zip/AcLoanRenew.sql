drop table "AcLoanRenew" purge;

create table "AcLoanRenew" (
  "CustNo" decimal(7, 0) default 0 not null,
  "NewFacmNo" decimal(3, 0) default 0 not null,
  "NewBormNo" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "OldBormNo" decimal(3, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "MainFlag" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "OtherFields" varchar2(2000),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AcLoanRenew" add constraint "AcLoanRenew_PK" primary key("CustNo", "NewFacmNo", "NewBormNo", "OldFacmNo", "OldBormNo");

create index "AcLoanRenew_Index1" on "AcLoanRenew"("CustNo" asc, "OldFacmNo" asc, "OldBormNo" asc, "NewFacmNo" asc, "NewBormNo" asc);

comment on table "AcLoanRenew" is '會計借新還舊檔';
comment on column "AcLoanRenew"."CustNo" is '戶號';
comment on column "AcLoanRenew"."NewFacmNo" is '新額度編號';
comment on column "AcLoanRenew"."NewBormNo" is '新撥款序號';
comment on column "AcLoanRenew"."OldFacmNo" is '舊額度編號';
comment on column "AcLoanRenew"."OldBormNo" is '舊撥款序號';
comment on column "AcLoanRenew"."RenewCode" is '展期記號';
comment on column "AcLoanRenew"."MainFlag" is '主要記號';
comment on column "AcLoanRenew"."AcDate" is '會計日期';
comment on column "AcLoanRenew"."OtherFields" is '其他欄位';
comment on column "AcLoanRenew"."CreateEmpNo" is '建檔人員';
comment on column "AcLoanRenew"."CreateDate" is '建檔日期';
comment on column "AcLoanRenew"."LastUpdateEmpNo" is '最後維護人員';
comment on column "AcLoanRenew"."LastUpdate" is '最後維護日期';
