drop table "JcicZ043Log" purge;

create table "JcicZ043Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CollateralType" varchar2(2),
  "OriginLoanAmt" decimal(12, 0) default 0 not null,
  "CreditBalance" decimal(12, 0) default 0 not null,
  "PerPeriordAmt" decimal(10, 0) default 0 not null,
  "LastPayAmt" decimal(10, 0) default 0 not null,
  "LastPayDate" decimal(8, 0) default 0 not null,
  "OutstandAmt" decimal(10, 0) default 0 not null,
  "RepayPerMonDay" decimal(2, 0) default 0 not null,
  "ContractStartYM" decimal(6, 0) default 0 not null,
  "ContractEndYM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ043Log" add constraint "JcicZ043Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ043Log" is '回報有擔保債權金額資料';
comment on column "JcicZ043Log"."Ukey" is '流水號';
comment on column "JcicZ043Log"."TxSeq" is '交易序號';
comment on column "JcicZ043Log"."TranKey" is '交易代碼';
comment on column "JcicZ043Log"."CollateralType" is '擔保品類別';
comment on column "JcicZ043Log"."OriginLoanAmt" is '原借款金額';
comment on column "JcicZ043Log"."CreditBalance" is '授信餘額';
comment on column "JcicZ043Log"."PerPeriordAmt" is '每期應付金額';
comment on column "JcicZ043Log"."LastPayAmt" is '最近一期繳款金額';
comment on column "JcicZ043Log"."LastPayDate" is '最後繳息日';
comment on column "JcicZ043Log"."OutstandAmt" is '已到期尚未償還金額';
comment on column "JcicZ043Log"."RepayPerMonDay" is '每月應還款日';
comment on column "JcicZ043Log"."ContractStartYM" is '契約起始年月';
comment on column "JcicZ043Log"."ContractEndYM" is '契約截止年月';
comment on column "JcicZ043Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ043Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ043Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ043Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ043Log"."LastUpdateEmpNo" is '最後更新人員';
