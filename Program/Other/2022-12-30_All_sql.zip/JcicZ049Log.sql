drop table "JcicZ049Log" purge;

create table "JcicZ049Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ClaimStatus" decimal(1, 0) default 0 not null,
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(6),
  "CourtCaseNo" nvarchar2(20),
  "Approve" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ049Log" add constraint "JcicZ049Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ049Log" is '債務清償方案法院認可資料檔案';
comment on column "JcicZ049Log"."Ukey" is '流水號';
comment on column "JcicZ049Log"."TxSeq" is '交易序號';
comment on column "JcicZ049Log"."TranKey" is '交易代碼';
comment on column "JcicZ049Log"."ClaimStatus" is '案件進度';
comment on column "JcicZ049Log"."ApplyDate" is '遞狀日';
comment on column "JcicZ049Log"."CourtCode" is '承審法院代碼';
comment on column "JcicZ049Log"."Year" is '年度別';
comment on column "JcicZ049Log"."CourtDiv" is '法院承審股別';
comment on column "JcicZ049Log"."CourtCaseNo" is '法院案號';
comment on column "JcicZ049Log"."Approve" is '法院認可與否';
comment on column "JcicZ049Log"."ClaimDate" is '法院裁定日期';
comment on column "JcicZ049Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ049Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ049Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ049Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ049Log"."LastUpdateEmpNo" is '最後更新人員';
