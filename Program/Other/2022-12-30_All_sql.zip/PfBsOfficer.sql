drop table "PfBsOfficer" purge;

create table "PfBsOfficer" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "EmpNo" varchar2(6),
  "Fullname" varchar2(40),
  "AreaCode" varchar2(6),
  "AreaItem" nvarchar2(12),
  "DeptCode" varchar2(6),
  "DepItem" nvarchar2(12),
  "DistCode" varchar2(6),
  "DistItem" nvarchar2(30),
  "StationName" nvarchar2(30),
  "GoalAmt" decimal(16, 2) default 0 not null,
  "SmryGoalAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfBsOfficer" add constraint "PfBsOfficer_PK" primary key("WorkMonth", "EmpNo");

comment on table "PfBsOfficer" is '房貸專員業績目標檔';
comment on column "PfBsOfficer"."WorkMonth" is '年月份';
comment on column "PfBsOfficer"."EmpNo" is '員工代號';
comment on column "PfBsOfficer"."Fullname" is '員工姓名';
comment on column "PfBsOfficer"."AreaCode" is '區域中心';
comment on column "PfBsOfficer"."AreaItem" is '中心中文';
comment on column "PfBsOfficer"."DeptCode" is '部室代號';
comment on column "PfBsOfficer"."DepItem" is '部室中文';
comment on column "PfBsOfficer"."DistCode" is '區部代號';
comment on column "PfBsOfficer"."DistItem" is '區部中文';
comment on column "PfBsOfficer"."StationName" is '駐在地';
comment on column "PfBsOfficer"."GoalAmt" is '目標金額';
comment on column "PfBsOfficer"."SmryGoalAmt" is '累計目標金額';
comment on column "PfBsOfficer"."CreateDate" is '建檔日期時間';
comment on column "PfBsOfficer"."CreateEmpNo" is '建檔人員';
comment on column "PfBsOfficer"."LastUpdate" is '最後更新日期時間';
comment on column "PfBsOfficer"."LastUpdateEmpNo" is '最後更新人員';
