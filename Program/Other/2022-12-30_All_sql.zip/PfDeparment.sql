drop table "PfDeparment" purge;

create table "PfDeparment" (
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "EmpNo" varchar2(6),
  "UnitItem" nvarchar2(20),
  "DistItem" nvarchar2(20),
  "DeptItem" nvarchar2(20),
  "DirectorCode" varchar2(1),
  "EmpName" nvarchar2(8),
  "DepartOfficer" nvarchar2(8),
  "GoalCnt" decimal(4, 0) default 0 not null,
  "SumGoalCnt" decimal(16, 0) default 0 not null,
  "GoalAmt" decimal(16, 2) default 0 not null,
  "SumGoalAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfDeparment" add constraint "PfDeparment_PK" primary key("DistCode", "DeptCode", "UnitCode");

comment on table "PfDeparment" is '單位、區部、部室業績目標檔';
comment on column "PfDeparment"."UnitCode" is '單位代號';
comment on column "PfDeparment"."DistCode" is '區部代號';
comment on column "PfDeparment"."DeptCode" is '部室代號';
comment on column "PfDeparment"."EmpNo" is '員工代號';
comment on column "PfDeparment"."UnitItem" is '單位中文';
comment on column "PfDeparment"."DistItem" is '區部中文';
comment on column "PfDeparment"."DeptItem" is '部室中文';
comment on column "PfDeparment"."DirectorCode" is '處長主任別';
comment on column "PfDeparment"."EmpName" is '員工姓名';
comment on column "PfDeparment"."DepartOfficer" is '專員姓名';
comment on column "PfDeparment"."GoalCnt" is '目標件數';
comment on column "PfDeparment"."SumGoalCnt" is '累計目標件數';
comment on column "PfDeparment"."GoalAmt" is '目標金額';
comment on column "PfDeparment"."SumGoalAmt" is '累計目標金額';
comment on column "PfDeparment"."CreateDate" is '建檔日期時間';
comment on column "PfDeparment"."CreateEmpNo" is '建檔人員';
comment on column "PfDeparment"."LastUpdate" is '最後更新日期時間';
comment on column "PfDeparment"."LastUpdateEmpNo" is '最後更新人員';
