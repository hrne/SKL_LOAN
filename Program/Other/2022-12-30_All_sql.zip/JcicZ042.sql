drop table "JcicZ042" purge;

create table "JcicZ042" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ReceExpAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "ReceCashAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "ReceCreditAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ042" add constraint "JcicZ042_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode");

create index "JcicZ042_Index1" on "JcicZ042"("SubmitKey" asc);

create index "JcicZ042_Index2" on "JcicZ042"("CustId" asc);

create index "JcicZ042_Index3" on "JcicZ042"("RcDate" asc);

create index "JcicZ042_Index4" on "JcicZ042"("MaxMainCode" asc);

comment on table "JcicZ042" is '回報無擔保債權金額資料';
comment on column "JcicZ042"."TranKey" is '交易代碼';
comment on column "JcicZ042"."SubmitKey" is '報送單位代號';
comment on column "JcicZ042"."CustId" is '債務人IDN';
comment on column "JcicZ042"."RcDate" is '協商申請日';
comment on column "JcicZ042"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ042"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ042"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ042"."ExpLoanAmt" is '信用貸款對內本息餘額';
comment on column "JcicZ042"."Civil323ExpAmt" is '依民法第323條計算之信用貸款本息餘額';
comment on column "JcicZ042"."ReceExpAmt" is '信用貸款最近一期繳款金額';
comment on column "JcicZ042"."CashCardAmt" is '現金卡放款對內本息餘額';
comment on column "JcicZ042"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ042"."ReceCashAmt" is '現金卡最近一期繳款金額';
comment on column "JcicZ042"."CreditCardAmt" is '信用卡對內本息餘額';
comment on column "JcicZ042"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ042"."ReceCreditAmt" is '信用卡最近一期繳款金額';
comment on column "JcicZ042"."ReceExpPrin" is '信用貸款本金';
comment on column "JcicZ042"."ReceExpInte" is '信用貸款利息';
comment on column "JcicZ042"."ReceExpPena" is '信用貸款違約金';
comment on column "JcicZ042"."ReceExpOther" is '信用貸款其他費用';
comment on column "JcicZ042"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ042"."CashCardInte" is '信金卡利息';
comment on column "JcicZ042"."CashCardPena" is '信金卡違約金';
comment on column "JcicZ042"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ042"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ042"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ042"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ042"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ042"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ042"."Ukey" is '流水號';
comment on column "JcicZ042"."CreateDate" is '建檔日期時間';
comment on column "JcicZ042"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ042"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ042"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ042"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ042"."ActualFilingMark" is '實際報送記號';
