drop table "JcicZ041Log" purge;

create table "JcicZ041Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ScDate" decimal(8, 0) default 0 not null,
  "NegoStartDate" decimal(8, 0) default 0 not null,
  "NonFinClaimAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ041Log" add constraint "JcicZ041Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ041Log" is '協商開始暨停催通知資料';
comment on column "JcicZ041Log"."Ukey" is '流水號';
comment on column "JcicZ041Log"."TxSeq" is '交易序號';
comment on column "JcicZ041Log"."TranKey" is '交易代碼';
comment on column "JcicZ041Log"."ScDate" is '停催日期';
comment on column "JcicZ041Log"."NegoStartDate" is '協商開始日';
comment on column "JcicZ041Log"."NonFinClaimAmt" is '非金融機構債權金額';
comment on column "JcicZ041Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ041Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ041Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ041Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ041Log"."LastUpdateEmpNo" is '最後更新人員';
