drop table "CdBaseRate" purge;

create table "CdBaseRate" (
  "CurrencyCode" varchar2(3),
  "BaseRateCode" varchar2(2),
  "EffectDate" decimal(8, 0) default 0 not null,
  "BaseRate" decimal(6, 4) default 0 not null,
  "Remark" nvarchar2(40),
  "EffectFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBaseRate" add constraint "CdBaseRate_PK" primary key("CurrencyCode", "BaseRateCode", "EffectDate");

comment on table "CdBaseRate" is '指標利率檔';
comment on column "CdBaseRate"."CurrencyCode" is '幣別';
comment on column "CdBaseRate"."BaseRateCode" is '利率代碼';
comment on column "CdBaseRate"."EffectDate" is '生效日期';
comment on column "CdBaseRate"."BaseRate" is '利率';
comment on column "CdBaseRate"."Remark" is '備註';
comment on column "CdBaseRate"."EffectFlag" is '生效記號';
comment on column "CdBaseRate"."CreateDate" is '建檔日期時間';
comment on column "CdBaseRate"."CreateEmpNo" is '建檔人員';
comment on column "CdBaseRate"."LastUpdate" is '最後更新日期時間';
comment on column "CdBaseRate"."LastUpdateEmpNo" is '最後更新人員';
