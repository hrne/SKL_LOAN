drop table "JcicZ051" purge;

create table "JcicZ051" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "DelayCode" nvarchar2(1),
  "DelayYM" decimal(6, 0) default 0 not null,
  "DelayDesc" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "ActualFilingDate" decimal(8, 0) default 0 not null,
  "ActualFilingMark" varchar2(3)
);

alter table "JcicZ051" add constraint "JcicZ051_PK" primary key("SubmitKey", "CustId", "RcDate", "DelayYM");

create index "JcicZ051_Index1" on "JcicZ051"("SubmitKey" asc);

create index "JcicZ051_Index2" on "JcicZ051"("CustId" asc);

create index "JcicZ051_Index3" on "JcicZ051"("RcDate" asc);

create index "JcicZ051_Index4" on "JcicZ051"("DelayYM" asc);

comment on table "JcicZ051" is '延期繳款（喘息期）資料檔案';
comment on column "JcicZ051"."TranKey" is '交易代碼';
comment on column "JcicZ051"."SubmitKey" is '報送單位代號';
comment on column "JcicZ051"."CustId" is '債務人IDN';
comment on column "JcicZ051"."RcDate" is '協商申請日';
comment on column "JcicZ051"."DelayCode" is '延期繳款原因';
comment on column "JcicZ051"."DelayYM" is '延期繳款年月';
comment on column "JcicZ051"."DelayDesc" is '延期繳款案情說明';
comment on column "JcicZ051"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ051"."Ukey" is '流水號';
comment on column "JcicZ051"."CreateDate" is '建檔日期時間';
comment on column "JcicZ051"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ051"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ051"."LastUpdateEmpNo" is '最後更新人員';
comment on column "JcicZ051"."ActualFilingDate" is '實際報送日期';
comment on column "JcicZ051"."ActualFilingMark" is '實際報送記號';
