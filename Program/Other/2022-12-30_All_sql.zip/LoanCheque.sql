drop table "LoanCheque" purge;

create table "LoanCheque" (
  "CustNo" decimal(7, 0) default 0 not null,
  "ChequeAcct" decimal(9, 0) default 0 not null,
  "ChequeNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "ProcessCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "Kinbr" varchar2(4),
  "TellerNo" varchar2(6),
  "TxtNo" varchar2(8),
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ChequeAmt" decimal(16, 2) default 0 not null,
  "ChequeName" varchar2(60),
  "ChequeDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(2),
  "BankCode" varchar2(7),
  "BankItem" nvarchar2(50),
  "BranchItem" nvarchar2(50),
  "OutsideCode" varchar2(1),
  "BktwFlag" varchar2(1),
  "TsibFlag" varchar2(1),
  "MediaFlag" varchar2(1),
  "UsageCode" varchar2(2),
  "ServiceCenter" varchar2(1),
  "CreditorId" varchar2(10),
  "CreditorBankCode" varchar2(7),
  "OtherAcctCode" varchar2(3),
  "ReceiptNo" varchar2(5),
  "RepaidAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanCheque" add constraint "LoanCheque_PK" primary key("ChequeAcct", "ChequeNo");

comment on table "LoanCheque" is '支票檔';
comment on column "LoanCheque"."CustNo" is '借款人戶號';
comment on column "LoanCheque"."ChequeAcct" is '支票帳號';
comment on column "LoanCheque"."ChequeNo" is '支票號碼';
comment on column "LoanCheque"."StatusCode" is '票據狀況碼';
comment on column "LoanCheque"."ProcessCode" is '處理代碼';
comment on column "LoanCheque"."AcDate" is '交易序號-會計日期';
comment on column "LoanCheque"."Kinbr" is '交易單位';
comment on column "LoanCheque"."TellerNo" is '交易序號-櫃員';
comment on column "LoanCheque"."TxtNo" is '交易序號-流水號';
comment on column "LoanCheque"."ReceiveDate" is '收票日';
comment on column "LoanCheque"."EntryDate" is '入帳日';
comment on column "LoanCheque"."CurrencyCode" is '幣別';
comment on column "LoanCheque"."ChequeAmt" is '支票金額';
comment on column "LoanCheque"."ChequeName" is '發票人姓名';
comment on column "LoanCheque"."ChequeDate" is '支票到期日';
comment on column "LoanCheque"."AreaCode" is '交換區號';
comment on column "LoanCheque"."BankCode" is '行庫代號';
comment on column "LoanCheque"."BankItem" is '支票銀行';
comment on column "LoanCheque"."BranchItem" is '支票分行';
comment on column "LoanCheque"."OutsideCode" is '本埠外埠';
comment on column "LoanCheque"."BktwFlag" is '是否為台支';
comment on column "LoanCheque"."TsibFlag" is '是否為台新';
comment on column "LoanCheque"."MediaFlag" is '入媒體檔';
comment on column "LoanCheque"."UsageCode" is '支票用途';
comment on column "LoanCheque"."ServiceCenter" is '服務中心別';
comment on column "LoanCheque"."CreditorId" is '債權統一編號';
comment on column "LoanCheque"."CreditorBankCode" is '債權機構';
comment on column "LoanCheque"."OtherAcctCode" is '對方業務科目';
comment on column "LoanCheque"."ReceiptNo" is '收據號碼';
comment on column "LoanCheque"."RepaidAmt" is '已入帳金額';
comment on column "LoanCheque"."CreateDate" is '建檔日期時間';
comment on column "LoanCheque"."CreateEmpNo" is '建檔人員';
comment on column "LoanCheque"."LastUpdate" is '最後更新日期時間';
comment on column "LoanCheque"."LastUpdateEmpNo" is '最後更新人員';
