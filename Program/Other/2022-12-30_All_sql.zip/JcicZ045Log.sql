drop table "JcicZ045Log" purge;

create table "JcicZ045Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ045Log" add constraint "JcicZ045Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ045Log" is '回報是否同意債務清償方案資料';
comment on column "JcicZ045Log"."Ukey" is '流水號';
comment on column "JcicZ045Log"."TxSeq" is '交易序號';
comment on column "JcicZ045Log"."TranKey" is '交易代碼';
comment on column "JcicZ045Log"."AgreeCode" is '是否同意債務清償方案';
comment on column "JcicZ045Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ045Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ045Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ045Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ045Log"."LastUpdateEmpNo" is '最後更新人員';
