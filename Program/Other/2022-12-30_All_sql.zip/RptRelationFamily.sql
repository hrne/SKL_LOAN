drop table "RptRelationFamily" purge;

create table "RptRelationFamily" (
  "CusId" nvarchar2(20),
  "CusSCD" nvarchar2(2),
  "RlbID" nvarchar2(20),
  "RlbName" nvarchar2(40),
  "FamilyCD" nvarchar2(3),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "RlbCusCCD" nvarchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptRelationFamily" add constraint "RptRelationFamily_PK" primary key("CusId", "CusSCD", "RlbID");

comment on table "RptRelationFamily" is '報表用_金控利害關係人_關係人親屬資料';
comment on column "RptRelationFamily"."CusId" is 'CusId';
comment on column "RptRelationFamily"."CusSCD" is 'CusSCD';
comment on column "RptRelationFamily"."RlbID" is 'RlbID';
comment on column "RptRelationFamily"."RlbName" is 'RlbName';
comment on column "RptRelationFamily"."FamilyCD" is 'FamilyCD';
comment on column "RptRelationFamily"."LAW001" is 'LAW001';
comment on column "RptRelationFamily"."LAW002" is 'LAW002';
comment on column "RptRelationFamily"."LAW003" is 'LAW003';
comment on column "RptRelationFamily"."LAW004" is 'LAW004';
comment on column "RptRelationFamily"."LAW005" is 'LAW005';
comment on column "RptRelationFamily"."LAW006" is 'LAW006';
comment on column "RptRelationFamily"."LAW007" is 'LAW007';
comment on column "RptRelationFamily"."LAW008" is 'LAW008';
comment on column "RptRelationFamily"."LAW009" is 'LAW009';
comment on column "RptRelationFamily"."LAW010" is 'LAW010';
comment on column "RptRelationFamily"."RlbCusCCD" is 'RlbCusCCD';
comment on column "RptRelationFamily"."CreateDate" is '建檔日期時間';
comment on column "RptRelationFamily"."CreateEmpNo" is '建檔人員';
comment on column "RptRelationFamily"."LastUpdate" is '最後更新日期時間';
comment on column "RptRelationFamily"."LastUpdateEmpNo" is '最後更新人員';
