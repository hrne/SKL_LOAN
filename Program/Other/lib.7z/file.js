var fs = require("fs");
var path = require("path");

exports.readLines = readLines;
exports.writeLine = writeLine;

function readLines(filename) {
	var buf = fs.readFileSync(filename);

	if (buf[0] === 0xEF && buf[1] === 0xBB && buf[2] === 0xBF)
		buf = buf.slice(3);

	return buf.toString().split("\n");
}

function writeLine(filename, s) {
	/*
		fs.writeFile(filename, s, function(err) {
			if(err) console.error("[ERROR] "+err)
			else ;
		});
		*/
	fs.writeFileSync(filename, s);
	var t = fs.readFileSync(filename);
	if (s == t)
		;
	else {
		console.error("read/write " + filename + " not match");
		console.error(filename + ", write length:" + s.length);
		console.error(filename + ", read length:" + t.length);
	}
}

