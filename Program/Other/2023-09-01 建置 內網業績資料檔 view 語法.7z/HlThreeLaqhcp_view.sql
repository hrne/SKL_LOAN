CREATE VIEW HlThreeLaqhcp_VIEW AS 
SELECT "CalDate" AS CalDate
,"EmpNo" AS EmpNo
,"UnitCode" AS UnitCode
,"DistCode" AS DistCode
,"DeptCode" AS DeptCode
,"UnitName" AS UnitName
,"DistName" AS DistName
,"DeptName" AS DeptName
,"EmpName" AS EmpName
,"DepartOfficer" AS DepartOfficer
,"DirectorCode" AS DirectorCode
,"GoalNum" AS GoalNum
,"GoalAmt" AS GoalAmt
,"ActNum" AS ActNum
,"ActAmt" AS ActAmt
,"ActRate" AS ActRate
,"TGoalNum" AS TGoalNum
,"TGoalAmt" AS TGoalAmt
,"TActNum" AS TActNum
,"TActAmt" AS TActAmt
,"TActRate" AS TActRate
,"UpNo" AS UpNo
,"ProcessDate" AS ProcessDate
,"CreateDate" AS CreateDate
,"CreateEmpNo" AS CreateEmpNo
,"LastUpdate" AS LastUpdate
,"LastUpdateEmpNo" AS LastUpdateEmpNo
from "HlThreeLaqhcp"
;