
  CREATE VIEW HlAreaData_view AS 
  SELECT "AreaUnitNo"      AS AreaUnitNo
	   , "AreaName"        AS AreaName
	   , "AreaChiefEmpNo"  AS AreaChiefEmpNo
	   , "AreaChiefName"   AS AreaChiefName
	   , "CreateDate"      AS CreateDate
	   , "CreateEmpNo"     AS CreateEmpNo
	   , "LastUpdate"      AS LastUpdate
	   , "LastUpdateEmpNo" AS LastUpdateEmpNo
  FROM "HlAreaData";