CREATE VIEW HlAreaLnYg6Pt_VIEW AS
SELECT 
"WorkYM" AS WorkYM
, "AreaCode"  AS AreaCode
, "LstAppNum"  AS LstAppNum
, "LstAppAmt"  AS LstAppAmt
, "TisAppNum"  AS TisAppNum
, "TisAppAmt"  AS TisAppAmt
, "CalDate"  AS CalDate
, "UpNo"  AS UpNo
, "CreateDate"  AS CreateDate
, "CreateEmpNo"  AS CreateEmpNo
, "LastUpdate"  AS LastUpdate
, "LastUpdateEmpNo"  AS LastUpdateEmpNo
from "HlAreaLnYg6Pt"
;