CREATE VIEW HlEmpLnYg5Pt_view as
SELECT "WorkYM" AS WorkYM
	 , "EmpNo" AS EmpNo
	 , "Fullname" AS Fullname
	 , "AreaCode" AS AreaCode
	 , "AreaItem" AS AreaItem
	 , "DeptCode" AS DeptCode
	 , "DepItem" AS DepItem
	 , "DistCode" AS DistCode
	 , "DistItem" AS DistItem
	 , "StationName" AS StationName
	 , "GoalAmt" AS GoalAmt
	 , "HlAppNum" AS HlAppNum
	 , "HlAppAmt" AS HlAppAmt
	 , "ClAppNum" AS ClAppNum
	 , "ClAppAmt" AS ClAppAmt
	 , "ServiceAppNum" AS ServiceAppNum
	 , "ServiceAppAmt" AS ServiceAppAmt
	 , "CalDate" AS CalDate
	 , "UpNo" AS UpNo
	 , "CreateDate" AS CreateDate
	 , "CreateEmpNo" AS CreateEmpNo
	 , "LastUpdate" AS LastUpdate
	 , "LastUpdateEmpNo" AS LastUpdateEmpNo
from "HlEmpLnYg5Pt"
;