CREATE VIEW HlCusData_view AS
SELECT "HlCusNo" AS HlCusNo
	 , "HlCusName" AS HlCusName
	 , "ProcessDate" AS ProcessDate
	 , "CreateDate" AS CreateDate
	 , "CreateEmpNo" AS CreateEmpNo
	 , "LastUpdate" AS LastUpdate
	 , "LastUpdateEmpNo" AS LastUpdateEmpNo
from "HlCusData"
;