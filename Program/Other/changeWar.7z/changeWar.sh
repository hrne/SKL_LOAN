#!/bin/bash
# Change DEV war
java -cp /u01/app/wlserver/server/lib/weblogic.jar weblogic.Deployer \
-stop \
-targets iTX-ServerD \
-name iTX-D \
-adminmode \
-userconfigfile /home/weblogic/weblogic-WebLogicConfig.properties \
-userkeyfile /home/weblogic/weblogic-WebLogicKey.properties &&
java -cp /u01/app/wlserver/server/lib/weblogic.jar weblogic.Deployer \
-userconfigfile /home/weblogic/weblogic-WebLogicConfig.properties \
-userkeyfile /home/weblogic/weblogic-WebLogicKey.properties \
-targets iTX-ServerD \
-redeploy \
-source /home/weblogic/war/DEV/iTX.war \
-name iTX-D
# Change SIT war
java -cp /u01/app/wlserver/server/lib/weblogic.jar weblogic.Deployer \
-stop \
-targets iTX-Server \
-name iTX-Sit \
-adminmode \
-userconfigfile /home/weblogic/weblogic-WebLogicConfig.properties \
-userkeyfile /home/weblogic/weblogic-WebLogicKey.properties &&
java -cp /u01/app/wlserver/server/lib/weblogic.jar weblogic.Deployer \
-userconfigfile /home/weblogic/weblogic-WebLogicConfig.properties \
-userkeyfile /home/weblogic/weblogic-WebLogicKey.properties \
-targets iTX-Server \
-redeploy \
-source /home/weblogic/war/SIT_UAT/iTX.war \
-name iTX-Sit
# Change UAT war
java -cp /u01/app/wlserver/server/lib/weblogic.jar weblogic.Deployer \
-stop \
-targets iTX-ServerH \
-name iTX-Uat \
-adminmode \
-userconfigfile /home/weblogic/weblogic-WebLogicConfig.properties \
-userkeyfile /home/weblogic/weblogic-WebLogicKey.properties &&
java -cp /u01/app/wlserver/server/lib/weblogic.jar weblogic.Deployer \
-userconfigfile /home/weblogic/weblogic-WebLogicConfig.properties \
-userkeyfile /home/weblogic/weblogic-WebLogicKey.properties \
-targets iTX-ServerH \
-redeploy \
-source /home/weblogic/war/SIT_UAT/iTX.war \
-name iTX-Uat

