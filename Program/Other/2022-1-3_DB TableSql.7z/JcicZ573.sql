drop table "JcicZ573" purge;

create table "JcicZ573" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "TotalPayAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ573" add constraint "JcicZ573_PK" primary key("SubmitKey", "CustId", "ApplyDate", "PayDate");

create index "JcicZ573_Index1" on "JcicZ573"("SubmitKey" asc);

create index "JcicZ573_Index2" on "JcicZ573"("CustId" asc);

create index "JcicZ573_Index3" on "JcicZ573"("ApplyDate" asc);

create index "JcicZ573_Index4" on "JcicZ573"("PayDate" asc);

comment on table "JcicZ573" is '更生債務人繳款資料';
comment on column "JcicZ573"."TranKey" is '交易代碼';
comment on column "JcicZ573"."CustId" is '債務人IDN';
comment on column "JcicZ573"."SubmitKey" is '報送單位代號';
comment on column "JcicZ573"."ApplyDate" is '申請日期';
comment on column "JcicZ573"."PayDate" is '繳款日期';
comment on column "JcicZ573"."PayAmt" is '本日繳款金額';
comment on column "JcicZ573"."TotalPayAmt" is '累計繳款金額';
comment on column "JcicZ573"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ573"."Ukey" is '流水號';
comment on column "JcicZ573"."CreateDate" is '建檔日期時間';
comment on column "JcicZ573"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ573"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ573"."LastUpdateEmpNo" is '最後更新人員';
