drop table "ClFac" purge;

create table "ClFac" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ApproveNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "MainFlag" varchar2(1),
  "FacShareFlag" decimal(1, 0) default 0 not null,
  "ShareAmt" decimal(16, 2) default 0 not null,
  "OriSettingAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClFac" add constraint "ClFac_PK" primary key("ClCode1", "ClCode2", "ClNo", "ApproveNo");

alter table "ClFac" add constraint "ClFac_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

alter table "ClFac" add constraint "ClFac_FacCaseAppl_FK2" foreign key ("ApproveNo") references "FacCaseAppl" ("ApplNo") on delete cascade;

create index "ClFac_Index1" on "ClFac"("ClCode1" asc);

create index "ClFac_Index2" on "ClFac"("ClCode1" asc, "ClCode2" asc);

create index "ClFac_Index3" on "ClFac"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

create index "ClFac_Index4" on "ClFac"("ApproveNo" asc);

create index "ClFac_Index5" on "ClFac"("CustNo" asc, "FacmNo" asc);

comment on table "ClFac" is '擔保品與額度關聯檔';
comment on column "ClFac"."ClCode1" is '擔保品代號1';
comment on column "ClFac"."ClCode2" is '擔保品代號2';
comment on column "ClFac"."ClNo" is '擔保品編號';
comment on column "ClFac"."ApproveNo" is '核准號碼';
comment on column "ClFac"."CustNo" is '借款人戶號';
comment on column "ClFac"."FacmNo" is '額度編號';
comment on column "ClFac"."MainFlag" is '主要擔保品記號';
comment on column "ClFac"."FacShareFlag" is '共用額度記號';
comment on column "ClFac"."ShareAmt" is '分配金額';
comment on column "ClFac"."OriSettingAmt" is '設定金額/股數';
comment on column "ClFac"."CreateDate" is '建檔日期時間';
comment on column "ClFac"."CreateEmpNo" is '建檔人員';
comment on column "ClFac"."LastUpdate" is '最後更新日期時間';
comment on column "ClFac"."LastUpdateEmpNo" is '最後更新人員';
