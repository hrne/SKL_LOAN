drop table "JcicZ440" purge;

create table "JcicZ440" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "AgreeDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "RemindDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "ReportYn" varchar2(1),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ440" add constraint "JcicZ440_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ440_Index1" on "JcicZ440"("SubmitKey" asc);

create index "JcicZ440_Index2" on "JcicZ440"("CustId" asc);

create index "JcicZ440_Index3" on "JcicZ440"("ApplyDate" asc);

create index "JcicZ440_Index4" on "JcicZ440"("CourtCode" asc);

comment on table "JcicZ440" is '前置調解受理申請暨請求回報債權通知資料';
comment on column "JcicZ440"."TranKey" is '交易代碼';
comment on column "JcicZ440"."CustId" is '債務人IDN';
comment on column "JcicZ440"."SubmitKey" is '報送單位代號';
comment on column "JcicZ440"."ApplyDate" is '調解申請日';
comment on column "JcicZ440"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ440"."AgreeDate" is '同意書取得日期';
comment on column "JcicZ440"."StartDate" is '首次調解日';
comment on column "JcicZ440"."RemindDate" is '債權計算基準日';
comment on column "JcicZ440"."ApplyType" is '受理方式';
comment on column "JcicZ440"."ReportYn" is '協辦行是否需自行回報債權';
comment on column "JcicZ440"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ440"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ440"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ440"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ440"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ440"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ440"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ440"."Ukey" is '流水號';
comment on column "JcicZ440"."CreateDate" is '建檔日期時間';
comment on column "JcicZ440"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ440"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ440"."LastUpdateEmpNo" is '最後更新人員';
