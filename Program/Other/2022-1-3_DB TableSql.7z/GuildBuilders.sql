drop table "GuildBuilders" purge;

create table "GuildBuilders" (
  "CustNo" decimal(7, 0) default 0 not null,
  "BuilderStatus" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "GuildBuilders" add constraint "GuildBuilders_PK" primary key("CustNo");

comment on table "GuildBuilders" is '公會餘額統計建商名單檔';
comment on column "GuildBuilders"."CustNo" is '戶號';
comment on column "GuildBuilders"."BuilderStatus" is '建商狀況';
comment on column "GuildBuilders"."CreateDate" is '建檔日期時間';
comment on column "GuildBuilders"."CreateEmpNo" is '建檔人員';
comment on column "GuildBuilders"."LastUpdate" is '最後更新日期時間';
comment on column "GuildBuilders"."LastUpdateEmpNo" is '最後更新人員';
