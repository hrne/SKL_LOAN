drop table "JcicZ572Log" purge;

create table "JcicZ572Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "StartDate" decimal(8, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ572Log" add constraint "JcicZ572Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ572Log" is '受理更生款項統一收付款項分配表資料';
comment on column "JcicZ572Log"."Ukey" is '流水號';
comment on column "JcicZ572Log"."TxSeq" is '交易序號';
comment on column "JcicZ572Log"."TranKey" is '交易代碼';
comment on column "JcicZ572Log"."StartDate" is '生效日期';
comment on column "JcicZ572Log"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ572Log"."OwnPercentage" is '債權比例';
comment on column "JcicZ572Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ572Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ572Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ572Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ572Log"."LastUpdateEmpNo" is '最後更新人員';
