drop table "JcicZ056Log" purge;

create table "JcicZ056Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "Approve" varchar2(1),
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "AdminName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ056Log" add constraint "JcicZ056Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ056Log" is '清算案件資料報送';
comment on column "JcicZ056Log"."Ukey" is '流水號';
comment on column "JcicZ056Log"."TxSeq" is '交易序號';
comment on column "JcicZ056Log"."TranKey" is '交易代碼';
comment on column "JcicZ056Log"."Year" is '年度別';
comment on column "JcicZ056Log"."CourtDiv" is '法院承審股別';
comment on column "JcicZ056Log"."CourtCaseNo" is '法院案號';
comment on column "JcicZ056Log"."Approve" is '法院裁定免責確定';
comment on column "JcicZ056Log"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ056Log"."SubAmt" is '清算損失金額';
comment on column "JcicZ056Log"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ056Log"."SaveDate" is '保全處分起始日';
comment on column "JcicZ056Log"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ056Log"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ056Log"."AdminName" is '管理人姓名';
comment on column "JcicZ056Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ056Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ056Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ056Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ056Log"."LastUpdateEmpNo" is '最後更新人員';
