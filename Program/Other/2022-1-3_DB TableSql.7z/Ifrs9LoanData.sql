drop table "Ifrs9LoanData" purge;

create table "Ifrs9LoanData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "AcctCode" varchar2(3),
  "AcCode" varchar2(11),
  "AcCodeOld" varchar2(8),
  "Status" decimal(2, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "OvduDays" decimal(4, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ifrs9LoanData" add constraint "Ifrs9LoanData_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "Ifrs9LoanData" is 'IFRS9撥款資料檔';
comment on column "Ifrs9LoanData"."DataYM" is '年月份';
comment on column "Ifrs9LoanData"."CustNo" is '戶號';
comment on column "Ifrs9LoanData"."FacmNo" is '額度編號';
comment on column "Ifrs9LoanData"."BormNo" is '撥款序號';
comment on column "Ifrs9LoanData"."CustId" is '借款人ID / 統編';
comment on column "Ifrs9LoanData"."AcctCode" is '業務科目代號';
comment on column "Ifrs9LoanData"."AcCode" is '新會計科目(11碼)';
comment on column "Ifrs9LoanData"."AcCodeOld" is '舊會計科目(8碼)';
comment on column "Ifrs9LoanData"."Status" is '戶況';
comment on column "Ifrs9LoanData"."DrawdownDate" is '撥款日期';
comment on column "Ifrs9LoanData"."MaturityDate" is '到期日(撥款)';
comment on column "Ifrs9LoanData"."DrawdownAmt" is '撥款金額';
comment on column "Ifrs9LoanData"."LoanBal" is '本金餘額(撥款)';
comment on column "Ifrs9LoanData"."IntAmt" is '應收利息';
comment on column "Ifrs9LoanData"."Rate" is '利率(撥款)';
comment on column "Ifrs9LoanData"."OvduDays" is '逾期繳款天數';
comment on column "Ifrs9LoanData"."OvduDate" is '轉催收款日期';
comment on column "Ifrs9LoanData"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ifrs9LoanData"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ifrs9LoanData"."ApproveRate" is '核准利率';
comment on column "Ifrs9LoanData"."AmortizedCode" is '契約當時還款方式(月底日)';
comment on column "Ifrs9LoanData"."RateCode" is '契約當時利率調整方式(月底日)';
comment on column "Ifrs9LoanData"."RepayFreq" is '契約約定當時還本週期(月底日)';
comment on column "Ifrs9LoanData"."PayIntFreq" is '契約約定當時繳息週期(月底日)';
comment on column "Ifrs9LoanData"."FirstDueDate" is '首次應繳日';
comment on column "Ifrs9LoanData"."TotalPeriod" is '總期數';
comment on column "Ifrs9LoanData"."AgreeBefFacmNo" is '協議前之額度編號';
comment on column "Ifrs9LoanData"."AgreeBefBormNo" is '協議前之撥款序號';
comment on column "Ifrs9LoanData"."AcBookCode" is '帳冊別';
comment on column "Ifrs9LoanData"."PrevPayIntDate" is '上次繳息日(繳息迄日)';
comment on column "Ifrs9LoanData"."CreateDate" is '建檔日期時間';
comment on column "Ifrs9LoanData"."CreateEmpNo" is '建檔人員';
comment on column "Ifrs9LoanData"."LastUpdate" is '最後更新日期時間';
comment on column "Ifrs9LoanData"."LastUpdateEmpNo" is '最後更新人員';
