drop table "YearlyHouseLoanInt" purge;

create table "YearlyHouseLoanInt" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "UsageCode" varchar2(2),
  "AcctCode" varchar2(3),
  "RepayCode" varchar2(2),
  "LoanAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "YearlyInt" decimal(16, 2) default 0 not null,
  "HouseBuyDate" decimal(8, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "YearlyHouseLoanInt" add constraint "YearlyHouseLoanInt_PK" primary key("YearMonth", "CustNo", "FacmNo", "UsageCode");

comment on table "YearlyHouseLoanInt" is '每年房屋擔保借款繳息工作檔';
comment on column "YearlyHouseLoanInt"."YearMonth" is '資料年月';
comment on column "YearlyHouseLoanInt"."CustNo" is '戶號';
comment on column "YearlyHouseLoanInt"."FacmNo" is '額度編號';
comment on column "YearlyHouseLoanInt"."UsageCode" is '資金用途別';
comment on column "YearlyHouseLoanInt"."AcctCode" is '業務科目代號';
comment on column "YearlyHouseLoanInt"."RepayCode" is '繳款方式';
comment on column "YearlyHouseLoanInt"."LoanAmt" is '撥款金額';
comment on column "YearlyHouseLoanInt"."LoanBal" is '放款餘額';
comment on column "YearlyHouseLoanInt"."FirstDrawdownDate" is '初貸日';
comment on column "YearlyHouseLoanInt"."MaturityDate" is '到期日';
comment on column "YearlyHouseLoanInt"."YearlyInt" is '年度繳息金額';
comment on column "YearlyHouseLoanInt"."HouseBuyDate" is '房屋取得日期';
comment on column "YearlyHouseLoanInt"."JsonFields" is 'jason格式紀錄欄';
comment on column "YearlyHouseLoanInt"."CreateDate" is '建檔日期時間';
comment on column "YearlyHouseLoanInt"."CreateEmpNo" is '建檔人員';
comment on column "YearlyHouseLoanInt"."LastUpdate" is '最後更新日期時間';
comment on column "YearlyHouseLoanInt"."LastUpdateEmpNo" is '最後更新人員';
