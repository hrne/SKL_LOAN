drop table "JcicB095" purge;

create table "JcicB095" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "OwnerId" varchar2(10),
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "BdNo1" decimal(5, 0) default 0 not null,
  "BdNo2" decimal(3, 0) default 0 not null,
  "CityName" varchar2(36),
  "AreaName" varchar2(36),
  "Addr" varchar2(228),
  "BdMainUseCode" varchar2(1),
  "BdMtrlCode" varchar2(1),
  "BdSubUsageCode" varchar2(6),
  "TotalFloor" decimal(3, 0) default 0 not null,
  "FloorNo" varchar2(7),
  "BdDate" varchar2(7),
  "TotalArea" decimal(10, 2) default 0 not null,
  "FloorArea" decimal(10, 2) default 0 not null,
  "BdSubArea" decimal(10, 2) default 0 not null,
  "PublicArea" decimal(10, 2) default 0 not null,
  "Filler33" varchar2(44),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB095" add constraint "JcicB095_PK" primary key("DataYM", "ClActNo", "OwnerId", "CityJCICCode", "AreaJCICCode", "IrCode", "BdNo1", "BdNo2");

comment on table "JcicB095" is '聯徵不動產擔保品明細-建號附加檔';
comment on column "JcicB095"."DataYM" is '資料日期';
comment on column "JcicB095"."DataType" is '資料別';
comment on column "JcicB095"."BankItem" is '總行代號';
comment on column "JcicB095"."BranchItem" is '分行代號';
comment on column "JcicB095"."Filler4" is '空白';
comment on column "JcicB095"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB095"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB095"."CityJCICCode" is '縣市別';
comment on column "JcicB095"."AreaJCICCode" is '鄉鎮市區別';
comment on column "JcicB095"."IrCode" is '段、小段號';
comment on column "JcicB095"."BdNo1" is '建號-前五碼';
comment on column "JcicB095"."BdNo2" is '建號-後三碼';
comment on column "JcicB095"."CityName" is '縣市名稱';
comment on column "JcicB095"."AreaName" is '鄉鎮市區名稱';
comment on column "JcicB095"."Addr" is '村里/街路/段/巷/弄/號/樓';
comment on column "JcicB095"."BdMainUseCode" is '主要用途';
comment on column "JcicB095"."BdMtrlCode" is '主要建材(結構體)';
comment on column "JcicB095"."BdSubUsageCode" is '附屬建物用途';
comment on column "JcicB095"."TotalFloor" is '層數(標的所在樓高)';
comment on column "JcicB095"."FloorNo" is '層次(標的所在樓層)';
comment on column "JcicB095"."BdDate" is '建築完成日期(屋齡)';
comment on column "JcicB095"."TotalArea" is '建物總面積';
comment on column "JcicB095"."FloorArea" is '主建物(層次)面積';
comment on column "JcicB095"."BdSubArea" is '附屬建物面積';
comment on column "JcicB095"."PublicArea" is '共同部份持分面積';
comment on column "JcicB095"."Filler33" is '空白';
comment on column "JcicB095"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB095"."CreateDate" is '建檔日期時間';
comment on column "JcicB095"."CreateEmpNo" is '建檔人員';
comment on column "JcicB095"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB095"."LastUpdateEmpNo" is '最後更新人員';
