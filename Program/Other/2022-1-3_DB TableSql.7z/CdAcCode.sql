drop table "CdAcCode" purge;

create table "CdAcCode" (
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcNoItem" nvarchar2(40),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "ClassCode" decimal(1, 0) default 0 not null,
  "AcBookFlag" decimal(1, 0) default 0 not null,
  "DbCr" varchar2(1),
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "ClsChkFlag" decimal(1, 0) default 0 not null,
  "InuseFlag" decimal(1, 0) default 0 not null,
  "AcNoCodeOld" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAcCode" add constraint "CdAcCode_PK" primary key("AcNoCode", "AcSubCode", "AcDtlCode");

create index "CdAcCode_Index1" on "CdAcCode"("AcctCode" asc);

comment on table "CdAcCode" is '會計科子細目設定檔';
comment on column "CdAcCode"."AcNoCode" is '科目代號';
comment on column "CdAcCode"."AcSubCode" is '子目代號';
comment on column "CdAcCode"."AcDtlCode" is '細目代號';
comment on column "CdAcCode"."AcNoItem" is '科子細目名稱';
comment on column "CdAcCode"."AcctCode" is '業務科目代號';
comment on column "CdAcCode"."AcctItem" is '業務科目名稱';
comment on column "CdAcCode"."ClassCode" is '科子目級別';
comment on column "CdAcCode"."AcBookFlag" is '帳冊別記號';
comment on column "CdAcCode"."DbCr" is '借貸別';
comment on column "CdAcCode"."AcctFlag" is '業務科目記號';
comment on column "CdAcCode"."ReceivableFlag" is '銷帳科目記號';
comment on column "CdAcCode"."ClsChkFlag" is '日結餘額檢查記號';
comment on column "CdAcCode"."InuseFlag" is '放款部使用記號';
comment on column "CdAcCode"."AcNoCodeOld" is '舊科目代號';
comment on column "CdAcCode"."CreateDate" is '建檔日期時間';
comment on column "CdAcCode"."CreateEmpNo" is '建檔人員';
comment on column "CdAcCode"."LastUpdate" is '最後更新日期時間';
comment on column "CdAcCode"."LastUpdateEmpNo" is '最後更新人員';
