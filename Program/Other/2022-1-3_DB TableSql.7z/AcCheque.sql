drop table "AcCheque" purge;

create table "AcCheque" (
  "DataDate" decimal(8, 0) default 0 not null,
  "UnitCode" varchar2(6),
  "ChequeSeq" decimal(8, 0) default 0 not null,
  "BankNo" decimal(8, 0) default 0 not null,
  "ChequeAccount" decimal(8, 0) default 0 not null,
  "Amt" decimal(16, 2) default 0 not null,
  "ChequeDate" decimal(8, 0) default 0 not null,
  "KeyInDate" decimal(8, 0) default 0 not null,
  "ExpectedExchangeDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcCheque" add constraint "AcCheque_PK" primary key("DataDate", "UnitCode", "ChequeSeq");

comment on table "AcCheque" is '應收票據資料檔';
comment on column "AcCheque"."DataDate" is '資料年月';
comment on column "AcCheque"."UnitCode" is '入帳單位';
comment on column "AcCheque"."ChequeSeq" is '支票流水號';
comment on column "AcCheque"."BankNo" is '銀行代號';
comment on column "AcCheque"."ChequeAccount" is '支票帳號';
comment on column "AcCheque"."Amt" is '金額';
comment on column "AcCheque"."ChequeDate" is '支票日期';
comment on column "AcCheque"."KeyInDate" is '建檔日';
comment on column "AcCheque"."ExpectedExchangeDate" is '預計交換日';
comment on column "AcCheque"."CreateDate" is '建檔日期時間';
comment on column "AcCheque"."CreateEmpNo" is '建檔人員';
comment on column "AcCheque"."LastUpdate" is '最後更新日期時間';
comment on column "AcCheque"."LastUpdateEmpNo" is '最後更新人員';
