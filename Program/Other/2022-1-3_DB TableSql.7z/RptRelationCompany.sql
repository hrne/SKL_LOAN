drop table "RptRelationCompany" purge;

create table "RptRelationCompany" (
  "CusId" nvarchar2(20),
  "CusSCD" nvarchar2(2),
  "ComNo" nvarchar2(10),
  "ComName" nvarchar2(50),
  "ComCRA" nvarchar2(18),
  "STSCD" nvarchar2(2),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptRelationCompany" add constraint "RptRelationCompany_PK" primary key("CusId", "CusSCD", "ComNo", "STSCD");

comment on table "RptRelationCompany" is '報表用_金控利害關係人_關係人公司資料';
comment on column "RptRelationCompany"."CusId" is 'CusId';
comment on column "RptRelationCompany"."CusSCD" is 'CusSCD';
comment on column "RptRelationCompany"."ComNo" is 'ComNo';
comment on column "RptRelationCompany"."ComName" is 'ComName';
comment on column "RptRelationCompany"."ComCRA" is 'ComCRA';
comment on column "RptRelationCompany"."STSCD" is 'STSCD';
comment on column "RptRelationCompany"."LAW001" is 'LAW001';
comment on column "RptRelationCompany"."LAW002" is 'LAW002';
comment on column "RptRelationCompany"."LAW003" is 'LAW003';
comment on column "RptRelationCompany"."LAW004" is 'LAW004';
comment on column "RptRelationCompany"."LAW005" is 'LAW005';
comment on column "RptRelationCompany"."LAW006" is 'LAW006';
comment on column "RptRelationCompany"."LAW007" is 'LAW007';
comment on column "RptRelationCompany"."LAW008" is 'LAW008';
comment on column "RptRelationCompany"."LAW009" is 'LAW009';
comment on column "RptRelationCompany"."LAW010" is 'LAW010';
comment on column "RptRelationCompany"."CreateDate" is '建檔日期時間';
comment on column "RptRelationCompany"."CreateEmpNo" is '建檔人員';
comment on column "RptRelationCompany"."LastUpdate" is '最後更新日期時間';
comment on column "RptRelationCompany"."LastUpdateEmpNo" is '最後更新人員';
