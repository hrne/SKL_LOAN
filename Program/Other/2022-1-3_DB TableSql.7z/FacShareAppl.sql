drop table "FacShareAppl" purge;

create table "FacShareAppl" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "MainApplNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "KeyinSeq" decimal(2, 0) default 0 not null,
  "JcicMergeFlag" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacShareAppl" add constraint "FacShareAppl_PK" primary key("ApplNo");

comment on table "FacShareAppl" is '共同借款人資料檔';
comment on column "FacShareAppl"."ApplNo" is '核准號碼';
comment on column "FacShareAppl"."MainApplNo" is '主核准號碼(登錄順序=1)';
comment on column "FacShareAppl"."CustNo" is '戶號';
comment on column "FacShareAppl"."FacmNo" is '額度';
comment on column "FacShareAppl"."KeyinSeq" is '登錄順序(由1起編)';
comment on column "FacShareAppl"."JcicMergeFlag" is '是否合併申報(Y/N)';
comment on column "FacShareAppl"."CreateDate" is '建檔日期時間';
comment on column "FacShareAppl"."CreateEmpNo" is '建檔人員';
comment on column "FacShareAppl"."LastUpdate" is '最後更新日期時間';
comment on column "FacShareAppl"."LastUpdateEmpNo" is '最後更新人員';
