drop table "MlaundryDetail" purge;

create table "MlaundryDetail" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "Factor" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "TotalCnt" decimal(4, 0) default 0 not null,
  "TotalAmt" decimal(16, 2) default 0 not null,
  "Rational" varchar2(1),
  "EmpNoDesc" nvarchar2(50),
  "ManagerCheck" varchar2(1),
  "ManagerDate" decimal(8, 0) default 0 not null,
  "ManagerCheckDate" decimal(8, 0) default 0 not null,
  "ManagerDesc" nvarchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryDetail" add constraint "MlaundryDetail_PK" primary key("EntryDate", "Factor", "CustNo");

comment on table "MlaundryDetail" is '疑似洗錢交易合理性明細檔';
comment on column "MlaundryDetail"."EntryDate" is '入帳日期';
comment on column "MlaundryDetail"."Factor" is '交易樣態';
comment on column "MlaundryDetail"."CustNo" is '戶號';
comment on column "MlaundryDetail"."TotalCnt" is '累積筆數';
comment on column "MlaundryDetail"."TotalAmt" is '累積金額';
comment on column "MlaundryDetail"."Rational" is '合理性記號';
comment on column "MlaundryDetail"."EmpNoDesc" is '經辦合理性說明';
comment on column "MlaundryDetail"."ManagerCheck" is '主管覆核';
comment on column "MlaundryDetail"."ManagerDate" is '主管同意日期';
comment on column "MlaundryDetail"."ManagerCheckDate" is '主管覆核日期';
comment on column "MlaundryDetail"."ManagerDesc" is '主管覆核說明';
comment on column "MlaundryDetail"."CreateDate" is '建檔日期時間';
comment on column "MlaundryDetail"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryDetail"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryDetail"."LastUpdateEmpNo" is '最後更新人員';
