drop table "NegFinShare" purge;

create table "NegFinShare" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "FinCode" varchar2(8),
  "ContractAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegFinShare" add constraint "NegFinShare_PK" primary key("CustNo", "CaseSeq", "FinCode");

comment on table "NegFinShare" is '債務協商債權分攤檔';
comment on column "NegFinShare"."CustNo" is '債務人戶號';
comment on column "NegFinShare"."CaseSeq" is '案件序號';
comment on column "NegFinShare"."FinCode" is '債權機構';
comment on column "NegFinShare"."ContractAmt" is '簽約金額';
comment on column "NegFinShare"."AmtRatio" is '債權比例%';
comment on column "NegFinShare"."DueAmt" is '期款';
comment on column "NegFinShare"."CancelDate" is '註銷日期';
comment on column "NegFinShare"."CancelAmt" is '註銷本金';
comment on column "NegFinShare"."CreateDate" is '建檔日期時間';
comment on column "NegFinShare"."CreateEmpNo" is '建檔人員';
comment on column "NegFinShare"."LastUpdate" is '最後更新日期時間';
comment on column "NegFinShare"."LastUpdateEmpNo" is '最後更新人員';
