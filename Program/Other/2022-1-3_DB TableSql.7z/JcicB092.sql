drop table "JcicB092" purge;

create table "JcicB092" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" varchar2(9),
  "EvaDate" decimal(5, 0) default 0 not null,
  "LoanLimitAmt" varchar2(9),
  "SettingDate" decimal(5, 0) default 0 not null,
  "MonthSettingAmt" varchar2(9),
  "SettingSeq" decimal(1, 0) default 0 not null,
  "SettingAmt" varchar2(9),
  "PreSettingAmt" varchar2(9),
  "DispPrice" varchar2(9),
  "IssueEndDate" decimal(5, 0) default 0 not null,
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "LandNo1" decimal(4, 0) default 0 not null,
  "LandNo2" decimal(4, 0) default 0 not null,
  "BdNo1" decimal(5, 0) default 0 not null,
  "BdNo2" decimal(3, 0) default 0 not null,
  "Zip" varchar2(5),
  "InsuFg" varchar2(1),
  "LVITax" varchar2(9),
  "LVITaxYearMonth" varchar2(5),
  "ContractPrice" varchar2(9),
  "ContractDate" varchar2(7),
  "ParkingTypeCode" varchar2(1),
  "Area" varchar2(9),
  "LandOwnedArea" varchar2(10),
  "BdTypeCode" varchar2(2),
  "Filler33" varchar2(29),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB092" add constraint "JcicB092_PK" primary key("DataYM", "ClActNo", "ClTypeJCIC", "OwnerId", "CityJCICCode", "AreaJCICCode", "IrCode", "LandNo1", "LandNo2", "BdNo1", "BdNo2");

comment on table "JcicB092" is '聯徵不動產擔保品明細檔';
comment on column "JcicB092"."DataYM" is '資料日期';
comment on column "JcicB092"."DataType" is '資料別';
comment on column "JcicB092"."BankItem" is '總行代號';
comment on column "JcicB092"."BranchItem" is '分行代號';
comment on column "JcicB092"."Filler4" is '空白';
comment on column "JcicB092"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB092"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB092"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB092"."EvaAmt" is '鑑估(總市)值';
comment on column "JcicB092"."EvaDate" is '鑑估日期';
comment on column "JcicB092"."LoanLimitAmt" is '可放款值';
comment on column "JcicB092"."SettingDate" is '設定日期';
comment on column "JcicB092"."MonthSettingAmt" is '本行本月設定金額';
comment on column "JcicB092"."SettingSeq" is '本行設定抵押順位';
comment on column "JcicB092"."SettingAmt" is '本行累計已設定總金額';
comment on column "JcicB092"."PreSettingAmt" is '其他債權人已設定金額';
comment on column "JcicB092"."DispPrice" is '處分價格';
comment on column "JcicB092"."IssueEndDate" is '權利到期年月';
comment on column "JcicB092"."CityJCICCode" is '縣市別';
comment on column "JcicB092"."AreaJCICCode" is '鄉鎮市區別';
comment on column "JcicB092"."IrCode" is '段、小段號';
comment on column "JcicB092"."LandNo1" is '地號-前四碼';
comment on column "JcicB092"."LandNo2" is '地號-後四碼';
comment on column "JcicB092"."BdNo1" is '建號-前五碼';
comment on column "JcicB092"."BdNo2" is '建號-後三碼';
comment on column "JcicB092"."Zip" is '郵遞區號';
comment on column "JcicB092"."InsuFg" is '是否有保險';
comment on column "JcicB092"."LVITax" is '預估應計土地增值稅';
comment on column "JcicB092"."LVITaxYearMonth" is '應計土地增值稅之預估年月';
comment on column "JcicB092"."ContractPrice" is '買賣契約價格';
comment on column "JcicB092"."ContractDate" is '買賣契約日期';
comment on column "JcicB092"."ParkingTypeCode" is '停車位形式';
comment on column "JcicB092"."Area" is '車位單獨登記面積';
comment on column "JcicB092"."LandOwnedArea" is '土地持份面積';
comment on column "JcicB092"."BdTypeCode" is '建物類別';
comment on column "JcicB092"."Filler33" is '空白';
comment on column "JcicB092"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB092"."CreateDate" is '建檔日期時間';
comment on column "JcicB092"."CreateEmpNo" is '建檔人員';
comment on column "JcicB092"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB092"."LastUpdateEmpNo" is '最後更新人員';
