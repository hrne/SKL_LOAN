drop table "NegFinAcct" purge;

create table "NegFinAcct" (
  "FinCode" varchar2(8),
  "FinItem" nvarchar2(60),
  "RemitBank" varchar2(7),
  "RemitAcct" varchar2(16),
  "DataSendSection" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegFinAcct" add constraint "NegFinAcct_PK" primary key("FinCode");

comment on table "NegFinAcct" is '債務協商債權機構帳戶檔';
comment on column "NegFinAcct"."FinCode" is '債權機構代號';
comment on column "NegFinAcct"."FinItem" is '債權機構名稱';
comment on column "NegFinAcct"."RemitBank" is '匯款銀行';
comment on column "NegFinAcct"."RemitAcct" is '匯款帳號';
comment on column "NegFinAcct"."DataSendSection" is '資料傳送單位';
comment on column "NegFinAcct"."CreateDate" is '建檔日期時間';
comment on column "NegFinAcct"."CreateEmpNo" is '建檔人員';
comment on column "NegFinAcct"."LastUpdate" is '最後更新日期時間';
comment on column "NegFinAcct"."LastUpdateEmpNo" is '最後更新人員';
