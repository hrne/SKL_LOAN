drop table "CdSupv" purge;

create table "CdSupv" (
  "SupvReasonCode" varchar2(4),
  "SupvReasonItem" nvarchar2(40),
  "SupvReasonLevel" varchar2(1),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdSupv" add constraint "CdSupv_PK" primary key("SupvReasonCode");

comment on table "CdSupv" is '主管理由檔';
comment on column "CdSupv"."SupvReasonCode" is '理由代碼';
comment on column "CdSupv"."SupvReasonItem" is '理由說明';
comment on column "CdSupv"."SupvReasonLevel" is '理由階層';
comment on column "CdSupv"."Enable" is '啟用記號';
comment on column "CdSupv"."CreateDate" is '建檔日期時間';
comment on column "CdSupv"."CreateEmpNo" is '建檔人員';
comment on column "CdSupv"."LastUpdate" is '最後更新日期時間';
comment on column "CdSupv"."LastUpdateEmpNo" is '最後更新人員';
