drop table "CdBcm" purge;

create table "CdBcm" (
  "UnitCode" varchar2(6),
  "UnitItem" nvarchar2(20),
  "DeptCode" varchar2(6),
  "DeptItem" nvarchar2(20),
  "DistCode" varchar2(6),
  "DistItem" nvarchar2(20),
  "UnitManager" varchar2(6),
  "DeptManager" varchar2(6),
  "DistManager" varchar2(6),
  "ShortDeptItem" varchar2(6),
  "ShortDistItem" varchar2(6),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBcm" add constraint "CdBcm_PK" primary key("UnitCode");

create index "CdBcm_Index1" on "CdBcm"("DeptCode" asc);

create index "CdBcm_Index2" on "CdBcm"("DistCode" asc);

comment on table "CdBcm" is '分公司資料檔';
comment on column "CdBcm"."UnitCode" is '單位代號';
comment on column "CdBcm"."UnitItem" is '單位名稱';
comment on column "CdBcm"."DeptCode" is '部室代號';
comment on column "CdBcm"."DeptItem" is '部室名稱';
comment on column "CdBcm"."DistCode" is '區部代號';
comment on column "CdBcm"."DistItem" is '區部名稱';
comment on column "CdBcm"."UnitManager" is '單位經理代號';
comment on column "CdBcm"."DeptManager" is '部室經理代號';
comment on column "CdBcm"."DistManager" is '區部經理代號';
comment on column "CdBcm"."ShortDeptItem" is '部室名稱簡寫';
comment on column "CdBcm"."ShortDistItem" is '區部名稱簡寫';
comment on column "CdBcm"."Enable" is '啟用記號';
comment on column "CdBcm"."CreateDate" is '建檔日期時間';
comment on column "CdBcm"."CreateEmpNo" is '建檔人員';
comment on column "CdBcm"."LastUpdate" is '最後更新日期時間';
comment on column "CdBcm"."LastUpdateEmpNo" is '最後更新人員';
