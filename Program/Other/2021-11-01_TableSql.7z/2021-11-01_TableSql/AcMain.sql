drop table "AcMain" purge;

create table "AcMain" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcDate" decimal(8, 0) default 0 not null,
  "YdBal" decimal(16, 2) default 0 not null,
  "TdBal" decimal(16, 2) default 0 not null,
  "DbCnt" decimal(8, 0) default 0 not null,
  "DbAmt" decimal(16, 2) default 0 not null,
  "CrCnt" decimal(8, 0) default 0 not null,
  "CrAmt" decimal(16, 2) default 0 not null,
  "CoreDbCnt" decimal(8, 0) default 0 not null,
  "CoreDbAmt" decimal(16, 2) default 0 not null,
  "CoreCrCnt" decimal(8, 0) default 0 not null,
  "CoreCrAmt" decimal(16, 2) default 0 not null,
  "AcctCode" varchar2(3),
  "MonthEndYm" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcMain" add constraint "AcMain_PK" primary key("AcBookCode", "AcSubBookCode", "BranchNo", "CurrencyCode", "AcNoCode", "AcSubCode", "AcDtlCode", "AcDate");

create index "AcMain_Index1" on "AcMain"("AcBookCode" asc, "BranchNo" asc, "CurrencyCode" asc, "AcDate" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc);

create index "AcMain_Index2" on "AcMain"("AcDate" asc, "AcBookCode" asc, "BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc);

comment on table "AcMain" is '會計總帳檔';
comment on column "AcMain"."AcBookCode" is '帳冊別';
comment on column "AcMain"."AcSubBookCode" is '區隔帳冊';
comment on column "AcMain"."BranchNo" is '單位別';
comment on column "AcMain"."CurrencyCode" is '幣別';
comment on column "AcMain"."AcNoCode" is '科目代號';
comment on column "AcMain"."AcSubCode" is '子目代號';
comment on column "AcMain"."AcDtlCode" is '細目代號';
comment on column "AcMain"."AcDate" is '會計日期';
comment on column "AcMain"."YdBal" is '前日餘額';
comment on column "AcMain"."TdBal" is '本日餘額';
comment on column "AcMain"."DbCnt" is '借方筆數';
comment on column "AcMain"."DbAmt" is '借方金額';
comment on column "AcMain"."CrCnt" is '貸方筆數';
comment on column "AcMain"."CrAmt" is '貸方金額';
comment on column "AcMain"."CoreDbCnt" is '核心借方筆數';
comment on column "AcMain"."CoreDbAmt" is '核心借方金額';
comment on column "AcMain"."CoreCrCnt" is '核心貸方筆數';
comment on column "AcMain"."CoreCrAmt" is '核心貸方金額';
comment on column "AcMain"."AcctCode" is '業務科目代號';
comment on column "AcMain"."MonthEndYm" is '月底年月';
comment on column "AcMain"."CreateDate" is '建檔日期時間';
comment on column "AcMain"."CreateEmpNo" is '建檔人員';
comment on column "AcMain"."LastUpdate" is '最後更新日期時間';
comment on column "AcMain"."LastUpdateEmpNo" is '最後更新人員';
