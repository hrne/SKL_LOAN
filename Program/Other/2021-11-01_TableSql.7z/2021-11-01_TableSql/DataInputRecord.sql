drop table "DataInputRecord" purge;

create table "DataInputRecord" (
  "DataDate" decimal(8, 0) default 0 not null,
  "TableName" varchar2(30),
  "Seq" decimal(8, 0) default 0 not null,
  "InputCounts" decimal(14, 0) default 0 not null,
  "MovedFlag" varchar2(1),
  "MovedCount" decimal(14, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "DataInputRecord" add constraint "DataInputRecord_PK" primary key("DataDate", "TableName", "Seq");

comment on table "DataInputRecord" is '資料傳入記錄檔';
comment on column "DataInputRecord"."DataDate" is '資料傳輸日期';
comment on column "DataInputRecord"."TableName" is '資料表名稱';
comment on column "DataInputRecord"."Seq" is '流水號';
comment on column "DataInputRecord"."InputCounts" is '傳入筆數';
comment on column "DataInputRecord"."MovedFlag" is '是否已搬入對應資料表';
comment on column "DataInputRecord"."MovedCount" is '搬入筆數';
comment on column "DataInputRecord"."CreateDate" is '建檔日期時間';
comment on column "DataInputRecord"."CreateEmpNo" is '建檔人員';
comment on column "DataInputRecord"."LastUpdate" is '最後更新日期時間';
comment on column "DataInputRecord"."LastUpdateEmpNo" is '最後更新人員';
