drop table "JcicB204" purge;

create table "JcicB204" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "DataDate" decimal(7, 0) default 0 not null,
  "AcctNo" varchar2(50),
  "CustId" varchar2(10),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "SubTranCode" varchar2(1),
  "LineAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DBR22Amt" decimal(10, 0) default 0 not null,
  "SeqNo" varchar2(1),
  "Filler13" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB204" add constraint "JcicB204_PK" primary key("DataYMD", "BankItem", "BranchItem", "DataDate", "AcctNo", "CustId", "AcctCode", "SubAcctCode", "SubTranCode", "SeqNo");

comment on table "JcicB204" is '聯徵授信餘額日報檔';
comment on column "JcicB204"."DataYMD" is '資料日期';
comment on column "JcicB204"."BankItem" is '總行代號';
comment on column "JcicB204"."BranchItem" is '分行代號';
comment on column "JcicB204"."DataDate" is '新增核准額度日期／清償日期／額度到期或解約日期';
comment on column "JcicB204"."AcctNo" is '額度控制編碼／帳號';
comment on column "JcicB204"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB204"."AcctCode" is '科目別';
comment on column "JcicB204"."SubAcctCode" is '科目別註記';
comment on column "JcicB204"."SubTranCode" is '交易別';
comment on column "JcicB204"."LineAmt" is '訂約金額';
comment on column "JcicB204"."DrawdownAmt" is '新增核准額度當日動撥／清償金額';
comment on column "JcicB204"."DBR22Amt" is '本筆新增核准額度應計入DBR22倍規範之金額';
comment on column "JcicB204"."SeqNo" is '1~7欄資料值相同之交易序號';
comment on column "JcicB204"."Filler13" is '空白';
comment on column "JcicB204"."CreateDate" is '建檔日期時間';
comment on column "JcicB204"."CreateEmpNo" is '建檔人員';
comment on column "JcicB204"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB204"."LastUpdateEmpNo" is '最後更新人員';
