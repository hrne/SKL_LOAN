drop table "Ias34Bp" purge;

create table "Ias34Bp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LoanRate" decimal(8, 6) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Bp" add constraint "Ias34Bp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "Ias34Bp" is 'IAS34欄位清單B檔';
comment on column "Ias34Bp"."DataYM" is '年月份';
comment on column "Ias34Bp"."CustNo" is '戶號';
comment on column "Ias34Bp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Bp"."FacmNo" is '額度編號';
comment on column "Ias34Bp"."BormNo" is '撥款序號';
comment on column "Ias34Bp"."LoanRate" is '貸放利率';
comment on column "Ias34Bp"."RateCode" is '利率調整方式';
comment on column "Ias34Bp"."EffectDate" is '利率欄位生效日';
comment on column "Ias34Bp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Bp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Bp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Bp"."LastUpdateEmpNo" is '最後更新人員';
