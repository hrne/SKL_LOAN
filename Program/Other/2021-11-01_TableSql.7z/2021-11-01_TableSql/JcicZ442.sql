drop table "JcicZ442" purge;

create table "JcicZ442" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "IsMaxMain" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "Civil323GuarAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "GuarObliPrin" decimal(9, 0) default 0 not null,
  "GuarObliInte" decimal(9, 0) default 0 not null,
  "GuarObliPena" decimal(9, 0) default 0 not null,
  "GuarObliOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ442" add constraint "JcicZ442_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode");

create index "JcicZ442_Index1" on "JcicZ442"("SubmitKey" asc);

create index "JcicZ442_Index2" on "JcicZ442"("CustId" asc);

create index "JcicZ442_Index3" on "JcicZ442"("ApplyDate" asc);

create index "JcicZ442_Index4" on "JcicZ442"("CourtCode" asc);

create index "JcicZ442_Index5" on "JcicZ442"("MaxMainCode" asc);

comment on table "JcicZ442" is '前置調解回報無擔保債權金額資料';
comment on column "JcicZ442"."TranKey" is '交易代碼';
comment on column "JcicZ442"."CustId" is '債務人IDN';
comment on column "JcicZ442"."SubmitKey" is '報送單位代號';
comment on column "JcicZ442"."ApplyDate" is '調解申請日';
comment on column "JcicZ442"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ442"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ442"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ442"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ442"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ442"."Civil323ExpAmt" is '依民法第323條計算之信用放款本息餘額';
comment on column "JcicZ442"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ442"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ442"."Civil323GuarAmt" is '依民法第323條計算之保證債權本息餘額';
comment on column "JcicZ442"."ReceExpPrin" is '信用放款本金';
comment on column "JcicZ442"."ReceExpInte" is '信用放款利息';
comment on column "JcicZ442"."ReceExpPena" is '信用放款違約金';
comment on column "JcicZ442"."ReceExpOther" is '信用放款其他費用';
comment on column "JcicZ442"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ442"."CashCardInte" is '現金卡利息';
comment on column "JcicZ442"."CashCardPena" is '現金卡違約金';
comment on column "JcicZ442"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ442"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ442"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ442"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ442"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ442"."GuarObliPrin" is '保證債權本金';
comment on column "JcicZ442"."GuarObliInte" is '保證債權利息';
comment on column "JcicZ442"."GuarObliPena" is '保證債權違約金';
comment on column "JcicZ442"."GuarObliOther" is '保證債權其他費用';
comment on column "JcicZ442"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ442"."Ukey" is '流水號';
comment on column "JcicZ442"."CreateDate" is '建檔日期時間';
comment on column "JcicZ442"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ442"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ442"."LastUpdateEmpNo" is '最後更新人員';
