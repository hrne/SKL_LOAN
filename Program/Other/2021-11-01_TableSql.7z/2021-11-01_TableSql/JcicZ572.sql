drop table "JcicZ572" purge;

create table "JcicZ572" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "BankId" nvarchar2(3),
  "AllotAmt" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ572" add constraint "JcicZ572_PK" primary key("SubmitKey", "CustId", "ApplyDate", "PayDate", "BankId");

create index "JcicZ572_Index1" on "JcicZ572"("SubmitKey" asc);

create index "JcicZ572_Index2" on "JcicZ572"("CustId" asc);

create index "JcicZ572_Index3" on "JcicZ572"("ApplyDate" asc);

create index "JcicZ572_Index4" on "JcicZ572"("PayDate" asc);

create index "JcicZ572_Index5" on "JcicZ572"("BankId" asc);

comment on table "JcicZ572" is '受理更生款項統一收付款項分配表資料';
comment on column "JcicZ572"."TranKey" is '交易代碼';
comment on column "JcicZ572"."SubmitKey" is '報送單位代號';
comment on column "JcicZ572"."CustId" is '債務人IDN';
comment on column "JcicZ572"."ApplyDate" is '申請日期';
comment on column "JcicZ572"."StartDate" is '生效日期';
comment on column "JcicZ572"."PayDate" is '本分配表首繳日';
comment on column "JcicZ572"."BankId" is '債權金融機構代號';
comment on column "JcicZ572"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ572"."OwnPercentage" is '債權比例';
comment on column "JcicZ572"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ572"."Ukey" is '流水號';
comment on column "JcicZ572"."CreateDate" is '建檔日期時間';
comment on column "JcicZ572"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ572"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ572"."LastUpdateEmpNo" is '最後更新人員';
