drop table "LoanIfrsCp" purge;

create table "LoanIfrsCp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsCp" add constraint "LoanIfrsCp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "LoanIfrsCp" is 'IFRS9欄位清單3';
comment on column "LoanIfrsCp"."DataYM" is '年月份';
comment on column "LoanIfrsCp"."CustNo" is '戶號';
comment on column "LoanIfrsCp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsCp"."FacmNo" is '額度編號';
comment on column "LoanIfrsCp"."BormNo" is '撥款序號';
comment on column "LoanIfrsCp"."AmortizedCode" is '約定還款方式';
comment on column "LoanIfrsCp"."PayIntFreq" is '繳息週期';
comment on column "LoanIfrsCp"."RepayFreq" is '還本週期';
comment on column "LoanIfrsCp"."EffectDate" is '生效日期';
comment on column "LoanIfrsCp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsCp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsCp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsCp"."LastUpdateEmpNo" is '最後更新人員';
