drop table "JcicZ448Log" purge;

create table "JcicZ448Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "SignPrin" decimal(9, 0) default 0 not null,
  "SignOther" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "AcQuitAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ448Log" add constraint "JcicZ448Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ448Log" is '前置調解無擔保債務還款分配資料';
comment on column "JcicZ448Log"."Ukey" is '流水號';
comment on column "JcicZ448Log"."TxSeq" is '交易序號';
comment on column "JcicZ448Log"."TranKey" is '交易代碼';
comment on column "JcicZ448Log"."SignPrin" is '簽約金額-本金';
comment on column "JcicZ448Log"."SignOther" is '簽約金額-利息、違約金及其他費用';
comment on column "JcicZ448Log"."OwnPercentage" is '債權比例';
comment on column "JcicZ448Log"."AcQuitAmt" is '每月清償金額';
comment on column "JcicZ448Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ448Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ448Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ448Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ448Log"."LastUpdateEmpNo" is '最後更新人員';
