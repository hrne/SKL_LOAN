drop table "CdVarValue" purge;

create table "CdVarValue" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "AvailableFunds" decimal(16, 2) default 0 not null,
  "LoanTotalLmt" decimal(16, 2) default 0 not null,
  "NoGurTotalLmt" decimal(16, 2) default 0 not null,
  "Totalequity" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdVarValue" add constraint "CdVarValue_PK" primary key("YearMonth");

comment on table "CdVarValue" is '變動數值設定檔';
comment on column "CdVarValue"."YearMonth" is '年月';
comment on column "CdVarValue"."AvailableFunds" is '可運用資金';
comment on column "CdVarValue"."LoanTotalLmt" is '總借款限額';
comment on column "CdVarValue"."NoGurTotalLmt" is '無擔保限額';
comment on column "CdVarValue"."Totalequity" is '股東權益(淨值)';
comment on column "CdVarValue"."CreateDate" is '建檔日期時間';
comment on column "CdVarValue"."CreateEmpNo" is '建檔人員';
comment on column "CdVarValue"."LastUpdate" is '最後更新日期時間';
comment on column "CdVarValue"."LastUpdateEmpNo" is '最後更新人員';
