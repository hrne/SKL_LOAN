drop table "ClBuilding" purge;

create table "ClBuilding" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "Road" nvarchar2(40),
  "Section" varchar2(5),
  "Alley" varchar2(5),
  "Lane" varchar2(5),
  "Num" varchar2(5),
  "NumDash" varchar2(5),
  "Floor" varchar2(5),
  "FloorDash" varchar2(5),
  "BdNo1" varchar2(5),
  "BdNo2" varchar2(3),
  "BdLocation" nvarchar2(150),
  "BdMainUseCode" varchar2(2),
  "BdUsageCode" varchar2(1),
  "BdMtrlCode" varchar2(2),
  "BdTypeCode" varchar2(2),
  "TotalFloor" decimal(3, 0) default 0 not null,
  "FloorNo" varchar2(7),
  "FloorArea" decimal(16, 2) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "RoofStructureCode" varchar2(2),
  "BdDate" decimal(8, 0) default 0 not null,
  "BdSubUsageCode" varchar2(2),
  "BdSubArea" decimal(16, 2) default 0 not null,
  "SellerId" varchar2(10),
  "SellerName" nvarchar2(100),
  "ContractPrice" decimal(16, 2) default 0 not null,
  "ContractDate" decimal(8, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "ParkingArea" decimal(16, 2) default 0 not null,
  "ParkingProperty" varchar2(1),
  "HouseTaxNo" varchar2(12),
  "HouseBuyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClBuilding" add constraint "ClBuilding_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClBuilding" add constraint "ClBuilding_ClImm_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClImm" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClBuilding_Index1" on "ClBuilding"("ClCode1" asc);

create index "ClBuilding_Index2" on "ClBuilding"("ClCode1" asc, "ClCode2" asc);

comment on table "ClBuilding" is '擔保品不動產建物檔';
comment on column "ClBuilding"."ClCode1" is '擔保品代號1';
comment on column "ClBuilding"."ClCode2" is '擔保品代號2';
comment on column "ClBuilding"."ClNo" is '擔保品編號';
comment on column "ClBuilding"."CityCode" is '縣市';
comment on column "ClBuilding"."AreaCode" is '鄉鎮市區';
comment on column "ClBuilding"."IrCode" is '段小段代碼';
comment on column "ClBuilding"."Road" is '路名';
comment on column "ClBuilding"."Section" is '段';
comment on column "ClBuilding"."Alley" is '巷';
comment on column "ClBuilding"."Lane" is '弄';
comment on column "ClBuilding"."Num" is '號';
comment on column "ClBuilding"."NumDash" is '號之';
comment on column "ClBuilding"."Floor" is '樓';
comment on column "ClBuilding"."FloorDash" is '樓之';
comment on column "ClBuilding"."BdNo1" is '建號';
comment on column "ClBuilding"."BdNo2" is '建號(子號)';
comment on column "ClBuilding"."BdLocation" is '建物門牌';
comment on column "ClBuilding"."BdMainUseCode" is '建物主要用途';
comment on column "ClBuilding"."BdUsageCode" is '建物使用別';
comment on column "ClBuilding"."BdMtrlCode" is '建物主要建材';
comment on column "ClBuilding"."BdTypeCode" is '建物類別';
comment on column "ClBuilding"."TotalFloor" is '總樓層';
comment on column "ClBuilding"."FloorNo" is '擔保品所在樓層';
comment on column "ClBuilding"."FloorArea" is '擔保品所在樓層面積';
comment on column "ClBuilding"."EvaUnitPrice" is '鑑價單價/坪';
comment on column "ClBuilding"."RoofStructureCode" is '屋頂結構';
comment on column "ClBuilding"."BdDate" is '建築完成日期';
comment on column "ClBuilding"."BdSubUsageCode" is '附屬建物用途';
comment on column "ClBuilding"."BdSubArea" is '附屬建物面積';
comment on column "ClBuilding"."SellerId" is '賣方統編';
comment on column "ClBuilding"."SellerName" is '賣方姓名';
comment on column "ClBuilding"."ContractPrice" is '買賣契約價格';
comment on column "ClBuilding"."ContractDate" is '買賣契約日期';
comment on column "ClBuilding"."ParkingTypeCode" is '停車位形式';
comment on column "ClBuilding"."ParkingArea" is '登記面積(坪)';
comment on column "ClBuilding"."ParkingProperty" is '獨立產權車位註記';
comment on column "ClBuilding"."HouseTaxNo" is '房屋稅籍號碼';
comment on column "ClBuilding"."HouseBuyDate" is '房屋取得日期';
comment on column "ClBuilding"."CreateDate" is '建檔日期時間';
comment on column "ClBuilding"."CreateEmpNo" is '建檔人員';
comment on column "ClBuilding"."LastUpdate" is '最後更新日期時間';
comment on column "ClBuilding"."LastUpdateEmpNo" is '最後更新人員';
