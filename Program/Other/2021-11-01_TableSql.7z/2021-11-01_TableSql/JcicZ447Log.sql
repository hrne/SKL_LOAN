drop table "JcicZ447Log" purge;

create table "JcicZ447Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ447Log" add constraint "JcicZ447Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ447Log" is '前置調解金融機構無擔保債務協議資料';
comment on column "JcicZ447Log"."Ukey" is '流水號';
comment on column "JcicZ447Log"."TxSeq" is '交易序號';
comment on column "JcicZ447Log"."TranKey" is '交易代碼';
comment on column "JcicZ447Log"."Civil323Amt" is '依民法第323條計算之債務總金額';
comment on column "JcicZ447Log"."TotalAmt" is '簽約總債務金額';
comment on column "JcicZ447Log"."SignDate" is '簽約完成日期';
comment on column "JcicZ447Log"."FirstPayDate" is '首期應繳款日';
comment on column "JcicZ447Log"."Period" is '期數';
comment on column "JcicZ447Log"."Rate" is '利率';
comment on column "JcicZ447Log"."MonthPayAmt" is '月付金';
comment on column "JcicZ447Log"."PayAccount" is '繳款帳號';
comment on column "JcicZ447Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ447Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ447Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ447Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ447Log"."LastUpdateEmpNo" is '最後更新人員';
