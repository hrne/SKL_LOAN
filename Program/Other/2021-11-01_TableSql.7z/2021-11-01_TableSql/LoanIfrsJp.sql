drop table "LoanIfrsJp" purge;

create table "LoanIfrsJp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "AcDateYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "NewFacmNo" decimal(3, 0) default 0 not null,
  "NewBormNo" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "OldBormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsJp" add constraint "LoanIfrsJp_PK" primary key("DataYM", "AcDateYM", "CustNo", "NewFacmNo", "NewBormNo", "OldFacmNo", "OldBormNo");

comment on table "LoanIfrsJp" is 'IFRS9欄位清單10';
comment on column "LoanIfrsJp"."DataYM" is '年月份';
comment on column "LoanIfrsJp"."AcDateYM" is '發生時會計日期年月';
comment on column "LoanIfrsJp"."CustNo" is '戶號';
comment on column "LoanIfrsJp"."NewFacmNo" is '新額度編號';
comment on column "LoanIfrsJp"."NewBormNo" is '新撥款序號';
comment on column "LoanIfrsJp"."OldFacmNo" is '舊額度編號';
comment on column "LoanIfrsJp"."OldBormNo" is '舊撥款序號';
comment on column "LoanIfrsJp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsJp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsJp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsJp"."LastUpdateEmpNo" is '最後更新人員';
