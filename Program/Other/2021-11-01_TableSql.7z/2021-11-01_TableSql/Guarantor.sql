drop table "Guarantor" purge;

create table "Guarantor" (
  "ApproveNo" decimal(7, 0) default 0 not null,
  "GuaUKey" varchar2(32),
  "GuaRelCode" varchar2(2),
  "GuaAmt" decimal(16, 2) default 0 not null,
  "GuaTypeCode" varchar2(2),
  "GuaDate" decimal(8, 0) default 0 not null,
  "GuaStatCode" varchar2(1),
  "CancelDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Guarantor" add constraint "Guarantor_PK" primary key("ApproveNo", "GuaUKey");

alter table "Guarantor" add constraint "Guarantor_CustMain_FK1" foreign key ("GuaUKey") references "CustMain" ("CustUKey") on delete cascade;

alter table "Guarantor" add constraint "Guarantor_FacCaseAppl_FK2" foreign key ("ApproveNo") references "FacCaseAppl" ("ApplNo") on delete cascade;

create index "Guarantor_Index1" on "Guarantor"("ApproveNo" asc);

create index "Guarantor_Index2" on "Guarantor"("GuaUKey" asc);

comment on table "Guarantor" is '保證人檔';
comment on column "Guarantor"."ApproveNo" is '核准號碼';
comment on column "Guarantor"."GuaUKey" is '保證人客戶識別碼';
comment on column "Guarantor"."GuaRelCode" is '保證人關係代碼';
comment on column "Guarantor"."GuaAmt" is '保證金額';
comment on column "Guarantor"."GuaTypeCode" is '保證類別代碼';
comment on column "Guarantor"."GuaDate" is '對保日期';
comment on column "Guarantor"."GuaStatCode" is '保證狀況碼';
comment on column "Guarantor"."CancelDate" is '解除日期';
comment on column "Guarantor"."CreateDate" is '建檔日期時間';
comment on column "Guarantor"."CreateEmpNo" is '建檔人員';
comment on column "Guarantor"."LastUpdate" is '最後更新日期時間';
comment on column "Guarantor"."LastUpdateEmpNo" is '最後更新人員';
