drop table "CdInsurer" purge;

create table "CdInsurer" (
  "InsurerType" varchar2(1),
  "InsurerCode" varchar2(2),
  "InsurerId" varchar2(8),
  "InsurerItem" nvarchar2(40),
  "InsurerShort" nvarchar2(20),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdInsurer" add constraint "CdInsurer_PK" primary key("InsurerType", "InsurerCode");

comment on table "CdInsurer" is '保險公司資料檔';
comment on column "CdInsurer"."InsurerType" is '公司種類';
comment on column "CdInsurer"."InsurerCode" is '公司代號';
comment on column "CdInsurer"."InsurerId" is '公司統編';
comment on column "CdInsurer"."InsurerItem" is '公司名稱';
comment on column "CdInsurer"."InsurerShort" is '公司簡稱';
comment on column "CdInsurer"."TelArea" is '連絡電話區碼';
comment on column "CdInsurer"."TelNo" is '連絡電話號碼';
comment on column "CdInsurer"."TelExt" is '連絡電話分機號碼';
comment on column "CdInsurer"."Enable" is '啟用記號';
comment on column "CdInsurer"."CreateDate" is '建檔日期時間';
comment on column "CdInsurer"."CreateEmpNo" is '建檔人員';
comment on column "CdInsurer"."LastUpdate" is '最後更新日期時間';
comment on column "CdInsurer"."LastUpdateEmpNo" is '最後更新人員';
