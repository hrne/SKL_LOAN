drop table "TbJcicZZ50" purge;

create table "TbJcicZZ50" (
  "QryStartDate" decimal(8, 0) default 0 not null,
  "QryEndDate" decimal(8, 0) default 0 not null,
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "TbJcicZZ50" add constraint "TbJcicZZ50_PK" primary key("QryStartDate", "QryEndDate");

create index "TbJcicZZ50_Index1" on "TbJcicZZ50"("QryStartDate" asc);

create index "TbJcicZZ50_Index2" on "TbJcicZZ50"("QryEndDate" asc);

comment on table "TbJcicZZ50" is '會員查詢紀錄查詢';
comment on column "TbJcicZZ50"."QryStartDate" is '查詢開始日';
comment on column "TbJcicZZ50"."QryEndDate" is '查詢結束日';
comment on column "TbJcicZZ50"."OutJcictxtDate" is '轉出JCIC文字檔日期';
comment on column "TbJcicZZ50"."CreateDate" is '建檔日期時間';
comment on column "TbJcicZZ50"."CreateEmpNo" is '建檔人員';
comment on column "TbJcicZZ50"."LastUpdate" is '最後更新日期時間';
comment on column "TbJcicZZ50"."LastUpdateEmpNo" is '最後更新人員';
