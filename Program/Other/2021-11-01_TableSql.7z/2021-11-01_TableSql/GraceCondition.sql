drop table "GraceCondition" purge;

create table "GraceCondition" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ActUse" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "GraceCondition" add constraint "GraceCondition_PK" primary key("CustNo", "FacmNo");

comment on table "GraceCondition" is '寬限條件控管繳息檔';
comment on column "GraceCondition"."CustNo" is '借款人戶號';
comment on column "GraceCondition"."FacmNo" is '額度編號';
comment on column "GraceCondition"."ActUse" is '使用碼';
comment on column "GraceCondition"."CreateDate" is '建檔日期時間';
comment on column "GraceCondition"."CreateEmpNo" is '建檔人員';
comment on column "GraceCondition"."LastUpdate" is '最後更新日期時間';
comment on column "GraceCondition"."LastUpdateEmpNo" is '最後更新人員';
