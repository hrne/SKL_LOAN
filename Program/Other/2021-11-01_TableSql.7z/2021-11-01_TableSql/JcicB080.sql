drop table "JcicB080" purge;

create table "JcicB080" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "Filler4" varchar2(4),
  "CustId" varchar2(10),
  "FacmNo" varchar2(50),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmtFx" decimal(10, 0) default 0 not null,
  "DrawdownDate" decimal(5, 0) default 0 not null,
  "MaturityDate" decimal(5, 0) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "UpFacmNo" varchar2(50),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "ClTypeCode" varchar2(2),
  "Filler18" varchar2(24),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB080" add constraint "JcicB080_PK" primary key("DataYM", "BankItem", "FacmNo");

comment on table "JcicB080" is '聯徵授信額度資料檔';
comment on column "JcicB080"."DataYM" is '資料年月';
comment on column "JcicB080"."DataType" is '資料別';
comment on column "JcicB080"."BankItem" is '總行代號';
comment on column "JcicB080"."BranchItem" is '分行代號';
comment on column "JcicB080"."TranCode" is '交易代碼';
comment on column "JcicB080"."Filler4" is '空白';
comment on column "JcicB080"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB080"."FacmNo" is '本階共用額度控制編碼';
comment on column "JcicB080"."CurrencyCode" is '授信幣別';
comment on column "JcicB080"."DrawdownAmt" is '本階訂約金額(台幣)';
comment on column "JcicB080"."DrawdownAmtFx" is '本階訂約金額(外幣)';
comment on column "JcicB080"."DrawdownDate" is '本階額度開始年月';
comment on column "JcicB080"."MaturityDate" is '本階額度約定截止年月';
comment on column "JcicB080"."RecycleCode" is '循環信用註記';
comment on column "JcicB080"."IrrevocableFlag" is '額度可否撤銷';
comment on column "JcicB080"."UpFacmNo" is '上階共用額度控制編碼';
comment on column "JcicB080"."AcctCode" is '科目別';
comment on column "JcicB080"."SubAcctCode" is '科目別註記';
comment on column "JcicB080"."ClTypeCode" is '擔保品類別';
comment on column "JcicB080"."Filler18" is '空白';
comment on column "JcicB080"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB080"."CreateDate" is '建檔日期時間';
comment on column "JcicB080"."CreateEmpNo" is '建檔人員';
comment on column "JcicB080"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB080"."LastUpdateEmpNo" is '最後更新人員';
