drop table "InnLoanMeeting" purge;

create table "InnLoanMeeting" (
  "MeetNo" decimal(6, 0) default 0 not null,
  "MeetingDate" decimal(8, 0) default 0 not null,
  "CustCode" varchar2(1),
  "Amount" decimal(14, 0) default 0 not null,
  "Issue" varchar2(50),
  "Remark" varchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InnLoanMeeting" add constraint "InnLoanMeeting_PK" primary key("MeetNo");

comment on table "InnLoanMeeting" is '放審會記錄檔';
comment on column "InnLoanMeeting"."MeetNo" is '放審會流水號';
comment on column "InnLoanMeeting"."MeetingDate" is '日期';
comment on column "InnLoanMeeting"."CustCode" is '戶別';
comment on column "InnLoanMeeting"."Amount" is '金額';
comment on column "InnLoanMeeting"."Issue" is '議題';
comment on column "InnLoanMeeting"."Remark" is '備註';
comment on column "InnLoanMeeting"."CreateDate" is '建檔日期時間';
comment on column "InnLoanMeeting"."CreateEmpNo" is '建檔人員';
comment on column "InnLoanMeeting"."LastUpdate" is '最後更新日期時間';
comment on column "InnLoanMeeting"."LastUpdateEmpNo" is '最後更新人員';
