drop table "JcicZ053" purge;

create table "JcicZ053" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "AgreeSend" varchar2(1),
  "AgreeSendData1" nvarchar2(2),
  "AgreeSendData2" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ053" add constraint "JcicZ053_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode");

create index "JcicZ053_Index1" on "JcicZ053"("SubmitKey" asc);

create index "JcicZ053_Index2" on "JcicZ053"("CustId" asc);

create index "JcicZ053_Index3" on "JcicZ053"("RcDate" asc);

create index "JcicZ053_Index4" on "JcicZ053"("MaxMainCode" asc);

comment on table "JcicZ053" is '同意報送例外處理檔案';
comment on column "JcicZ053"."TranKey" is '交易代碼';
comment on column "JcicZ053"."SubmitKey" is '報送單位代號';
comment on column "JcicZ053"."CustId" is '債務人IDN';
comment on column "JcicZ053"."RcDate" is '協商申請日';
comment on column "JcicZ053"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ053"."AgreeSend" is '是否同意報送例外處理檔案格式';
comment on column "JcicZ053"."AgreeSendData1" is '同意補報送檔案格式資料別1';
comment on column "JcicZ053"."AgreeSendData2" is '同意補報送檔案格式資料別2';
comment on column "JcicZ053"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ053"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ053"."Ukey" is '流水號';
comment on column "JcicZ053"."CreateDate" is '建檔日期時間';
comment on column "JcicZ053"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ053"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ053"."LastUpdateEmpNo" is '最後更新人員';
