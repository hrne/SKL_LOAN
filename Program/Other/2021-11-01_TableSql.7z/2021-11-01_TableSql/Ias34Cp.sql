drop table "Ias34Cp" purge;

create table "Ias34Cp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Cp" add constraint "Ias34Cp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "Ias34Cp" is 'IAS34欄位清單C檔';
comment on column "Ias34Cp"."DataYM" is '年月份';
comment on column "Ias34Cp"."CustNo" is '戶號';
comment on column "Ias34Cp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Cp"."FacmNo" is '額度編號';
comment on column "Ias34Cp"."BormNo" is '撥款序號';
comment on column "Ias34Cp"."AmortizedCode" is '約定還款方式';
comment on column "Ias34Cp"."PayIntFreq" is '繳息週期';
comment on column "Ias34Cp"."RepayFreq" is '還本週期';
comment on column "Ias34Cp"."EffectDate" is '生效日期';
comment on column "Ias34Cp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Cp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Cp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Cp"."LastUpdateEmpNo" is '最後更新人員';
