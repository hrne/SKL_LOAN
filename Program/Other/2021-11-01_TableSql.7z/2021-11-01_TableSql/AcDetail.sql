drop table "AcDetail" purge;

create table "AcDetail" (
  "RelDy" decimal(8, 0) default 0 not null,
  "RelTxseq" varchar2(18),
  "AcSeq" decimal(4, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcctCode" varchar2(3),
  "DbCr" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "EntAc" decimal(1, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RvNo" varchar2(30),
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "AcBookFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "SumNo" varchar2(3),
  "DscptCode" varchar2(4),
  "SlipNote" nvarchar2(80),
  "SlipBatNo" decimal(2, 0) default 0 not null,
  "SlipNo" decimal(6, 0) default 0 not null,
  "TitaKinbr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "TitaTxCd" varchar2(5),
  "TitaSecNo" varchar2(2),
  "TitaBatchNo" varchar2(6),
  "TitaBatchSeq" varchar2(6),
  "TitaSupNo" varchar2(6),
  "TitaRelCd" decimal(1, 0) default 0 not null,
  "JsonFields" varchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcDetail" add constraint "AcDetail_PK" primary key("RelDy", "RelTxseq", "AcSeq");

create index "AcDetail_Index1" on "AcDetail"("RelDy" asc, "RelTxseq" asc, "AcSeq" asc);

create index "AcDetail_Index2" on "AcDetail"("AcDate" asc, "BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc, "SlipNo" asc);

create index "AcDetail_Index3" on "AcDetail"("BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "RvNo" asc, "AcDate" asc, "SlipBatNo" asc, "SlipNo" asc);

create index "AcDetail_Index4" on "AcDetail"("AcDate" asc, "TitaKinbr" asc, "TitaTlrNo" asc, "TitaTxtNo" asc, "AcSeq" asc);

comment on table "AcDetail" is '會計帳務明細檔';
comment on column "AcDetail"."RelDy" is '登放日期';
comment on column "AcDetail"."RelTxseq" is '登放序號';
comment on column "AcDetail"."AcSeq" is '分錄序號';
comment on column "AcDetail"."AcDate" is '會計日期';
comment on column "AcDetail"."BranchNo" is '單位別';
comment on column "AcDetail"."CurrencyCode" is '幣別';
comment on column "AcDetail"."AcNoCode" is '科目代號';
comment on column "AcDetail"."AcSubCode" is '子目代號';
comment on column "AcDetail"."AcDtlCode" is '細目代號';
comment on column "AcDetail"."AcctCode" is '業務科目代號';
comment on column "AcDetail"."DbCr" is '借貸別';
comment on column "AcDetail"."TxAmt" is '記帳金額';
comment on column "AcDetail"."EntAc" is '入總帳記號';
comment on column "AcDetail"."CustNo" is '戶號';
comment on column "AcDetail"."FacmNo" is '額度編號';
comment on column "AcDetail"."BormNo" is '撥款序號';
comment on column "AcDetail"."RvNo" is '銷帳編號';
comment on column "AcDetail"."AcctFlag" is '業務科目記號';
comment on column "AcDetail"."ReceivableFlag" is '銷帳科目記號';
comment on column "AcDetail"."AcBookFlag" is '帳冊別記號';
comment on column "AcDetail"."AcBookCode" is '帳冊別';
comment on column "AcDetail"."AcSubBookCode" is '區隔帳冊';
comment on column "AcDetail"."SumNo" is '彙總別';
comment on column "AcDetail"."DscptCode" is '摘要代號';
comment on column "AcDetail"."SlipNote" is '傳票摘要';
comment on column "AcDetail"."SlipBatNo" is '傳票批號';
comment on column "AcDetail"."SlipNo" is '傳票號碼';
comment on column "AcDetail"."TitaKinbr" is '登錄單位別';
comment on column "AcDetail"."TitaTlrNo" is '登錄經辦';
comment on column "AcDetail"."TitaTxtNo" is '登錄交易序號';
comment on column "AcDetail"."TitaTxCd" is '交易代號';
comment on column "AcDetail"."TitaSecNo" is '業務類別';
comment on column "AcDetail"."TitaBatchNo" is '整批批號';
comment on column "AcDetail"."TitaBatchSeq" is '整批明細序號';
comment on column "AcDetail"."TitaSupNo" is '核准主管';
comment on column "AcDetail"."TitaRelCd" is '作業模式';
comment on column "AcDetail"."JsonFields" is 'jason格式紀錄欄';
comment on column "AcDetail"."CreateDate" is '建檔日期時間';
comment on column "AcDetail"."CreateEmpNo" is '建檔人員';
comment on column "AcDetail"."LastUpdate" is '最後更新日期時間';
comment on column "AcDetail"."LastUpdateEmpNo" is '最後更新人員';
