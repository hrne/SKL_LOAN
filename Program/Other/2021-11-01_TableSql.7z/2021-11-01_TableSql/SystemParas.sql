drop table "SystemParas" purge;

create table "SystemParas" (
  "BusinessType" varchar2(2),
  "GraceDays" decimal(2, 0) default 0 not null,
  "AchAuthOneTime" varchar2(1),
  "AchDeductFlag" decimal(1, 0) default 0 not null,
  "AchDeductDD1" decimal(2, 0) default 0 not null,
  "AchDeductDD2" decimal(2, 0) default 0 not null,
  "AchDeductDD3" decimal(2, 0) default 0 not null,
  "AchDeductDD4" decimal(2, 0) default 0 not null,
  "AchDeductDD5" decimal(2, 0) default 0 not null,
  "AchSecondDeductDays" decimal(2, 0) default 0 not null,
  "AchDeductMethod" decimal(1, 0) default 0 not null,
  "PostDeductFlag" decimal(1, 0) default 0 not null,
  "PostDeductDD1" decimal(2, 0) default 0 not null,
  "PostDeductDD2" decimal(2, 0) default 0 not null,
  "PostDeductDD3" decimal(2, 0) default 0 not null,
  "PostDeductDD4" decimal(2, 0) default 0 not null,
  "PostDeductDD5" decimal(2, 0) default 0 not null,
  "PostSecondDeductDays" decimal(2, 0) default 0 not null,
  "PostDeductMethod" decimal(1, 0) default 0 not null,
  "LoanDeptCustNo" decimal(7, 0) default 0 not null,
  "NegDeptCustNo" decimal(7, 0) default 0 not null,
  "PerfBackRepayAmt" decimal(16, 2) default 0 not null,
  "PerfBackPeriodS" decimal(3, 0) default 0 not null,
  "PerfBackPeriodE" decimal(3, 0) default 0 not null,
  "AcctCode310A" decimal(3, 0) default 0 not null,
  "AcctCode310B" decimal(3, 0) default 0 not null,
  "AcctCode320A" decimal(3, 0) default 0 not null,
  "AcctCode320B" decimal(3, 0) default 0 not null,
  "AcctCode330A" decimal(3, 0) default 0 not null,
  "AcctCode330B" decimal(3, 0) default 0 not null,
  "ReduceAmtLimit" decimal(5, 0) default 0 not null,
  "PreRepayTerms" decimal(3, 0) default 0 not null,
  "PreRepayTermsBatch" decimal(3, 0) default 0 not null,
  "ShortPrinPercent" decimal(3, 0) default 0 not null,
  "ShortIntPercent" decimal(3, 0) default 0 not null,
  "AmlFg" decimal(1, 0) default 0 not null,
  "AmlUrl" nvarchar2(50),
  "PerfDate" decimal(8, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcBookAdjDate" decimal(8, 0) default 0 not null,
  "EbsFg" varchar2(1),
  "EbsUrl" varchar2(100),
  "EbsAuth" varchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "SystemParas" add constraint "SystemParas_PK" primary key("BusinessType");

comment on table "SystemParas" is '系統參數設定檔';
comment on column "SystemParas"."BusinessType" is '業務類型';
comment on column "SystemParas"."GraceDays" is '違約寬限天數(營業日)';
comment on column "SystemParas"."AchAuthOneTime" is 'ACH授權提出一日一批';
comment on column "SystemParas"."AchDeductFlag" is 'ACH扣款方式';
comment on column "SystemParas"."AchDeductDD1" is 'ACH扣款特定日1';
comment on column "SystemParas"."AchDeductDD2" is 'ACH扣款特定日2';
comment on column "SystemParas"."AchDeductDD3" is 'ACH扣款特定日3';
comment on column "SystemParas"."AchDeductDD4" is 'ACH扣款特定日4';
comment on column "SystemParas"."AchDeductDD5" is 'ACH扣款特定日5';
comment on column "SystemParas"."AchSecondDeductDays" is 'ACH特定日二扣營業日差';
comment on column "SystemParas"."AchDeductMethod" is 'ACH連續日扣款方式';
comment on column "SystemParas"."PostDeductFlag" is 'POST扣款方式';
comment on column "SystemParas"."PostDeductDD1" is 'ACH扣款特定日1';
comment on column "SystemParas"."PostDeductDD2" is 'ACH扣款特定日2';
comment on column "SystemParas"."PostDeductDD3" is 'ACH扣款特定日3';
comment on column "SystemParas"."PostDeductDD4" is 'ACH扣款特定日4';
comment on column "SystemParas"."PostDeductDD5" is 'ACH扣款特定日5';
comment on column "SystemParas"."PostSecondDeductDays" is 'ACH特定日二扣營業日差';
comment on column "SystemParas"."PostDeductMethod" is 'ACH連續日扣款方式';
comment on column "SystemParas"."LoanDeptCustNo" is '放款部收款專戶戶號';
comment on column "SystemParas"."NegDeptCustNo" is '前置協商收款專戶戶號';
comment on column "SystemParas"."PerfBackRepayAmt" is '業績追回之部分還款金額條件';
comment on column "SystemParas"."PerfBackPeriodS" is '業績追回之起期數';
comment on column "SystemParas"."PerfBackPeriodE" is '業績追回之止期數';
comment on column "SystemParas"."AcctCode310A" is '短期擔保放款年限之起';
comment on column "SystemParas"."AcctCode310B" is '短期擔保放款年限之止';
comment on column "SystemParas"."AcctCode320A" is '中期擔保放款年限之起';
comment on column "SystemParas"."AcctCode320B" is '中期擔保放款年限之止';
comment on column "SystemParas"."AcctCode330A" is '長期擔保放款年限之起';
comment on column "SystemParas"."AcctCode330B" is '長期擔保放款年限之止';
comment on column "SystemParas"."ReduceAmtLimit" is '減免金額限額';
comment on column "SystemParas"."PreRepayTerms" is '單筆預收期數';
comment on column "SystemParas"."PreRepayTermsBatch" is '批次預收期數';
comment on column "SystemParas"."ShortPrinPercent" is '回收時可短繳本金金額之百分比';
comment on column "SystemParas"."ShortIntPercent" is '回收時可短繳利息金額之百分比';
comment on column "SystemParas"."AmlFg" is 'AML檢查記號';
comment on column "SystemParas"."AmlUrl" is 'AML網址';
comment on column "SystemParas"."PerfDate" is '業績日期';
comment on column "SystemParas"."AcBookCode" is '帳冊別';
comment on column "SystemParas"."AcSubBookCode" is '區隔帳冊';
comment on column "SystemParas"."AcBookAdjDate" is '帳冊別帳務調整日期';
comment on column "SystemParas"."EbsFg" is 'EBS啟用記號';
comment on column "SystemParas"."EbsUrl" is 'EBS網址';
comment on column "SystemParas"."EbsAuth" is 'EBS認證';
comment on column "SystemParas"."CreateDate" is '建檔日期時間';
comment on column "SystemParas"."CreateEmpNo" is '建檔人員';
comment on column "SystemParas"."LastUpdate" is '最後更新日期時間';
comment on column "SystemParas"."LastUpdateEmpNo" is '最後更新人員';
