drop table "CdCity" purge;

create table "CdCity" (
  "CityCode" varchar2(2),
  "CityItem" nvarchar2(10),
  "UnitCode" varchar2(6),
  "AccCollPsn" varchar2(6),
  "AccTelArea" varchar2(5),
  "AccTelNo" varchar2(10),
  "AccTelExt" varchar2(5),
  "LegalPsn" varchar2(6),
  "LegalArea" varchar2(5),
  "LegalNo" varchar2(10),
  "LegalExt" varchar2(5),
  "IntRateIncr" decimal(6, 4) default 0 not null,
  "IntRateCeiling" decimal(6, 4) default 0 not null,
  "IntRateFloor" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCity" add constraint "CdCity_PK" primary key("CityCode");

create index "CdCity_Index1" on "CdCity"("UnitCode" asc);

create index "CdCity_Index2" on "CdCity"("CityItem" asc);

comment on table "CdCity" is '地區別代碼檔';
comment on column "CdCity"."CityCode" is '縣市代碼(地區別)';
comment on column "CdCity"."CityItem" is '縣市名稱(地區別)';
comment on column "CdCity"."UnitCode" is '單位代號';
comment on column "CdCity"."AccCollPsn" is '催收人員';
comment on column "CdCity"."AccTelArea" is '催收人員電話-區碼';
comment on column "CdCity"."AccTelNo" is '催收人員電話';
comment on column "CdCity"."AccTelExt" is '催收人員電話-分機';
comment on column "CdCity"."LegalPsn" is '法務人員';
comment on column "CdCity"."LegalArea" is '法務人員電話-區碼';
comment on column "CdCity"."LegalNo" is '法務人員電話';
comment on column "CdCity"."LegalExt" is '法務人員電話-分機';
comment on column "CdCity"."IntRateIncr" is '利率加減碼';
comment on column "CdCity"."IntRateCeiling" is '利率上限';
comment on column "CdCity"."IntRateFloor" is '利率下限';
comment on column "CdCity"."CreateDate" is '建檔日期時間';
comment on column "CdCity"."CreateEmpNo" is '建檔人員';
comment on column "CdCity"."LastUpdate" is '最後更新日期時間';
comment on column "CdCity"."LastUpdateEmpNo" is '最後更新人員';
