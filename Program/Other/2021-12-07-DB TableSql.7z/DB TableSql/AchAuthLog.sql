drop table "AchAuthLog" purge;

create table "AchAuthLog" (
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcct" varchar2(14),
  "CreateFlag" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "AuthStatus" varchar2(1),
  "AuthMeth" varchar2(1),
  "LimitAmt" decimal(8, 2) default 0 not null,
  "MediaCode" varchar2(1),
  "BatchNo" varchar2(6),
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "TitaTxCd" varchar2(5),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AchAuthLog" add constraint "AchAuthLog_PK" primary key("AuthCreateDate", "CustNo", "RepayBank", "RepayAcct", "CreateFlag");

create index "AchAuthLog_Index1" on "AchAuthLog"("AuthCreateDate" asc);

create index "AchAuthLog_Index2" on "AchAuthLog"("MediaCode" asc, "AuthStatus" asc);

create index "AchAuthLog_Index3" on "AchAuthLog"("PropDate" asc);

create index "AchAuthLog_Index4" on "AchAuthLog"("RetrDate" asc);

comment on table "AchAuthLog" is 'ACH授權記錄檔';
comment on column "AchAuthLog"."AuthCreateDate" is '建檔日期';
comment on column "AchAuthLog"."CustNo" is '戶號';
comment on column "AchAuthLog"."RepayBank" is '扣款銀行';
comment on column "AchAuthLog"."RepayAcct" is '扣款帳號';
comment on column "AchAuthLog"."CreateFlag" is '新增或取消記號';
comment on column "AchAuthLog"."FacmNo" is '額度號碼';
comment on column "AchAuthLog"."ProcessDate" is '處理日期';
comment on column "AchAuthLog"."StampFinishDate" is '核印完成日期時間';
comment on column "AchAuthLog"."AuthStatus" is '授權狀態';
comment on column "AchAuthLog"."AuthMeth" is '授權方式';
comment on column "AchAuthLog"."LimitAmt" is '每筆扣款限額';
comment on column "AchAuthLog"."MediaCode" is '媒體碼';
comment on column "AchAuthLog"."BatchNo" is '批號';
comment on column "AchAuthLog"."PropDate" is '提出日期';
comment on column "AchAuthLog"."RetrDate" is '提回日期';
comment on column "AchAuthLog"."DeleteDate" is '刪除日期/暫停授權日期';
comment on column "AchAuthLog"."RelationCode" is '與借款人關係';
comment on column "AchAuthLog"."RelAcctName" is '第三人帳戶戶名';
comment on column "AchAuthLog"."RelationId" is '第三人身分證字號';
comment on column "AchAuthLog"."RelAcctBirthday" is '第三人出生日期';
comment on column "AchAuthLog"."RelAcctGender" is '第三人性別';
comment on column "AchAuthLog"."AmlRsp" is 'AML回應碼';
comment on column "AchAuthLog"."TitaTxCd" is '交易代號';
comment on column "AchAuthLog"."CreateEmpNo" is '建立者櫃員編號';
comment on column "AchAuthLog"."CreateDate" is '建立日期時間';
comment on column "AchAuthLog"."LastUpdateEmpNo" is '修改者櫃員編號';
comment on column "AchAuthLog"."LastUpdate" is '修改日期時間';
