drop table "EmpDeductSchedule" purge;

create table "EmpDeductSchedule" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "AgType1" varchar2(1),
  "EntryDate" decimal(8, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "EmpDeductSchedule" add constraint "EmpDeductSchedule_PK" primary key("WorkMonth", "AgType1");

create index "EmpDeductSchedule_Index1" on "EmpDeductSchedule"("WorkMonth" asc, "AgType1" asc);

comment on table "EmpDeductSchedule" is '員工扣薪日程表';
comment on column "EmpDeductSchedule"."WorkMonth" is '工作年月';
comment on column "EmpDeductSchedule"."AgType1" is '流程別';
comment on column "EmpDeductSchedule"."EntryDate" is '入帳日期';
comment on column "EmpDeductSchedule"."MediaDate" is '媒體日期';
comment on column "EmpDeductSchedule"."CreateDate" is '建檔日期時間';
comment on column "EmpDeductSchedule"."CreateEmpNo" is '建檔人員';
comment on column "EmpDeductSchedule"."LastUpdate" is '最後更新日期時間';
comment on column "EmpDeductSchedule"."LastUpdateEmpNo" is '最後更新人員';
