drop table "CdCode" purge;

create table "CdCode" (
  "DefCode" varchar2(20),
  "DefType" decimal(2, 0) default 0 not null,
  "Code" varchar2(20),
  "Item" nvarchar2(50),
  "Enable" varchar2(1),
  "EffectFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCode" add constraint "CdCode_PK" primary key("DefCode", "Code");

comment on table "CdCode" is '共用代碼檔';
comment on column "CdCode"."DefCode" is '代碼檔代號';
comment on column "CdCode"."DefType" is '代碼檔業務類別';
comment on column "CdCode"."Code" is '代碼';
comment on column "CdCode"."Item" is '代碼說明';
comment on column "CdCode"."Enable" is '啟用記號';
comment on column "CdCode"."EffectFlag" is '狀態';
comment on column "CdCode"."CreateDate" is '建檔日期時間';
comment on column "CdCode"."CreateEmpNo" is '建檔人員';
comment on column "CdCode"."LastUpdate" is '最後更新日期時間';
comment on column "CdCode"."LastUpdateEmpNo" is '最後更新人員';
