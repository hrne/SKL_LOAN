drop table "HlThreeDetail" purge;

create table "HlThreeDetail" (
  "CusBNo" varchar2(2),
  "HlCusNo" decimal(14, 0) default 0 not null,
  "AmountNo" varchar2(3),
  "AplAmount" decimal(14, 2) default 0 not null,
  "CaseNo" varchar2(1),
  "IfCal" varchar2(1),
  "TActAmt" varchar2(30),
  "EmpNo" varchar2(10),
  "EmpId" varchar2(10),
  "HlEmpName" nvarchar2(15),
  "DeptNo" varchar2(6),
  "BranchNo" varchar2(50),
  "UnitNo" varchar2(6),
  "DeptName" varchar2(20),
  "BranchName" varchar2(20),
  "UnitName" varchar2(20),
  "FirAppDate" varchar2(8),
  "BiReteNo" varchar2(2),
  "TwoYag" decimal(14, 2) default 0 not null,
  "ThreeYag" decimal(14, 2) default 0 not null,
  "TwoPay" decimal(14, 2) default 0 not null,
  "ThreePay" decimal(14, 2) default 0 not null,
  "UnitChiefNo" varchar2(10),
  "UnitChiefName" nvarchar2(15),
  "AreaChiefNo" varchar2(10),
  "AreaChiefName" nvarchar2(15),
  "Id3" varchar2(10),
  "Id3Name" nvarchar2(15),
  "TeamChiefNo" varchar2(10),
  "TeamChiefName" nvarchar2(15),
  "Id0" varchar2(10),
  "Id0Name" nvarchar2(15),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlThreeDetail" add constraint "HlThreeDetail_PK" primary key("CusBNo", "HlCusNo", "AmountNo", "CaseNo");

comment on table "HlThreeDetail" is '房貸換算業績網頁查詢檔';
comment on column "HlThreeDetail"."CusBNo" is '營業單位別';
comment on column "HlThreeDetail"."HlCusNo" is '借款人戶號';
comment on column "HlThreeDetail"."AmountNo" is '額度編號';
comment on column "HlThreeDetail"."AplAmount" is '已用額度';
comment on column "HlThreeDetail"."CaseNo" is '計件代碼';
comment on column "HlThreeDetail"."IfCal" is '是否已計件';
comment on column "HlThreeDetail"."TActAmt" is '累計達成金額';
comment on column "HlThreeDetail"."EmpNo" is '員工代號';
comment on column "HlThreeDetail"."EmpId" is '統一編號';
comment on column "HlThreeDetail"."HlEmpName" is '員工姓名';
comment on column "HlThreeDetail"."DeptNo" is '部室代號';
comment on column "HlThreeDetail"."BranchNo" is '區部代號';
comment on column "HlThreeDetail"."UnitNo" is '單位代號';
comment on column "HlThreeDetail"."DeptName" is '部室中文';
comment on column "HlThreeDetail"."BranchName" is '區部中文';
comment on column "HlThreeDetail"."UnitName" is '單位中文';
comment on column "HlThreeDetail"."FirAppDate" is '首次撥款日';
comment on column "HlThreeDetail"."BiReteNo" is '基本利率代碼';
comment on column "HlThreeDetail"."TwoYag" is '二階換算業績';
comment on column "HlThreeDetail"."ThreeYag" is '三階換算業績';
comment on column "HlThreeDetail"."TwoPay" is '二階業務報酬';
comment on column "HlThreeDetail"."ThreePay" is '三階業務報酬';
comment on column "HlThreeDetail"."UnitChiefNo" is '統一編號';
comment on column "HlThreeDetail"."UnitChiefName" is '員工姓名';
comment on column "HlThreeDetail"."AreaChiefNo" is '統一編號';
comment on column "HlThreeDetail"."AreaChiefName" is '員工姓名';
comment on column "HlThreeDetail"."Id3" is '統一編號';
comment on column "HlThreeDetail"."Id3Name" is '員工姓名';
comment on column "HlThreeDetail"."TeamChiefNo" is '統一編號';
comment on column "HlThreeDetail"."TeamChiefName" is '員工姓名';
comment on column "HlThreeDetail"."Id0" is '統一編號';
comment on column "HlThreeDetail"."Id0Name" is '員工姓名';
comment on column "HlThreeDetail"."UpNo" is 'UpdateIdentifier';
comment on column "HlThreeDetail"."ProcessDate" is '更新日期';
comment on column "HlThreeDetail"."CreateDate" is '建檔日期時間';
comment on column "HlThreeDetail"."CreateEmpNo" is '建檔人員';
comment on column "HlThreeDetail"."LastUpdate" is '最後更新日期時間';
comment on column "HlThreeDetail"."LastUpdateEmpNo" is '最後更新人員';
