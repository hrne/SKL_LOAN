drop table "BatxDetail" purge;

create table "BatxDetail" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "FileName" varchar2(50),
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RvNo" nvarchar2(30),
  "RepayType" decimal(2, 0) default 0 not null,
  "ReconCode" varchar2(3),
  "RepayAcCode" varchar2(18),
  "AcquiredAmt" decimal(14, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "AcctAmt" decimal(14, 0) default 0 not null,
  "DisacctAmt" decimal(14, 0) default 0 not null,
  "ProcStsCode" varchar2(1),
  "ProcCode" varchar2(5),
  "ProcNote" nvarchar2(600),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxDetail" add constraint "BatxDetail_PK" primary key("AcDate", "BatchNo", "DetailSeq");

alter table "BatxDetail" add constraint "BatxDetail_BatxHead_FK1" foreign key ("AcDate", "BatchNo") references "BatxHead" ("AcDate", "BatchNo") on delete cascade;

create index "BatxDetail_Index1" on "BatxDetail"("MediaDate" asc, "MediaKind" asc, "MediaSeq" asc);

create index "BatxDetail_Index2" on "BatxDetail"("EntryDate" asc, "CustNo" asc, "FacmNo" asc, "RepayCode" asc);

create index "BatxDetail_Index3" on "BatxDetail"("AcDate" asc);

create index "BatxDetail_Index4" on "BatxDetail"("AcDate" asc, "BatchNo" asc, "RepayType" asc, "FileName" asc, "ProcStsCode" asc);

comment on table "BatxDetail" is '整批入帳明細檔';
comment on column "BatxDetail"."AcDate" is '會計日期';
comment on column "BatxDetail"."BatchNo" is '整批批號';
comment on column "BatxDetail"."DetailSeq" is '明細序號';
comment on column "BatxDetail"."RepayCode" is '還款來源';
comment on column "BatxDetail"."FileName" is '檔名';
comment on column "BatxDetail"."EntryDate" is '入帳日期';
comment on column "BatxDetail"."CustNo" is '戶號';
comment on column "BatxDetail"."FacmNo" is '額度';
comment on column "BatxDetail"."RvNo" is '銷帳編號';
comment on column "BatxDetail"."RepayType" is '還款類別';
comment on column "BatxDetail"."ReconCode" is '對帳類別';
comment on column "BatxDetail"."RepayAcCode" is '來源會計科目';
comment on column "BatxDetail"."AcquiredAmt" is '還款總金額';
comment on column "BatxDetail"."RepayAmt" is '還款金額';
comment on column "BatxDetail"."AcctAmt" is '已作帳金額';
comment on column "BatxDetail"."DisacctAmt" is '未作帳金額';
comment on column "BatxDetail"."ProcStsCode" is '處理狀態';
comment on column "BatxDetail"."ProcCode" is '處理代碼';
comment on column "BatxDetail"."ProcNote" is '處理說明';
comment on column "BatxDetail"."TitaTlrNo" is '經辦';
comment on column "BatxDetail"."TitaTxtNo" is '交易序號';
comment on column "BatxDetail"."MediaDate" is '媒體日期';
comment on column "BatxDetail"."MediaKind" is '媒體別';
comment on column "BatxDetail"."MediaSeq" is '媒體序號';
comment on column "BatxDetail"."CreateDate" is '建檔日期時間';
comment on column "BatxDetail"."CreateEmpNo" is '建檔人員';
comment on column "BatxDetail"."LastUpdate" is '最後更新日期時間';
comment on column "BatxDetail"."LastUpdateEmpNo" is '最後更新人員';
