drop table "CdOverdue" purge;

create table "CdOverdue" (
  "OverdueSign" varchar2(1),
  "OverdueCode" varchar2(4),
  "OverdueItem" nvarchar2(50),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdOverdue" add constraint "CdOverdue_PK" primary key("OverdueSign", "OverdueCode");

create index "CdOverdue_Index1" on "CdOverdue"("OverdueSign" asc);

create index "CdOverdue_Index2" on "CdOverdue"("OverdueCode" asc);

create index "CdOverdue_Index3" on "CdOverdue"("Enable" asc);

comment on table "CdOverdue" is '逾期新增減少原因檔';
comment on column "CdOverdue"."OverdueSign" is '逾期增減碼';
comment on column "CdOverdue"."OverdueCode" is '增減原因代號';
comment on column "CdOverdue"."OverdueItem" is '增減原因說明';
comment on column "CdOverdue"."Enable" is '啟用記號';
comment on column "CdOverdue"."CreateDate" is '建檔日期時間';
comment on column "CdOverdue"."CreateEmpNo" is '建檔人員';
comment on column "CdOverdue"."LastUpdate" is '最後更新日期時間';
comment on column "CdOverdue"."LastUpdateEmpNo" is '最後更新人員';
