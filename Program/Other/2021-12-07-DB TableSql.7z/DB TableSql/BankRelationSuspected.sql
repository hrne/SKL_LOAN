drop table "BankRelationSuspected" purge;

create table "BankRelationSuspected" (
  "RepCusName" nvarchar2(100),
  "CustId" varchar2(11),
  "CustName" nvarchar2(100),
  "SubCom" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationSuspected" add constraint "BankRelationSuspected_PK" primary key("RepCusName", "CustId");

comment on table "BankRelationSuspected" is '是否為疑似準利害關係人檔';
comment on column "BankRelationSuspected"."RepCusName" is '自然人姓名';
comment on column "BankRelationSuspected"."CustId" is '該自然人擔任董事長之公司統一編號';
comment on column "BankRelationSuspected"."CustName" is '公司名稱';
comment on column "BankRelationSuspected"."SubCom" is '職務名稱';
comment on column "BankRelationSuspected"."CreateDate" is '建檔日期時間';
comment on column "BankRelationSuspected"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationSuspected"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationSuspected"."LastUpdateEmpNo" is '最後更新人員';
