drop table "JcicZ040Log" purge;

create table "JcicZ040Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "RbDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "RefBankId" nvarchar2(3),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ040Log" add constraint "JcicZ040Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ040Log" is '前置協商受理申請暨請求回報償權通知資料';
comment on column "JcicZ040Log"."Ukey" is '流水號';
comment on column "JcicZ040Log"."TxSeq" is '交易序號';
comment on column "JcicZ040Log"."TranKey" is '交易代碼';
comment on column "JcicZ040Log"."RbDate" is '止息基準日';
comment on column "JcicZ040Log"."ApplyType" is '受理方式';
comment on column "JcicZ040Log"."RefBankId" is '轉介金融機構代號';
comment on column "JcicZ040Log"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ040Log"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ040Log"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ040Log"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ040Log"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ040Log"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ040Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ040Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ040Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ040Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ040Log"."LastUpdateEmpNo" is '最後更新人員';
