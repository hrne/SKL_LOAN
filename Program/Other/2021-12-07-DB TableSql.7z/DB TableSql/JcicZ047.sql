drop table "JcicZ047" purge;

create table "JcicZ047" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "PassDate" decimal(8, 0) default 0 not null,
  "InterviewDate" decimal(8, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "LimitDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(38),
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ047" add constraint "JcicZ047_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ047_Index1" on "JcicZ047"("SubmitKey" asc);

create index "JcicZ047_Index2" on "JcicZ047"("CustId" asc);

create index "JcicZ047_Index3" on "JcicZ047"("RcDate" asc);

comment on table "JcicZ047" is '金融機構無擔保債務協議資料檔案';
comment on column "JcicZ047"."TranKey" is '交易代碼';
comment on column "JcicZ047"."SubmitKey" is '報送單位代號';
comment on column "JcicZ047"."CustId" is '債務人IDN';
comment on column "JcicZ047"."RcDate" is '協商申請日';
comment on column "JcicZ047"."Period" is '期數';
comment on column "JcicZ047"."Rate" is '利率';
comment on column "JcicZ047"."Civil323ExpAmt" is '依民法第323條計算之信用貸款債務總金額';
comment on column "JcicZ047"."ExpLoanAmt" is '信用貸款債務簽約總金額';
comment on column "JcicZ047"."Civil323CashAmt" is '依民法第323條計算之現金卡債務總金額';
comment on column "JcicZ047"."CashCardAmt" is '現金卡債務簽約總金額';
comment on column "JcicZ047"."Civil323CreditAmt" is '依民法第323條計算之信用卡債務總金額';
comment on column "JcicZ047"."CreditCardAmt" is '信用卡債務簽約總金額';
comment on column "JcicZ047"."Civil323Amt" is '依民法第323條計算之債務總金額';
comment on column "JcicZ047"."TotalAmt" is '簽約總債務金額';
comment on column "JcicZ047"."PassDate" is '協議完成日';
comment on column "JcicZ047"."InterviewDate" is '面談日期';
comment on column "JcicZ047"."SignDate" is '簽約完成日期';
comment on column "JcicZ047"."LimitDate" is '前置協商註記訊息揭露期限';
comment on column "JcicZ047"."FirstPayDate" is '首期應繳款日';
comment on column "JcicZ047"."MonthPayAmt" is '月付金';
comment on column "JcicZ047"."PayAccount" is '繳款帳號';
comment on column "JcicZ047"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ047"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ047"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ047"."Period2" is '第二段期數';
comment on column "JcicZ047"."Rate2" is '第二階段利率';
comment on column "JcicZ047"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ047"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ047"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ047"."Ukey" is '流水號';
comment on column "JcicZ047"."CreateDate" is '建檔日期時間';
comment on column "JcicZ047"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ047"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ047"."LastUpdateEmpNo" is '最後更新人員';
