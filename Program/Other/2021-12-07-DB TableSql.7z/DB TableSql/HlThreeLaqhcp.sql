drop table "HlThreeLaqhcp" purge;

create table "HlThreeLaqhcp" (
  "CalDate" varchar2(10),
  "EmpNo" varchar2(6),
  "UnitNo" varchar2(6),
  "BranchNo" varchar2(6),
  "DeptNo" varchar2(6),
  "UnitName" varchar2(20),
  "BranchName" varchar2(20),
  "DeptName" varchar2(20),
  "ChiefName" nvarchar2(15),
  "HlEmpName" nvarchar2(15),
  "MType" varchar2(1),
  "GoalNum" decimal(14, 2) default 0 not null,
  "GoalAmt" decimal(14, 2) default 0 not null,
  "ActNum" decimal(14, 2) default 0 not null,
  "ActAmt" decimal(14, 2) default 0 not null,
  "ActRate" decimal(14, 2) default 0 not null,
  "TGoalNum" decimal(14, 2) default 0 not null,
  "TGoalAmt" decimal(14, 2) default 0 not null,
  "TActNum" decimal(14, 2) default 0 not null,
  "TActAmt" decimal(14, 2) default 0 not null,
  "TActRate" decimal(14, 2) default 0 not null,
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlThreeLaqhcp" add constraint "HlThreeLaqhcp_PK" primary key("CalDate", "EmpNo", "BranchNo", "DeptNo", "UnitNo");

comment on table "HlThreeLaqhcp" is '房貸排行邏輯檔';
comment on column "HlThreeLaqhcp"."CalDate" is '年月日';
comment on column "HlThreeLaqhcp"."EmpNo" is '員工代號';
comment on column "HlThreeLaqhcp"."UnitNo" is '單位代號';
comment on column "HlThreeLaqhcp"."BranchNo" is '區部代號';
comment on column "HlThreeLaqhcp"."DeptNo" is '部室代號';
comment on column "HlThreeLaqhcp"."UnitName" is '單位中文';
comment on column "HlThreeLaqhcp"."BranchName" is '區部中文';
comment on column "HlThreeLaqhcp"."DeptName" is '部室中文';
comment on column "HlThreeLaqhcp"."ChiefName" is '員工姓名';
comment on column "HlThreeLaqhcp"."HlEmpName" is '專員姓名';
comment on column "HlThreeLaqhcp"."MType" is '處長主任別';
comment on column "HlThreeLaqhcp"."GoalNum" is '目標件數';
comment on column "HlThreeLaqhcp"."GoalAmt" is '目標金額';
comment on column "HlThreeLaqhcp"."ActNum" is '達成件數';
comment on column "HlThreeLaqhcp"."ActAmt" is '達成金額';
comment on column "HlThreeLaqhcp"."ActRate" is '本月達成率';
comment on column "HlThreeLaqhcp"."TGoalNum" is '累計目標件數';
comment on column "HlThreeLaqhcp"."TGoalAmt" is '累計目標金額';
comment on column "HlThreeLaqhcp"."TActNum" is '累計達成件數';
comment on column "HlThreeLaqhcp"."TActAmt" is '累計達成金額';
comment on column "HlThreeLaqhcp"."TActRate" is '累計達成率';
comment on column "HlThreeLaqhcp"."UpNo" is 'UpdateIdentifier';
comment on column "HlThreeLaqhcp"."ProcessDate" is '更新日期';
comment on column "HlThreeLaqhcp"."CreateDate" is '建檔日期時間';
comment on column "HlThreeLaqhcp"."CreateEmpNo" is '建檔人員';
comment on column "HlThreeLaqhcp"."LastUpdate" is '最後更新日期時間';
comment on column "HlThreeLaqhcp"."LastUpdateEmpNo" is '最後更新人員';
