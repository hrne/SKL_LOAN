drop table "JcicAtomDetail" purge;

create table "JcicAtomDetail" (
  "FunctionCode" varchar2(6),
  "DataOrder" decimal(3, 0) default 0 not null,
  "FiledName" nvarchar2(50),
  "FiledType" nvarchar2(20),
  "Remark" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicAtomDetail" add constraint "JcicAtomDetail_PK" primary key("FunctionCode", "DataOrder");

comment on table "JcicAtomDetail" is '債務匯入資料功能明細檔';
comment on column "JcicAtomDetail"."FunctionCode" is '功能代碼';
comment on column "JcicAtomDetail"."DataOrder" is '順序';
comment on column "JcicAtomDetail"."FiledName" is '欄位名稱';
comment on column "JcicAtomDetail"."FiledType" is '格式與長度';
comment on column "JcicAtomDetail"."Remark" is '中文說明';
comment on column "JcicAtomDetail"."CreateDate" is '建檔日期時間';
comment on column "JcicAtomDetail"."CreateEmpNo" is '建檔人員';
comment on column "JcicAtomDetail"."LastUpdate" is '最後更新日期時間';
comment on column "JcicAtomDetail"."LastUpdateEmpNo" is '最後更新人員';
