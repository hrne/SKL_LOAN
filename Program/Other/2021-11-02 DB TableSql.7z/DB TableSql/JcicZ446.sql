drop table "JcicZ446" purge;

create table "JcicZ446" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "CloseCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ446" add constraint "JcicZ446_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ446_Index1" on "JcicZ446"("SubmitKey" asc);

create index "JcicZ446_Index2" on "JcicZ446"("CustId" asc);

create index "JcicZ446_Index3" on "JcicZ446"("ApplyDate" asc);

create index "JcicZ446_Index4" on "JcicZ446"("CourtCode" asc);

comment on table "JcicZ446" is '前置調解結案通知資料';
comment on column "JcicZ446"."TranKey" is '交易代碼';
comment on column "JcicZ446"."CustId" is '債務人IDN';
comment on column "JcicZ446"."SubmitKey" is '報送單位代號';
comment on column "JcicZ446"."ApplyDate" is '調解申請日';
comment on column "JcicZ446"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ446"."CloseCode" is '結案原因代號';
comment on column "JcicZ446"."CloseDate" is '結案日期';
comment on column "JcicZ446"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ446"."Ukey" is '流水號';
comment on column "JcicZ446"."CreateDate" is '建檔日期時間';
comment on column "JcicZ446"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ446"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ446"."LastUpdateEmpNo" is '最後更新人員';
