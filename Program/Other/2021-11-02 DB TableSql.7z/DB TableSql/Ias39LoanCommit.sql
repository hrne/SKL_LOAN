drop table "Ias39LoanCommit" purge;

create table "Ias39LoanCommit" (
  "DataYm" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(13, 2) default 0 not null,
  "UtilBal" decimal(13, 2) default 0 not null,
  "AvblBal" decimal(13, 2) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "Ccf" decimal(5, 2) default 0 not null,
  "ExpLimitAmt" decimal(13, 2) default 0 not null,
  "DbAcNoCode" varchar2(11),
  "CrAcNoCode" varchar2(11),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39LoanCommit" add constraint "Ias39LoanCommit_PK" primary key("DataYm", "CustNo", "FacmNo", "ApplNo");

comment on table "Ias39LoanCommit" is 'IAS39放款承諾明細檔';
comment on column "Ias39LoanCommit"."DataYm" is '年月份';
comment on column "Ias39LoanCommit"."CustNo" is '戶號';
comment on column "Ias39LoanCommit"."FacmNo" is '額度編號';
comment on column "Ias39LoanCommit"."ApplNo" is '核准號碼';
comment on column "Ias39LoanCommit"."ApproveDate" is '核准日期';
comment on column "Ias39LoanCommit"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias39LoanCommit"."MaturityDate" is '到期日';
comment on column "Ias39LoanCommit"."LoanTermYy" is '貸款期間年';
comment on column "Ias39LoanCommit"."LoanTermMm" is '貸款期間月';
comment on column "Ias39LoanCommit"."LoanTermDd" is '貸款期間日';
comment on column "Ias39LoanCommit"."UtilDeadline" is '動支期限';
comment on column "Ias39LoanCommit"."RecycleDeadline" is '循環動用期限';
comment on column "Ias39LoanCommit"."LineAmt" is '核准額度';
comment on column "Ias39LoanCommit"."UtilBal" is '放款餘額';
comment on column "Ias39LoanCommit"."AvblBal" is '可動用餘額';
comment on column "Ias39LoanCommit"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "Ias39LoanCommit"."IrrevocableFlag" is '該筆額度是否為不可撤銷';
comment on column "Ias39LoanCommit"."AcBookCode" is '帳冊別';
comment on column "Ias39LoanCommit"."AcSubBookCode" is '區隔帳冊';
comment on column "Ias39LoanCommit"."Ccf" is '信用風險轉換係數';
comment on column "Ias39LoanCommit"."ExpLimitAmt" is '表外曝險金額';
comment on column "Ias39LoanCommit"."DbAcNoCode" is '借方：備忘分錄會計科目';
comment on column "Ias39LoanCommit"."CrAcNoCode" is '貸方：備忘分錄會計科目';
comment on column "Ias39LoanCommit"."DrawdownFg" is '已核撥記號';
comment on column "Ias39LoanCommit"."CreateDate" is '建檔日期時間';
comment on column "Ias39LoanCommit"."CreateEmpNo" is '建檔人員';
comment on column "Ias39LoanCommit"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39LoanCommit"."LastUpdateEmpNo" is '最後更新人員';
