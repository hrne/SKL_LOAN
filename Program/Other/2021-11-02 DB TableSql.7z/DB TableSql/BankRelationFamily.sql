drop table "BankRelationFamily" purge;

create table "BankRelationFamily" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "RelationId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationFamily" add constraint "BankRelationFamily_PK" primary key("CustName", "CustId", "RelationId");

comment on table "BankRelationFamily" is '金控利害關係人_關係人員工之親屬資料';
comment on column "BankRelationFamily"."CustName" is '借款戶所屬公司名稱';
comment on column "BankRelationFamily"."CustId" is '借款戶統編';
comment on column "BankRelationFamily"."RelationId" is '親屬統編';
comment on column "BankRelationFamily"."LAW001" is '金控法第44條';
comment on column "BankRelationFamily"."LAW002" is '金控法第44條(列項)';
comment on column "BankRelationFamily"."LAW003" is '金控法第45條';
comment on column "BankRelationFamily"."LAW005" is '保險法(放款)';
comment on column "BankRelationFamily"."LAW008" is '準利害關係人';
comment on column "BankRelationFamily"."CreateDate" is '建檔日期時間';
comment on column "BankRelationFamily"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationFamily"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationFamily"."LastUpdateEmpNo" is '最後更新人員';
