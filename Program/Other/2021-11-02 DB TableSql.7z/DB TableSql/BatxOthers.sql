drop table "BatxOthers" purge;

create table "BatxOthers" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAcCode" varchar2(18),
  "EntryDate" decimal(8, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "RepayId" varchar2(10),
  "RepayName" nvarchar2(100),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CustNm" nvarchar2(100),
  "RvNo" varchar2(12),
  "Note" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxOthers" add constraint "BatxOthers_PK" primary key("AcDate", "BatchNo", "DetailSeq");

create index "BatxOthers_Index1" on "BatxOthers"("AcDate" asc, "BatchNo" asc, "RepayType" asc, "CreateEmpNo" asc);

comment on table "BatxOthers" is '其他還款來源檔';
comment on column "BatxOthers"."AcDate" is '會計日期';
comment on column "BatxOthers"."BatchNo" is '整批批號';
comment on column "BatxOthers"."DetailSeq" is '明細序號';
comment on column "BatxOthers"."RepayCode" is '來源';
comment on column "BatxOthers"."RepayType" is '還款類別';
comment on column "BatxOthers"."RepayAcCode" is '來源會計科目';
comment on column "BatxOthers"."EntryDate" is '入帳日期';
comment on column "BatxOthers"."RepayAmt" is '金額';
comment on column "BatxOthers"."RepayId" is '來源統編';
comment on column "BatxOthers"."RepayName" is '來源戶名';
comment on column "BatxOthers"."CustNo" is '借款人戶號';
comment on column "BatxOthers"."FacmNo" is '額度號碼';
comment on column "BatxOthers"."CustNm" is '借款人戶名';
comment on column "BatxOthers"."RvNo" is '銷帳碼';
comment on column "BatxOthers"."Note" is '摘要';
comment on column "BatxOthers"."CreateDate" is '建檔日期時間';
comment on column "BatxOthers"."CreateEmpNo" is '建檔人員';
comment on column "BatxOthers"."LastUpdate" is '最後更新日期時間';
comment on column "BatxOthers"."LastUpdateEmpNo" is '最後更新人員';
