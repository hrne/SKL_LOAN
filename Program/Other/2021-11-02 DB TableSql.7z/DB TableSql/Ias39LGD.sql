drop table "Ias39LGD" purge;

create table "Ias39LGD" (
  "Date" decimal(8, 0) default 0 not null,
  "Type" varchar2(2),
  "TypeDesc" nvarchar2(10),
  "LGDPercent" decimal(7, 5) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39LGD" add constraint "Ias39LGD_PK" primary key("Date", "Type");

comment on table "Ias39LGD" is '違約損失率檔';
comment on column "Ias39LGD"."Date" is '生效日期';
comment on column "Ias39LGD"."Type" is '類別';
comment on column "Ias39LGD"."TypeDesc" is '類別說明';
comment on column "Ias39LGD"."LGDPercent" is '違約損失率％';
comment on column "Ias39LGD"."Enable" is '啟用記號';
comment on column "Ias39LGD"."CreateDate" is '建檔日期時間';
comment on column "Ias39LGD"."CreateEmpNo" is '建檔人員';
comment on column "Ias39LGD"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39LGD"."LastUpdateEmpNo" is '最後更新人員';
