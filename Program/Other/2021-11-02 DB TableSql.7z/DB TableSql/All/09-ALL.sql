drop table "AcAcctCheck" purge;

create table "AcAcctCheck" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "TdBal" decimal(18, 2) default 0 not null,
  "TdCnt" decimal(8, 0) default 0 not null,
  "TdNewCnt" decimal(8, 0) default 0 not null,
  "TdClsCnt" decimal(8, 0) default 0 not null,
  "TdExtCnt" decimal(8, 0) default 0 not null,
  "TdExtAmt" decimal(18, 2) default 0 not null,
  "ReceivableBal" decimal(18, 2) default 0 not null,
  "AcctMasterBal" decimal(18, 2) default 0 not null,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AcAcctCheck" add constraint "AcAcctCheck_PK" primary key("AcDate", "BranchNo", "CurrencyCode", "AcctCode", "AcSubBookCode");

comment on table "AcAcctCheck" is '會計業務檢核檔';
comment on column "AcAcctCheck"."AcDate" is '會計日期';
comment on column "AcAcctCheck"."BranchNo" is '單位別';
comment on column "AcAcctCheck"."CurrencyCode" is '幣別';
comment on column "AcAcctCheck"."AcSubBookCode" is '區隔帳冊';
comment on column "AcAcctCheck"."AcctCode" is '業務科目代號';
comment on column "AcAcctCheck"."AcctItem" is '業務科目名稱';
comment on column "AcAcctCheck"."TdBal" is '本日餘額';
comment on column "AcAcctCheck"."TdCnt" is '本日件數';
comment on column "AcAcctCheck"."TdNewCnt" is '本日開戶件數';
comment on column "AcAcctCheck"."TdClsCnt" is '本日結清件數';
comment on column "AcAcctCheck"."TdExtCnt" is '本日展期件數';
comment on column "AcAcctCheck"."TdExtAmt" is '本日展期金額';
comment on column "AcAcctCheck"."ReceivableBal" is '銷帳檔餘額';
comment on column "AcAcctCheck"."AcctMasterBal" is '業務檔餘額';
comment on column "AcAcctCheck"."CreateEmpNo" is '建檔人員';
comment on column "AcAcctCheck"."CreateDate" is '建檔日期';
comment on column "AcAcctCheck"."LastUpdateEmpNo" is '最後維護人員';
comment on column "AcAcctCheck"."LastUpdate" is '最後維護日期';
drop table "AcAcctCheckDetail" purge;

create table "AcAcctCheckDetail" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcBal" decimal(16, 2) default 0 not null,
  "AcctMasterBal" decimal(16, 2) default 0 not null,
  "DiffBal" decimal(16, 2) default 0 not null,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AcAcctCheckDetail" add constraint "AcAcctCheckDetail_PK" primary key("AcDate", "BranchNo", "CurrencyCode", "AcctCode", "CustNo", "FacmNo", "BormNo", "AcSubBookCode");

comment on table "AcAcctCheckDetail" is '會計業務檢核明細檔';
comment on column "AcAcctCheckDetail"."AcDate" is '會計日期';
comment on column "AcAcctCheckDetail"."BranchNo" is '單位別';
comment on column "AcAcctCheckDetail"."CurrencyCode" is '幣別';
comment on column "AcAcctCheckDetail"."AcSubBookCode" is '區隔帳冊';
comment on column "AcAcctCheckDetail"."AcctCode" is '業務科目代號';
comment on column "AcAcctCheckDetail"."AcctItem" is '業務科目名稱';
comment on column "AcAcctCheckDetail"."CustNo" is '戶號';
comment on column "AcAcctCheckDetail"."FacmNo" is '額度號碼';
comment on column "AcAcctCheckDetail"."BormNo" is '撥款序號';
comment on column "AcAcctCheckDetail"."AcBal" is '會計帳餘額';
comment on column "AcAcctCheckDetail"."AcctMasterBal" is '業務帳餘額';
comment on column "AcAcctCheckDetail"."DiffBal" is '差額';
comment on column "AcAcctCheckDetail"."CreateEmpNo" is '建檔人員';
comment on column "AcAcctCheckDetail"."CreateDate" is '建檔日期';
comment on column "AcAcctCheckDetail"."LastUpdateEmpNo" is '最後維護人員';
comment on column "AcAcctCheckDetail"."LastUpdate" is '最後維護日期';
drop table "AcCheque" purge;

create table "AcCheque" (
  "DataDate" decimal(8, 0) default 0 not null,
  "UnitCode" varchar2(6),
  "ChequeSeq" decimal(8, 0) default 0 not null,
  "BankNo" decimal(8, 0) default 0 not null,
  "ChequeAccount" decimal(8, 0) default 0 not null,
  "Amt" decimal(16, 2) default 0 not null,
  "ChequeDate" decimal(8, 0) default 0 not null,
  "KeyInDate" decimal(8, 0) default 0 not null,
  "ExpectedExchangeDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcCheque" add constraint "AcCheque_PK" primary key("DataDate", "UnitCode", "ChequeSeq");

comment on table "AcCheque" is '應收票據資料檔';
comment on column "AcCheque"."DataDate" is '資料年月';
comment on column "AcCheque"."UnitCode" is '入帳單位';
comment on column "AcCheque"."ChequeSeq" is '支票流水號';
comment on column "AcCheque"."BankNo" is '銀行代號';
comment on column "AcCheque"."ChequeAccount" is '支票帳號';
comment on column "AcCheque"."Amt" is '金額';
comment on column "AcCheque"."ChequeDate" is '支票日期';
comment on column "AcCheque"."KeyInDate" is '建檔日';
comment on column "AcCheque"."ExpectedExchangeDate" is '預計交換日';
comment on column "AcCheque"."CreateDate" is '建檔日期時間';
comment on column "AcCheque"."CreateEmpNo" is '建檔人員';
comment on column "AcCheque"."LastUpdate" is '最後更新日期時間';
comment on column "AcCheque"."LastUpdateEmpNo" is '最後更新人員';
drop table "AcClose" purge;

create table "AcClose" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "SecNo" varchar2(2),
  "ClsFg" decimal(1, 0) default 0 not null,
  "BatNo" decimal(2, 0) default 0 not null,
  "ClsNo" decimal(2, 0) default 0 not null,
  "SlipNo" decimal(6, 0) default 0 not null,
  "CoreSeqNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcClose" add constraint "AcClose_PK" primary key("AcDate", "BranchNo", "SecNo");

comment on table "AcClose" is '會計業務關帳控制檔';
comment on column "AcClose"."AcDate" is '會計日期';
comment on column "AcClose"."BranchNo" is '單位別';
comment on column "AcClose"."SecNo" is '業務類別';
comment on column "AcClose"."ClsFg" is '關帳狀態';
comment on column "AcClose"."BatNo" is '業務批號';
comment on column "AcClose"."ClsNo" is '業務關帳次數';
comment on column "AcClose"."SlipNo" is '傳票號碼';
comment on column "AcClose"."CoreSeqNo" is '上傳核心序號';
comment on column "AcClose"."CreateDate" is '建檔日期時間';
comment on column "AcClose"."CreateEmpNo" is '建檔人員';
comment on column "AcClose"."LastUpdate" is '最後更新日期時間';
comment on column "AcClose"."LastUpdateEmpNo" is '最後更新人員';
drop table "AcDetail" purge;

create table "AcDetail" (
  "RelDy" decimal(8, 0) default 0 not null,
  "RelTxseq" varchar2(18),
  "AcSeq" decimal(4, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcctCode" varchar2(3),
  "DbCr" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "EntAc" decimal(1, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RvNo" varchar2(30),
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "AcBookFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "SumNo" varchar2(3),
  "DscptCode" varchar2(4),
  "SlipNote" nvarchar2(80),
  "SlipBatNo" decimal(2, 0) default 0 not null,
  "SlipNo" decimal(6, 0) default 0 not null,
  "TitaKinbr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "TitaTxCd" varchar2(5),
  "TitaSecNo" varchar2(2),
  "TitaBatchNo" varchar2(6),
  "TitaBatchSeq" varchar2(6),
  "TitaSupNo" varchar2(6),
  "TitaRelCd" decimal(1, 0) default 0 not null,
  "JsonFields" varchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcDetail" add constraint "AcDetail_PK" primary key("RelDy", "RelTxseq", "AcSeq");

create index "AcDetail_Index1" on "AcDetail"("RelDy" asc, "RelTxseq" asc, "AcSeq" asc);

create index "AcDetail_Index2" on "AcDetail"("AcDate" asc, "BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc, "SlipNo" asc);

create index "AcDetail_Index3" on "AcDetail"("BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "RvNo" asc, "AcDate" asc, "SlipBatNo" asc, "SlipNo" asc);

create index "AcDetail_Index4" on "AcDetail"("AcDate" asc, "TitaKinbr" asc, "TitaTlrNo" asc, "TitaTxtNo" asc, "AcSeq" asc);

comment on table "AcDetail" is '會計帳務明細檔';
comment on column "AcDetail"."RelDy" is '登放日期';
comment on column "AcDetail"."RelTxseq" is '登放序號';
comment on column "AcDetail"."AcSeq" is '分錄序號';
comment on column "AcDetail"."AcDate" is '會計日期';
comment on column "AcDetail"."BranchNo" is '單位別';
comment on column "AcDetail"."CurrencyCode" is '幣別';
comment on column "AcDetail"."AcNoCode" is '科目代號';
comment on column "AcDetail"."AcSubCode" is '子目代號';
comment on column "AcDetail"."AcDtlCode" is '細目代號';
comment on column "AcDetail"."AcctCode" is '業務科目代號';
comment on column "AcDetail"."DbCr" is '借貸別';
comment on column "AcDetail"."TxAmt" is '記帳金額';
comment on column "AcDetail"."EntAc" is '入總帳記號';
comment on column "AcDetail"."CustNo" is '戶號';
comment on column "AcDetail"."FacmNo" is '額度編號';
comment on column "AcDetail"."BormNo" is '撥款序號';
comment on column "AcDetail"."RvNo" is '銷帳編號';
comment on column "AcDetail"."AcctFlag" is '業務科目記號';
comment on column "AcDetail"."ReceivableFlag" is '銷帳科目記號';
comment on column "AcDetail"."AcBookFlag" is '帳冊別記號';
comment on column "AcDetail"."AcBookCode" is '帳冊別';
comment on column "AcDetail"."AcSubBookCode" is '區隔帳冊';
comment on column "AcDetail"."SumNo" is '彙總別';
comment on column "AcDetail"."DscptCode" is '摘要代號';
comment on column "AcDetail"."SlipNote" is '傳票摘要';
comment on column "AcDetail"."SlipBatNo" is '傳票批號';
comment on column "AcDetail"."SlipNo" is '傳票號碼';
comment on column "AcDetail"."TitaKinbr" is '登錄單位別';
comment on column "AcDetail"."TitaTlrNo" is '登錄經辦';
comment on column "AcDetail"."TitaTxtNo" is '登錄交易序號';
comment on column "AcDetail"."TitaTxCd" is '交易代號';
comment on column "AcDetail"."TitaSecNo" is '業務類別';
comment on column "AcDetail"."TitaBatchNo" is '整批批號';
comment on column "AcDetail"."TitaBatchSeq" is '整批明細序號';
comment on column "AcDetail"."TitaSupNo" is '核准主管';
comment on column "AcDetail"."TitaRelCd" is '作業模式';
comment on column "AcDetail"."JsonFields" is 'jason格式紀錄欄';
comment on column "AcDetail"."CreateDate" is '建檔日期時間';
comment on column "AcDetail"."CreateEmpNo" is '建檔人員';
comment on column "AcDetail"."LastUpdate" is '最後更新日期時間';
comment on column "AcDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "AchAuthLog" purge;

create table "AchAuthLog" (
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcct" varchar2(14),
  "CreateFlag" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "AuthStatus" varchar2(1),
  "AuthMeth" varchar2(1),
  "LimitAmt" decimal(8, 2) default 0 not null,
  "MediaCode" varchar2(1),
  "BatchNo" varchar2(6),
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "TitaTxCd" varchar2(5),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AchAuthLog" add constraint "AchAuthLog_PK" primary key("AuthCreateDate", "CustNo", "RepayBank", "RepayAcct", "CreateFlag");

create index "AchAuthLog_Index1" on "AchAuthLog"("AuthCreateDate" asc);

create index "AchAuthLog_Index2" on "AchAuthLog"("MediaCode" asc, "AuthStatus" asc);

create index "AchAuthLog_Index3" on "AchAuthLog"("PropDate" asc);

create index "AchAuthLog_Index4" on "AchAuthLog"("RetrDate" asc);

comment on table "AchAuthLog" is 'ACH授權記錄檔';
comment on column "AchAuthLog"."AuthCreateDate" is '建檔日期';
comment on column "AchAuthLog"."CustNo" is '戶號';
comment on column "AchAuthLog"."RepayBank" is '扣款銀行';
comment on column "AchAuthLog"."RepayAcct" is '扣款帳號';
comment on column "AchAuthLog"."CreateFlag" is '新增或取消記號';
comment on column "AchAuthLog"."FacmNo" is '額度號碼';
comment on column "AchAuthLog"."ProcessDate" is '處理日期';
comment on column "AchAuthLog"."StampFinishDate" is '核印完成日期時間';
comment on column "AchAuthLog"."AuthStatus" is '授權狀態';
comment on column "AchAuthLog"."AuthMeth" is '授權方式';
comment on column "AchAuthLog"."LimitAmt" is '每筆扣款限額';
comment on column "AchAuthLog"."MediaCode" is '媒體碼';
comment on column "AchAuthLog"."BatchNo" is '批號';
comment on column "AchAuthLog"."PropDate" is '提出日期';
comment on column "AchAuthLog"."RetrDate" is '提回日期';
comment on column "AchAuthLog"."DeleteDate" is '刪除日期/暫停授權日期';
comment on column "AchAuthLog"."RelationCode" is '與借款人關係';
comment on column "AchAuthLog"."RelAcctName" is '第三人帳戶戶名';
comment on column "AchAuthLog"."RelationId" is '第三人身分證字號';
comment on column "AchAuthLog"."RelAcctBirthday" is '第三人出生日期';
comment on column "AchAuthLog"."RelAcctGender" is '第三人性別';
comment on column "AchAuthLog"."AmlRsp" is 'AML回應碼';
comment on column "AchAuthLog"."TitaTxCd" is '交易代號';
comment on column "AchAuthLog"."CreateEmpNo" is '建立者櫃員編號';
comment on column "AchAuthLog"."CreateDate" is '建立日期時間';
comment on column "AchAuthLog"."LastUpdateEmpNo" is '修改者櫃員編號';
comment on column "AchAuthLog"."LastUpdate" is '修改日期時間';
drop table "AchAuthLogHistory" purge;

drop sequence "AchAuthLogHistory_SEQ";

create table "AchAuthLogHistory" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcct" varchar2(14),
  "CreateFlag" varchar2(1),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "AuthStatus" varchar2(1),
  "AuthMeth" varchar2(1),
  "LimitAmt" decimal(8, 2) default 0 not null,
  "MediaCode" varchar2(1),
  "BatchNo" varchar2(6),
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AchAuthLogHistory" add constraint "AchAuthLogHistory_PK" primary key("LogNo");

create sequence "AchAuthLogHistory_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

comment on table "AchAuthLogHistory" is 'ACH授權記錄歷史檔';
comment on column "AchAuthLogHistory"."LogNo" is '序號';
comment on column "AchAuthLogHistory"."CustNo" is '戶號';
comment on column "AchAuthLogHistory"."FacmNo" is '額度號碼';
comment on column "AchAuthLogHistory"."AuthCreateDate" is '建檔日期';
comment on column "AchAuthLogHistory"."RepayBank" is '扣款銀行';
comment on column "AchAuthLogHistory"."RepayAcct" is '扣款帳號';
comment on column "AchAuthLogHistory"."CreateFlag" is '新增或取消記號';
comment on column "AchAuthLogHistory"."ProcessDate" is '處理日期';
comment on column "AchAuthLogHistory"."StampFinishDate" is '核印完成日期時間';
comment on column "AchAuthLogHistory"."AuthStatus" is '授權狀態';
comment on column "AchAuthLogHistory"."AuthMeth" is '授權方式';
comment on column "AchAuthLogHistory"."LimitAmt" is '每筆扣款限額';
comment on column "AchAuthLogHistory"."MediaCode" is '媒體碼';
comment on column "AchAuthLogHistory"."BatchNo" is '批號';
comment on column "AchAuthLogHistory"."PropDate" is '提出日期';
comment on column "AchAuthLogHistory"."RetrDate" is '提回日期';
comment on column "AchAuthLogHistory"."DeleteDate" is '刪除日期/暫停授權日期';
comment on column "AchAuthLogHistory"."RelationCode" is '與借款人關係';
comment on column "AchAuthLogHistory"."RelAcctName" is '第三人帳戶戶名';
comment on column "AchAuthLogHistory"."RelationId" is '第三人身分證字號';
comment on column "AchAuthLogHistory"."RelAcctBirthday" is '第三人出生日期';
comment on column "AchAuthLogHistory"."RelAcctGender" is '第三人性別';
comment on column "AchAuthLogHistory"."AmlRsp" is 'AML回應碼';
comment on column "AchAuthLogHistory"."CreateEmpNo" is '建立者櫃員編號';
comment on column "AchAuthLogHistory"."CreateDate" is '建立日期時間';
comment on column "AchAuthLogHistory"."LastUpdateEmpNo" is '修改者櫃員編號';
comment on column "AchAuthLogHistory"."LastUpdate" is '修改日期時間';
drop table "AchDeductMedia" purge;

create table "AchDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ReturnCode" varchar2(2),
  "EntryDate" decimal(8, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcctNo" varchar2(14),
  "AchRepayCode" varchar2(1),
  "AcctCode" varchar2(3),
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "DepCode" varchar2(2),
  "RelationCode" varchar2(2),
  "RelCustName" nvarchar2(100),
  "RelCustId" varchar2(10),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AchDeductMedia" add constraint "AchDeductMedia_PK" primary key("MediaDate", "MediaKind", "MediaSeq");

create index "AchDeductMedia_Index1" on "AchDeductMedia"("AcDate" asc, "BatchNo" asc, "DetailSeq" asc);

create index "AchDeductMedia_Index2" on "AchDeductMedia"("CustNo" asc, "FacmNo" asc);

comment on table "AchDeductMedia" is 'ACH扣款媒體檔';
comment on column "AchDeductMedia"."MediaDate" is '媒體日期';
comment on column "AchDeductMedia"."MediaKind" is '媒體別';
comment on column "AchDeductMedia"."MediaSeq" is '媒體序號';
comment on column "AchDeductMedia"."CustNo" is '戶號';
comment on column "AchDeductMedia"."FacmNo" is '額度號碼';
comment on column "AchDeductMedia"."RepayType" is '還款類別';
comment on column "AchDeductMedia"."RepayAmt" is '扣款金額,還款金額';
comment on column "AchDeductMedia"."ReturnCode" is '退件理由代號';
comment on column "AchDeductMedia"."EntryDate" is '入帳日期';
comment on column "AchDeductMedia"."PrevIntDate" is '繳息迄日';
comment on column "AchDeductMedia"."RepayBank" is '扣款銀行';
comment on column "AchDeductMedia"."RepayAcctNo" is '扣款帳號';
comment on column "AchDeductMedia"."AchRepayCode" is '入帳扣款別';
comment on column "AchDeductMedia"."AcctCode" is '科目';
comment on column "AchDeductMedia"."IntStartDate" is '計息起日';
comment on column "AchDeductMedia"."IntEndDate" is '計息迄日';
comment on column "AchDeductMedia"."DepCode" is '存摺代號';
comment on column "AchDeductMedia"."RelationCode" is '與借款人關係';
comment on column "AchDeductMedia"."RelCustName" is '帳戶戶名';
comment on column "AchDeductMedia"."RelCustId" is '身分證字號';
comment on column "AchDeductMedia"."AcDate" is '會計日期';
comment on column "AchDeductMedia"."BatchNo" is '批號';
comment on column "AchDeductMedia"."DetailSeq" is '明細序號';
comment on column "AchDeductMedia"."CreateDate" is '建檔日期時間';
comment on column "AchDeductMedia"."CreateEmpNo" is '建檔人員';
comment on column "AchDeductMedia"."LastUpdate" is '最後更新日期時間';
comment on column "AchDeductMedia"."LastUpdateEmpNo" is '最後更新人員';
drop table "AcLoanInt" purge;

create table "AcLoanInt" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "TermNo" decimal(3, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "Amount" decimal(16, 2) default 0 not null,
  "IntRate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "AcctCode" varchar2(3),
  "PayIntDate" decimal(8, 0) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "Aging" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "BranchNo" varchar2(4),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcLoanInt" add constraint "AcLoanInt_PK" primary key("YearMonth", "CustNo", "FacmNo", "BormNo", "TermNo");

comment on table "AcLoanInt" is '提息明細檔';
comment on column "AcLoanInt"."YearMonth" is '提息年月';
comment on column "AcLoanInt"."CustNo" is '借款人戶號';
comment on column "AcLoanInt"."FacmNo" is '額度編號';
comment on column "AcLoanInt"."BormNo" is '撥款序號';
comment on column "AcLoanInt"."TermNo" is '期數編號';
comment on column "AcLoanInt"."IntStartDate" is '計息起日';
comment on column "AcLoanInt"."IntEndDate" is '計息止日';
comment on column "AcLoanInt"."Amount" is '計息本金';
comment on column "AcLoanInt"."IntRate" is '計息利率';
comment on column "AcLoanInt"."Principal" is '回收本金';
comment on column "AcLoanInt"."Interest" is '利息';
comment on column "AcLoanInt"."DelayInt" is '延滯息';
comment on column "AcLoanInt"."BreachAmt" is '違約金';
comment on column "AcLoanInt"."RateIncr" is '加碼利率';
comment on column "AcLoanInt"."IndividualIncr" is '個別加碼利率';
comment on column "AcLoanInt"."AcctCode" is '業務科目代號';
comment on column "AcLoanInt"."PayIntDate" is '應繳息日';
comment on column "AcLoanInt"."LoanBal" is '放款餘額';
comment on column "AcLoanInt"."Aging" is '帳齡';
comment on column "AcLoanInt"."AcBookCode" is '帳冊別';
comment on column "AcLoanInt"."AcSubBookCode" is '區隔帳冊';
comment on column "AcLoanInt"."BranchNo" is '單位別';
comment on column "AcLoanInt"."CreateDate" is '建檔日期時間';
comment on column "AcLoanInt"."CreateEmpNo" is '建檔人員';
comment on column "AcLoanInt"."LastUpdate" is '最後更新日期時間';
comment on column "AcLoanInt"."LastUpdateEmpNo" is '最後更新人員';
drop table "AcLoanRenew" purge;

create table "AcLoanRenew" (
  "CustNo" decimal(7, 0) default 0 not null,
  "NewFacmNo" decimal(3, 0) default 0 not null,
  "NewBormNo" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "OldBormNo" decimal(3, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "MainFlag" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AcLoanRenew" add constraint "AcLoanRenew_PK" primary key("CustNo", "NewFacmNo", "NewBormNo", "OldFacmNo", "OldBormNo");

create index "AcLoanRenew_Index1" on "AcLoanRenew"("CustNo" asc, "OldFacmNo" asc, "OldBormNo" asc, "NewFacmNo" asc, "NewBormNo" asc);

comment on table "AcLoanRenew" is '會計借新還舊檔';
comment on column "AcLoanRenew"."CustNo" is '戶號';
comment on column "AcLoanRenew"."NewFacmNo" is '新額度編號';
comment on column "AcLoanRenew"."NewBormNo" is '新撥款序號';
comment on column "AcLoanRenew"."OldFacmNo" is '舊額度編號';
comment on column "AcLoanRenew"."OldBormNo" is '舊撥款序號';
comment on column "AcLoanRenew"."RenewCode" is '展期記號';
comment on column "AcLoanRenew"."MainFlag" is '主要記號';
comment on column "AcLoanRenew"."AcDate" is '會計日期';
comment on column "AcLoanRenew"."CreateEmpNo" is '建檔人員';
comment on column "AcLoanRenew"."CreateDate" is '建檔日期';
comment on column "AcLoanRenew"."LastUpdateEmpNo" is '最後維護人員';
comment on column "AcLoanRenew"."LastUpdate" is '最後維護日期';
drop table "AcMain" purge;

create table "AcMain" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcDate" decimal(8, 0) default 0 not null,
  "YdBal" decimal(16, 2) default 0 not null,
  "TdBal" decimal(16, 2) default 0 not null,
  "DbCnt" decimal(8, 0) default 0 not null,
  "DbAmt" decimal(16, 2) default 0 not null,
  "CrCnt" decimal(8, 0) default 0 not null,
  "CrAmt" decimal(16, 2) default 0 not null,
  "CoreDbCnt" decimal(8, 0) default 0 not null,
  "CoreDbAmt" decimal(16, 2) default 0 not null,
  "CoreCrCnt" decimal(8, 0) default 0 not null,
  "CoreCrAmt" decimal(16, 2) default 0 not null,
  "AcctCode" varchar2(3),
  "MonthEndYm" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AcMain" add constraint "AcMain_PK" primary key("AcBookCode", "AcSubBookCode", "BranchNo", "CurrencyCode", "AcNoCode", "AcSubCode", "AcDtlCode", "AcDate");

create index "AcMain_Index1" on "AcMain"("AcBookCode" asc, "BranchNo" asc, "CurrencyCode" asc, "AcDate" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc);

create index "AcMain_Index2" on "AcMain"("AcDate" asc, "AcBookCode" asc, "BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc);

comment on table "AcMain" is '會計總帳檔';
comment on column "AcMain"."AcBookCode" is '帳冊別';
comment on column "AcMain"."AcSubBookCode" is '區隔帳冊';
comment on column "AcMain"."BranchNo" is '單位別';
comment on column "AcMain"."CurrencyCode" is '幣別';
comment on column "AcMain"."AcNoCode" is '科目代號';
comment on column "AcMain"."AcSubCode" is '子目代號';
comment on column "AcMain"."AcDtlCode" is '細目代號';
comment on column "AcMain"."AcDate" is '會計日期';
comment on column "AcMain"."YdBal" is '前日餘額';
comment on column "AcMain"."TdBal" is '本日餘額';
comment on column "AcMain"."DbCnt" is '借方筆數';
comment on column "AcMain"."DbAmt" is '借方金額';
comment on column "AcMain"."CrCnt" is '貸方筆數';
comment on column "AcMain"."CrAmt" is '貸方金額';
comment on column "AcMain"."CoreDbCnt" is '核心借方筆數';
comment on column "AcMain"."CoreDbAmt" is '核心借方金額';
comment on column "AcMain"."CoreCrCnt" is '核心貸方筆數';
comment on column "AcMain"."CoreCrAmt" is '核心貸方金額';
comment on column "AcMain"."AcctCode" is '業務科目代號';
comment on column "AcMain"."MonthEndYm" is '月底年月';
comment on column "AcMain"."CreateDate" is '建檔日期時間';
comment on column "AcMain"."CreateEmpNo" is '建檔人員';
comment on column "AcMain"."LastUpdate" is '最後更新日期時間';
comment on column "AcMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "AcReceivable" purge;

create table "AcReceivable" (
  "AcctCode" varchar2(3),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RvNo" varchar2(30),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "ClsFlag" decimal(1, 0) default 0 not null,
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "RvAmt" decimal(16, 2) default 0 not null,
  "RvBal" decimal(16, 2) default 0 not null,
  "AcBal" decimal(16, 2) default 0 not null,
  "SlipNote" nvarchar2(80),
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "OpenAcDate" decimal(8, 0) default 0 not null,
  "LastAcDate" decimal(8, 0) default 0 not null,
  "LastTxDate" decimal(8, 0) default 0 not null,
  "TitaTxCd" varchar2(5),
  "TitaKinBr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "JsonFields" varchar2(300),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "AcReceivable" add constraint "AcReceivable_PK" primary key("AcctCode", "CustNo", "FacmNo", "RvNo");

create index "AcReceivable_Index1" on "AcReceivable"("AcctCode" asc, "CustNo" asc, "FacmNo" asc, "RvNo" asc);

create index "AcReceivable_Index2" on "AcReceivable"("ClsFlag" asc, "BranchNo" asc, "CurrencyCode" asc, "AcNoCode" asc, "AcSubCode" asc, "AcDtlCode" asc, "CustNo" asc, "FacmNo" asc, "RvNo" asc);

create index "AcReceivable_Index3" on "AcReceivable"("ClsFlag" asc, "CustNo" asc, "AcctFlag" asc, "FacmNo" asc, "AcDtlCode" asc, "RvNo" asc);

comment on table "AcReceivable" is '會計銷帳檔';
comment on column "AcReceivable"."AcctCode" is '業務科目代號';
comment on column "AcReceivable"."CustNo" is '戶號';
comment on column "AcReceivable"."FacmNo" is '額度編號';
comment on column "AcReceivable"."RvNo" is '銷帳編號';
comment on column "AcReceivable"."AcNoCode" is '科目代號';
comment on column "AcReceivable"."AcSubCode" is '子目代號';
comment on column "AcReceivable"."AcDtlCode" is '細目代號';
comment on column "AcReceivable"."BranchNo" is '單位別';
comment on column "AcReceivable"."CurrencyCode" is '幣別';
comment on column "AcReceivable"."ClsFlag" is '銷帳記號';
comment on column "AcReceivable"."AcctFlag" is '業務科目記號';
comment on column "AcReceivable"."ReceivableFlag" is '銷帳科目記號';
comment on column "AcReceivable"."RvAmt" is '起帳總額';
comment on column "AcReceivable"."RvBal" is '未銷餘額';
comment on column "AcReceivable"."AcBal" is '會計日餘額';
comment on column "AcReceivable"."SlipNote" is '傳票摘要';
comment on column "AcReceivable"."AcBookCode" is '帳冊別';
comment on column "AcReceivable"."AcSubBookCode" is '區隔帳冊';
comment on column "AcReceivable"."OpenAcDate" is '起帳日期';
comment on column "AcReceivable"."LastAcDate" is '最後作帳日';
comment on column "AcReceivable"."LastTxDate" is '最後交易日';
comment on column "AcReceivable"."TitaTxCd" is '交易代號';
comment on column "AcReceivable"."TitaKinBr" is '單位別';
comment on column "AcReceivable"."TitaTlrNo" is '經辦';
comment on column "AcReceivable"."TitaTxtNo" is '交易序號';
comment on column "AcReceivable"."JsonFields" is 'jason格式紀錄欄';
comment on column "AcReceivable"."CreateEmpNo" is '建檔人員';
comment on column "AcReceivable"."CreateDate" is '建檔日期';
comment on column "AcReceivable"."LastUpdateEmpNo" is '最後維護人員';
comment on column "AcReceivable"."LastUpdate" is '最後維護日期';
drop table "AmlCustList" purge;

create table "AmlCustList" (
  "CustNo" decimal(7, 0) default 0 not null,
  "Note1" varchar2(1),
  "Note2" varchar2(1),
  "Note3" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "AmlCustList" add constraint "AmlCustList_PK" primary key("CustNo");

comment on table "AmlCustList" is 'AML每日有效客戶名單';
comment on column "AmlCustList"."CustNo" is '借款人戶號';
comment on column "AmlCustList"."Note1" is '註記1';
comment on column "AmlCustList"."Note2" is '註記2';
comment on column "AmlCustList"."Note3" is '註記3';
comment on column "AmlCustList"."CreateDate" is '建檔日期時間';
comment on column "AmlCustList"."CreateEmpNo" is '建檔人員';
comment on column "AmlCustList"."LastUpdate" is '最後更新日期時間';
comment on column "AmlCustList"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankAuthAct" purge;

create table "BankAuthAct" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthType" varchar2(2),
  "RepayBank" varchar2(3),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "Status" varchar2(1),
  "LimitAmt" decimal(14, 0) default 0 not null,
  "AcctSeq" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankAuthAct" add constraint "BankAuthAct_PK" primary key("CustNo", "FacmNo", "AuthType");

create index "BankAuthAct_Index1" on "BankAuthAct"("CustNo" asc, "FacmNo" asc, "RepayAcct" asc);

comment on table "BankAuthAct" is '銀扣授權帳號檔';
comment on column "BankAuthAct"."CustNo" is '戶號';
comment on column "BankAuthAct"."FacmNo" is '額度';
comment on column "BankAuthAct"."AuthType" is '授權類別';
comment on column "BankAuthAct"."RepayBank" is '扣款銀行';
comment on column "BankAuthAct"."PostDepCode" is '郵局存款別';
comment on column "BankAuthAct"."RepayAcct" is '扣款帳號';
comment on column "BankAuthAct"."Status" is '狀態碼';
comment on column "BankAuthAct"."LimitAmt" is '每筆扣款限額';
comment on column "BankAuthAct"."AcctSeq" is '帳號碼';
comment on column "BankAuthAct"."CreateDate" is '建檔日期時間';
comment on column "BankAuthAct"."CreateEmpNo" is '建檔人員';
comment on column "BankAuthAct"."LastUpdate" is '最後更新日期時間';
comment on column "BankAuthAct"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankDeductDtl" purge;

create table "BankDeductDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "PayIntDate" decimal(8, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "RepayBank" varchar2(3),
  "RepayAcctNo" varchar2(14),
  "RepayAcctSeq" varchar2(2),
  "UnpaidAmt" decimal(14, 0) default 0 not null,
  "TempAmt" decimal(14, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "PostCode" varchar2(1),
  "MediaCode" varchar2(1),
  "RelationCode" varchar2(2),
  "RelCustName" nvarchar2(100),
  "RelCustId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "AmlRsp" varchar2(1),
  "ReturnCode" varchar2(2),
  "JsonFields" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankDeductDtl" add constraint "BankDeductDtl_PK" primary key("EntryDate", "CustNo", "FacmNo", "BormNo", "RepayType", "PayIntDate");

create index "BankDeductDtl_Index1" on "BankDeductDtl"("CustNo" asc, "EntryDate" asc);

create index "BankDeductDtl_Index2" on "BankDeductDtl"("MediaDate" asc, "MediaKind" asc, "MediaSeq" asc);

comment on table "BankDeductDtl" is '銀行扣款明細檔';
comment on column "BankDeductDtl"."EntryDate" is '入帳日期';
comment on column "BankDeductDtl"."CustNo" is '戶號';
comment on column "BankDeductDtl"."FacmNo" is '額度';
comment on column "BankDeductDtl"."BormNo" is '撥款';
comment on column "BankDeductDtl"."RepayType" is '還款類別';
comment on column "BankDeductDtl"."PayIntDate" is '應繳日';
comment on column "BankDeductDtl"."PrevIntDate" is '繳息迄日';
comment on column "BankDeductDtl"."AcctCode" is '科目';
comment on column "BankDeductDtl"."RepayBank" is '扣款銀行';
comment on column "BankDeductDtl"."RepayAcctNo" is '扣款帳號';
comment on column "BankDeductDtl"."RepayAcctSeq" is '帳號碼';
comment on column "BankDeductDtl"."UnpaidAmt" is '應扣金額';
comment on column "BankDeductDtl"."TempAmt" is '暫收款抵繳金額';
comment on column "BankDeductDtl"."RepayAmt" is '扣款金額';
comment on column "BankDeductDtl"."IntStartDate" is '計息起日';
comment on column "BankDeductDtl"."IntEndDate" is '計息迄日';
comment on column "BankDeductDtl"."PostCode" is '郵局存款別';
comment on column "BankDeductDtl"."MediaCode" is '媒體碼';
comment on column "BankDeductDtl"."RelationCode" is '與借款人關係';
comment on column "BankDeductDtl"."RelCustName" is '第三人帳戶戶名';
comment on column "BankDeductDtl"."RelCustId" is '第三人身分證字號';
comment on column "BankDeductDtl"."RelAcctBirthday" is '第三人出生日期';
comment on column "BankDeductDtl"."RelAcctGender" is '第三人性別';
comment on column "BankDeductDtl"."MediaDate" is '媒體日期';
comment on column "BankDeductDtl"."MediaKind" is '媒體別';
comment on column "BankDeductDtl"."MediaSeq" is '媒體序號';
comment on column "BankDeductDtl"."AcDate" is '會計日期';
comment on column "BankDeductDtl"."TitaTlrNo" is '經辦';
comment on column "BankDeductDtl"."TitaTxtNo" is '交易序號';
comment on column "BankDeductDtl"."AmlRsp" is 'AML回應碼';
comment on column "BankDeductDtl"."ReturnCode" is '回應代碼';
comment on column "BankDeductDtl"."JsonFields" is 'jason格式紀錄欄';
comment on column "BankDeductDtl"."CreateDate" is '建檔日期時間';
comment on column "BankDeductDtl"."CreateEmpNo" is '建檔人員';
comment on column "BankDeductDtl"."LastUpdate" is '最後更新日期時間';
comment on column "BankDeductDtl"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankRelationCompany" purge;

create table "BankRelationCompany" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "CompanyId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationCompany" add constraint "BankRelationCompany_PK" primary key("CustName", "CustId", "CompanyId");

comment on table "BankRelationCompany" is '金控利害關係人_關係企業資料';
comment on column "BankRelationCompany"."CustName" is '借款戶所屬公司名稱';
comment on column "BankRelationCompany"."CustId" is '借款戶統編/親屬統編';
comment on column "BankRelationCompany"."CompanyId" is '關係企業統編';
comment on column "BankRelationCompany"."LAW001" is '金控法第44條';
comment on column "BankRelationCompany"."LAW002" is '金控法第44條(列項)';
comment on column "BankRelationCompany"."LAW003" is '金控法第45條';
comment on column "BankRelationCompany"."LAW005" is '保險法(放款)';
comment on column "BankRelationCompany"."LAW008" is '準利害關係人';
comment on column "BankRelationCompany"."CreateDate" is '建檔日期時間';
comment on column "BankRelationCompany"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationCompany"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationCompany"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankRelationFamily" purge;

create table "BankRelationFamily" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "RelationId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationFamily" add constraint "BankRelationFamily_PK" primary key("CustName", "CustId", "RelationId");

comment on table "BankRelationFamily" is '金控利害關係人_關係人員工之親屬資料';
comment on column "BankRelationFamily"."CustName" is '借款戶所屬公司名稱';
comment on column "BankRelationFamily"."CustId" is '借款戶統編';
comment on column "BankRelationFamily"."RelationId" is '親屬統編';
comment on column "BankRelationFamily"."LAW001" is '金控法第44條';
comment on column "BankRelationFamily"."LAW002" is '金控法第44條(列項)';
comment on column "BankRelationFamily"."LAW003" is '金控法第45條';
comment on column "BankRelationFamily"."LAW005" is '保險法(放款)';
comment on column "BankRelationFamily"."LAW008" is '準利害關係人';
comment on column "BankRelationFamily"."CreateDate" is '建檔日期時間';
comment on column "BankRelationFamily"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationFamily"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationFamily"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankRelationSelf" purge;

create table "BankRelationSelf" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationSelf" add constraint "BankRelationSelf_PK" primary key("CustName", "CustId");

comment on table "BankRelationSelf" is '金控利害關係人_關係人員工資料';
comment on column "BankRelationSelf"."CustName" is '借款戶所屬公司名稱';
comment on column "BankRelationSelf"."CustId" is '借款戶統編';
comment on column "BankRelationSelf"."LAW001" is '金控法第44條';
comment on column "BankRelationSelf"."LAW002" is '金控法第44條(列項)';
comment on column "BankRelationSelf"."LAW003" is '金控法第45條';
comment on column "BankRelationSelf"."LAW005" is '保險法(放款)';
comment on column "BankRelationSelf"."LAW008" is '準利害關係人';
comment on column "BankRelationSelf"."CreateDate" is '建檔日期時間';
comment on column "BankRelationSelf"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationSelf"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationSelf"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankRelationSuspected" purge;

create table "BankRelationSuspected" (
  "RepCusName" nvarchar2(100),
  "CustId" varchar2(11),
  "CustName" nvarchar2(100),
  "SubCom" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationSuspected" add constraint "BankRelationSuspected_PK" primary key("RepCusName", "CustId");

comment on table "BankRelationSuspected" is '是否為疑似準利害關係人檔';
comment on column "BankRelationSuspected"."RepCusName" is '自然人姓名';
comment on column "BankRelationSuspected"."CustId" is '該自然人擔任董事長之公司統一編號';
comment on column "BankRelationSuspected"."CustName" is '公司名稱';
comment on column "BankRelationSuspected"."SubCom" is '職務名稱';
comment on column "BankRelationSuspected"."CreateDate" is '建檔日期時間';
comment on column "BankRelationSuspected"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationSuspected"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationSuspected"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankRemit" purge;

create table "BankRemit" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "BatchNo" varchar2(6),
  "DrawdownCode" decimal(2, 0) default 0 not null,
  "StatusCode" decimal(1, 0) default 0 not null,
  "RemitBank" varchar2(3),
  "RemitBranch" varchar2(4),
  "RemitAcctNo" varchar2(14),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustName" nvarchar2(100),
  "Remark" nvarchar2(100),
  "CurrencyCode" varchar2(3),
  "RemitAmt" decimal(16, 2) default 0 not null,
  "AmlRsp" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "ModifyContent" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRemit" add constraint "BankRemit_PK" primary key("AcDate", "TitaTlrNo", "TitaTxtNo");

create index "BankRemit_Index1" on "BankRemit"("CustNo" asc);

comment on table "BankRemit" is '撥款匯款檔';
comment on column "BankRemit"."AcDate" is '會計日期';
comment on column "BankRemit"."TitaTlrNo" is '經辦';
comment on column "BankRemit"."TitaTxtNo" is '交易序號';
comment on column "BankRemit"."BatchNo" is '整批批號';
comment on column "BankRemit"."DrawdownCode" is '撥款方式';
comment on column "BankRemit"."StatusCode" is '狀態';
comment on column "BankRemit"."RemitBank" is '匯款銀行';
comment on column "BankRemit"."RemitBranch" is '匯款分行';
comment on column "BankRemit"."RemitAcctNo" is '匯款帳號';
comment on column "BankRemit"."CustNo" is '收款戶號';
comment on column "BankRemit"."FacmNo" is '額度編號';
comment on column "BankRemit"."BormNo" is '撥款序號';
comment on column "BankRemit"."CustName" is '收款戶名';
comment on column "BankRemit"."Remark" is '附言';
comment on column "BankRemit"."CurrencyCode" is '幣別';
comment on column "BankRemit"."RemitAmt" is '匯款金額';
comment on column "BankRemit"."AmlRsp" is 'AML回應碼';
comment on column "BankRemit"."ActFg" is '交易進行記號';
comment on column "BankRemit"."ModifyContent" is '產檔後修正後內容';
comment on column "BankRemit"."CreateDate" is '建檔日期時間';
comment on column "BankRemit"."CreateEmpNo" is '建檔人員';
comment on column "BankRemit"."LastUpdate" is '最後更新日期時間';
comment on column "BankRemit"."LastUpdateEmpNo" is '最後更新人員';
drop table "BankRmtf" purge;

create table "BankRmtf" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayType" varchar2(2),
  "RepayAmt" decimal(14, 0) default 0 not null,
  "DepAcctNo" varchar2(14),
  "EntryDate" decimal(8, 0) default 0 not null,
  "DscptCode" varchar2(4),
  "VirtualAcctNo" nvarchar2(14),
  "WithdrawAmt" decimal(14, 0) default 0 not null,
  "DepositAmt" decimal(14, 0) default 0 not null,
  "Balance" decimal(14, 0) default 0 not null,
  "RemintBank" varchar2(7),
  "TraderInfo" nvarchar2(20),
  "AmlRsp" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRmtf" add constraint "BankRmtf_PK" primary key("AcDate", "BatchNo", "DetailSeq");

comment on table "BankRmtf" is '匯款轉帳檔';
comment on column "BankRmtf"."AcDate" is '會計日';
comment on column "BankRmtf"."BatchNo" is '批號';
comment on column "BankRmtf"."DetailSeq" is '明細序號';
comment on column "BankRmtf"."CustNo" is '戶號';
comment on column "BankRmtf"."RepayType" is '還款類別';
comment on column "BankRmtf"."RepayAmt" is '還款金額';
comment on column "BankRmtf"."DepAcctNo" is '存摺帳號';
comment on column "BankRmtf"."EntryDate" is '入帳日期';
comment on column "BankRmtf"."DscptCode" is '摘要代碼';
comment on column "BankRmtf"."VirtualAcctNo" is '虛擬帳號';
comment on column "BankRmtf"."WithdrawAmt" is '提款';
comment on column "BankRmtf"."DepositAmt" is '存款';
comment on column "BankRmtf"."Balance" is '結餘';
comment on column "BankRmtf"."RemintBank" is '匯款銀行代碼';
comment on column "BankRmtf"."TraderInfo" is '交易人資料';
comment on column "BankRmtf"."AmlRsp" is 'AML回應碼';
comment on column "BankRmtf"."CreateDate" is '建檔日期時間';
comment on column "BankRmtf"."CreateEmpNo" is '建檔人員';
comment on column "BankRmtf"."LastUpdate" is '最後更新日期時間';
comment on column "BankRmtf"."LastUpdateEmpNo" is '最後更新人員';
drop table "BatxCheque" purge;

create table "BatxCheque" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "ChequeAcct" varchar2(9),
  "ChequeNo" varchar2(7),
  "ChequeAmt" decimal(14, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "AdjDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "ChequeDate" decimal(8, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "ProcessCode" varchar2(1),
  "OutsideCode" varchar2(1),
  "MediaCode" varchar2(1),
  "BankCode" varchar2(7),
  "MediaBatchNo" varchar2(2),
  "OfficeCode" varchar2(1),
  "ExchangeAreaCode" varchar2(2),
  "ChequeId" varchar2(10),
  "ChequeName" nvarchar2(100),
  "AmlRsp" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxCheque" add constraint "BatxCheque_PK" primary key("AcDate", "BatchNo", "ChequeAcct", "ChequeNo");

comment on table "BatxCheque" is '支票兌現檔';
comment on column "BatxCheque"."AcDate" is '會計日期';
comment on column "BatxCheque"."BatchNo" is '批號';
comment on column "BatxCheque"."ChequeAcct" is '支票帳號';
comment on column "BatxCheque"."ChequeNo" is '支票號碼';
comment on column "BatxCheque"."ChequeAmt" is '支票金額';
comment on column "BatxCheque"."CustNo" is '戶號';
comment on column "BatxCheque"."StatusCode" is '票據狀況碼';
comment on column "BatxCheque"."AdjDate" is '異動日';
comment on column "BatxCheque"."TitaTlrNo" is '經辦';
comment on column "BatxCheque"."TitaTxtNo" is '交易序號';
comment on column "BatxCheque"."ChequeDate" is '到期日';
comment on column "BatxCheque"."EntryDate" is '收票日';
comment on column "BatxCheque"."ProcessCode" is '處理代碼';
comment on column "BatxCheque"."OutsideCode" is '本埠外埠';
comment on column "BatxCheque"."MediaCode" is '入媒體';
comment on column "BatxCheque"."BankCode" is '行庫代號';
comment on column "BatxCheque"."MediaBatchNo" is '媒體批號';
comment on column "BatxCheque"."OfficeCode" is '服務中心別';
comment on column "BatxCheque"."ExchangeAreaCode" is '交換區號';
comment on column "BatxCheque"."ChequeId" is '發票人ID';
comment on column "BatxCheque"."ChequeName" is '發票人姓名';
comment on column "BatxCheque"."AmlRsp" is 'AML回應碼';
comment on column "BatxCheque"."CreateDate" is '建檔日期時間';
comment on column "BatxCheque"."CreateEmpNo" is '建檔人員';
comment on column "BatxCheque"."LastUpdate" is '最後更新日期時間';
comment on column "BatxCheque"."LastUpdateEmpNo" is '最後更新人員';
drop table "BatxDetail" purge;

create table "BatxDetail" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "FileName" varchar2(50),
  "RecordSeq" decimal(6, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RvNo" nvarchar2(30),
  "RepayType" decimal(2, 0) default 0 not null,
  "ReconCode" varchar2(3),
  "RepayAcCode" varchar2(18),
  "AcquiredAmt" decimal(14, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "AcctAmt" decimal(14, 0) default 0 not null,
  "DisacctAmt" decimal(14, 0) default 0 not null,
  "ProcStsCode" varchar2(1),
  "ProcCode" varchar2(5),
  "ProcNote" nvarchar2(600),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxDetail" add constraint "BatxDetail_PK" primary key("AcDate", "BatchNo", "DetailSeq");

alter table "BatxDetail" add constraint "BatxDetail_BatxHead_FK1" foreign key ("AcDate", "BatchNo") references "BatxHead" ("AcDate", "BatchNo") on delete cascade;

create index "BatxDetail_Index1" on "BatxDetail"("MediaDate" asc, "MediaKind" asc, "MediaSeq" asc);

create index "BatxDetail_Index2" on "BatxDetail"("EntryDate" asc, "CustNo" asc, "FacmNo" asc, "RepayCode" asc);

create index "BatxDetail_Index3" on "BatxDetail"("AcDate" asc);

create index "BatxDetail_Index4" on "BatxDetail"("AcDate" asc, "BatchNo" asc, "RepayType" asc, "FileName" asc, "ProcStsCode" asc);

comment on table "BatxDetail" is '整批入帳明細檔';
comment on column "BatxDetail"."AcDate" is '會計日期';
comment on column "BatxDetail"."BatchNo" is '整批批號';
comment on column "BatxDetail"."DetailSeq" is '明細序號';
comment on column "BatxDetail"."RepayCode" is '還款來源';
comment on column "BatxDetail"."FileName" is '檔名';
comment on column "BatxDetail"."RecordSeq" is '檔案序號';
comment on column "BatxDetail"."EntryDate" is '入帳日期';
comment on column "BatxDetail"."CustNo" is '戶號';
comment on column "BatxDetail"."FacmNo" is '額度';
comment on column "BatxDetail"."RvNo" is '銷帳編號';
comment on column "BatxDetail"."RepayType" is '還款類別';
comment on column "BatxDetail"."ReconCode" is '對帳類別';
comment on column "BatxDetail"."RepayAcCode" is '來源會計科目';
comment on column "BatxDetail"."AcquiredAmt" is '還款總金額';
comment on column "BatxDetail"."RepayAmt" is '還款金額';
comment on column "BatxDetail"."AcctAmt" is '已作帳金額';
comment on column "BatxDetail"."DisacctAmt" is '未作帳金額';
comment on column "BatxDetail"."ProcStsCode" is '處理狀態';
comment on column "BatxDetail"."ProcCode" is '處理代碼';
comment on column "BatxDetail"."ProcNote" is '處理說明';
comment on column "BatxDetail"."TitaTlrNo" is '經辦';
comment on column "BatxDetail"."TitaTxtNo" is '交易序號';
comment on column "BatxDetail"."MediaDate" is '媒體日期';
comment on column "BatxDetail"."MediaKind" is '媒體別';
comment on column "BatxDetail"."MediaSeq" is '媒體序號';
comment on column "BatxDetail"."CreateDate" is '建檔日期時間';
comment on column "BatxDetail"."CreateEmpNo" is '建檔人員';
comment on column "BatxDetail"."LastUpdate" is '最後更新日期時間';
comment on column "BatxDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "BatxHead" purge;

create table "BatxHead" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "BatxTotAmt" decimal(14, 0) default 0 not null,
  "BatxTotCnt" decimal(6, 0) default 0 not null,
  "UnfinishCnt" decimal(6, 0) default 0 not null,
  "BatxExeCode" varchar2(1),
  "BatxStsCode" varchar2(1),
  "TitaTlrNo" varchar2(6),
  "TitaTxCd" varchar2(5),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxHead" add constraint "BatxHead_PK" primary key("AcDate", "BatchNo");

comment on table "BatxHead" is '整批入帳總數檔';
comment on column "BatxHead"."AcDate" is '會計日期';
comment on column "BatxHead"."BatchNo" is '批號';
comment on column "BatxHead"."BatxTotAmt" is '總金額';
comment on column "BatxHead"."BatxTotCnt" is '總筆數';
comment on column "BatxHead"."UnfinishCnt" is '未完筆數';
comment on column "BatxHead"."BatxExeCode" is '作業狀態';
comment on column "BatxHead"."BatxStsCode" is '整批作業狀態';
comment on column "BatxHead"."TitaTlrNo" is '經辦';
comment on column "BatxHead"."TitaTxCd" is '交易代號';
comment on column "BatxHead"."CreateDate" is '建檔日期時間';
comment on column "BatxHead"."CreateEmpNo" is '建檔人員';
comment on column "BatxHead"."LastUpdate" is '最後更新日期時間';
comment on column "BatxHead"."LastUpdateEmpNo" is '最後更新人員';
drop table "BatxOthers" purge;

create table "BatxOthers" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAcCode" varchar2(18),
  "EntryDate" decimal(8, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "RepayId" varchar2(10),
  "RepayName" nvarchar2(100),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CustNm" nvarchar2(100),
  "RvNo" varchar2(12),
  "Note" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxOthers" add constraint "BatxOthers_PK" primary key("AcDate", "BatchNo", "DetailSeq");

create index "BatxOthers_Index1" on "BatxOthers"("AcDate" asc, "BatchNo" asc, "RepayType" asc, "CreateEmpNo" asc);

comment on table "BatxOthers" is '其他還款來源檔';
comment on column "BatxOthers"."AcDate" is '會計日期';
comment on column "BatxOthers"."BatchNo" is '整批批號';
comment on column "BatxOthers"."DetailSeq" is '明細序號';
comment on column "BatxOthers"."RepayCode" is '來源';
comment on column "BatxOthers"."RepayType" is '還款類別';
comment on column "BatxOthers"."RepayAcCode" is '來源會計科目';
comment on column "BatxOthers"."EntryDate" is '入帳日期';
comment on column "BatxOthers"."RepayAmt" is '金額';
comment on column "BatxOthers"."RepayId" is '來源統編';
comment on column "BatxOthers"."RepayName" is '來源戶名';
comment on column "BatxOthers"."CustNo" is '借款人戶號';
comment on column "BatxOthers"."FacmNo" is '額度號碼';
comment on column "BatxOthers"."CustNm" is '借款人戶名';
comment on column "BatxOthers"."RvNo" is '銷帳碼';
comment on column "BatxOthers"."Note" is '摘要';
comment on column "BatxOthers"."CreateDate" is '建檔日期時間';
comment on column "BatxOthers"."CreateEmpNo" is '建檔人員';
comment on column "BatxOthers"."LastUpdate" is '最後更新日期時間';
comment on column "BatxOthers"."LastUpdateEmpNo" is '最後更新人員';
drop table "BatxRateChange" purge;

create table "BatxRateChange" (
  "AdjDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "TxKind" decimal(1, 0) default 0 not null,
  "DrawdownAmt" decimal(14, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IncrFlag" varchar2(1),
  "AdjCode" decimal(1, 0) default 0 not null,
  "RateKeyInCode" decimal(1, 0) default 0 not null,
  "ConfirmFlag" decimal(1, 0) default 0 not null,
  "TotBalance" decimal(14, 0) default 0 not null,
  "LoanBalance" decimal(14, 0) default 0 not null,
  "PresEffDate" decimal(8, 0) default 0 not null,
  "CurtEffDate" decimal(8, 0) default 0 not null,
  "PreNextAdjDate" decimal(8, 0) default 0 not null,
  "PreNextAdjFreq" decimal(2, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "CustCode" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "RateIncr" decimal(6, 4) default 0 not null,
  "ContractRate" decimal(6, 4) default 0 not null,
  "PresentRate" decimal(6, 4) default 0 not null,
  "ProposalRate" decimal(6, 4) default 0 not null,
  "AdjustedRate" decimal(6, 4) default 0 not null,
  "ContrBaseRate" decimal(6, 4) default 0 not null,
  "ContrRateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "BaseRateCode" varchar2(2),
  "RateCode" varchar2(1),
  "CurrBaseRate" decimal(6, 4) default 0 not null,
  "TxEffectDate" decimal(8, 0) default 0 not null,
  "TxRateAdjFreq" decimal(2, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "OvduTerm" decimal(3, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxRateChange" add constraint "BatxRateChange_PK" primary key("AdjDate", "CustNo", "FacmNo", "BormNo");

comment on table "BatxRateChange" is '整批利率調整檔';
comment on column "BatxRateChange"."AdjDate" is '調整日期';
comment on column "BatxRateChange"."CustNo" is '戶號';
comment on column "BatxRateChange"."FacmNo" is '額度';
comment on column "BatxRateChange"."BormNo" is '撥款序號';
comment on column "BatxRateChange"."TxKind" is '作業項目';
comment on column "BatxRateChange"."DrawdownAmt" is '撥款金額';
comment on column "BatxRateChange"."CityCode" is '地區別';
comment on column "BatxRateChange"."AreaCode" is '鄉鎮區';
comment on column "BatxRateChange"."IncrFlag" is '加減碼是否依合約';
comment on column "BatxRateChange"."AdjCode" is '調整記號';
comment on column "BatxRateChange"."RateKeyInCode" is '是否輸入利率';
comment on column "BatxRateChange"."ConfirmFlag" is '確認記號';
comment on column "BatxRateChange"."TotBalance" is '全戶餘額';
comment on column "BatxRateChange"."LoanBalance" is '放款餘額';
comment on column "BatxRateChange"."PresEffDate" is '目前生效日';
comment on column "BatxRateChange"."CurtEffDate" is '本次生效日';
comment on column "BatxRateChange"."PreNextAdjDate" is '調整前下次利率調整日';
comment on column "BatxRateChange"."PreNextAdjFreq" is '調整前下次利率調整週期';
comment on column "BatxRateChange"."PrevIntDate" is '繳息迄日';
comment on column "BatxRateChange"."CustCode" is '戶別';
comment on column "BatxRateChange"."ProdNo" is '商品代碼';
comment on column "BatxRateChange"."RateIncr" is '利率加減碼';
comment on column "BatxRateChange"."ContractRate" is '合約利率';
comment on column "BatxRateChange"."PresentRate" is '目前利率';
comment on column "BatxRateChange"."ProposalRate" is '擬調利率';
comment on column "BatxRateChange"."AdjustedRate" is '調整後利率';
comment on column "BatxRateChange"."ContrBaseRate" is '合約指標利率';
comment on column "BatxRateChange"."ContrRateIncr" is '合約加減碼';
comment on column "BatxRateChange"."IndividualIncr" is '個別加減碼';
comment on column "BatxRateChange"."BaseRateCode" is '指標利率代碼';
comment on column "BatxRateChange"."RateCode" is '利率區分';
comment on column "BatxRateChange"."CurrBaseRate" is '本次指標利率';
comment on column "BatxRateChange"."TxEffectDate" is '調整時鍵入利率生效日';
comment on column "BatxRateChange"."TxRateAdjFreq" is '產檔時鍵入預調利率週期';
comment on column "BatxRateChange"."JsonFields" is 'jason格式紀錄欄';
comment on column "BatxRateChange"."OvduTerm" is '逾期期數';
comment on column "BatxRateChange"."TitaTlrNo" is '經辦';
comment on column "BatxRateChange"."TitaTxtNo" is '交易序號';
comment on column "BatxRateChange"."CreateDate" is '建檔日期時間';
comment on column "BatxRateChange"."CreateEmpNo" is '建檔人員';
comment on column "BatxRateChange"."LastUpdate" is '最後更新日期時間';
comment on column "BatxRateChange"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdAcBook" purge;

create table "CdAcBook" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "TargetAmt" decimal(16, 2) default 0 not null,
  "ActualAmt" decimal(16, 2) default 0 not null,
  "AssignSeq" decimal(2, 0) default 0 not null,
  "AcctSource" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAcBook" add constraint "CdAcBook_PK" primary key("AcBookCode", "AcSubBookCode");

comment on table "CdAcBook" is '帳冊別金額設定檔';
comment on column "CdAcBook"."AcBookCode" is '帳冊別';
comment on column "CdAcBook"."AcSubBookCode" is '區隔帳冊';
comment on column "CdAcBook"."CurrencyCode" is '幣別';
comment on column "CdAcBook"."TargetAmt" is '放款目標金額';
comment on column "CdAcBook"."ActualAmt" is '放款實際金額';
comment on column "CdAcBook"."AssignSeq" is '分配順序';
comment on column "CdAcBook"."AcctSource" is '資金來源';
comment on column "CdAcBook"."CreateDate" is '建檔日期時間';
comment on column "CdAcBook"."CreateEmpNo" is '建檔人員';
comment on column "CdAcBook"."LastUpdate" is '最後更新日期時間';
comment on column "CdAcBook"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdAcCode" purge;

create table "CdAcCode" (
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcNoItem" nvarchar2(40),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "ClassCode" decimal(1, 0) default 0 not null,
  "AcBookFlag" decimal(1, 0) default 0 not null,
  "DbCr" varchar2(1),
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "ClsChkFlag" decimal(1, 0) default 0 not null,
  "InuseFlag" decimal(1, 0) default 0 not null,
  "AcNoCodeOld" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAcCode" add constraint "CdAcCode_PK" primary key("AcNoCode", "AcSubCode", "AcDtlCode");

create index "CdAcCode_Index1" on "CdAcCode"("AcctCode" asc);

comment on table "CdAcCode" is '會計科子細目設定檔';
comment on column "CdAcCode"."AcNoCode" is '科目代號';
comment on column "CdAcCode"."AcSubCode" is '子目代號';
comment on column "CdAcCode"."AcDtlCode" is '細目代號';
comment on column "CdAcCode"."AcNoItem" is '科子細目名稱';
comment on column "CdAcCode"."AcctCode" is '業務科目代號';
comment on column "CdAcCode"."AcctItem" is '業務科目名稱';
comment on column "CdAcCode"."ClassCode" is '科子目級別';
comment on column "CdAcCode"."AcBookFlag" is '帳冊別記號';
comment on column "CdAcCode"."DbCr" is '借貸別';
comment on column "CdAcCode"."AcctFlag" is '業務科目記號';
comment on column "CdAcCode"."ReceivableFlag" is '銷帳科目記號';
comment on column "CdAcCode"."ClsChkFlag" is '日結餘額檢查記號';
comment on column "CdAcCode"."InuseFlag" is '放款部使用記號';
comment on column "CdAcCode"."AcNoCodeOld" is '舊科目代號';
comment on column "CdAcCode"."CreateDate" is '建檔日期時間';
comment on column "CdAcCode"."CreateEmpNo" is '建檔人員';
comment on column "CdAcCode"."LastUpdate" is '最後更新日期時間';
comment on column "CdAcCode"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdAoDept" purge;

create table "CdAoDept" (
  "EmployeeNo" varchar2(6),
  "DeptCode" varchar2(6),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAoDept" add constraint "CdAoDept_PK" primary key("EmployeeNo");

comment on table "CdAoDept" is '放款專員所屬業務部室對照檔';
comment on column "CdAoDept"."EmployeeNo" is '員工編號';
comment on column "CdAoDept"."DeptCode" is '部室代號';
comment on column "CdAoDept"."CreateDate" is '建檔日期時間';
comment on column "CdAoDept"."CreateEmpNo" is '建檔人員';
comment on column "CdAoDept"."LastUpdate" is '最後更新日期時間';
comment on column "CdAoDept"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdAppraisalCompany" purge;

create table "CdAppraisalCompany" (
  "AppraisalCompany" varchar2(30),
  "Company" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAppraisalCompany" add constraint "CdAppraisalCompany_PK" primary key("AppraisalCompany");

comment on table "CdAppraisalCompany" is '估價公司檔';
comment on column "CdAppraisalCompany"."AppraisalCompany" is '估價公司代號';
comment on column "CdAppraisalCompany"."Company" is '公司名稱';
comment on column "CdAppraisalCompany"."CreateDate" is '建檔日期時間';
comment on column "CdAppraisalCompany"."CreateEmpNo" is '建檔人員';
comment on column "CdAppraisalCompany"."LastUpdate" is '最後更新日期時間';
comment on column "CdAppraisalCompany"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdAppraiser" purge;

create table "CdAppraiser" (
  "AppraiserCode" varchar2(6),
  "AppraiserItem" nvarchar2(100),
  "Company" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdAppraiser" add constraint "CdAppraiser_PK" primary key("AppraiserCode");

comment on table "CdAppraiser" is '估價人員檔';
comment on column "CdAppraiser"."AppraiserCode" is '估價人員代號';
comment on column "CdAppraiser"."AppraiserItem" is '估價人員姓名';
comment on column "CdAppraiser"."Company" is '公司名稱';
comment on column "CdAppraiser"."CreateDate" is '建檔日期時間';
comment on column "CdAppraiser"."CreateEmpNo" is '建檔人員';
comment on column "CdAppraiser"."LastUpdate" is '最後更新日期時間';
comment on column "CdAppraiser"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdArea" purge;

create table "CdArea" (
  "CityCode" varchar2(2),
  "AreaCode" varchar2(2),
  "AreaItem" nvarchar2(12),
  "CityShort" nvarchar2(6),
  "AreaShort" nvarchar2(8),
  "JcicCityCode" varchar2(1),
  "JcicAreaCode" varchar2(2),
  "CityType" varchar2(2),
  "Zip3" varchar2(3),
  "DepartCode" varchar2(6),
  "CityGroup" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdArea" add constraint "CdArea_PK" primary key("CityCode", "AreaCode");

alter table "CdArea" add constraint "CdArea_CdCity_FK1" foreign key ("CityCode") references "CdCity" ("CityCode") on delete cascade;

create index "CdArea_Index1" on "CdArea"("Zip3" asc);

comment on table "CdArea" is '縣市與鄉鎮區對照檔';
comment on column "CdArea"."CityCode" is '縣市別代碼';
comment on column "CdArea"."AreaCode" is '鄉鎮區代碼';
comment on column "CdArea"."AreaItem" is '鄉鎮區名稱';
comment on column "CdArea"."CityShort" is '縣市簡稱';
comment on column "CdArea"."AreaShort" is '鄉鎮簡稱';
comment on column "CdArea"."JcicCityCode" is 'JCIC縣市碼';
comment on column "CdArea"."JcicAreaCode" is 'JCIC鄉鎮碼';
comment on column "CdArea"."CityType" is '地區類別';
comment on column "CdArea"."Zip3" is '郵遞區號';
comment on column "CdArea"."DepartCode" is '部室代號';
comment on column "CdArea"."CityGroup" is '組合地區別';
comment on column "CdArea"."CreateDate" is '建檔日期時間';
comment on column "CdArea"."CreateEmpNo" is '建檔人員';
comment on column "CdArea"."LastUpdate" is '最後更新日期時間';
comment on column "CdArea"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBank" purge;

create table "CdBank" (
  "BankCode" varchar2(3),
  "BranchCode" varchar2(4),
  "BankItem" nvarchar2(50),
  "BranchItem" nvarchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBank" add constraint "CdBank_PK" primary key("BankCode", "BranchCode");

comment on table "CdBank" is '行庫資料檔';
comment on column "CdBank"."BankCode" is '行庫代號';
comment on column "CdBank"."BranchCode" is '分行代號';
comment on column "CdBank"."BankItem" is '行庫名稱';
comment on column "CdBank"."BranchItem" is '分行名稱';
comment on column "CdBank"."CreateDate" is '建檔日期時間';
comment on column "CdBank"."CreateEmpNo" is '建檔人員';
comment on column "CdBank"."LastUpdate" is '最後更新日期時間';
comment on column "CdBank"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBaseRate" purge;

create table "CdBaseRate" (
  "CurrencyCode" varchar2(3),
  "BaseRateCode" varchar2(2),
  "EffectDate" decimal(8, 0) default 0 not null,
  "BaseRate" decimal(6, 4) default 0 not null,
  "Remark" nvarchar2(40),
  "EffectFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBaseRate" add constraint "CdBaseRate_PK" primary key("CurrencyCode", "BaseRateCode", "EffectDate");

comment on table "CdBaseRate" is '指標利率檔';
comment on column "CdBaseRate"."CurrencyCode" is '幣別';
comment on column "CdBaseRate"."BaseRateCode" is '利率代碼';
comment on column "CdBaseRate"."EffectDate" is '生效日期';
comment on column "CdBaseRate"."BaseRate" is '利率';
comment on column "CdBaseRate"."Remark" is '備註';
comment on column "CdBaseRate"."EffectFlag" is '生效記號';
comment on column "CdBaseRate"."CreateDate" is '建檔日期時間';
comment on column "CdBaseRate"."CreateEmpNo" is '建檔人員';
comment on column "CdBaseRate"."LastUpdate" is '最後更新日期時間';
comment on column "CdBaseRate"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBcm" purge;

create table "CdBcm" (
  "UnitCode" varchar2(6),
  "UnitItem" nvarchar2(20),
  "DeptCode" varchar2(6),
  "DeptItem" nvarchar2(20),
  "DistCode" varchar2(6),
  "DistItem" nvarchar2(20),
  "UnitManager" varchar2(6),
  "DeptManager" varchar2(6),
  "DistManager" varchar2(6),
  "ShortDeptItem" varchar2(6),
  "ShortDistItem" varchar2(6),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBcm" add constraint "CdBcm_PK" primary key("UnitCode");

create index "CdBcm_Index1" on "CdBcm"("DeptCode" asc);

create index "CdBcm_Index2" on "CdBcm"("DistCode" asc);

comment on table "CdBcm" is '分公司資料檔';
comment on column "CdBcm"."UnitCode" is '單位代號';
comment on column "CdBcm"."UnitItem" is '單位名稱';
comment on column "CdBcm"."DeptCode" is '部室代號';
comment on column "CdBcm"."DeptItem" is '部室名稱';
comment on column "CdBcm"."DistCode" is '區部代號';
comment on column "CdBcm"."DistItem" is '區部名稱';
comment on column "CdBcm"."UnitManager" is '單位經理代號';
comment on column "CdBcm"."DeptManager" is '部室經理代號';
comment on column "CdBcm"."DistManager" is '區部經理代號';
comment on column "CdBcm"."ShortDeptItem" is '部室名稱簡寫';
comment on column "CdBcm"."ShortDistItem" is '區部名稱簡寫';
comment on column "CdBcm"."Enable" is '啟用記號';
comment on column "CdBcm"."CreateDate" is '建檔日期時間';
comment on column "CdBcm"."CreateEmpNo" is '建檔人員';
comment on column "CdBcm"."LastUpdate" is '最後更新日期時間';
comment on column "CdBcm"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBonus" purge;

create table "CdBonus" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(1, 0) default 0 not null,
  "Condition" varchar2(5),
  "AmtStartRange" decimal(16, 2) default 0 not null,
  "AmtEndRange" decimal(16, 2) default 0 not null,
  "Bonus" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBonus" add constraint "CdBonus_PK" primary key("WorkMonth", "ConditionCode", "Condition");

create index "CdBonus_Index1" on "CdBonus"("WorkMonth" asc, "ConditionCode" asc);

comment on table "CdBonus" is '介紹人加碼獎勵津貼標準設定';
comment on column "CdBonus"."WorkMonth" is '工作年月';
comment on column "CdBonus"."ConditionCode" is '條件記號';
comment on column "CdBonus"."Condition" is '標準條件';
comment on column "CdBonus"."AmtStartRange" is '新貸案件撥貸金額級距-起';
comment on column "CdBonus"."AmtEndRange" is '新貸案件撥貸金額級距-止';
comment on column "CdBonus"."Bonus" is '獎勵津貼';
comment on column "CdBonus"."CreateDate" is '建檔日期時間';
comment on column "CdBonus"."CreateEmpNo" is '建檔人員';
comment on column "CdBonus"."LastUpdate" is '最後更新日期時間';
comment on column "CdBonus"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBonusCo" purge;

create table "CdBonusCo" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(1, 0) default 0 not null,
  "Condition" varchar2(5),
  "ConditionAmt" decimal(16, 2) default 0 not null,
  "Bonus" decimal(16, 2) default 0 not null,
  "ClassPassBonus" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBonusCo" add constraint "CdBonusCo_PK" primary key("WorkMonth", "ConditionCode", "Condition");

comment on table "CdBonusCo" is '協辦獎勵津貼標準設定';
comment on column "CdBonusCo"."WorkMonth" is '工作年月';
comment on column "CdBonusCo"."ConditionCode" is '條件記號';
comment on column "CdBonusCo"."Condition" is '標準條件';
comment on column "CdBonusCo"."ConditionAmt" is '標準金額';
comment on column "CdBonusCo"."Bonus" is '獎勵津貼';
comment on column "CdBonusCo"."ClassPassBonus" is '獎勵津貼-初階授信通過';
comment on column "CdBonusCo"."CreateDate" is '建檔日期時間';
comment on column "CdBonusCo"."CreateEmpNo" is '建檔人員';
comment on column "CdBonusCo"."LastUpdate" is '最後更新日期時間';
comment on column "CdBonusCo"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBranch" purge;

create table "CdBranch" (
  "BranchNo" varchar2(4),
  "AcBranchNo" varchar2(4),
  "CRH" varchar2(2),
  "BranchStatusCode" varchar2(1),
  "BranchShort" nvarchar2(14),
  "BranchItem" nvarchar2(40),
  "BranchAddress1" nvarchar2(30),
  "BranchAddress2" nvarchar2(30),
  "Zip3" varchar2(3),
  "Zip2" varchar2(2),
  "Owner" nvarchar2(14),
  "BusinessID" varchar2(10),
  "RSOCode" varchar2(3),
  "MediaUnitCode" varchar2(4),
  "CIFKey" varchar2(6),
  "LastestCustNo" varchar2(7),
  "Group1" nvarchar2(10),
  "Group2" nvarchar2(10),
  "Group3" nvarchar2(10),
  "Group4" nvarchar2(10),
  "Group5" nvarchar2(10),
  "Group6" nvarchar2(10),
  "Group7" nvarchar2(10),
  "Group8" nvarchar2(10),
  "Group9" nvarchar2(10),
  "Group10" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBranch" add constraint "CdBranch_PK" primary key("BranchNo");

comment on table "CdBranch" is '營業單位資料檔';
comment on column "CdBranch"."BranchNo" is '單位別';
comment on column "CdBranch"."AcBranchNo" is '核心會計單位別';
comment on column "CdBranch"."CRH" is '總分處';
comment on column "CdBranch"."BranchStatusCode" is '單位控制碼';
comment on column "CdBranch"."BranchShort" is '單位簡稱';
comment on column "CdBranch"."BranchItem" is '單位全名';
comment on column "CdBranch"."BranchAddress1" is '單位住址1';
comment on column "CdBranch"."BranchAddress2" is '單位住址2';
comment on column "CdBranch"."Zip3" is '郵遞區號前三碼';
comment on column "CdBranch"."Zip2" is '郵遞區號後兩碼';
comment on column "CdBranch"."Owner" is '負責人';
comment on column "CdBranch"."BusinessID" is '營利統一編號';
comment on column "CdBranch"."RSOCode" is '稽徵機關代號';
comment on column "CdBranch"."MediaUnitCode" is '媒體單位代號';
comment on column "CdBranch"."CIFKey" is 'CIF KEY';
comment on column "CdBranch"."LastestCustNo" is '最終戶號';
comment on column "CdBranch"."Group1" is '課組別1';
comment on column "CdBranch"."Group2" is '課組別2';
comment on column "CdBranch"."Group3" is '課組別3';
comment on column "CdBranch"."Group4" is '課組別4';
comment on column "CdBranch"."Group5" is '課組別5';
comment on column "CdBranch"."Group6" is '課組別6';
comment on column "CdBranch"."Group7" is '課組別7';
comment on column "CdBranch"."Group8" is '課組別8';
comment on column "CdBranch"."Group9" is '課組別9';
comment on column "CdBranch"."Group10" is '課組別10';
comment on column "CdBranch"."CreateDate" is '建檔日期時間';
comment on column "CdBranch"."CreateEmpNo" is '建檔人員';
comment on column "CdBranch"."LastUpdate" is '最後更新日期時間';
comment on column "CdBranch"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBranchGroup" purge;

create table "CdBranchGroup" (
  "BranchNo" varchar2(4),
  "GroupNo" varchar2(1),
  "GroupItem" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBranchGroup" add constraint "CdBranchGroup_PK" primary key("BranchNo", "GroupNo");

comment on table "CdBranchGroup" is '營業單位課組別檔';
comment on column "CdBranchGroup"."BranchNo" is '單位別';
comment on column "CdBranchGroup"."GroupNo" is '課組別代號';
comment on column "CdBranchGroup"."GroupItem" is '課組別說明';
comment on column "CdBranchGroup"."CreateDate" is '建檔日期時間';
comment on column "CdBranchGroup"."CreateEmpNo" is '建檔人員';
comment on column "CdBranchGroup"."LastUpdate" is '最後更新日期時間';
comment on column "CdBranchGroup"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBudget" purge;

create table "CdBudget" (
  "Year" decimal(4, 0) default 0 not null,
  "Month" decimal(2, 0) default 0 not null,
  "Budget" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBudget" add constraint "CdBudget_PK" primary key("Year", "Month");

comment on table "CdBudget" is '利息收入預算檔';
comment on column "CdBudget"."Year" is '預算年度';
comment on column "CdBudget"."Month" is '預算月份';
comment on column "CdBudget"."Budget" is '預算數';
comment on column "CdBudget"."CreateDate" is '建檔日期時間';
comment on column "CdBudget"."CreateEmpNo" is '建檔人員';
comment on column "CdBudget"."LastUpdate" is '最後更新日期時間';
comment on column "CdBudget"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdBuildingCost" purge;

create table "CdBuildingCost" (
  "CityCode" varchar2(2),
  "FloorLowerLimit" decimal(3, 0) default 0 not null,
  "Cost" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdBuildingCost" add constraint "CdBuildingCost_PK" primary key("CityCode", "FloorLowerLimit");

comment on table "CdBuildingCost" is '建築造價參考檔';
comment on column "CdBuildingCost"."CityCode" is '縣市代碼(地區別)';
comment on column "CdBuildingCost"."FloorLowerLimit" is '總樓層數(下限)';
comment on column "CdBuildingCost"."Cost" is '建築造價';
comment on column "CdBuildingCost"."CreateDate" is '建檔日期時間';
comment on column "CdBuildingCost"."CreateEmpNo" is '建檔人員';
comment on column "CdBuildingCost"."LastUpdate" is '最後更新日期時間';
comment on column "CdBuildingCost"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdCashFlow" purge;

create table "CdCashFlow" (
  "DataYearMonth" decimal(6, 0) default 0 not null,
  "InterestIncome" decimal(16, 2) default 0 not null,
  "PrincipalAmortizeAmt" decimal(16, 2) default 0 not null,
  "PrepaymentAmt" decimal(16, 2) default 0 not null,
  "DuePaymentAmt" decimal(16, 2) default 0 not null,
  "ExtendAmt" decimal(16, 2) default 0 not null,
  "LoanAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCashFlow" add constraint "CdCashFlow_PK" primary key("DataYearMonth");

comment on table "CdCashFlow" is '現金流量預估資料檔';
comment on column "CdCashFlow"."DataYearMonth" is '年月份';
comment on column "CdCashFlow"."InterestIncome" is '利息收入';
comment on column "CdCashFlow"."PrincipalAmortizeAmt" is '本金攤還金額';
comment on column "CdCashFlow"."PrepaymentAmt" is '提前還款金額';
comment on column "CdCashFlow"."DuePaymentAmt" is '到期清償金額';
comment on column "CdCashFlow"."ExtendAmt" is '展期金額';
comment on column "CdCashFlow"."LoanAmt" is '貸放金額';
comment on column "CdCashFlow"."CreateDate" is '建檔日期時間';
comment on column "CdCashFlow"."CreateEmpNo" is '建檔人員';
comment on column "CdCashFlow"."LastUpdate" is '最後更新日期時間';
comment on column "CdCashFlow"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdCity" purge;

create table "CdCity" (
  "CityCode" varchar2(2),
  "CityItem" nvarchar2(10),
  "UnitCode" varchar2(6),
  "AccCollPsn" varchar2(6),
  "AccTelArea" varchar2(5),
  "AccTelNo" varchar2(10),
  "AccTelExt" varchar2(5),
  "LegalPsn" varchar2(6),
  "LegalArea" varchar2(5),
  "LegalNo" varchar2(10),
  "LegalExt" varchar2(5),
  "IntRateIncr" decimal(6, 4) default 0 not null,
  "IntRateCeiling" decimal(6, 4) default 0 not null,
  "IntRateFloor" decimal(6, 4) default 0 not null,
  "JcicCityCode" varchar2(0),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCity" add constraint "CdCity_PK" primary key("CityCode");

create index "CdCity_Index1" on "CdCity"("UnitCode" asc);

create index "CdCity_Index2" on "CdCity"("CityItem" asc);

comment on table "CdCity" is '地區別代碼檔';
comment on column "CdCity"."CityCode" is '縣市代碼(地區別)';
comment on column "CdCity"."CityItem" is '縣市名稱(地區別)';
comment on column "CdCity"."UnitCode" is '單位代號';
comment on column "CdCity"."AccCollPsn" is '催收人員';
comment on column "CdCity"."AccTelArea" is '催收人員電話-區碼';
comment on column "CdCity"."AccTelNo" is '催收人員電話';
comment on column "CdCity"."AccTelExt" is '催收人員電話-分機';
comment on column "CdCity"."LegalPsn" is '法務人員';
comment on column "CdCity"."LegalArea" is '法務人員電話-區碼';
comment on column "CdCity"."LegalNo" is '法務人員電話';
comment on column "CdCity"."LegalExt" is '法務人員電話-分機';
comment on column "CdCity"."IntRateIncr" is '利率加減碼';
comment on column "CdCity"."IntRateCeiling" is '利率上限';
comment on column "CdCity"."IntRateFloor" is '利率下限';
comment on column "CdCity"."JcicCityCode" is '聯徵用縣市代碼';
comment on column "CdCity"."CreateDate" is '建檔日期時間';
comment on column "CdCity"."CreateEmpNo" is '建檔人員';
comment on column "CdCity"."LastUpdate" is '最後更新日期時間';
comment on column "CdCity"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdCl" purge;

create table "CdCl" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClItem" nvarchar2(20),
  "ClTypeJCIC" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCl" add constraint "CdCl_PK" primary key("ClCode1", "ClCode2");

create index "CdCl_Index1" on "CdCl"("ClCode1" asc);

create index "CdCl_Index2" on "CdCl"("ClTypeJCIC" asc);

comment on table "CdCl" is '擔保品代號檔';
comment on column "CdCl"."ClCode1" is '擔保品代號1';
comment on column "CdCl"."ClCode2" is '擔保品代號2';
comment on column "CdCl"."ClItem" is '擔保品名稱';
comment on column "CdCl"."ClTypeJCIC" is 'JCIC類別';
comment on column "CdCl"."CreateDate" is '建檔日期時間';
comment on column "CdCl"."CreateEmpNo" is '建檔人員';
comment on column "CdCl"."LastUpdate" is '最後更新日期時間';
comment on column "CdCl"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdCode" purge;

create table "CdCode" (
  "DefCode" varchar2(20),
  "DefType" decimal(2, 0) default 0 not null,
  "Code" varchar2(20),
  "Item" nvarchar2(50),
  "Enable" varchar2(1),
  "EffectFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCode" add constraint "CdCode_PK" primary key("DefCode", "Code");

comment on table "CdCode" is '共用代碼檔';
comment on column "CdCode"."DefCode" is '代碼檔代號';
comment on column "CdCode"."DefType" is '代碼檔業務類別';
comment on column "CdCode"."Code" is '代碼';
comment on column "CdCode"."Item" is '代碼說明';
comment on column "CdCode"."Enable" is '啟用記號';
comment on column "CdCode"."EffectFlag" is '狀態';
comment on column "CdCode"."CreateDate" is '建檔日期時間';
comment on column "CdCode"."CreateEmpNo" is '建檔人員';
comment on column "CdCode"."LastUpdate" is '最後更新日期時間';
comment on column "CdCode"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdEmp" purge;

create table "CdEmp" (
  "AgentCode" varchar2(12),
  "EmployeeNo" varchar2(10),
  "Fullname" nvarchar2(40),
  "CenterShortName" nvarchar2(10),
  "CenterCodeName" nvarchar2(20),
  "CenterCode1" varchar2(6),
  "CenterCode1Short" nvarchar2(10),
  "CenterCode1Name" nvarchar2(20),
  "CenterCode2" varchar2(6),
  "CenterCode2Short" nvarchar2(10),
  "CenterCode2Name" nvarchar2(20),
  "CenterCodeAcc1" varchar2(6),
  "CenterCodeAcc1Name" nvarchar2(20),
  "CenterCodeAcc2" varchar2(6),
  "CenterCodeAcc2Name" nvarchar2(20),
  "CommLineCode" varchar2(2),
  "CommLineType" varchar2(1),
  "OrigIntroducerId" varchar2(12),
  "IntroducerInd" varchar2(1),
  "RegisterLevel" varchar2(2),
  "RegisterDate" decimal(8, 0) default 0 not null,
  "CenterCode" varchar2(6),
  "AdministratId" varchar2(12),
  "InputDate" decimal(8, 0) default 0 not null,
  "InputUser" varchar2(8),
  "AgStatusCode" varchar2(1),
  "AgStatusDate" decimal(8, 0) default 0 not null,
  "TranDate" decimal(8, 0) default 0 not null,
  "TranUser" varchar2(8),
  "ReRegisterDate" decimal(8, 0) default 0 not null,
  "DirectorId" varchar2(12),
  "DirectorIdF" varchar2(12),
  "IntroducerId" varchar2(12),
  "IntroducerIdF" varchar2(12),
  "AgLevel" varchar2(2),
  "LastLevel" varchar2(2),
  "LevelDate" decimal(8, 0) default 0 not null,
  "TopLevel" varchar2(2),
  "OccpInd" varchar2(1),
  "QuotaAmt" decimal(10, 0) default 0 not null,
  "ApplType" varchar2(1),
  "TaxRate" decimal(5, 3) default 0 not null,
  "SocialInsuClass" decimal(5, 0) default 0 not null,
  "PromotLevelYM" varchar2(7),
  "DirectorYM" varchar2(7),
  "RecordDate" decimal(8, 0) default 0 not null,
  "ExRecordDate" decimal(8, 0) default 0 not null,
  "RxTrDate" decimal(8, 0) default 0 not null,
  "ExTrIdent" varchar2(16),
  "ExTrIdent2" varchar2(9),
  "ExTrIdent3" varchar2(12),
  "ExTrDate" decimal(8, 0) default 0 not null,
  "RegisterBefore" decimal(5, 0) default 0 not null,
  "DirectorAfter" decimal(5, 0) default 0 not null,
  "MedicalCode" varchar2(2),
  "ExChgDate" decimal(8, 0) default 0 not null,
  "ExDelDate" decimal(8, 0) default 0 not null,
  "ApplCode" varchar2(10),
  "FirstRegDate" decimal(8, 0) default 0 not null,
  "AginSource" varchar2(3),
  "AguiCenter" varchar2(9),
  "AgentId" varchar2(10),
  "TopId" varchar2(12),
  "AgDegree" varchar2(2),
  "CollectInd" varchar2(1),
  "AgType1" varchar2(1),
  "ContractInd" varchar2(1),
  "ContractIndYM" varchar2(7),
  "AgType2" varchar2(1),
  "AgType3" varchar2(1),
  "AgType4" varchar2(1),
  "AginInd1" varchar2(1),
  "AgPoInd" varchar2(1),
  "AgDocInd" varchar2(1),
  "NewHireType" varchar2(1),
  "AgCurInd" varchar2(1),
  "AgSendType" varchar2(3),
  "AgSendNo" nvarchar2(100),
  "RegisterDate2" decimal(8, 0) default 0 not null,
  "AgReturnDate" decimal(8, 0) default 0 not null,
  "AgTransferDateF" decimal(8, 0) default 0 not null,
  "AgTransferDate" decimal(8, 0) default 0 not null,
  "PromotYM" varchar2(7),
  "PromotYMF" varchar2(7),
  "AgPostChgDate" decimal(8, 0) default 0 not null,
  "FamiliesTax" decimal(5, 0) default 0 not null,
  "AgentCodeI" varchar2(12),
  "AgLevelSys" varchar2(2),
  "AgPostIn" varchar2(6),
  "CenterCodeAcc" varchar2(6),
  "EvalueInd" varchar2(1),
  "EvalueInd1" varchar2(1),
  "BatchNo" decimal(10, 0) default 0 not null,
  "EvalueYM" varchar2(7),
  "AgTransferCode" varchar2(2),
  "Birth" decimal(8, 0) default 0 not null,
  "Education" varchar2(1),
  "LrInd" varchar2(1),
  "ProceccDate" decimal(8, 0) default 0 not null,
  "QuitDate" decimal(8, 0) default 0 not null,
  "AgPost" varchar2(2),
  "LevelNameChs" nvarchar2(10),
  "LrSystemType" varchar2(1),
  "SeniorityYY" decimal(5, 0) default 0 not null,
  "SeniorityMM" decimal(5, 0) default 0 not null,
  "SeniorityDD" decimal(5, 0) default 0 not null,
  "AglaProcessInd" varchar2(2),
  "StatusCode" varchar2(1),
  "AglaCancelReason" varchar2(1),
  "ISAnnApplDate" decimal(8, 0) default 0 not null,
  "RecordDateC" decimal(8, 0) default 0 not null,
  "StopReason" nvarchar2(20),
  "StopStrDate" decimal(8, 0) default 0 not null,
  "StopEndDate" decimal(8, 0) default 0 not null,
  "IFPDate" decimal(8, 0) default 0 not null,
  "EffectStrDate" decimal(8, 0) default 0 not null,
  "EffectEndDate" decimal(8, 0) default 0 not null,
  "AnnApplDate" decimal(8, 0) default 0 not null,
  "CenterCodeAccName" nvarchar2(20),
  "ReHireCode" varchar2(1),
  "RSVDAdminCode" varchar2(1),
  "Account" varchar2(16),
  "PRPDate" varchar2(15),
  "Zip" varchar2(5),
  "Address" nvarchar2(80),
  "PhoneH" varchar2(30),
  "PhoneC" varchar2(30),
  "SalesQualInd" varchar2(1),
  "AgsqStartDate" decimal(8, 0) default 0 not null,
  "PinYinNameIndi" nvarchar2(50),
  "Email" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdEmp" add constraint "CdEmp_PK" primary key("EmployeeNo");

create index "CdEmp_Index1" on "CdEmp"("EmployeeNo" asc);

comment on table "CdEmp" is '員工資料檔';
comment on column "CdEmp"."AgentCode" is '業務員代號';
comment on column "CdEmp"."EmployeeNo" is '電腦編號';
comment on column "CdEmp"."Fullname" is '姓名';
comment on column "CdEmp"."CenterShortName" is '單位簡稱';
comment on column "CdEmp"."CenterCodeName" is '單位名稱';
comment on column "CdEmp"."CenterCode1" is '區部代號';
comment on column "CdEmp"."CenterCode1Short" is '區部簡稱';
comment on column "CdEmp"."CenterCode1Name" is '區部名稱';
comment on column "CdEmp"."CenterCode2" is '部室代號';
comment on column "CdEmp"."CenterCode2Short" is '部室簡稱';
comment on column "CdEmp"."CenterCode2Name" is '部室名稱';
comment on column "CdEmp"."CenterCodeAcc1" is '區部代號(駐在單位)';
comment on column "CdEmp"."CenterCodeAcc1Name" is '區部名稱(駐在單位)';
comment on column "CdEmp"."CenterCodeAcc2" is '部室代號(駐在單位)';
comment on column "CdEmp"."CenterCodeAcc2Name" is '部室名稱(駐在單位)';
comment on column "CdEmp"."CommLineCode" is '業務線代號';
comment on column "CdEmp"."CommLineType" is '業務線別';
comment on column "CdEmp"."OrigIntroducerId" is '介紹人';
comment on column "CdEmp"."IntroducerInd" is '介紹關係碼';
comment on column "CdEmp"."RegisterLevel" is '報聘職等';
comment on column "CdEmp"."RegisterDate" is '在職/締約日期';
comment on column "CdEmp"."CenterCode" is '單位代號';
comment on column "CdEmp"."AdministratId" is '單位主管';
comment on column "CdEmp"."InputDate" is '建檔日期';
comment on column "CdEmp"."InputUser" is '建檔人';
comment on column "CdEmp"."AgStatusCode" is '業務人員任用狀況碼';
comment on column "CdEmp"."AgStatusDate" is '業務人員任用狀況異動日';
comment on column "CdEmp"."TranDate" is '作業日期(交易日期)';
comment on column "CdEmp"."TranUser" is '作業者';
comment on column "CdEmp"."ReRegisterDate" is '再聘日';
comment on column "CdEmp"."DirectorId" is '上層主管';
comment on column "CdEmp"."DirectorIdF" is '主管_財務';
comment on column "CdEmp"."IntroducerId" is '區主任/上一代主管';
comment on column "CdEmp"."IntroducerIdF" is '推介人_財務';
comment on column "CdEmp"."AgLevel" is '業務人員職等';
comment on column "CdEmp"."LastLevel" is '前次業務人員職等';
comment on column "CdEmp"."LevelDate" is '職等異動日';
comment on column "CdEmp"."TopLevel" is '最高職等';
comment on column "CdEmp"."OccpInd" is '任職型態';
comment on column "CdEmp"."QuotaAmt" is '責任額';
comment on column "CdEmp"."ApplType" is '申請登錄類別';
comment on column "CdEmp"."TaxRate" is '所得稅率';
comment on column "CdEmp"."SocialInsuClass" is '勞保等級';
comment on column "CdEmp"."PromotLevelYM" is '職等平階起始年月';
comment on column "CdEmp"."DirectorYM" is '晉陞主管年月';
comment on column "CdEmp"."RecordDate" is '登錄日期';
comment on column "CdEmp"."ExRecordDate" is '發證日期';
comment on column "CdEmp"."RxTrDate" is '證書日期/測驗日期';
comment on column "CdEmp"."ExTrIdent" is '證書字號';
comment on column "CdEmp"."ExTrIdent2" is '中專證號';
comment on column "CdEmp"."ExTrIdent3" is '投資型證號';
comment on column "CdEmp"."ExTrDate" is '投資登錄日期';
comment on column "CdEmp"."RegisterBefore" is '報聘前年資(月表示)';
comment on column "CdEmp"."DirectorAfter" is '主管年資';
comment on column "CdEmp"."MedicalCode" is '免體檢授權碼';
comment on column "CdEmp"."ExChgDate" is '換證日期';
comment on column "CdEmp"."ExDelDate" is '註銷日期';
comment on column "CdEmp"."ApplCode" is '申請業務類別';
comment on column "CdEmp"."FirstRegDate" is '初次登錄日';
comment on column "CdEmp"."AginSource" is '業務來源之專案';
comment on column "CdEmp"."AguiCenter" is '單位代號';
comment on column "CdEmp"."AgentId" is '業務人員身份證字號';
comment on column "CdEmp"."TopId" is '業務人員主管';
comment on column "CdEmp"."AgDegree" is '業務人員職級';
comment on column "CdEmp"."CollectInd" is '收費員指示碼';
comment on column "CdEmp"."AgType1" is '制度別';
comment on column "CdEmp"."ContractInd" is '單雙合約碼';
comment on column "CdEmp"."ContractIndYM" is '單雙合約異動工作月';
comment on column "CdEmp"."AgType2" is '身份別';
comment on column "CdEmp"."AgType3" is '特殊人員碼';
comment on column "CdEmp"."AgType4" is '新舊制別';
comment on column "CdEmp"."AginInd1" is '辦事員碼';
comment on column "CdEmp"."AgPoInd" is '可招攬指示碼';
comment on column "CdEmp"."AgDocInd" is '齊件否';
comment on column "CdEmp"."NewHireType" is '新舊人指示碼';
comment on column "CdEmp"."AgCurInd" is '現職指示碼';
comment on column "CdEmp"."AgSendType" is '發文類別';
comment on column "CdEmp"."AgSendNo" is '發文文號';
comment on column "CdEmp"."RegisterDate2" is '任職日期';
comment on column "CdEmp"."AgReturnDate" is '回任日期';
comment on column "CdEmp"."AgTransferDateF" is '初次轉制日期';
comment on column "CdEmp"."AgTransferDate" is '轉制日期';
comment on column "CdEmp"."PromotYM" is '初次晉升年月';
comment on column "CdEmp"."PromotYMF" is '生效業績年月';
comment on column "CdEmp"."AgPostChgDate" is '職務異動日';
comment on column "CdEmp"."FamiliesTax" is '扶養人數';
comment on column "CdEmp"."AgentCodeI" is '原區主任代號';
comment on column "CdEmp"."AgLevelSys" is '職等_系統';
comment on column "CdEmp"."AgPostIn" is '內階職務';
comment on column "CdEmp"."CenterCodeAcc" is '駐在單位';
comment on column "CdEmp"."EvalueInd" is '考核特殊碼';
comment on column "CdEmp"."EvalueInd1" is '辦法優待碼';
comment on column "CdEmp"."BatchNo" is '批次號碼';
comment on column "CdEmp"."EvalueYM" is '考核年月';
comment on column "CdEmp"."AgTransferCode" is '轉檔碼';
comment on column "CdEmp"."Birth" is '出生年月日';
comment on column "CdEmp"."Education" is '學歷';
comment on column "CdEmp"."LrInd" is '勞退狀況';
comment on column "CdEmp"."ProceccDate" is '資料處理時間';
comment on column "CdEmp"."QuitDate" is '離職/停約日';
comment on column "CdEmp"."AgPost" is '職務';
comment on column "CdEmp"."LevelNameChs" is '職等中文';
comment on column "CdEmp"."LrSystemType" is '勞退碼';
comment on column "CdEmp"."SeniorityYY" is '年資_年';
comment on column "CdEmp"."SeniorityMM" is '年資_月';
comment on column "CdEmp"."SeniorityDD" is '年資_日';
comment on column "CdEmp"."AglaProcessInd" is '登錄處理事項';
comment on column "CdEmp"."StatusCode" is '登錄狀態';
comment on column "CdEmp"."AglaCancelReason" is '註銷原因';
comment on column "CdEmp"."ISAnnApplDate" is '利變年金通報日';
comment on column "CdEmp"."RecordDateC" is '外幣保單登入日';
comment on column "CdEmp"."StopReason" is '停招/撤銷原因';
comment on column "CdEmp"."StopStrDate" is '停止招攬起日';
comment on column "CdEmp"."StopEndDate" is '停止招攬迄日';
comment on column "CdEmp"."IFPDate" is 'IFP登錄日';
comment on column "CdEmp"."EffectStrDate" is '撤銷起日';
comment on column "CdEmp"."EffectEndDate" is '撤銷迄日';
comment on column "CdEmp"."AnnApplDate" is '一般年金通報日';
comment on column "CdEmp"."CenterCodeAccName" is '單位名稱(駐在單位)';
comment on column "CdEmp"."ReHireCode" is '重僱碼';
comment on column "CdEmp"."RSVDAdminCode" is '特別碼';
comment on column "CdEmp"."Account" is '帳號';
comment on column "CdEmp"."PRPDate" is '優體測驗通過日';
comment on column "CdEmp"."Zip" is '戶籍地址郵遞區號';
comment on column "CdEmp"."Address" is '戶籍地址';
comment on column "CdEmp"."PhoneH" is '住家電話';
comment on column "CdEmp"."PhoneC" is '手機電話';
comment on column "CdEmp"."SalesQualInd" is '基金銷售資格碼';
comment on column "CdEmp"."AgsqStartDate" is '基金銷售資格日';
comment on column "CdEmp"."PinYinNameIndi" is '原住民羅馬拼音姓名';
comment on column "CdEmp"."Email" is '電子郵件';
comment on column "CdEmp"."CreateDate" is '建檔日期時間';
comment on column "CdEmp"."CreateEmpNo" is '建檔人員';
comment on column "CdEmp"."LastUpdate" is '最後更新日期時間';
comment on column "CdEmp"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdGseq" purge;

create table "CdGseq" (
  "GseqDate" decimal(8, 0) default 0 not null,
  "GseqCode" decimal(1, 0) default 0 not null,
  "GseqType" varchar2(2),
  "GseqKind" varchar2(4),
  "Offset" decimal(8, 0) default 0 not null,
  "SeqNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdGseq" add constraint "CdGseq_PK" primary key("GseqDate", "GseqCode", "GseqType", "GseqKind");

comment on table "CdGseq" is '編號編碼檔';
comment on column "CdGseq"."GseqDate" is '編號日期';
comment on column "CdGseq"."GseqCode" is '編號方式';
comment on column "CdGseq"."GseqType" is '業務類別';
comment on column "CdGseq"."GseqKind" is '交易種類';
comment on column "CdGseq"."Offset" is '有效值';
comment on column "CdGseq"."SeqNo" is '流水號';
comment on column "CdGseq"."CreateDate" is '建檔日期時間';
comment on column "CdGseq"."CreateEmpNo" is '建檔人員';
comment on column "CdGseq"."LastUpdate" is '最後更新日期時間';
comment on column "CdGseq"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdGuarantor" purge;

create table "CdGuarantor" (
  "GuaRelCode" varchar2(2),
  "GuaRelItem" nvarchar2(30),
  "GuaRelJcic" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdGuarantor" add constraint "CdGuarantor_PK" primary key("GuaRelCode");

create index "CdGuarantor_Index1" on "CdGuarantor"("GuaRelJcic" asc);

comment on table "CdGuarantor" is '保證人關係代碼檔';
comment on column "CdGuarantor"."GuaRelCode" is '保證人關係代碼';
comment on column "CdGuarantor"."GuaRelItem" is '保證人關係說明';
comment on column "CdGuarantor"."GuaRelJcic" is '保證人關係ＪＣＩＣ代碼';
comment on column "CdGuarantor"."CreateDate" is '建檔日期時間';
comment on column "CdGuarantor"."CreateEmpNo" is '建檔人員';
comment on column "CdGuarantor"."LastUpdate" is '最後更新日期時間';
comment on column "CdGuarantor"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdIndustry" purge;

create table "CdIndustry" (
  "IndustryCode" varchar2(6),
  "IndustryItem" nvarchar2(50),
  "MainType" varchar2(1),
  "IndustryRating" varchar2(1),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdIndustry" add constraint "CdIndustry_PK" primary key("IndustryCode");

create index "CdIndustry_Index1" on "CdIndustry"("MainType" asc);

comment on table "CdIndustry" is '行業別代號檔';
comment on column "CdIndustry"."IndustryCode" is '行業代號';
comment on column "CdIndustry"."IndustryItem" is '行業說明';
comment on column "CdIndustry"."MainType" is '主計處大類';
comment on column "CdIndustry"."IndustryRating" is '企金放款產業評等';
comment on column "CdIndustry"."Enable" is '啟用記號';
comment on column "CdIndustry"."CreateDate" is '建檔日期時間';
comment on column "CdIndustry"."CreateEmpNo" is '建檔人員';
comment on column "CdIndustry"."LastUpdate" is '最後更新日期時間';
comment on column "CdIndustry"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdInsurer" purge;

create table "CdInsurer" (
  "InsurerType" varchar2(1),
  "InsurerCode" varchar2(2),
  "InsurerId" varchar2(8),
  "InsurerItem" nvarchar2(40),
  "InsurerShort" nvarchar2(20),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdInsurer" add constraint "CdInsurer_PK" primary key("InsurerType", "InsurerCode");

comment on table "CdInsurer" is '保險公司資料檔';
comment on column "CdInsurer"."InsurerType" is '公司種類';
comment on column "CdInsurer"."InsurerCode" is '公司代號';
comment on column "CdInsurer"."InsurerId" is '公司統編';
comment on column "CdInsurer"."InsurerItem" is '公司名稱';
comment on column "CdInsurer"."InsurerShort" is '公司簡稱';
comment on column "CdInsurer"."TelArea" is '連絡電話區碼';
comment on column "CdInsurer"."TelNo" is '連絡電話號碼';
comment on column "CdInsurer"."TelExt" is '連絡電話分機號碼';
comment on column "CdInsurer"."Enable" is '啟用記號';
comment on column "CdInsurer"."CreateDate" is '建檔日期時間';
comment on column "CdInsurer"."CreateEmpNo" is '建檔人員';
comment on column "CdInsurer"."LastUpdate" is '最後更新日期時間';
comment on column "CdInsurer"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdLandSection" purge;

create table "CdLandSection" (
  "CityCode" varchar2(2),
  "AreaCode" varchar2(2),
  "IrCode" varchar2(5),
  "IrItem" nvarchar2(30),
  "LandOfficeCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdLandSection" add constraint "CdLandSection_PK" primary key("CityCode", "AreaCode", "IrCode");

alter table "CdLandSection" add constraint "CdLandSection_CdArea_FK1" foreign key ("CityCode", "AreaCode") references "CdArea" ("CityCode", "AreaCode") on delete cascade;

create index "CdLandSection_Index1" on "CdLandSection"("CityCode" asc);

create index "CdLandSection_Index2" on "CdLandSection"("CityCode" asc, "AreaCode" asc);

comment on table "CdLandSection" is '地段代碼檔';
comment on column "CdLandSection"."CityCode" is '地區別';
comment on column "CdLandSection"."AreaCode" is '鄉鎮區';
comment on column "CdLandSection"."IrCode" is '段小段代碼';
comment on column "CdLandSection"."IrItem" is '段小段名稱';
comment on column "CdLandSection"."LandOfficeCode" is '地所代碼';
comment on column "CdLandSection"."CreateDate" is '建檔日期時間';
comment on column "CdLandSection"."CreateEmpNo" is '建檔人員';
comment on column "CdLandSection"."LastUpdate" is '最後更新日期時間';
comment on column "CdLandSection"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdLoanNotYet" purge;

create table "CdLoanNotYet" (
  "NotYetCode" varchar2(2),
  "NotYetItem" nvarchar2(40),
  "YetDays" decimal(3, 0) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdLoanNotYet" add constraint "CdLoanNotYet_PK" primary key("NotYetCode");

comment on table "CdLoanNotYet" is '未齊件代碼檔';
comment on column "CdLoanNotYet"."NotYetCode" is '未齊件代碼';
comment on column "CdLoanNotYet"."NotYetItem" is '未齊件說明';
comment on column "CdLoanNotYet"."YetDays" is '齊件日期計算日';
comment on column "CdLoanNotYet"."Enable" is '啟用記號';
comment on column "CdLoanNotYet"."CreateDate" is '建檔日期時間';
comment on column "CdLoanNotYet"."CreateEmpNo" is '建檔人員';
comment on column "CdLoanNotYet"."LastUpdate" is '最後更新日期時間';
comment on column "CdLoanNotYet"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdOverdue" purge;

create table "CdOverdue" (
  "OverdueSign" varchar2(1),
  "OverdueCode" varchar2(4),
  "OverdueItem" nvarchar2(50),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdOverdue" add constraint "CdOverdue_PK" primary key("OverdueSign", "OverdueCode");

create index "CdOverdue_Index1" on "CdOverdue"("OverdueSign" asc);

create index "CdOverdue_Index2" on "CdOverdue"("OverdueCode" asc);

create index "CdOverdue_Index3" on "CdOverdue"("Enable" asc);

comment on table "CdOverdue" is '逾期新增減少原因檔';
comment on column "CdOverdue"."OverdueSign" is '逾期增減碼';
comment on column "CdOverdue"."OverdueCode" is '增減原因代號';
comment on column "CdOverdue"."OverdueItem" is '增減原因說明';
comment on column "CdOverdue"."Enable" is '啟用記號';
comment on column "CdOverdue"."CreateDate" is '建檔日期時間';
comment on column "CdOverdue"."CreateEmpNo" is '建檔人員';
comment on column "CdOverdue"."LastUpdate" is '最後更新日期時間';
comment on column "CdOverdue"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdPerformance" purge;

create table "CdPerformance" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "PieceCode" varchar2(1),
  "UnitCnt" decimal(4, 2) default 0 not null,
  "UnitAmtCond" decimal(16, 2) default 0 not null,
  "UnitPercent" decimal(9, 6) default 0 not null,
  "IntrodPerccent" decimal(9, 6) default 0 not null,
  "IntrodAmtCond" decimal(16, 2) default 0 not null,
  "IntrodPfEqBase" decimal(16, 2) default 0 not null,
  "IntrodPfEqAmt" decimal(16, 2) default 0 not null,
  "IntrodRewardBase" decimal(16, 2) default 0 not null,
  "IntrodReward" decimal(16, 2) default 0 not null,
  "BsOffrCnt" decimal(4, 2) default 0 not null,
  "BsOffrCntLimit" decimal(4, 2) default 0 not null,
  "BsOffrAmtCond" decimal(16, 2) default 0 not null,
  "BsOffrPerccent" decimal(9, 6) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdPerformance" add constraint "CdPerformance_PK" primary key("WorkMonth", "PieceCode");

comment on table "CdPerformance" is '業績件數及金額核算標準設定檔';
comment on column "CdPerformance"."WorkMonth" is '工作年月';
comment on column "CdPerformance"."PieceCode" is '計件代碼';
comment on column "CdPerformance"."UnitCnt" is '介紹單位_件數';
comment on column "CdPerformance"."UnitAmtCond" is '介紹單位_計件金額門檻';
comment on column "CdPerformance"."UnitPercent" is '介紹單位_撥款業績_比例';
comment on column "CdPerformance"."IntrodPerccent" is '介紹人_介紹獎金_比例';
comment on column "CdPerformance"."IntrodAmtCond" is '介紹人_介紹獎金_門檻(新增額度)';
comment on column "CdPerformance"."IntrodPfEqBase" is '介紹人_換算業績率(分母)';
comment on column "CdPerformance"."IntrodPfEqAmt" is '介紹人_換算業績率(分子)';
comment on column "CdPerformance"."IntrodRewardBase" is '介紹人_業務報酬率(分母)';
comment on column "CdPerformance"."IntrodReward" is '介紹人_業務報酬率(分子)';
comment on column "CdPerformance"."BsOffrCnt" is '房貸專員_件數';
comment on column "CdPerformance"."BsOffrCntLimit" is '房貸專員_件數上限';
comment on column "CdPerformance"."BsOffrAmtCond" is '房貸專員_計件金額門檻';
comment on column "CdPerformance"."BsOffrPerccent" is '房貸專員_撥款業績_比例';
comment on column "CdPerformance"."CreateDate" is '建檔日期時間';
comment on column "CdPerformance"."CreateEmpNo" is '建檔人員';
comment on column "CdPerformance"."LastUpdate" is '最後更新日期時間';
comment on column "CdPerformance"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdPfParms" purge;

create table "CdPfParms" (
  "ConditionCode1" varchar2(1),
  "ConditionCode2" varchar2(1),
  "Condition" varchar2(6),
  "WorkMonthStart" decimal(6, 0) default 0 not null,
  "WorkMonthEnd" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdPfParms" add constraint "CdPfParms_PK" primary key("ConditionCode1", "ConditionCode2", "Condition");

comment on table "CdPfParms" is '業績特殊參數設定檔';
comment on column "CdPfParms"."ConditionCode1" is '條件記號1';
comment on column "CdPfParms"."ConditionCode2" is '條件記號2';
comment on column "CdPfParms"."Condition" is '標準條件';
comment on column "CdPfParms"."WorkMonthStart" is '有效工作月(起)';
comment on column "CdPfParms"."WorkMonthEnd" is '有效工作月(止)';
comment on column "CdPfParms"."CreateDate" is '建檔日期時間';
comment on column "CdPfParms"."CreateEmpNo" is '建檔人員';
comment on column "CdPfParms"."LastUpdate" is '最後更新日期時間';
comment on column "CdPfParms"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdReport" purge;

create table "CdReport" (
  "FormNo" varchar2(10),
  "FormName" nvarchar2(40),
  "Cycle" decimal(2, 0) default 0 not null,
  "SendCode" decimal(1, 0) default 0 not null,
  "Letter" decimal(1, 0) default 0 not null,
  "Message" decimal(1, 0) default 0 not null,
  "Email" decimal(1, 0) default 0 not null,
  "UsageDesc" nvarchar2(40),
  "SignCode" decimal(1, 0) default 0 not null,
  "WatermarkFlag" decimal(1, 0) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdReport" add constraint "CdReport_PK" primary key("FormNo");

create index "CdReport_Index1" on "CdReport"("Cycle" asc);

create index "CdReport_Index2" on "CdReport"("Enable" asc);

comment on table "CdReport" is '報表代號對照檔';
comment on column "CdReport"."FormNo" is '報表代號';
comment on column "CdReport"."FormName" is '報表名稱';
comment on column "CdReport"."Cycle" is '報表週期';
comment on column "CdReport"."SendCode" is '寄送記號';
comment on column "CdReport"."Letter" is '書面寄送';
comment on column "CdReport"."Message" is '簡訊寄送';
comment on column "CdReport"."Email" is '電子郵件寄送';
comment on column "CdReport"."UsageDesc" is '用途說明';
comment on column "CdReport"."SignCode" is '簽核記號';
comment on column "CdReport"."WatermarkFlag" is '浮水印記號';
comment on column "CdReport"."Enable" is '啟用記號';
comment on column "CdReport"."CreateDate" is '建檔日期時間';
comment on column "CdReport"."CreateEmpNo" is '建檔人員';
comment on column "CdReport"."LastUpdate" is '最後更新日期時間';
comment on column "CdReport"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdStock" purge;

create table "CdStock" (
  "StockCode" varchar2(10),
  "StockItem" nvarchar2(20),
  "StockCompanyName" nvarchar2(50),
  "Currency" varchar2(3),
  "YdClosePrice" decimal(16, 2) default 0 not null,
  "MonthlyAvg" decimal(16, 2) default 0 not null,
  "ThreeMonthAvg" decimal(16, 2) default 0 not null,
  "StockType" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdStock" add constraint "CdStock_PK" primary key("StockCode");

comment on table "CdStock" is '股票代號檔';
comment on column "CdStock"."StockCode" is '股票代號';
comment on column "CdStock"."StockItem" is '股票簡稱';
comment on column "CdStock"."StockCompanyName" is '股票公司名稱';
comment on column "CdStock"."Currency" is '幣別';
comment on column "CdStock"."YdClosePrice" is '前日收盤價';
comment on column "CdStock"."MonthlyAvg" is '一個月平均價';
comment on column "CdStock"."ThreeMonthAvg" is '三個月平均價';
comment on column "CdStock"."StockType" is '上市上櫃記號';
comment on column "CdStock"."CreateDate" is '建檔日期時間';
comment on column "CdStock"."CreateEmpNo" is '建檔人員';
comment on column "CdStock"."LastUpdate" is '最後更新日期時間';
comment on column "CdStock"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdSupv" purge;

create table "CdSupv" (
  "SupvReasonCode" varchar2(4),
  "SupvReasonItem" nvarchar2(40),
  "SupvReasonLevel" varchar2(1),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdSupv" add constraint "CdSupv_PK" primary key("SupvReasonCode");

comment on table "CdSupv" is '主管理由檔';
comment on column "CdSupv"."SupvReasonCode" is '理由代碼';
comment on column "CdSupv"."SupvReasonItem" is '理由說明';
comment on column "CdSupv"."SupvReasonLevel" is '理由階層';
comment on column "CdSupv"."Enable" is '啟用記號';
comment on column "CdSupv"."CreateDate" is '建檔日期時間';
comment on column "CdSupv"."CreateEmpNo" is '建檔人員';
comment on column "CdSupv"."LastUpdate" is '最後更新日期時間';
comment on column "CdSupv"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdVarValue" purge;

create table "CdVarValue" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "AvailableFunds" decimal(16, 2) default 0 not null,
  "LoanTotalLmt" decimal(16, 2) default 0 not null,
  "NoGurTotalLmt" decimal(16, 2) default 0 not null,
  "Totalequity" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdVarValue" add constraint "CdVarValue_PK" primary key("YearMonth");

comment on table "CdVarValue" is '變動數值設定檔';
comment on column "CdVarValue"."YearMonth" is '年月';
comment on column "CdVarValue"."AvailableFunds" is '可運用資金';
comment on column "CdVarValue"."LoanTotalLmt" is '總借款限額';
comment on column "CdVarValue"."NoGurTotalLmt" is '無擔保限額';
comment on column "CdVarValue"."Totalequity" is '股東權益(淨值)';
comment on column "CdVarValue"."CreateDate" is '建檔日期時間';
comment on column "CdVarValue"."CreateEmpNo" is '建檔人員';
comment on column "CdVarValue"."LastUpdate" is '最後更新日期時間';
comment on column "CdVarValue"."LastUpdateEmpNo" is '最後更新人員';
drop table "CdWorkMonth" purge;

create table "CdWorkMonth" (
  "Year" decimal(4, 0) default 0 not null,
  "Month" decimal(2, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdWorkMonth" add constraint "CdWorkMonth_PK" primary key("Year", "Month");

comment on table "CdWorkMonth" is '放款業績工作月對照檔';
comment on column "CdWorkMonth"."Year" is '業績年度';
comment on column "CdWorkMonth"."Month" is '工作月份';
comment on column "CdWorkMonth"."StartDate" is '開始日期';
comment on column "CdWorkMonth"."EndDate" is '終止日期';
comment on column "CdWorkMonth"."CreateDate" is '建檔日期時間';
comment on column "CdWorkMonth"."CreateEmpNo" is '建檔人員';
comment on column "CdWorkMonth"."LastUpdate" is '最後更新日期時間';
comment on column "CdWorkMonth"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClBuilding" purge;

create table "ClBuilding" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "Road" nvarchar2(40),
  "Section" varchar2(5),
  "Alley" varchar2(5),
  "Lane" varchar2(5),
  "Num" varchar2(5),
  "NumDash" varchar2(5),
  "Floor" varchar2(5),
  "FloorDash" varchar2(5),
  "BdNo1" varchar2(5),
  "BdNo2" varchar2(3),
  "BdLocation" nvarchar2(150),
  "BdMainUseCode" varchar2(2),
  "BdUsageCode" varchar2(1),
  "BdMtrlCode" varchar2(2),
  "BdTypeCode" varchar2(2),
  "TotalFloor" decimal(3, 0) default 0 not null,
  "FloorNo" varchar2(7),
  "FloorArea" decimal(16, 2) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "RoofStructureCode" varchar2(2),
  "BdDate" decimal(8, 0) default 0 not null,
  "BdSubUsageCode" varchar2(2),
  "BdSubArea" decimal(16, 2) default 0 not null,
  "SellerId" varchar2(10),
  "SellerName" nvarchar2(100),
  "ContractPrice" decimal(16, 2) default 0 not null,
  "ContractDate" decimal(8, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "ParkingArea" decimal(16, 2) default 0 not null,
  "ParkingProperty" varchar2(1),
  "HouseTaxNo" varchar2(12),
  "HouseBuyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClBuilding" add constraint "ClBuilding_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClBuilding" add constraint "ClBuilding_ClImm_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClImm" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClBuilding_Index1" on "ClBuilding"("ClCode1" asc);

create index "ClBuilding_Index2" on "ClBuilding"("ClCode1" asc, "ClCode2" asc);

comment on table "ClBuilding" is '擔保品不動產建物檔';
comment on column "ClBuilding"."ClCode1" is '擔保品代號1';
comment on column "ClBuilding"."ClCode2" is '擔保品代號2';
comment on column "ClBuilding"."ClNo" is '擔保品編號';
comment on column "ClBuilding"."CityCode" is '縣市';
comment on column "ClBuilding"."AreaCode" is '鄉鎮市區';
comment on column "ClBuilding"."IrCode" is '段小段代碼';
comment on column "ClBuilding"."Road" is '路名';
comment on column "ClBuilding"."Section" is '段';
comment on column "ClBuilding"."Alley" is '巷';
comment on column "ClBuilding"."Lane" is '弄';
comment on column "ClBuilding"."Num" is '號';
comment on column "ClBuilding"."NumDash" is '號之';
comment on column "ClBuilding"."Floor" is '樓';
comment on column "ClBuilding"."FloorDash" is '樓之';
comment on column "ClBuilding"."BdNo1" is '建號';
comment on column "ClBuilding"."BdNo2" is '建號(子號)';
comment on column "ClBuilding"."BdLocation" is '建物門牌';
comment on column "ClBuilding"."BdMainUseCode" is '建物主要用途';
comment on column "ClBuilding"."BdUsageCode" is '建物使用別';
comment on column "ClBuilding"."BdMtrlCode" is '建物主要建材';
comment on column "ClBuilding"."BdTypeCode" is '建物類別';
comment on column "ClBuilding"."TotalFloor" is '總樓層';
comment on column "ClBuilding"."FloorNo" is '擔保品所在樓層';
comment on column "ClBuilding"."FloorArea" is '擔保品所在樓層面積';
comment on column "ClBuilding"."EvaUnitPrice" is '鑑價單價/坪';
comment on column "ClBuilding"."RoofStructureCode" is '屋頂結構';
comment on column "ClBuilding"."BdDate" is '建築完成日期';
comment on column "ClBuilding"."BdSubUsageCode" is '附屬建物用途';
comment on column "ClBuilding"."BdSubArea" is '附屬建物面積';
comment on column "ClBuilding"."SellerId" is '賣方統編';
comment on column "ClBuilding"."SellerName" is '賣方姓名';
comment on column "ClBuilding"."ContractPrice" is '買賣契約價格';
comment on column "ClBuilding"."ContractDate" is '買賣契約日期';
comment on column "ClBuilding"."ParkingTypeCode" is '停車位形式';
comment on column "ClBuilding"."ParkingArea" is '登記面積(坪)';
comment on column "ClBuilding"."ParkingProperty" is '獨立產權車位註記';
comment on column "ClBuilding"."HouseTaxNo" is '房屋稅籍號碼';
comment on column "ClBuilding"."HouseBuyDate" is '房屋取得日期';
comment on column "ClBuilding"."CreateDate" is '建檔日期時間';
comment on column "ClBuilding"."CreateEmpNo" is '建檔人員';
comment on column "ClBuilding"."LastUpdate" is '最後更新日期時間';
comment on column "ClBuilding"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClBuildingOwner" purge;

create table "ClBuildingOwner" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "OwnerRelCode" varchar2(2),
  "OwnerPart" decimal(10, 0) default 0 not null,
  "OwnerTotal" decimal(10, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClBuildingOwner" add constraint "ClBuildingOwner_PK" primary key("ClCode1", "ClCode2", "ClNo", "OwnerCustUKey");

alter table "ClBuildingOwner" add constraint "ClBuildingOwner_ClBuilding_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClBuilding" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClBuildingOwner_Index1" on "ClBuildingOwner"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

create index "ClBuildingOwner_Index2" on "ClBuildingOwner"("OwnerCustUKey" asc);

create index "ClBuildingOwner_Index3" on "ClBuildingOwner"("ClCode1" asc, "ClCode2" asc, "ClNo" asc, "OwnerRelCode" asc);

comment on table "ClBuildingOwner" is '擔保品-建物所有權人檔';
comment on column "ClBuildingOwner"."ClCode1" is '擔保品-代號1';
comment on column "ClBuildingOwner"."ClCode2" is '擔保品-代號2';
comment on column "ClBuildingOwner"."ClNo" is '擔保品編號';
comment on column "ClBuildingOwner"."OwnerCustUKey" is '客戶識別碼';
comment on column "ClBuildingOwner"."OwnerRelCode" is '與授信戶關係';
comment on column "ClBuildingOwner"."OwnerPart" is '持份比率(分子)';
comment on column "ClBuildingOwner"."OwnerTotal" is '持份比率(分母)';
comment on column "ClBuildingOwner"."CreateDate" is '建檔日期時間';
comment on column "ClBuildingOwner"."CreateEmpNo" is '建檔人員';
comment on column "ClBuildingOwner"."LastUpdate" is '最後更新日期時間';
comment on column "ClBuildingOwner"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClBuildingPublic" purge;

create table "ClBuildingPublic" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PublicSeq" decimal(5, 0) default 0 not null,
  "PublicBdNo1" decimal(5, 0) default 0 not null,
  "PublicBdNo2" decimal(3, 0) default 0 not null,
  "Area" decimal(16, 2) default 0 not null,
  "OwnerId" varchar2(10),
  "OwnerName" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClBuildingPublic" add constraint "ClBuildingPublic_PK" primary key("ClCode1", "ClCode2", "ClNo", "PublicSeq");

alter table "ClBuildingPublic" add constraint "ClBuildingPublic_ClBuilding_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClBuilding" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClBuildingPublic_Index1" on "ClBuildingPublic"("PublicBdNo1" asc);

create index "ClBuildingPublic_Index2" on "ClBuildingPublic"("PublicBdNo1" asc, "PublicBdNo2" asc);

comment on table "ClBuildingPublic" is '擔保品-建物公設建號檔';
comment on column "ClBuildingPublic"."ClCode1" is '擔保品-代號1';
comment on column "ClBuildingPublic"."ClCode2" is '擔保品-代號2';
comment on column "ClBuildingPublic"."ClNo" is '擔保品編號';
comment on column "ClBuildingPublic"."PublicSeq" is '公設資料序號';
comment on column "ClBuildingPublic"."PublicBdNo1" is '公設建號';
comment on column "ClBuildingPublic"."PublicBdNo2" is '公設建號(子號)';
comment on column "ClBuildingPublic"."Area" is '登記面積(坪)';
comment on column "ClBuildingPublic"."OwnerId" is '所有權人統編';
comment on column "ClBuildingPublic"."OwnerName" is '所有權人姓名';
comment on column "ClBuildingPublic"."CreateDate" is '建檔日期時間';
comment on column "ClBuildingPublic"."CreateEmpNo" is '建檔人員';
comment on column "ClBuildingPublic"."LastUpdate" is '最後更新日期時間';
comment on column "ClBuildingPublic"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClBuildingReason" purge;

create table "ClBuildingReason" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ReasonSeq" decimal(3, 0) default 0 not null,
  "Reason" decimal(1, 0) default 0 not null,
  "OtherReason" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClBuildingReason" add constraint "ClBuildingReason_PK" primary key("ClCode1", "ClCode2", "ClNo", "ReasonSeq");

alter table "ClBuildingReason" add constraint "ClBuildingReason_ClBuilding_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClBuilding" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create unique index "ClBuildingReason_Index1" on "ClBuildingReason"("ClCode1" asc, "ClCode2" asc, "ClNo" asc, "ReasonSeq" asc);

comment on table "ClBuildingReason" is '擔保品-建物修改原因檔';
comment on column "ClBuildingReason"."ClCode1" is '擔保品-代號1';
comment on column "ClBuildingReason"."ClCode2" is '擔保品-代號2';
comment on column "ClBuildingReason"."ClNo" is '擔保品編號';
comment on column "ClBuildingReason"."ReasonSeq" is '修改原因序號';
comment on column "ClBuildingReason"."Reason" is '修改原因';
comment on column "ClBuildingReason"."OtherReason" is '其他原因';
comment on column "ClBuildingReason"."CreateDate" is '建檔日期時間';
comment on column "ClBuildingReason"."CreateEmpNo" is '建檔人員';
comment on column "ClBuildingReason"."LastUpdate" is '最後更新日期時間';
comment on column "ClBuildingReason"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClEva" purge;

create table "ClEva" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "EvaNo" decimal(2, 0) default 0 not null,
  "EvaDate" decimal(8, 0) default 0 not null,
  "EvaAmt" decimal(16, 2) default 0 not null,
  "EvaNetWorth" decimal(16, 2) default 0 not null,
  "RentEvaValue" decimal(16, 2) default 0 not null,
  "EvaCompanyId" varchar2(2),
  "EvaCompanyName" nvarchar2(100),
  "EvaEmpno" varchar2(6),
  "EvaReason" decimal(2, 0) default 0 not null,
  "OtherReason" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClEva" add constraint "ClEva_PK" primary key("ClCode1", "ClCode2", "ClNo", "EvaNo");

alter table "ClEva" add constraint "ClEva_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClEva_Index1" on "ClEva"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

comment on table "ClEva" is '擔保品重評資料檔';
comment on column "ClEva"."ClCode1" is '擔保品代號1';
comment on column "ClEva"."ClCode2" is '擔保品代號2';
comment on column "ClEva"."ClNo" is '擔保品編號';
comment on column "ClEva"."EvaNo" is '鑑估序號';
comment on column "ClEva"."EvaDate" is '鑑價日期';
comment on column "ClEva"."EvaAmt" is '評估總價';
comment on column "ClEva"."EvaNetWorth" is '評估淨值';
comment on column "ClEva"."RentEvaValue" is '出租評估淨值';
comment on column "ClEva"."EvaCompanyId" is '估價公司代碼';
comment on column "ClEva"."EvaCompanyName" is '估價公司名稱';
comment on column "ClEva"."EvaEmpno" is '估價人員';
comment on column "ClEva"."EvaReason" is '重評原因';
comment on column "ClEva"."OtherReason" is '其他重評原因';
comment on column "ClEva"."CreateDate" is '建檔日期時間';
comment on column "ClEva"."CreateEmpNo" is '建檔人員';
comment on column "ClEva"."LastUpdate" is '最後更新日期時間';
comment on column "ClEva"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClFac" purge;

create table "ClFac" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ApproveNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "MainFlag" varchar2(1),
  "FacShareFlag" decimal(1, 0) default 0 not null,
  "ShareAmt" decimal(16, 2) default 0 not null,
  "OriSettingAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClFac" add constraint "ClFac_PK" primary key("ClCode1", "ClCode2", "ClNo", "ApproveNo");

alter table "ClFac" add constraint "ClFac_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

alter table "ClFac" add constraint "ClFac_FacCaseAppl_FK2" foreign key ("ApproveNo") references "FacCaseAppl" ("ApplNo") on delete cascade;

create index "ClFac_Index1" on "ClFac"("ClCode1" asc);

create index "ClFac_Index2" on "ClFac"("ClCode1" asc, "ClCode2" asc);

create index "ClFac_Index3" on "ClFac"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

create index "ClFac_Index4" on "ClFac"("ApproveNo" asc);

create index "ClFac_Index5" on "ClFac"("CustNo" asc, "FacmNo" asc);

comment on table "ClFac" is '擔保品與額度關聯檔';
comment on column "ClFac"."ClCode1" is '擔保品代號1';
comment on column "ClFac"."ClCode2" is '擔保品代號2';
comment on column "ClFac"."ClNo" is '擔保品編號';
comment on column "ClFac"."ApproveNo" is '核准號碼';
comment on column "ClFac"."CustNo" is '借款人戶號';
comment on column "ClFac"."FacmNo" is '額度編號';
comment on column "ClFac"."MainFlag" is '主要擔保品記號';
comment on column "ClFac"."FacShareFlag" is '共用額度記號';
comment on column "ClFac"."ShareAmt" is '分配金額';
comment on column "ClFac"."OriSettingAmt" is '設定金額';
comment on column "ClFac"."CreateDate" is '建檔日期時間';
comment on column "ClFac"."CreateEmpNo" is '建檔人員';
comment on column "ClFac"."LastUpdate" is '最後更新日期時間';
comment on column "ClFac"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClImm" purge;

create table "ClImm" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "EvaNetWorth" decimal(16, 2) default 0 not null,
  "LVITax" decimal(16, 2) default 0 not null,
  "RentEvaValue" decimal(16, 2) default 0 not null,
  "RentPrice" decimal(16, 2) default 0 not null,
  "OwnershipCode" varchar2(1),
  "MtgCode" varchar2(1),
  "MtgCheck" varchar2(1),
  "MtgLoan" varchar2(1),
  "MtgPledge" varchar2(1),
  "Agreement" varchar2(1),
  "EvaCompanyCode" varchar2(2),
  "LimitCancelDate" decimal(8, 0) default 0 not null,
  "ClCode" varchar2(1),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "OtherOwnerTotal" decimal(16, 2) default 0 not null,
  "CompensationCopy" varchar2(1),
  "BdRmk" nvarchar2(60),
  "MtgReasonCode" varchar2(1),
  "ReceivedDate" decimal(8, 0) default 0 not null,
  "ReceivedNo" nvarchar2(20),
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelNo" nvarchar2(20),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "ClaimDate" decimal(8, 0) default 0 not null,
  "SettingSeq" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClImm" add constraint "ClImm_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClImm" add constraint "ClImm_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClImm_Index1" on "ClImm"("ClCode1" asc);

create index "ClImm_Index2" on "ClImm"("ClCode1" asc, "ClCode2" asc);

comment on table "ClImm" is '擔保品不動產檔';
comment on column "ClImm"."ClCode1" is '擔保品代號1';
comment on column "ClImm"."ClCode2" is '擔保品代號2';
comment on column "ClImm"."ClNo" is '擔保品編號';
comment on column "ClImm"."EvaNetWorth" is '評估淨值';
comment on column "ClImm"."LVITax" is '土地增值稅';
comment on column "ClImm"."RentEvaValue" is '出租評估淨值';
comment on column "ClImm"."RentPrice" is '押租金';
comment on column "ClImm"."OwnershipCode" is '權利種類';
comment on column "ClImm"."MtgCode" is '抵押權註記';
comment on column "ClImm"."MtgCheck" is '最高限額抵押權之擔保債權種類-票據';
comment on column "ClImm"."MtgLoan" is '最高限額抵押權之擔保債權種類-借款';
comment on column "ClImm"."MtgPledge" is '最高限額抵押權之擔保債權種類-保證債務';
comment on column "ClImm"."Agreement" is '檢附同意書';
comment on column "ClImm"."EvaCompanyCode" is '鑑價公司';
comment on column "ClImm"."LimitCancelDate" is '限制塗銷日期';
comment on column "ClImm"."ClCode" is '擔保註記';
comment on column "ClImm"."LoanToValue" is '貸放成數(%)';
comment on column "ClImm"."OtherOwnerTotal" is '其他債權人設定總額';
comment on column "ClImm"."CompensationCopy" is '代償後謄本';
comment on column "ClImm"."BdRmk" is '建物標示備註';
comment on column "ClImm"."MtgReasonCode" is '最高抵押權確定事由';
comment on column "ClImm"."ReceivedDate" is '收文日期';
comment on column "ClImm"."ReceivedNo" is '收文案號';
comment on column "ClImm"."CancelDate" is '撤銷日期';
comment on column "ClImm"."CancelNo" is '撤銷案號';
comment on column "ClImm"."SettingStat" is '設定狀態';
comment on column "ClImm"."ClStat" is '擔保品狀態';
comment on column "ClImm"."SettingDate" is '設定日期';
comment on column "ClImm"."SettingAmt" is '設定金額';
comment on column "ClImm"."ClaimDate" is '擔保債權確定日期';
comment on column "ClImm"."SettingSeq" is '設定順位(1~9)';
comment on column "ClImm"."CreateDate" is '建檔日期時間';
comment on column "ClImm"."CreateEmpNo" is '建檔人員';
comment on column "ClImm"."LastUpdate" is '最後更新日期時間';
comment on column "ClImm"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClImmRankDetail" purge;

create table "ClImmRankDetail" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "SettingSeq" varchar2(1),
  "FirstCreditor" nvarchar2(40),
  "FirstAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClImmRankDetail" add constraint "ClImmRankDetail_PK" primary key("ClCode1", "ClCode2", "ClNo", "SettingSeq");

comment on table "ClImmRankDetail" is '擔保品不動產檔設定順位明細檔';
comment on column "ClImmRankDetail"."ClCode1" is '擔保品代號1';
comment on column "ClImmRankDetail"."ClCode2" is '擔保品代號2';
comment on column "ClImmRankDetail"."ClNo" is '擔保品編號';
comment on column "ClImmRankDetail"."SettingSeq" is '設定順位(1~9)';
comment on column "ClImmRankDetail"."FirstCreditor" is '前一順位債權人';
comment on column "ClImmRankDetail"."FirstAmt" is '前一順位金額';
comment on column "ClImmRankDetail"."CreateDate" is '建檔日期時間';
comment on column "ClImmRankDetail"."CreateEmpNo" is '建檔人員';
comment on column "ClImmRankDetail"."LastUpdate" is '最後更新日期時間';
comment on column "ClImmRankDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClLand" purge;

create table "ClLand" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "LandSeq" decimal(3, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "LandNo1" varchar2(4),
  "LandNo2" varchar2(4),
  "LandLocation" nvarchar2(150),
  "LandCode" varchar2(2),
  "Area" decimal(9, 2) default 0 not null,
  "LandZoningCode" varchar2(2),
  "LandUsageType" varchar2(2),
  "LandUsageCode" varchar2(2),
  "PostedLandValue" decimal(16, 2) default 0 not null,
  "PostedLandValueYearMonth" decimal(6, 0) default 0 not null,
  "TransferedYear" decimal(4, 0) default 0 not null,
  "LastTransferedAmt" decimal(16, 2) default 0 not null,
  "LVITax" decimal(16, 2) default 0 not null,
  "LVITaxYearMonth" decimal(6, 0) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "LandRentStartDate" decimal(8, 0) default 0 not null,
  "LandRentEndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClLand" add constraint "ClLand_PK" primary key("ClCode1", "ClCode2", "ClNo", "LandSeq");

alter table "ClLand" add constraint "ClLand_ClImm_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClImm" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClLand_Index1" on "ClLand"("ClCode1" asc);

create index "ClLand_Index2" on "ClLand"("ClCode1" asc, "ClCode2" asc);

comment on table "ClLand" is '擔保品不動產土地檔';
comment on column "ClLand"."ClCode1" is '擔保品代號1';
comment on column "ClLand"."ClCode2" is '擔保品代號2';
comment on column "ClLand"."ClNo" is '擔保品編號';
comment on column "ClLand"."LandSeq" is '土地序號';
comment on column "ClLand"."CityCode" is '縣市';
comment on column "ClLand"."AreaCode" is '鄉鎮市區';
comment on column "ClLand"."IrCode" is '段小段代碼';
comment on column "ClLand"."LandNo1" is '地號';
comment on column "ClLand"."LandNo2" is '地號(子號)';
comment on column "ClLand"."LandLocation" is '土地座落';
comment on column "ClLand"."LandCode" is '地目';
comment on column "ClLand"."Area" is '面積';
comment on column "ClLand"."LandZoningCode" is '土地使用區分';
comment on column "ClLand"."LandUsageType" is '使用地類別';
comment on column "ClLand"."LandUsageCode" is '土地使用別';
comment on column "ClLand"."PostedLandValue" is '公告土地現值';
comment on column "ClLand"."PostedLandValueYearMonth" is '公告土地現值年月';
comment on column "ClLand"."TransferedYear" is '移轉年度';
comment on column "ClLand"."LastTransferedAmt" is '前次移轉金額';
comment on column "ClLand"."LVITax" is '土地增值稅';
comment on column "ClLand"."LVITaxYearMonth" is '土地增值稅年月';
comment on column "ClLand"."EvaUnitPrice" is '鑑價單價/坪';
comment on column "ClLand"."LandRentStartDate" is '土地租約起日';
comment on column "ClLand"."LandRentEndDate" is '土地租約到期日';
comment on column "ClLand"."CreateDate" is '建檔日期時間';
comment on column "ClLand"."CreateEmpNo" is '建檔人員';
comment on column "ClLand"."LastUpdate" is '最後更新日期時間';
comment on column "ClLand"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClLandOwner" purge;

create table "ClLandOwner" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "LandSeq" decimal(3, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "OwnerRelCode" varchar2(2),
  "OwnerPart" decimal(10, 0) default 0 not null,
  "OwnerTotal" decimal(10, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClLandOwner" add constraint "ClLandOwner_PK" primary key("ClCode1", "ClCode2", "ClNo", "LandSeq", "OwnerCustUKey");

alter table "ClLandOwner" add constraint "ClLandOwner_ClLand_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClLand" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClLandOwner_Index1" on "ClLandOwner"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

create index "ClLandOwner_Index2" on "ClLandOwner"("OwnerCustUKey" asc);

comment on table "ClLandOwner" is '擔保品-土地所有權人檔';
comment on column "ClLandOwner"."ClCode1" is '擔保品代號1';
comment on column "ClLandOwner"."ClCode2" is '擔保品代號2';
comment on column "ClLandOwner"."ClNo" is '擔保品編號';
comment on column "ClLandOwner"."LandSeq" is '土地序號';
comment on column "ClLandOwner"."OwnerCustUKey" is '客戶識別碼';
comment on column "ClLandOwner"."OwnerRelCode" is '與授信戶關係';
comment on column "ClLandOwner"."OwnerPart" is '持份比率(分子)';
comment on column "ClLandOwner"."OwnerTotal" is '持份比率(分母)';
comment on column "ClLandOwner"."CreateDate" is '建檔日期時間';
comment on column "ClLandOwner"."CreateEmpNo" is '建檔人員';
comment on column "ClLandOwner"."LastUpdate" is '最後更新日期時間';
comment on column "ClLandOwner"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClLandReason" purge;

create table "ClLandReason" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ReasonSeq" decimal(3, 0) default 0 not null,
  "Reason" decimal(1, 0) default 0 not null,
  "OtherReason" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClLandReason" add constraint "ClLandReason_PK" primary key("ClCode1", "ClCode2", "ClNo", "ReasonSeq");

alter table "ClLandReason" add constraint "ClLandReason_ClLand_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClLand" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create unique index "ClLandReason_Index1" on "ClLandReason"("ClCode1" asc, "ClCode2" asc, "ClNo" asc, "ReasonSeq" asc);

comment on table "ClLandReason" is '擔保品-土地修改原因檔';
comment on column "ClLandReason"."ClCode1" is '擔保品-代號1';
comment on column "ClLandReason"."ClCode2" is '擔保品-代號2';
comment on column "ClLandReason"."ClNo" is '擔保品編號';
comment on column "ClLandReason"."ReasonSeq" is '修改原因序號';
comment on column "ClLandReason"."Reason" is '修改原因';
comment on column "ClLandReason"."OtherReason" is '其他原因';
comment on column "ClLandReason"."CreateDate" is '建檔日期時間';
comment on column "ClLandReason"."CreateEmpNo" is '建檔人員';
comment on column "ClLandReason"."LastUpdate" is '最後更新日期時間';
comment on column "ClLandReason"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClMain" purge;

create table "ClMain" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ClTypeCode" varchar2(3),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "ClStatus" varchar2(1),
  "EvaDate" decimal(8, 0) default 0 not null,
  "EvaAmt" decimal(16, 2) default 0 not null,
  "ShareTotal" decimal(16, 2) default 0 not null,
  "Synd" varchar2(1),
  "SyndCode" varchar2(1),
  "DispPrice" decimal(16, 2) default 0 not null,
  "DispDate" decimal(8, 0) default 0 not null,
  "NewNote" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClMain" add constraint "ClMain_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClMain" add constraint "ClMain_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "ClMain_Index1" on "ClMain"("ClCode1" asc);

create index "ClMain_Index2" on "ClMain"("ClCode1" asc, "ClCode2" asc);

create index "ClMain_Index3" on "ClMain"("ClNo" asc);

create index "ClMain_Index4" on "ClMain"("CustUKey" asc);

comment on table "ClMain" is '擔保品主檔';
comment on column "ClMain"."ClCode1" is '擔保品代號1';
comment on column "ClMain"."ClCode2" is '擔保品代號2';
comment on column "ClMain"."ClNo" is '擔保品編號';
comment on column "ClMain"."CustUKey" is '客戶識別碼';
comment on column "ClMain"."ClTypeCode" is '擔保品類別代碼';
comment on column "ClMain"."CityCode" is '地區別';
comment on column "ClMain"."AreaCode" is '鄉鎮區';
comment on column "ClMain"."ClStatus" is '擔保品狀況碼';
comment on column "ClMain"."EvaDate" is '鑑估日期';
comment on column "ClMain"."EvaAmt" is '鑑估總值';
comment on column "ClMain"."ShareTotal" is '可分配金額';
comment on column "ClMain"."Synd" is '是否為聯貸案';
comment on column "ClMain"."SyndCode" is '聯貸案類型';
comment on column "ClMain"."DispPrice" is '處分價格';
comment on column "ClMain"."DispDate" is '處分日期';
comment on column "ClMain"."NewNote" is '最新註記';
comment on column "ClMain"."CreateDate" is '建檔日期時間';
comment on column "ClMain"."CreateEmpNo" is '建檔人員';
comment on column "ClMain"."LastUpdate" is '最後更新日期時間';
comment on column "ClMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClMovables" purge;

create table "ClMovables" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "ServiceLife" decimal(2, 0) default 0 not null,
  "ProductSpec" varchar2(20),
  "ProductType" varchar2(10),
  "ProductBrand" varchar2(20),
  "ProductCC" varchar2(10),
  "ProductColor" varchar2(10),
  "EngineSN" varchar2(50),
  "LicenseNo" varchar2(10),
  "LicenseTypeCode" varchar2(1),
  "LicenseUsageCode" varchar2(1),
  "LiceneIssueDate" decimal(8, 0) default 0 not null,
  "MfgYearMonth" decimal(6, 0) default 0 not null,
  "VehicleTypeCode" varchar2(2),
  "VehicleStyleCode" varchar2(2),
  "VehicleOfficeCode" varchar2(3),
  "Currency" varchar2(3),
  "ExchangeRate" decimal(8, 5) default 0 not null,
  "Insurance" varchar2(1),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "ScrapValue" decimal(16, 2) default 0 not null,
  "MtgCode" varchar2(1),
  "MtgCheck" varchar2(1),
  "MtgLoan" varchar2(1),
  "MtgPledge" varchar2(1),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "ReceiptNo" nvarchar2(20),
  "MtgNo" nvarchar2(20),
  "ReceivedDate" decimal(8, 0) default 0 not null,
  "MortgageIssueStartDate" decimal(8, 0) default 0 not null,
  "MortgageIssueEndDate" decimal(8, 0) default 0 not null,
  "Remark" nvarchar2(120),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClMovables" add constraint "ClMovables_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClMovables" add constraint "ClMovables_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClMovables_Index1" on "ClMovables"("ClCode1" asc);

create index "ClMovables_Index2" on "ClMovables"("ClCode1" asc, "ClCode2" asc);

create index "ClMovables_Index3" on "ClMovables"("OwnerCustUKey" asc);

comment on table "ClMovables" is '擔保品動產檔';
comment on column "ClMovables"."ClCode1" is '擔保品代號1';
comment on column "ClMovables"."ClCode2" is '擔保品代號2';
comment on column "ClMovables"."ClNo" is '擔保品編號';
comment on column "ClMovables"."OwnerCustUKey" is '客戶識別碼';
comment on column "ClMovables"."ServiceLife" is '耐用年限';
comment on column "ClMovables"."ProductSpec" is '形式/規格';
comment on column "ClMovables"."ProductType" is '產品代碼/型號';
comment on column "ClMovables"."ProductBrand" is '品牌/廠牌/船名';
comment on column "ClMovables"."ProductCC" is '排氣量';
comment on column "ClMovables"."ProductColor" is '顏色';
comment on column "ClMovables"."EngineSN" is '引擎號碼';
comment on column "ClMovables"."LicenseNo" is '牌照號碼';
comment on column "ClMovables"."LicenseTypeCode" is '牌照類別';
comment on column "ClMovables"."LicenseUsageCode" is '牌照用途';
comment on column "ClMovables"."LiceneIssueDate" is '發照日期';
comment on column "ClMovables"."MfgYearMonth" is '製造年月';
comment on column "ClMovables"."VehicleTypeCode" is '車別';
comment on column "ClMovables"."VehicleStyleCode" is '車身樣式';
comment on column "ClMovables"."VehicleOfficeCode" is '監理站';
comment on column "ClMovables"."Currency" is '幣別';
comment on column "ClMovables"."ExchangeRate" is '匯率';
comment on column "ClMovables"."Insurance" is '投保註記';
comment on column "ClMovables"."LoanToValue" is '貸放成數(%)';
comment on column "ClMovables"."ScrapValue" is '殘值';
comment on column "ClMovables"."MtgCode" is '抵押權註記';
comment on column "ClMovables"."MtgCheck" is '最高限額抵押權之擔保債權種類-票據';
comment on column "ClMovables"."MtgLoan" is '最高限額抵押權之擔保債權種類-借款';
comment on column "ClMovables"."MtgPledge" is '最高限額抵押權之擔保債權種類-保證債務';
comment on column "ClMovables"."SettingStat" is '設定狀態';
comment on column "ClMovables"."ClStat" is '擔保品狀態';
comment on column "ClMovables"."SettingDate" is '設定日期';
comment on column "ClMovables"."SettingAmt" is '抵押設定金額';
comment on column "ClMovables"."ReceiptNo" is '收件字號';
comment on column "ClMovables"."MtgNo" is '抵押登記字號';
comment on column "ClMovables"."ReceivedDate" is '抵押收件日';
comment on column "ClMovables"."MortgageIssueStartDate" is '抵押登記起日';
comment on column "ClMovables"."MortgageIssueEndDate" is '抵押登記迄日';
comment on column "ClMovables"."Remark" is '備註';
comment on column "ClMovables"."CreateDate" is '建檔日期時間';
comment on column "ClMovables"."CreateEmpNo" is '建檔人員';
comment on column "ClMovables"."LastUpdate" is '最後更新日期時間';
comment on column "ClMovables"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClNoMap" purge;

create table "ClNoMap" (
  "GdrId1" decimal(1, 0) default 0 not null,
  "GdrId2" decimal(2, 0) default 0 not null,
  "GdrNum" decimal(7, 0) default 0 not null,
  "LgtSeq" decimal(2, 0) default 0 not null,
  "MainGdrId1" decimal(1, 0) default 0 not null,
  "MainGdrId2" decimal(2, 0) default 0 not null,
  "MainGdrNum" decimal(7, 0) default 0 not null,
  "MainLgtSeq" decimal(2, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "TfStatus" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClNoMap" add constraint "ClNoMap_PK" primary key("GdrId1", "GdrId2", "GdrNum", "LgtSeq");

create index "ClNoMap_Index1" on "ClNoMap"("MainGdrId1" asc, "MainGdrId2" asc, "MainGdrNum" asc, "MainLgtSeq" asc);

create index "ClNoMap_Index2" on "ClNoMap"("ClCode1" asc, "ClCode2" asc, "ClNo" asc);

comment on table "ClNoMap" is '擔保品編號新舊對照檔';
comment on column "ClNoMap"."GdrId1" is '原擔保品代號1';
comment on column "ClNoMap"."GdrId2" is '原擔保品代號2';
comment on column "ClNoMap"."GdrNum" is '原擔保品編號';
comment on column "ClNoMap"."LgtSeq" is '原擔保品序號';
comment on column "ClNoMap"."MainGdrId1" is '最新擔保品代號1';
comment on column "ClNoMap"."MainGdrId2" is '最新擔保品代號2';
comment on column "ClNoMap"."MainGdrNum" is '最新擔保品編號';
comment on column "ClNoMap"."MainLgtSeq" is '最新擔保品序號';
comment on column "ClNoMap"."ClCode1" is '新擔保品代號1';
comment on column "ClNoMap"."ClCode2" is '新擔保品代號2';
comment on column "ClNoMap"."ClNo" is '新擔保品編號';
comment on column "ClNoMap"."TfStatus" is '轉換結果';
comment on column "ClNoMap"."CreateDate" is '建檔日期時間';
comment on column "ClNoMap"."CreateEmpNo" is '建檔人員';
comment on column "ClNoMap"."LastUpdate" is '最後更新日期時間';
comment on column "ClNoMap"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClOther" purge;

create table "ClOther" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PledgeStartDate" decimal(8, 0) default 0 not null,
  "PledgeEndDate" decimal(8, 0) default 0 not null,
  "PledgeBankCode" varchar2(2),
  "PledgeNO" varchar2(30),
  "OwnerCustUKey" varchar2(32),
  "IssuingId" varchar2(10),
  "IssuingCounty" varchar2(3),
  "DocNo" nvarchar2(30),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "SecuritiesType" varchar2(2),
  "Listed" varchar2(2),
  "OfferingDate" decimal(8, 0) default 0 not null,
  "ExpirationDate" decimal(8, 0) default 0 not null,
  "TargetIssuer" varchar2(2),
  "SubTargetIssuer" varchar2(2),
  "CreditDate" decimal(8, 0) default 0 not null,
  "Credit" varchar2(2),
  "ExternalCredit" varchar2(3),
  "Index" varchar2(2),
  "TradingMethod" varchar2(1),
  "Compensation" varchar2(3),
  "Investment" nvarchar2(300),
  "PublicValue" nvarchar2(300),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClOther" add constraint "ClOther_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClOther" add constraint "ClOther_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClOther_Index1" on "ClOther"("ClCode1" asc);

create index "ClOther_Index2" on "ClOther"("ClCode1" asc, "ClCode2" asc);

create index "ClOther_Index3" on "ClOther"("OwnerCustUKey" asc);

comment on table "ClOther" is '擔保品其他檔';
comment on column "ClOther"."ClCode1" is '擔保品代號1';
comment on column "ClOther"."ClCode2" is '擔保品代號2';
comment on column "ClOther"."ClNo" is '擔保品編號';
comment on column "ClOther"."PledgeStartDate" is '保證起日';
comment on column "ClOther"."PledgeEndDate" is '保證迄日';
comment on column "ClOther"."PledgeBankCode" is '保證銀行';
comment on column "ClOther"."PledgeNO" is '保證書字號';
comment on column "ClOther"."OwnerCustUKey" is '客戶識別碼';
comment on column "ClOther"."IssuingId" is '發行機構統編';
comment on column "ClOther"."IssuingCounty" is '發行機構所在國別';
comment on column "ClOther"."DocNo" is '憑證編號';
comment on column "ClOther"."LoanToValue" is '貸放成數(%)';
comment on column "ClOther"."SecuritiesType" is '有價證券類別';
comment on column "ClOther"."Listed" is '掛牌交易所';
comment on column "ClOther"."OfferingDate" is '發行日';
comment on column "ClOther"."ExpirationDate" is '到期日';
comment on column "ClOther"."TargetIssuer" is '發行者對象別';
comment on column "ClOther"."SubTargetIssuer" is '發行者次對象別';
comment on column "ClOther"."CreditDate" is '評等日期';
comment on column "ClOther"."Credit" is '評等公司';
comment on column "ClOther"."ExternalCredit" is '外部評等';
comment on column "ClOther"."Index" is '主要指數';
comment on column "ClOther"."TradingMethod" is '交易方法';
comment on column "ClOther"."Compensation" is '受償順位';
comment on column "ClOther"."Investment" is '投資內容';
comment on column "ClOther"."PublicValue" is '公開價值';
comment on column "ClOther"."SettingStat" is '設定狀態';
comment on column "ClOther"."ClStat" is '擔保品狀態';
comment on column "ClOther"."SettingDate" is '設定日期';
comment on column "ClOther"."SettingAmt" is '設定金額';
comment on column "ClOther"."CreateDate" is '建檔日期時間';
comment on column "ClOther"."CreateEmpNo" is '建檔人員';
comment on column "ClOther"."LastUpdate" is '最後更新日期時間';
comment on column "ClOther"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClOtherRights" purge;

create table "ClOtherRights" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "Seq" varchar2(8),
  "City" nvarchar2(3),
  "LandAdm" nvarchar2(3),
  "RecYear" decimal(3, 0) default 0 not null,
  "RecWord" nvarchar2(4),
  "RecNumber" varchar2(6),
  "RightsNote" nvarchar2(10),
  "SecuredTotal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClOtherRights" add constraint "ClOtherRights_PK" primary key("ClCode1", "ClCode2", "ClNo", "Seq");

alter table "ClOtherRights" add constraint "ClOtherRights_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClOtherRights_Index1" on "ClOtherRights"("ClCode1" asc);

create index "ClOtherRights_Index2" on "ClOtherRights"("ClCode1" asc, "ClCode2" asc);

comment on table "ClOtherRights" is '擔保品他項權利檔';
comment on column "ClOtherRights"."ClCode1" is '擔保品代號1';
comment on column "ClOtherRights"."ClCode2" is '擔保品代號2';
comment on column "ClOtherRights"."ClNo" is '擔保品編號';
comment on column "ClOtherRights"."Seq" is '他項權利序號';
comment on column "ClOtherRights"."City" is '縣市';
comment on column "ClOtherRights"."LandAdm" is '地政';
comment on column "ClOtherRights"."RecYear" is '收件年';
comment on column "ClOtherRights"."RecWord" is '收件字';
comment on column "ClOtherRights"."RecNumber" is '收件號';
comment on column "ClOtherRights"."RightsNote" is '權利價值說明';
comment on column "ClOtherRights"."SecuredTotal" is '擔保債權總金額';
comment on column "ClOtherRights"."CreateDate" is '建檔日期時間';
comment on column "ClOtherRights"."CreateEmpNo" is '建檔人員';
comment on column "ClOtherRights"."LastUpdate" is '最後更新日期時間';
comment on column "ClOtherRights"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClOwnerRelation" purge;

create table "ClOwnerRelation" (
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "OwnerRelCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClOwnerRelation" add constraint "ClOwnerRelation_PK" primary key("CreditSysNo", "CustNo", "OwnerCustUKey");

comment on table "ClOwnerRelation" is '擔保品所有權人與授信戶關係檔';
comment on column "ClOwnerRelation"."CreditSysNo" is '案件編號';
comment on column "ClOwnerRelation"."CustNo" is '借款人戶號';
comment on column "ClOwnerRelation"."OwnerCustUKey" is '客戶識別碼';
comment on column "ClOwnerRelation"."OwnerRelCode" is '與授信戶關係';
comment on column "ClOwnerRelation"."CreateDate" is '建檔日期時間';
comment on column "ClOwnerRelation"."CreateEmpNo" is '建檔人員';
comment on column "ClOwnerRelation"."LastUpdate" is '最後更新日期時間';
comment on column "ClOwnerRelation"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClParking" purge;

create table "ClParking" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ParkingSeqNo" decimal(5, 0) default 0 not null,
  "ParkingNo" nvarchar2(20),
  "ParkingQty" decimal(5, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "OwnerPart" decimal(10, 0) default 0 not null,
  "OwnerTotal" decimal(10, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "BdNo1" varchar2(5),
  "BdNo2" varchar2(3),
  "LandNo1" varchar2(4),
  "LandNo2" varchar2(4),
  "ParkingArea" decimal(16, 2) default 0 not null,
  "Amount" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClParking" add constraint "ClParking_PK" primary key("ClCode1", "ClCode2", "ClNo", "ParkingSeqNo");

comment on table "ClParking" is '擔保品-車位資料檔';
comment on column "ClParking"."ClCode1" is '擔保品-代號1';
comment on column "ClParking"."ClCode2" is '擔保品-代號2';
comment on column "ClParking"."ClNo" is '擔保品編號';
comment on column "ClParking"."ParkingSeqNo" is '車位資料序號';
comment on column "ClParking"."ParkingNo" is '車位編號';
comment on column "ClParking"."ParkingQty" is '車位數量';
comment on column "ClParking"."ParkingTypeCode" is '停車位型式';
comment on column "ClParking"."OwnerPart" is '持份比率(分子)';
comment on column "ClParking"."OwnerTotal" is '持份比率(分母)';
comment on column "ClParking"."CityCode" is '縣市';
comment on column "ClParking"."AreaCode" is '鄉鎮市區';
comment on column "ClParking"."IrCode" is '段小段代碼';
comment on column "ClParking"."BdNo1" is '建號';
comment on column "ClParking"."BdNo2" is '建號(子號)';
comment on column "ClParking"."LandNo1" is '地號';
comment on column "ClParking"."LandNo2" is '地號(子號)';
comment on column "ClParking"."ParkingArea" is '車位面積(坪)';
comment on column "ClParking"."Amount" is '價格(元)';
comment on column "ClParking"."CreateDate" is '建檔日期時間';
comment on column "ClParking"."CreateEmpNo" is '建檔人員';
comment on column "ClParking"."LastUpdate" is '最後更新日期時間';
comment on column "ClParking"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClParkingType" purge;

create table "ClParkingType" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "ParkingQty" decimal(5, 0) default 0 not null,
  "ParkingArea" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClParkingType" add constraint "ClParkingType_PK" primary key("ClCode1", "ClCode2", "ClNo", "ParkingTypeCode");

comment on table "ClParkingType" is '擔保品-停車位型式檔';
comment on column "ClParkingType"."ClCode1" is '擔保品-代號1';
comment on column "ClParkingType"."ClCode2" is '擔保品-代號2';
comment on column "ClParkingType"."ClNo" is '擔保品編號';
comment on column "ClParkingType"."ParkingTypeCode" is '停車位型式';
comment on column "ClParkingType"."ParkingQty" is '車位數量';
comment on column "ClParkingType"."ParkingArea" is '車位面積(坪)';
comment on column "ClParkingType"."CreateDate" is '建檔日期時間';
comment on column "ClParkingType"."CreateEmpNo" is '建檔人員';
comment on column "ClParkingType"."LastUpdate" is '最後更新日期時間';
comment on column "ClParkingType"."LastUpdateEmpNo" is '最後更新人員';
drop table "ClStock" purge;

create table "ClStock" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "StockCode" varchar2(10),
  "ListingType" varchar2(2),
  "StockType" varchar2(1),
  "CompanyId" varchar2(10),
  "DataYear" decimal(4, 0) default 0 not null,
  "IssuedShares" decimal(16, 2) default 0 not null,
  "NetWorth" decimal(16, 2) default 0 not null,
  "EvaStandard" varchar2(2),
  "ParValue" decimal(16, 2) default 0 not null,
  "MonthlyAvg" decimal(16, 2) default 0 not null,
  "YdClosingPrice" decimal(16, 2) default 0 not null,
  "ThreeMonthAvg" decimal(16, 2) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "InsiderJobTitle" varchar2(2),
  "InsiderPosition" varchar2(2),
  "LegalPersonId" varchar2(10),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "ClMtr" decimal(5, 2) default 0 not null,
  "NoticeMtr" decimal(5, 2) default 0 not null,
  "ImplementMtr" decimal(5, 2) default 0 not null,
  "AcMtr" decimal(5, 2) default 0 not null,
  "PledgeNo" nvarchar2(14),
  "ComputeMTR" varchar2(1),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingBalance" decimal(16, 2) default 0 not null,
  "MtgDate" decimal(8, 0) default 0 not null,
  "CustodyNo" nvarchar2(5),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ClStock" add constraint "ClStock_PK" primary key("ClCode1", "ClCode2", "ClNo");

alter table "ClStock" add constraint "ClStock_ClMain_FK1" foreign key ("ClCode1", "ClCode2", "ClNo") references "ClMain" ("ClCode1", "ClCode2", "ClNo") on delete cascade;

create index "ClStock_Index1" on "ClStock"("ClCode1" asc);

create index "ClStock_Index2" on "ClStock"("ClCode1" asc, "ClCode2" asc);

create index "ClStock_Index3" on "ClStock"("OwnerCustUKey" asc);

comment on table "ClStock" is '擔保品股票檔';
comment on column "ClStock"."ClCode1" is '擔保品代號1';
comment on column "ClStock"."ClCode2" is '擔保品代號2';
comment on column "ClStock"."ClNo" is '擔保品號碼';
comment on column "ClStock"."StockCode" is '股票代號';
comment on column "ClStock"."ListingType" is '掛牌別';
comment on column "ClStock"."StockType" is '股票種類';
comment on column "ClStock"."CompanyId" is '發行公司統一編號';
comment on column "ClStock"."DataYear" is '資料年度';
comment on column "ClStock"."IssuedShares" is '發行股數';
comment on column "ClStock"."NetWorth" is '非上市(櫃)每股淨值';
comment on column "ClStock"."EvaStandard" is '每股單價鑑估標準';
comment on column "ClStock"."ParValue" is '每股面額';
comment on column "ClStock"."MonthlyAvg" is '一個月平均價';
comment on column "ClStock"."YdClosingPrice" is '前日收盤價';
comment on column "ClStock"."ThreeMonthAvg" is '三個月平均價';
comment on column "ClStock"."EvaUnitPrice" is '鑑定單價';
comment on column "ClStock"."OwnerCustUKey" is '客戶識別碼';
comment on column "ClStock"."InsiderJobTitle" is '公司內部人職稱';
comment on column "ClStock"."InsiderPosition" is '公司內部人身分註記';
comment on column "ClStock"."LegalPersonId" is '法定關係人統編';
comment on column "ClStock"."LoanToValue" is '貸放成數(%)';
comment on column "ClStock"."ClMtr" is '擔保維持率(%)';
comment on column "ClStock"."NoticeMtr" is '通知追繳維持率(%)';
comment on column "ClStock"."ImplementMtr" is '實行職權維持率(%)';
comment on column "ClStock"."AcMtr" is '全戶維持率(%)';
comment on column "ClStock"."PledgeNo" is '質權設定書號';
comment on column "ClStock"."ComputeMTR" is '計算維持率';
comment on column "ClStock"."SettingStat" is '設定狀態';
comment on column "ClStock"."ClStat" is '擔保品狀態';
comment on column "ClStock"."SettingDate" is '股票設解(質)日期';
comment on column "ClStock"."SettingBalance" is '設質股數餘額';
comment on column "ClStock"."MtgDate" is '擔保債權確定日期';
comment on column "ClStock"."CustodyNo" is '保管條號碼';
comment on column "ClStock"."CreateDate" is '建檔日期時間';
comment on column "ClStock"."CreateEmpNo" is '建檔人員';
comment on column "ClStock"."LastUpdate" is '最後更新日期時間';
comment on column "ClStock"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollLaw" purge;

create table "CollLaw" (
  "CaseCode" varchar2(1),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "RecordDate" decimal(8, 0) default 0 not null,
  "LegalProg" varchar2(3),
  "Amount" decimal(16, 2) default 0 not null,
  "Remark" varchar2(1),
  "Memo" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollLaw" add constraint "CollLaw_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollLaw" is '法催紀錄法務進度檔';
comment on column "CollLaw"."CaseCode" is '案件種類';
comment on column "CollLaw"."ClCode1" is '擔保品代號1';
comment on column "CollLaw"."ClCode2" is '擔保品代號2';
comment on column "CollLaw"."ClNo" is '擔保品編號';
comment on column "CollLaw"."CustNo" is '借款人戶號';
comment on column "CollLaw"."FacmNo" is '額度編號';
comment on column "CollLaw"."AcDate" is '作業日期';
comment on column "CollLaw"."TitaTlrNo" is '經辦';
comment on column "CollLaw"."TitaTxtNo" is '交易序號';
comment on column "CollLaw"."RecordDate" is '記錄日期';
comment on column "CollLaw"."LegalProg" is '法務進度';
comment on column "CollLaw"."Amount" is '金額';
comment on column "CollLaw"."Remark" is '其他記錄選項';
comment on column "CollLaw"."Memo" is '其他紀錄內容';
comment on column "CollLaw"."CreateDate" is '建檔日期時間';
comment on column "CollLaw"."CreateEmpNo" is '建檔人員';
comment on column "CollLaw"."LastUpdate" is '最後更新日期時間';
comment on column "CollLaw"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollLetter" purge;

create table "CollLetter" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MailTypeCode" varchar2(1),
  "MailDate" decimal(8, 0) default 0 not null,
  "MailObj" varchar2(1),
  "CustName" nvarchar2(100),
  "DelvrYet" varchar2(1),
  "DelvrCode" varchar2(1),
  "AddressCode" decimal(1, 0) default 0 not null,
  "Address" nvarchar2(60),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollLetter" add constraint "CollLetter_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollLetter" is '法催紀錄函催檔';
comment on column "CollLetter"."CaseCode" is '案件種類';
comment on column "CollLetter"."CustNo" is '借款人戶號';
comment on column "CollLetter"."FacmNo" is '額度編號';
comment on column "CollLetter"."AcDate" is '作業日期';
comment on column "CollLetter"."TitaTlrNo" is '經辦';
comment on column "CollLetter"."TitaTxtNo" is '交易序號';
comment on column "CollLetter"."MailTypeCode" is '發函種類';
comment on column "CollLetter"."MailDate" is '發函日期';
comment on column "CollLetter"."MailObj" is '發函對象';
comment on column "CollLetter"."CustName" is '姓名';
comment on column "CollLetter"."DelvrYet" is '送達否';
comment on column "CollLetter"."DelvrCode" is '送達方式';
comment on column "CollLetter"."AddressCode" is '寄送地點選項';
comment on column "CollLetter"."Address" is '寄送地點';
comment on column "CollLetter"."Remark" is '其他記錄';
comment on column "CollLetter"."CreateDate" is '建檔日期時間';
comment on column "CollLetter"."CreateEmpNo" is '建檔人員';
comment on column "CollLetter"."LastUpdate" is '最後更新日期時間';
comment on column "CollLetter"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollList" purge;

create table "CollList" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CaseCode" varchar2(1),
  "TxDate" decimal(8, 0) default 0 not null,
  "TxCode" varchar2(1),
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "OvduTerm" decimal(3, 0) default 0 not null,
  "OvduDays" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "AccCollPsn" varchar2(6),
  "LegalPsn" varchar2(6),
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "IsSpecify" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollList" add constraint "CollList_PK" primary key("CustNo", "FacmNo");

create index "CollList_Index1" on "CollList"("CustNo" asc, "FacmNo" asc, "Status" asc);

comment on table "CollList" is '法催紀錄清單檔';
comment on column "CollList"."CustNo" is '戶號';
comment on column "CollList"."FacmNo" is '額度';
comment on column "CollList"."CaseCode" is '案件種類';
comment on column "CollList"."TxDate" is '作業日期';
comment on column "CollList"."TxCode" is '作業項目';
comment on column "CollList"."PrevIntDate" is '繳息迄日';
comment on column "CollList"."NextIntDate" is '應繳息日';
comment on column "CollList"."OvduTerm" is '逾期期數';
comment on column "CollList"."OvduDays" is '逾期天數';
comment on column "CollList"."CurrencyCode" is '幣別';
comment on column "CollList"."PrinBalance" is '本金餘額';
comment on column "CollList"."BadDebtBal" is '呆帳餘額';
comment on column "CollList"."AccCollPsn" is '催收員';
comment on column "CollList"."LegalPsn" is '法務人員';
comment on column "CollList"."Status" is '戶況';
comment on column "CollList"."AcctCode" is '業務科目代號';
comment on column "CollList"."FacAcctCode" is '額度業務科目';
comment on column "CollList"."ClCustNo" is '同擔保品戶號';
comment on column "CollList"."ClFacmNo" is '同擔保品額度';
comment on column "CollList"."ClRowNo" is '同擔保品序列號';
comment on column "CollList"."ClCode1" is '擔保品代號1';
comment on column "CollList"."ClCode2" is '擔保品代號2';
comment on column "CollList"."ClNo" is '擔保品號碼';
comment on column "CollList"."RenewCode" is '展期記號';
comment on column "CollList"."AcDate" is '會計日期';
comment on column "CollList"."IsSpecify" is '是否指定';
comment on column "CollList"."CreateDate" is '建檔日期時間';
comment on column "CollList"."CreateEmpNo" is '建檔人員';
comment on column "CollList"."LastUpdate" is '最後更新日期時間';
comment on column "CollList"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollListTmp" purge;

create table "CollListTmp" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "CaseCode" varchar2(1),
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "RenewCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollListTmp" add constraint "CollListTmp_PK" primary key("CustNo", "FacmNo", "ClCode1", "ClCode2", "ClNo");

comment on table "CollListTmp" is '法催紀錄清單暫存檔';
comment on column "CollListTmp"."CustNo" is '戶號';
comment on column "CollListTmp"."FacmNo" is '額度';
comment on column "CollListTmp"."ClCode1" is '擔保品代號1';
comment on column "CollListTmp"."ClCode2" is '擔保品代號2';
comment on column "CollListTmp"."ClNo" is '擔保品編號';
comment on column "CollListTmp"."ClCustNo" is '同擔保品戶號';
comment on column "CollListTmp"."ClFacmNo" is '同擔保品額度';
comment on column "CollListTmp"."ClRowNo" is '同擔保品序列號';
comment on column "CollListTmp"."CaseCode" is '案件種類';
comment on column "CollListTmp"."PrevIntDate" is '繳息迄日';
comment on column "CollListTmp"."NextIntDate" is '應繳息日';
comment on column "CollListTmp"."CurrencyCode" is '幣別';
comment on column "CollListTmp"."PrinBalance" is '本金餘額';
comment on column "CollListTmp"."BadDebtBal" is '呆帳餘額';
comment on column "CollListTmp"."Status" is '戶況';
comment on column "CollListTmp"."AcctCode" is '業務科目代號';
comment on column "CollListTmp"."FacAcctCode" is '額度業務科目';
comment on column "CollListTmp"."RenewCode" is '展期記號';
comment on column "CollListTmp"."AcDate" is '會計日期';
comment on column "CollListTmp"."CreateDate" is '建檔日期時間';
comment on column "CollListTmp"."CreateEmpNo" is '建檔人員';
comment on column "CollListTmp"."LastUpdate" is '最後更新日期時間';
comment on column "CollListTmp"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollMeet" purge;

create table "CollMeet" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MeetDate" decimal(8, 0) default 0 not null,
  "MeetTime" varchar2(4),
  "ContactCode" varchar2(1),
  "MeetPsnCode" varchar2(1),
  "CollPsnCode" varchar2(1),
  "CollPsnName" nvarchar2(8),
  "MeetPlaceCode" decimal(1, 0) default 0 not null,
  "MeetPlace" nvarchar2(60),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollMeet" add constraint "CollMeet_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollMeet" is '法催紀錄面催檔';
comment on column "CollMeet"."CaseCode" is '案件種類';
comment on column "CollMeet"."CustNo" is '借款人戶號';
comment on column "CollMeet"."FacmNo" is '額度編號';
comment on column "CollMeet"."AcDate" is '作業日期';
comment on column "CollMeet"."TitaTlrNo" is '經辦';
comment on column "CollMeet"."TitaTxtNo" is '交易序號';
comment on column "CollMeet"."MeetDate" is '面催日期';
comment on column "CollMeet"."MeetTime" is '面催時間';
comment on column "CollMeet"."ContactCode" is '聯絡對象';
comment on column "CollMeet"."MeetPsnCode" is '面晤人';
comment on column "CollMeet"."CollPsnCode" is '催收人員';
comment on column "CollMeet"."CollPsnName" is '催收人員姓名';
comment on column "CollMeet"."MeetPlaceCode" is '面催地點選項';
comment on column "CollMeet"."MeetPlace" is '面催地點';
comment on column "CollMeet"."Remark" is '其他記錄';
comment on column "CollMeet"."CreateDate" is '建檔日期時間';
comment on column "CollMeet"."CreateEmpNo" is '建檔人員';
comment on column "CollMeet"."LastUpdate" is '最後更新日期時間';
comment on column "CollMeet"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollRemind" purge;

create table "CollRemind" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "CondCode" varchar2(1),
  "RemindDate" decimal(8, 0) default 0 not null,
  "EditDate" decimal(8, 0) default 0 not null,
  "EditTime" varchar2(4),
  "RemindCode" varchar2(2),
  "Remark" varchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollRemind" add constraint "CollRemind_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollRemind" is '法催紀錄提醒事項檔';
comment on column "CollRemind"."CaseCode" is '案件種類';
comment on column "CollRemind"."CustNo" is '借款人戶號';
comment on column "CollRemind"."FacmNo" is '額度編號';
comment on column "CollRemind"."AcDate" is '作業日期';
comment on column "CollRemind"."TitaTlrNo" is '經辦';
comment on column "CollRemind"."TitaTxtNo" is '交易序號';
comment on column "CollRemind"."CondCode" is '狀態';
comment on column "CollRemind"."RemindDate" is '提醒日期';
comment on column "CollRemind"."EditDate" is '維護日期';
comment on column "CollRemind"."EditTime" is '維護時間';
comment on column "CollRemind"."RemindCode" is '提醒項目';
comment on column "CollRemind"."Remark" is '其他記錄';
comment on column "CollRemind"."CreateDate" is '建檔日期時間';
comment on column "CollRemind"."CreateEmpNo" is '建檔人員';
comment on column "CollRemind"."LastUpdate" is '最後更新日期時間';
comment on column "CollRemind"."LastUpdateEmpNo" is '最後更新人員';
drop table "CollTel" purge;

create table "CollTel" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "TelDate" decimal(8, 0) default 0 not null,
  "TelTime" varchar2(4),
  "ContactCode" varchar2(1),
  "RecvrCode" varchar2(1),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "ResultCode" varchar2(1),
  "Remark" nvarchar2(500),
  "CallDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CollTel" add constraint "CollTel_PK" primary key("CaseCode", "CustNo", "FacmNo", "AcDate", "TitaTlrNo", "TitaTxtNo");

comment on table "CollTel" is '法催紀錄電催檔';
comment on column "CollTel"."CaseCode" is '案件種類';
comment on column "CollTel"."CustNo" is '借款人戶號';
comment on column "CollTel"."FacmNo" is '額度編號';
comment on column "CollTel"."AcDate" is '作業日期';
comment on column "CollTel"."TitaTlrNo" is '經辦';
comment on column "CollTel"."TitaTxtNo" is '交易序號';
comment on column "CollTel"."TelDate" is '電催日期';
comment on column "CollTel"."TelTime" is '電催時間';
comment on column "CollTel"."ContactCode" is '聯絡對象';
comment on column "CollTel"."RecvrCode" is '接話人';
comment on column "CollTel"."TelArea" is '連絡電話';
comment on column "CollTel"."TelNo" is '連絡電話';
comment on column "CollTel"."TelExt" is '連絡電話';
comment on column "CollTel"."ResultCode" is '通話結果';
comment on column "CollTel"."Remark" is '其他記錄';
comment on column "CollTel"."CallDate" is '通話日期';
comment on column "CollTel"."CreateDate" is '建檔日期時間';
comment on column "CollTel"."CreateEmpNo" is '建檔人員';
comment on column "CollTel"."LastUpdate" is '最後更新日期時間';
comment on column "CollTel"."LastUpdateEmpNo" is '最後更新人員';
drop table "CoreAcMain" purge;

create table "CoreAcMain" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDate" decimal(8, 0) default 0 not null,
  "YdBal" decimal(16, 2) default 0 not null,
  "TdBal" decimal(16, 2) default 0 not null,
  "DbAmt" decimal(16, 2) default 0 not null,
  "CrAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CoreAcMain" add constraint "CoreAcMain_PK" primary key("AcBookCode", "AcSubBookCode", "CurrencyCode", "AcNoCode", "AcSubCode", "AcDate");

comment on table "CoreAcMain" is '核心會計總帳檔';
comment on column "CoreAcMain"."AcBookCode" is '帳冊別';
comment on column "CoreAcMain"."AcSubBookCode" is '區隔帳冊';
comment on column "CoreAcMain"."CurrencyCode" is '幣別';
comment on column "CoreAcMain"."AcNoCode" is '科目代號';
comment on column "CoreAcMain"."AcSubCode" is '子目代號';
comment on column "CoreAcMain"."AcDate" is '會計日期';
comment on column "CoreAcMain"."YdBal" is '前日餘額';
comment on column "CoreAcMain"."TdBal" is '本日餘額';
comment on column "CoreAcMain"."DbAmt" is '借方金額';
comment on column "CoreAcMain"."CrAmt" is '貸方金額';
comment on column "CoreAcMain"."CreateDate" is '建檔日期時間';
comment on column "CoreAcMain"."CreateEmpNo" is '建檔人員';
comment on column "CoreAcMain"."LastUpdate" is '最後更新日期時間';
comment on column "CoreAcMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "CreditRating" purge;

create table "CreditRating" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreditRatingCode" varchar2(1),
  "OriModel" varchar2(1),
  "OriRatingDate" decimal(8, 0) default 0 not null,
  "OriRating" varchar2(1),
  "Model" varchar2(1),
  "RatingDate" decimal(8, 0) default 0 not null,
  "Rating" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CreditRating" add constraint "CreditRating_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "CreditRating" is '信用評等檔';
comment on column "CreditRating"."DataYM" is '資料年月';
comment on column "CreditRating"."CustNo" is '戶號';
comment on column "CreditRating"."FacmNo" is '額度編號';
comment on column "CreditRating"."BormNo" is '撥款序號';
comment on column "CreditRating"."CreditRatingCode" is '企業戶/個人戶';
comment on column "CreditRating"."OriModel" is '原始認列時信用評等模型';
comment on column "CreditRating"."OriRatingDate" is '原始認列信用評等日期';
comment on column "CreditRating"."OriRating" is '原始認列時時信用評等';
comment on column "CreditRating"."Model" is '財務報導日時信用評等模型';
comment on column "CreditRating"."RatingDate" is '財務報導日信用評等評定日期';
comment on column "CreditRating"."Rating" is '財務報導日時信用評等';
comment on column "CreditRating"."CreateDate" is '建檔日期時間';
comment on column "CreditRating"."CreateEmpNo" is '建檔人員';
comment on column "CreditRating"."LastUpdate" is '最後更新日期時間';
comment on column "CreditRating"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustCross" purge;

create table "CustCross" (
  "CustUKey" varchar2(32),
  "SubCompanyCode" varchar2(2),
  "CrossUse" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustCross" add constraint "CustCross_PK" primary key("CustUKey", "SubCompanyCode");

alter table "CustCross" add constraint "CustCross_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

comment on table "CustCross" is '客戶交互運用檔';
comment on column "CustCross"."CustUKey" is '客戶識別碼';
comment on column "CustCross"."SubCompanyCode" is '子公司代碼';
comment on column "CustCross"."CrossUse" is '交互運用';
comment on column "CustCross"."CreateDate" is '建檔日期時間';
comment on column "CustCross"."CreateEmpNo" is '建檔人員';
comment on column "CustCross"."LastUpdate" is '最後更新日期時間';
comment on column "CustCross"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustDataCtrl" purge;

create table "CustDataCtrl" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "Enable" varchar2(1),
  "ApplMark" decimal(1, 0) default 0 not null,
  "Reason" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustDataCtrl" add constraint "CustDataCtrl_PK" primary key("CustNo");

alter table "CustDataCtrl" add constraint "CustDataCtrl_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

comment on table "CustDataCtrl" is '結清戶個資控管檔';
comment on column "CustDataCtrl"."CustNo" is '借款人戶號';
comment on column "CustDataCtrl"."CustUKey" is '客戶識別碼';
comment on column "CustDataCtrl"."Enable" is '啟用記號';
comment on column "CustDataCtrl"."ApplMark" is '申請記號';
comment on column "CustDataCtrl"."Reason" is '解除原因';
comment on column "CustDataCtrl"."CreateDate" is '建檔日期時間';
comment on column "CustDataCtrl"."CreateEmpNo" is '建檔人員';
comment on column "CustDataCtrl"."LastUpdate" is '最後更新日期時間';
comment on column "CustDataCtrl"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustFin" purge;

create table "CustFin" (
  "CustUKey" varchar2(32),
  "DataYear" decimal(4, 0) default 0 not null,
  "AssetTotal" decimal(16, 2) default 0 not null,
  "Cash" decimal(16, 2) default 0 not null,
  "ShortInv" decimal(16, 2) default 0 not null,
  "AR" decimal(16, 2) default 0 not null,
  "Inventory" decimal(16, 2) default 0 not null,
  "LongInv" decimal(16, 2) default 0 not null,
  "FixedAsset" decimal(16, 2) default 0 not null,
  "OtherAsset" decimal(16, 2) default 0 not null,
  "LiabTotal" decimal(16, 2) default 0 not null,
  "BankLoan" decimal(16, 2) default 0 not null,
  "OtherCurrLiab" decimal(16, 2) default 0 not null,
  "LongLiab" decimal(16, 2) default 0 not null,
  "OtherLiab" decimal(16, 2) default 0 not null,
  "NetWorthTotal" decimal(16, 2) default 0 not null,
  "Capital" decimal(16, 2) default 0 not null,
  "RetainEarning" decimal(16, 2) default 0 not null,
  "OpIncome" decimal(16, 2) default 0 not null,
  "OpCost" decimal(16, 2) default 0 not null,
  "OpProfit" decimal(16, 2) default 0 not null,
  "OpExpense" decimal(16, 2) default 0 not null,
  "OpRevenue" decimal(16, 2) default 0 not null,
  "NopIncome" decimal(16, 2) default 0 not null,
  "FinExpense" decimal(16, 2) default 0 not null,
  "NopExpense" decimal(16, 2) default 0 not null,
  "NetIncome" decimal(16, 2) default 0 not null,
  "Accountant" nvarchar2(14),
  "AccountDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustFin" add constraint "CustFin_PK" primary key("CustUKey", "DataYear");

alter table "CustFin" add constraint "CustFin_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "CustFin_Index1" on "CustFin"("CustUKey" asc);

comment on table "CustFin" is '公司戶財務狀況檔';
comment on column "CustFin"."CustUKey" is '客戶識別碼';
comment on column "CustFin"."DataYear" is '年度';
comment on column "CustFin"."AssetTotal" is '資產總額';
comment on column "CustFin"."Cash" is '現金/銀存';
comment on column "CustFin"."ShortInv" is '短期投資';
comment on column "CustFin"."AR" is '應收帳款票據';
comment on column "CustFin"."Inventory" is '存貨';
comment on column "CustFin"."LongInv" is '長期投資';
comment on column "CustFin"."FixedAsset" is '固定資產';
comment on column "CustFin"."OtherAsset" is '其他資產';
comment on column "CustFin"."LiabTotal" is '負債總額';
comment on column "CustFin"."BankLoan" is '銀行借款';
comment on column "CustFin"."OtherCurrLiab" is '其他流動負債';
comment on column "CustFin"."LongLiab" is '長期負債';
comment on column "CustFin"."OtherLiab" is '其他負債';
comment on column "CustFin"."NetWorthTotal" is '淨值總額';
comment on column "CustFin"."Capital" is '資本';
comment on column "CustFin"."RetainEarning" is '公積保留盈餘';
comment on column "CustFin"."OpIncome" is '營業收入';
comment on column "CustFin"."OpCost" is '營業成本';
comment on column "CustFin"."OpProfit" is '營業毛利';
comment on column "CustFin"."OpExpense" is '管銷費用';
comment on column "CustFin"."OpRevenue" is '營業利益';
comment on column "CustFin"."NopIncome" is '營業外收入';
comment on column "CustFin"."FinExpense" is '財務支出';
comment on column "CustFin"."NopExpense" is '其他營業外支';
comment on column "CustFin"."NetIncome" is '稅後淨利';
comment on column "CustFin"."Accountant" is '簽證會計師';
comment on column "CustFin"."AccountDate" is '簽證日期';
comment on column "CustFin"."CreateDate" is '建檔日期時間';
comment on column "CustFin"."CreateEmpNo" is '建檔人員';
comment on column "CustFin"."LastUpdate" is '最後更新日期時間';
comment on column "CustFin"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustMain" purge;

create table "CustMain" (
  "CustUKey" varchar2(32),
  "CustId" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CustName" nvarchar2(100),
  "Birthday" decimal(8, 0) default 0 not null,
  "Sex" varchar2(1),
  "CustTypeCode" varchar2(2),
  "IndustryCode" varchar2(6),
  "NationalityCode" varchar2(2),
  "BussNationalityCode" varchar2(2),
  "SpouseId" varchar2(10),
  "SpouseName" nvarchar2(100),
  "RegZip3" varchar2(3),
  "RegZip2" varchar2(3),
  "RegCityCode" varchar2(2),
  "RegAreaCode" varchar2(3),
  "RegRoad" nvarchar2(40),
  "RegSection" varchar2(5),
  "RegAlley" varchar2(5),
  "RegLane" varchar2(5),
  "RegNum" varchar2(5),
  "RegNumDash" varchar2(5),
  "RegFloor" varchar2(5),
  "RegFloorDash" varchar2(5),
  "CurrZip3" varchar2(3),
  "CurrZip2" varchar2(3),
  "CurrCityCode" varchar2(2),
  "CurrAreaCode" varchar2(3),
  "CurrRoad" nvarchar2(40),
  "CurrSection" varchar2(5),
  "CurrAlley" varchar2(5),
  "CurrLane" varchar2(5),
  "CurrNum" varchar2(5),
  "CurrNumDash" varchar2(5),
  "CurrFloor" varchar2(5),
  "CurrFloorDash" varchar2(5),
  "CuscCd" varchar2(1),
  "EntCode" varchar2(1),
  "EmpNo" varchar2(6),
  "EName" varchar2(50),
  "EduCode" varchar2(1),
  "OwnedHome" varchar2(1),
  "CurrCompName" nvarchar2(60),
  "CurrCompId" varchar2(8),
  "CurrCompTel" varchar2(16),
  "JobTitle" nvarchar2(20),
  "JobTenure" varchar2(2),
  "IncomeOfYearly" decimal(9, 0) default 0 not null,
  "IncomeDataDate" varchar2(6),
  "PassportNo" varchar2(20),
  "AMLJobCode" varchar2(3),
  "AMLGroup" varchar2(3),
  "IndigenousName" nvarchar2(100),
  "LastFacmNo" decimal(3, 0) default 0 not null,
  "LastSyndNo" decimal(3, 0) default 0 not null,
  "AllowInquire" varchar2(1),
  "Email" varchar2(50),
  "ActFg" decimal(1, 0) default 0 not null,
  "Introducer" varchar2(6),
  "IsSuspected" varchar2(1),
  "IsSuspectedCheck" varchar2(1),
  "IsSuspectedCheckType" varchar2(1),
  "DataStatus" decimal(1, 0) default 0 not null,
  "TypeCode" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustMain" add constraint "CustMain_PK" primary key("CustUKey");

create unique index "CustMain_Index1" on "CustMain"("CustId" asc);

create index "CustMain_Index2" on "CustMain"("CustNo" asc);

create index "CustMain_Index3" on "CustMain"("EmpNo" asc);

comment on table "CustMain" is '客戶資料主檔';
comment on column "CustMain"."CustUKey" is '客戶識別碼';
comment on column "CustMain"."CustId" is '身份證字號/統一編號';
comment on column "CustMain"."CustNo" is '戶號';
comment on column "CustMain"."BranchNo" is '單位別';
comment on column "CustMain"."CustName" is '戶名/公司名稱';
comment on column "CustMain"."Birthday" is '出生年月日/設立日期';
comment on column "CustMain"."Sex" is '性別';
comment on column "CustMain"."CustTypeCode" is '客戶別';
comment on column "CustMain"."IndustryCode" is '行業別';
comment on column "CustMain"."NationalityCode" is '自然人:出生地國籍/法人:註冊地國籍';
comment on column "CustMain"."BussNationalityCode" is '法人:營業地國籍';
comment on column "CustMain"."SpouseId" is '配偶身份證號/負責人身分證';
comment on column "CustMain"."SpouseName" is '配偶姓名/負責人姓名';
comment on column "CustMain"."RegZip3" is '戶籍-郵遞區號前三碼';
comment on column "CustMain"."RegZip2" is '戶籍-郵遞區號後三碼';
comment on column "CustMain"."RegCityCode" is '戶籍-縣市代碼';
comment on column "CustMain"."RegAreaCode" is '戶籍-鄉鎮市區代碼';
comment on column "CustMain"."RegRoad" is '戶籍-路名';
comment on column "CustMain"."RegSection" is '戶籍-段';
comment on column "CustMain"."RegAlley" is '戶籍-巷';
comment on column "CustMain"."RegLane" is '戶籍-弄';
comment on column "CustMain"."RegNum" is '戶籍-號';
comment on column "CustMain"."RegNumDash" is '戶籍-號之';
comment on column "CustMain"."RegFloor" is '戶籍-樓';
comment on column "CustMain"."RegFloorDash" is '戶籍-樓之';
comment on column "CustMain"."CurrZip3" is '通訊-郵遞區號前三碼';
comment on column "CustMain"."CurrZip2" is '通訊-郵遞區號後三碼';
comment on column "CustMain"."CurrCityCode" is '通訊-縣市代碼';
comment on column "CustMain"."CurrAreaCode" is '通訊-鄉鎮市區代碼';
comment on column "CustMain"."CurrRoad" is '通訊-路名';
comment on column "CustMain"."CurrSection" is '通訊-段';
comment on column "CustMain"."CurrAlley" is '通訊-巷';
comment on column "CustMain"."CurrLane" is '通訊-弄';
comment on column "CustMain"."CurrNum" is '通訊-號';
comment on column "CustMain"."CurrNumDash" is '通訊-號之';
comment on column "CustMain"."CurrFloor" is '通訊-樓';
comment on column "CustMain"."CurrFloorDash" is '通訊-樓之';
comment on column "CustMain"."CuscCd" is '身份別';
comment on column "CustMain"."EntCode" is '企金別';
comment on column "CustMain"."EmpNo" is '員工代號';
comment on column "CustMain"."EName" is '英文姓名';
comment on column "CustMain"."EduCode" is '教育程度代號';
comment on column "CustMain"."OwnedHome" is '自有住宅有無';
comment on column "CustMain"."CurrCompName" is '任職機構名稱';
comment on column "CustMain"."CurrCompId" is '任職機構統編';
comment on column "CustMain"."CurrCompTel" is '任職機構電話';
comment on column "CustMain"."JobTitle" is '職位名稱';
comment on column "CustMain"."JobTenure" is '服務年資';
comment on column "CustMain"."IncomeOfYearly" is '年收入';
comment on column "CustMain"."IncomeDataDate" is '年收入資料年月';
comment on column "CustMain"."PassportNo" is '護照號碼';
comment on column "CustMain"."AMLJobCode" is 'AML職業別';
comment on column "CustMain"."AMLGroup" is 'AML組織';
comment on column "CustMain"."IndigenousName" is '原住民姓名';
comment on column "CustMain"."LastFacmNo" is '已編額度編號';
comment on column "CustMain"."LastSyndNo" is '已編聯貸案序號';
comment on column "CustMain"."AllowInquire" is '開放查詢';
comment on column "CustMain"."Email" is 'EmailAddress';
comment on column "CustMain"."ActFg" is '交易進行記號';
comment on column "CustMain"."Introducer" is '介紹人';
comment on column "CustMain"."IsSuspected" is '是否為金控「疑似準利害關係人」名單';
comment on column "CustMain"."IsSuspectedCheck" is '是否為金控疑似利害關係人';
comment on column "CustMain"."IsSuspectedCheckType" is '是否為金控疑似利害關係人_確認狀態';
comment on column "CustMain"."DataStatus" is '資料狀態';
comment on column "CustMain"."TypeCode" is '建檔身分別';
comment on column "CustMain"."CreateDate" is '建檔日期時間';
comment on column "CustMain"."CreateEmpNo" is '建檔人員';
comment on column "CustMain"."LastUpdate" is '最後更新日期時間';
comment on column "CustMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustNotice" purge;

create table "CustNotice" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FormNo" varchar2(10),
  "PaperNotice" varchar2(1),
  "MsgNotice" varchar2(1),
  "EmailNotice" varchar2(1),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustNotice" add constraint "CustNotice_PK" primary key("CustNo", "FacmNo", "FormNo");

alter table "CustNotice" add constraint "CustNotice_CdReport_FK1" foreign key ("FormNo") references "CdReport" ("FormNo") on delete cascade;

create index "CustNotice_Index1" on "CustNotice"("CustNo" asc);

create index "CustNotice_Index2" on "CustNotice"("FormNo" asc);

create index "CustNotice_Index3" on "CustNotice"("CustNo" asc, "FacmNo" asc);

comment on table "CustNotice" is '客戶通知設定檔';
comment on column "CustNotice"."CustNo" is '戶號';
comment on column "CustNotice"."FacmNo" is '額度編號';
comment on column "CustNotice"."FormNo" is '報表代號';
comment on column "CustNotice"."PaperNotice" is '書面通知與否';
comment on column "CustNotice"."MsgNotice" is '簡訊發送與否';
comment on column "CustNotice"."EmailNotice" is '電子郵件發送與否';
comment on column "CustNotice"."ApplyDate" is '申請日期';
comment on column "CustNotice"."CreateDate" is '建檔日期時間';
comment on column "CustNotice"."CreateEmpNo" is '建檔人員';
comment on column "CustNotice"."LastUpdate" is '最後更新日期時間';
comment on column "CustNotice"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustomerAmlRating" purge;

create table "CustomerAmlRating" (
  "CustId" varchar2(10),
  "AmlRating" varchar2(1),
  "IsRelated" varchar2(1),
  "IsLnrelNear" varchar2(1),
  "IsLimit" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustomerAmlRating" add constraint "CustomerAmlRating_PK" primary key("CustId");

comment on table "CustomerAmlRating" is '客戶AML評級資料檔';
comment on column "CustomerAmlRating"."CustId" is '身份證字號/統一編號';
comment on column "CustomerAmlRating"."AmlRating" is 'AML評級';
comment on column "CustomerAmlRating"."IsRelated" is '利害關係人記號';
comment on column "CustomerAmlRating"."IsLnrelNear" is '準利害關係人記號';
comment on column "CustomerAmlRating"."IsLimit" is '授信限制對象記號';
comment on column "CustomerAmlRating"."CreateDate" is '建檔日期時間';
comment on column "CustomerAmlRating"."CreateEmpNo" is '建檔人員';
comment on column "CustomerAmlRating"."LastUpdate" is '最後更新日期時間';
comment on column "CustomerAmlRating"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustRmk" purge;

create table "CustRmk" (
  "CustNo" decimal(7, 0) default 0 not null,
  "RmkNo" decimal(3, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "RmkCode" varchar2(3),
  "RmkDesc" nvarchar2(120),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustRmk" add constraint "CustRmk_PK" primary key("CustNo", "RmkNo");

alter table "CustRmk" add constraint "CustRmk_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "CustRmk_Index1" on "CustRmk"("CustNo" asc);

create index "CustRmk_Index2" on "CustRmk"("RmkCode" asc);

comment on table "CustRmk" is '顧客控管警訊檔';
comment on column "CustRmk"."CustNo" is '借款人戶號';
comment on column "CustRmk"."RmkNo" is '備忘錄序號';
comment on column "CustRmk"."CustUKey" is '客戶識別碼';
comment on column "CustRmk"."RmkCode" is '備忘錄代碼';
comment on column "CustRmk"."RmkDesc" is '備忘錄說明';
comment on column "CustRmk"."CreateDate" is '建檔日期時間';
comment on column "CustRmk"."CreateEmpNo" is '建檔人員';
comment on column "CustRmk"."LastUpdate" is '最後更新日期時間';
comment on column "CustRmk"."LastUpdateEmpNo" is '最後更新人員';
drop table "CustTelNo" purge;

create table "CustTelNo" (
  "TelNoUKey" varchar2(32),
  "CustUKey" varchar2(32),
  "TelTypeCode" varchar2(2),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "TelChgRsnCode" varchar2(2),
  "RelationCode" varchar2(2),
  "LiaisonName" nvarchar2(100),
  "Rmk" nvarchar2(40),
  "StopReason" nvarchar2(40),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CustTelNo" add constraint "CustTelNo_PK" primary key("TelNoUKey");

alter table "CustTelNo" add constraint "CustTelNo_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

create index "CustTelNo_Index1" on "CustTelNo"("CustUKey" asc);

create index "CustTelNo_Index2" on "CustTelNo"("Mobile" asc);

comment on table "CustTelNo" is '客戶聯絡電話檔';
comment on column "CustTelNo"."TelNoUKey" is '電話識別碼';
comment on column "CustTelNo"."CustUKey" is '客戶識別碼';
comment on column "CustTelNo"."TelTypeCode" is '電話種類';
comment on column "CustTelNo"."TelArea" is '電話區碼';
comment on column "CustTelNo"."TelNo" is '電話號碼';
comment on column "CustTelNo"."TelExt" is '分機號碼';
comment on column "CustTelNo"."TelChgRsnCode" is '異動原因';
comment on column "CustTelNo"."RelationCode" is '與借款人關係';
comment on column "CustTelNo"."LiaisonName" is '聯絡人姓名';
comment on column "CustTelNo"."Rmk" is '備註';
comment on column "CustTelNo"."StopReason" is '停用原因';
comment on column "CustTelNo"."Enable" is '啟用記號';
comment on column "CustTelNo"."CreateDate" is '建檔日期時間';
comment on column "CustTelNo"."CreateEmpNo" is '建檔人員';
comment on column "CustTelNo"."LastUpdate" is '最後更新日期時間';
comment on column "CustTelNo"."LastUpdateEmpNo" is '最後更新人員';
drop table "DailyLoanBal" purge;

create table "DailyLoanBal" (
  "DataDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LatestFlag" decimal(1, 0) default 0 not null,
  "MonthEndYm" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ProdNo" varchar2(5),
  "LoanBalance" decimal(16, 2) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtAcc" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "DailyLoanBal" add constraint "DailyLoanBal_PK" primary key("DataDate", "CustNo", "FacmNo", "BormNo");

create index "DailyLoanBal_Index1" on "DailyLoanBal"("LatestFlag" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "DataDate" asc);

comment on table "DailyLoanBal" is '每日放款餘額檔';
comment on column "DailyLoanBal"."DataDate" is '資料日期';
comment on column "DailyLoanBal"."CustNo" is '戶號';
comment on column "DailyLoanBal"."FacmNo" is '額度編號';
comment on column "DailyLoanBal"."BormNo" is '撥款序號';
comment on column "DailyLoanBal"."LatestFlag" is '資料是否為最新';
comment on column "DailyLoanBal"."MonthEndYm" is '月底年月';
comment on column "DailyLoanBal"."CurrencyCode" is '幣別';
comment on column "DailyLoanBal"."AcctCode" is '業務科目代號';
comment on column "DailyLoanBal"."FacAcctCode" is '額度業務科目';
comment on column "DailyLoanBal"."ProdNo" is '商品代碼';
comment on column "DailyLoanBal"."LoanBalance" is '放款餘額';
comment on column "DailyLoanBal"."StoreRate" is '計息利率';
comment on column "DailyLoanBal"."IntAmtRcv" is '實收利息';
comment on column "DailyLoanBal"."IntAmtAcc" is '提存利息';
comment on column "DailyLoanBal"."CreateDate" is '建檔日期時間';
comment on column "DailyLoanBal"."CreateEmpNo" is '建檔人員';
comment on column "DailyLoanBal"."LastUpdate" is '最後更新日期時間';
comment on column "DailyLoanBal"."LastUpdateEmpNo" is '最後更新人員';
drop table "DataInputMapping" purge;

create table "DataInputMapping" (
  "InputTableName" varchar2(30),
  "TargerTableName" varchar2(30),
  "EnableFlag" varchar2(1),
  "SourceSystem" nvarchar2(50),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "DataInputMapping" add constraint "DataInputMapping_PK" primary key("InputTableName");

comment on table "DataInputMapping" is '資料傳入對照檔';
comment on column "DataInputMapping"."InputTableName" is '傳入資料表名稱';
comment on column "DataInputMapping"."TargerTableName" is '目標資料表名稱';
comment on column "DataInputMapping"."EnableFlag" is '啟用記號';
comment on column "DataInputMapping"."SourceSystem" is '來源系統';
comment on column "DataInputMapping"."Remark" is '備註';
comment on column "DataInputMapping"."CreateDate" is '建檔日期時間';
comment on column "DataInputMapping"."CreateEmpNo" is '建檔人員';
comment on column "DataInputMapping"."LastUpdate" is '最後更新日期時間';
comment on column "DataInputMapping"."LastUpdateEmpNo" is '最後更新人員';
drop table "DataInputRecord" purge;

create table "DataInputRecord" (
  "DataDate" decimal(8, 0) default 0 not null,
  "TableName" varchar2(30),
  "Seq" decimal(8, 0) default 0 not null,
  "InputCounts" decimal(14, 0) default 0 not null,
  "MovedFlag" varchar2(1),
  "MovedCount" decimal(14, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "DataInputRecord" add constraint "DataInputRecord_PK" primary key("DataDate", "TableName", "Seq");

comment on table "DataInputRecord" is '資料傳入記錄檔';
comment on column "DataInputRecord"."DataDate" is '資料傳輸日期';
comment on column "DataInputRecord"."TableName" is '資料表名稱';
comment on column "DataInputRecord"."Seq" is '流水號';
comment on column "DataInputRecord"."InputCounts" is '傳入筆數';
comment on column "DataInputRecord"."MovedFlag" is '是否已搬入對應資料表';
comment on column "DataInputRecord"."MovedCount" is '搬入筆數';
comment on column "DataInputRecord"."CreateDate" is '建檔日期時間';
comment on column "DataInputRecord"."CreateEmpNo" is '建檔人員';
comment on column "DataInputRecord"."LastUpdate" is '最後更新日期時間';
comment on column "DataInputRecord"."LastUpdateEmpNo" is '最後更新人員';
drop table "EmpDeductDtl" purge;

create table "EmpDeductDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "AchRepayCode" decimal(2, 0) default 0 not null,
  "PerfMonth" decimal(6, 0) default 0 not null,
  "ProcCode" varchar2(1),
  "RepayCode" varchar2(1),
  "AcctCode" varchar2(12),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "EmpNo" varchar2(6),
  "CustId" varchar2(10),
  "TxAmt" decimal(14, 0) default 0 not null,
  "ErrMsg" nvarchar2(20),
  "Acdate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "BatchNo" varchar2(6),
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ResignCode" varchar2(2),
  "DeptCode" varchar2(6),
  "UnitCode" varchar2(6),
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "PositCode" varchar2(2),
  "Principal" decimal(14, 0) default 0 not null,
  "Interest" decimal(14, 0) default 0 not null,
  "SumOvpayAmt" decimal(14, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "CurrIntAmt" decimal(14, 0) default 0 not null,
  "CurrPrinAmt" decimal(14, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "EmpDeductDtl" add constraint "EmpDeductDtl_PK" primary key("EntryDate", "CustNo", "AchRepayCode", "PerfMonth", "ProcCode", "RepayCode", "AcctCode", "FacmNo", "BormNo");

comment on table "EmpDeductDtl" is '員工扣薪明細檔';
comment on column "EmpDeductDtl"."EntryDate" is '入帳日期';
comment on column "EmpDeductDtl"."CustNo" is '戶號';
comment on column "EmpDeductDtl"."AchRepayCode" is '入帳扣款別';
comment on column "EmpDeductDtl"."PerfMonth" is '業績年月';
comment on column "EmpDeductDtl"."ProcCode" is '流程別';
comment on column "EmpDeductDtl"."RepayCode" is '扣款代碼';
comment on column "EmpDeductDtl"."AcctCode" is '科目';
comment on column "EmpDeductDtl"."FacmNo" is '額度編號';
comment on column "EmpDeductDtl"."BormNo" is '撥款編號';
comment on column "EmpDeductDtl"."EmpNo" is '員工代號';
comment on column "EmpDeductDtl"."CustId" is '統一編號';
comment on column "EmpDeductDtl"."TxAmt" is '交易金額(實扣金額)';
comment on column "EmpDeductDtl"."ErrMsg" is '失敗原因';
comment on column "EmpDeductDtl"."Acdate" is '會計日期';
comment on column "EmpDeductDtl"."TitaTlrNo" is '經辦';
comment on column "EmpDeductDtl"."TitaTxtNo" is '交易序號';
comment on column "EmpDeductDtl"."BatchNo" is '批次號碼';
comment on column "EmpDeductDtl"."RepayAmt" is '應扣金額';
comment on column "EmpDeductDtl"."ResignCode" is '離職代碼';
comment on column "EmpDeductDtl"."DeptCode" is '部室代號';
comment on column "EmpDeductDtl"."UnitCode" is '單位代號';
comment on column "EmpDeductDtl"."IntStartDate" is '計息起日';
comment on column "EmpDeductDtl"."IntEndDate" is '計息迄日';
comment on column "EmpDeductDtl"."PositCode" is '職務代號';
comment on column "EmpDeductDtl"."Principal" is '本金';
comment on column "EmpDeductDtl"."Interest" is '利息';
comment on column "EmpDeductDtl"."SumOvpayAmt" is '累溢短收';
comment on column "EmpDeductDtl"."JsonFields" is 'jason格式紀錄欄';
comment on column "EmpDeductDtl"."CurrIntAmt" is '當期利息';
comment on column "EmpDeductDtl"."CurrPrinAmt" is '當期本金';
comment on column "EmpDeductDtl"."MediaDate" is '媒體日期';
comment on column "EmpDeductDtl"."MediaKind" is '媒體別';
comment on column "EmpDeductDtl"."MediaSeq" is '媒體序號';
comment on column "EmpDeductDtl"."CreateDate" is '建檔日期時間';
comment on column "EmpDeductDtl"."CreateEmpNo" is '建檔人員';
comment on column "EmpDeductDtl"."LastUpdate" is '最後更新日期時間';
comment on column "EmpDeductDtl"."LastUpdateEmpNo" is '最後更新人員';
drop table "EmpDeductMedia" purge;

create table "EmpDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "PerfRepayCode" decimal(1, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "PerfMonth" decimal(6, 0) default 0 not null,
  "FlowCode" varchar2(1),
  "UnitCode" varchar2(6),
  "CustId" varchar2(10),
  "EntryDate" decimal(8, 0) default 0 not null,
  "TxAmt" decimal(14, 0) default 0 not null,
  "ErrorCode" varchar2(2),
  "AcctCode" varchar2(3),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "EmpDeductMedia" add constraint "EmpDeductMedia_PK" primary key("MediaDate", "MediaKind", "MediaSeq");

create index "EmpDeductMedia_Index1" on "EmpDeductMedia"("AcDate" asc, "BatchNo" asc, "DetailSeq" asc);

create index "EmpDeductMedia_Index2" on "EmpDeductMedia"("MediaDate" asc, "MediaKind" asc, "MediaSeq" asc);

create index "EmpDeductMedia_Index3" on "EmpDeductMedia"("AcDate" asc, "PerfMonth" asc, "FlowCode" asc);

comment on table "EmpDeductMedia" is '員工扣薪媒體檔';
comment on column "EmpDeductMedia"."MediaDate" is '媒體日期';
comment on column "EmpDeductMedia"."MediaKind" is '媒體別';
comment on column "EmpDeductMedia"."MediaSeq" is '媒體序號';
comment on column "EmpDeductMedia"."CustNo" is '戶號';
comment on column "EmpDeductMedia"."RepayCode" is '還款類別';
comment on column "EmpDeductMedia"."PerfRepayCode" is '扣款代碼';
comment on column "EmpDeductMedia"."RepayAmt" is '還款金額(扣款金額)';
comment on column "EmpDeductMedia"."PerfMonth" is '業績年月';
comment on column "EmpDeductMedia"."FlowCode" is '流程別';
comment on column "EmpDeductMedia"."UnitCode" is '單位代號';
comment on column "EmpDeductMedia"."CustId" is '身分證統一編號';
comment on column "EmpDeductMedia"."EntryDate" is '入帳日期';
comment on column "EmpDeductMedia"."TxAmt" is '交易金額(實扣金額)';
comment on column "EmpDeductMedia"."ErrorCode" is '失敗原因';
comment on column "EmpDeductMedia"."AcctCode" is '科目';
comment on column "EmpDeductMedia"."AcDate" is '會計日期';
comment on column "EmpDeductMedia"."BatchNo" is '批號';
comment on column "EmpDeductMedia"."DetailSeq" is '明細序號';
comment on column "EmpDeductMedia"."CreateDate" is '建檔日期時間';
comment on column "EmpDeductMedia"."CreateEmpNo" is '建檔人員';
comment on column "EmpDeductMedia"."LastUpdate" is '最後更新日期時間';
comment on column "EmpDeductMedia"."LastUpdateEmpNo" is '最後更新人員';
drop table "EmpDeductSchedule" purge;

create table "EmpDeductSchedule" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "AgType1" varchar2(1),
  "EntryDate" decimal(8, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "EmpDeductSchedule" add constraint "EmpDeductSchedule_PK" primary key("WorkMonth", "AgType1");

create index "EmpDeductSchedule_Index1" on "EmpDeductSchedule"("WorkMonth" asc, "AgType1" asc);

comment on table "EmpDeductSchedule" is '員工扣薪日程表';
comment on column "EmpDeductSchedule"."WorkMonth" is '工作年月';
comment on column "EmpDeductSchedule"."AgType1" is '流程別';
comment on column "EmpDeductSchedule"."EntryDate" is '入帳日期';
comment on column "EmpDeductSchedule"."MediaDate" is '媒體日期';
comment on column "EmpDeductSchedule"."CreateDate" is '建檔日期時間';
comment on column "EmpDeductSchedule"."CreateEmpNo" is '建檔人員';
comment on column "EmpDeductSchedule"."LastUpdate" is '最後更新日期時間';
comment on column "EmpDeductSchedule"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacCaseAppl" purge;

create table "FacCaseAppl" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ApplDate" decimal(8, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "SyndNo" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ApplAmt" decimal(16, 2) default 0 not null,
  "ProdNo" varchar2(5),
  "Estimate" varchar2(6),
  "DepartmentCode" varchar2(1),
  "PieceCode" varchar2(1),
  "CreditOfficer" varchar2(6),
  "LoanOfficer" varchar2(6),
  "Introducer" varchar2(6),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "Supervisor" varchar2(6),
  "ProcessCode" varchar2(1),
  "ApproveDate" decimal(8, 0) default 0 not null,
  "GroupUKey" varchar2(32),
  "BranchNo" varchar2(4),
  "IsLimit" varchar2(1),
  "IsRelated" varchar2(1),
  "IsLnrelNear" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacCaseAppl" add constraint "FacCaseAppl_PK" primary key("ApplNo");

alter table "FacCaseAppl" add constraint "FacCaseAppl_CustMain_FK1" foreign key ("CustUKey") references "CustMain" ("CustUKey") on delete cascade;

alter table "FacCaseAppl" add constraint "FacCaseAppl_FacProd_FK2" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

comment on table "FacCaseAppl" is '案件申請檔';
comment on column "FacCaseAppl"."ApplNo" is '申請號碼';
comment on column "FacCaseAppl"."CustUKey" is '客戶識別碼';
comment on column "FacCaseAppl"."ApplDate" is '申請日期';
comment on column "FacCaseAppl"."CreditSysNo" is '案件編號';
comment on column "FacCaseAppl"."SyndNo" is '聯貸案編號';
comment on column "FacCaseAppl"."CurrencyCode" is '申請幣別';
comment on column "FacCaseAppl"."ApplAmt" is '申請金額';
comment on column "FacCaseAppl"."ProdNo" is '申請商品代碼';
comment on column "FacCaseAppl"."Estimate" is '估價';
comment on column "FacCaseAppl"."DepartmentCode" is '案件隸屬單位';
comment on column "FacCaseAppl"."PieceCode" is '計件代碼';
comment on column "FacCaseAppl"."CreditOfficer" is '授信';
comment on column "FacCaseAppl"."LoanOfficer" is '放款專員';
comment on column "FacCaseAppl"."Introducer" is '介紹人';
comment on column "FacCaseAppl"."Coorgnizer" is '協辦人';
comment on column "FacCaseAppl"."InterviewerA" is '晤談一';
comment on column "FacCaseAppl"."InterviewerB" is '晤談二';
comment on column "FacCaseAppl"."Supervisor" is '核決主管';
comment on column "FacCaseAppl"."ProcessCode" is '處理情形';
comment on column "FacCaseAppl"."ApproveDate" is '准駁日期';
comment on column "FacCaseAppl"."GroupUKey" is '團體戶識別碼';
comment on column "FacCaseAppl"."BranchNo" is '單位別';
comment on column "FacCaseAppl"."IsLimit" is '是否為授信限制對象';
comment on column "FacCaseAppl"."IsRelated" is '是否為利害關係人';
comment on column "FacCaseAppl"."IsLnrelNear" is '是否為準利害關係人';
comment on column "FacCaseAppl"."CreateDate" is '建檔日期時間';
comment on column "FacCaseAppl"."CreateEmpNo" is '建檔人員';
comment on column "FacCaseAppl"."LastUpdate" is '最後更新日期時間';
comment on column "FacCaseAppl"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacClose" purge;

create table "FacClose" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CloseNo" decimal(3, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ActFlag" decimal(1, 0) default 0 not null,
  "FunCode" varchar2(1),
  "CarLoan" decimal(1, 0) default 0 not null,
  "ApplDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseReasonCode" varchar2(2),
  "CloseAmt" decimal(16, 2) default 0 not null,
  "CollectFlag" varchar2(1),
  "CollectWayCode" varchar2(2),
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "TelNo1" varchar2(15),
  "TelNo2" varchar2(15),
  "FaxNum" varchar2(15),
  "EntryDate" decimal(8, 0) default 0 not null,
  "AgreeNo" varchar2(10),
  "DocNo" decimal(7, 0) default 0 not null,
  "ClsNo" nvarchar2(18),
  "Rmk" nvarchar2(100),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ReceiveFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacClose" add constraint "FacClose_PK" primary key("CustNo", "CloseNo");

create index "FacClose_Index1" on "FacClose"("CustNo" asc);

create index "FacClose_Index2" on "FacClose"("CustNo" asc, "FacmNo" asc);

create index "FacClose_Index3" on "FacClose"("CustNo" asc, "FacmNo" asc, "CloseDate" asc);

comment on table "FacClose" is '清償作業檔';
comment on column "FacClose"."CustNo" is '戶號';
comment on column "FacClose"."CloseNo" is '清償序號';
comment on column "FacClose"."FacmNo" is '額度編號';
comment on column "FacClose"."ActFlag" is '登放記號';
comment on column "FacClose"."FunCode" is '作業功能';
comment on column "FacClose"."CarLoan" is '車貸';
comment on column "FacClose"."ApplDate" is '申請日期';
comment on column "FacClose"."CloseDate" is '結案日期(入帳日期)';
comment on column "FacClose"."CloseReasonCode" is '清償原因';
comment on column "FacClose"."CloseAmt" is '還清金額';
comment on column "FacClose"."CollectFlag" is '是否領取清償證明(Y/N/'')';
comment on column "FacClose"."CollectWayCode" is '領取方式';
comment on column "FacClose"."ReceiveDate" is '領取日期';
comment on column "FacClose"."TelNo1" is '連絡電話1';
comment on column "FacClose"."TelNo2" is '連絡電話2';
comment on column "FacClose"."FaxNum" is '傳真機號碼';
comment on column "FacClose"."EntryDate" is '入帳日期';
comment on column "FacClose"."AgreeNo" is '塗銷同意書編號';
comment on column "FacClose"."DocNo" is '公文編號';
comment on column "FacClose"."ClsNo" is '銷號欄';
comment on column "FacClose"."Rmk" is '備註';
comment on column "FacClose"."ClCode1" is '擔保品代號1';
comment on column "FacClose"."ClCode2" is '擔保品代號2';
comment on column "FacClose"."ClNo" is '擔保品編號';
comment on column "FacClose"."ReceiveFg" is '領取記號';
comment on column "FacClose"."CreateDate" is '建檔日期時間';
comment on column "FacClose"."CreateEmpNo" is '建檔人員';
comment on column "FacClose"."LastUpdate" is '最後更新日期時間';
comment on column "FacClose"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacMain" purge;

create table "FacMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "LastBormNo" decimal(3, 0) default 0 not null,
  "LastBormRvNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AnnualIncr" decimal(6, 4) default 0 not null,
  "EmailIncr" decimal(6, 4) default 0 not null,
  "GraceIncr" decimal(6, 4) default 0 not null,
  "RateCode" varchar2(1),
  "FirstRateAdjFreq" decimal(2, 0) default 0 not null,
  "RateAdjFreq" decimal(2, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "LineAmt" decimal(16, 2) default 0 not null,
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "AcctCode" varchar2(3),
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "IntCalcCode" varchar2(1),
  "AmortizedCode" varchar2(1),
  "FreqBase" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "HandlingFee" decimal(16, 2) default 0 not null,
  "RuleCode" varchar2(2),
  "ExtraRepayCode" varchar2(1),
  "CustTypeCode" varchar2(2),
  "RecycleCode" varchar2(1),
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "UsageCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "IncomeTaxFlag" varchar2(1),
  "CompensateFlag" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "RateAdjNoticeCode" varchar2(1),
  "PieceCode" varchar2(1),
  "RepayCode" decimal(2, 0) default 0 not null,
  "Introducer" varchar2(6),
  "District" varchar2(6),
  "FireOfficer" varchar2(6),
  "Estimate" varchar2(6),
  "CreditOfficer" varchar2(6),
  "LoanOfficer" varchar2(6),
  "BusinessOfficer" varchar2(6),
  "Supervisor" varchar2(6),
  "InvestigateOfficer" varchar2(6),
  "EstimateReview" varchar2(6),
  "Coorgnizer" varchar2(6),
  "AdvanceCloseCode" decimal(2, 0) default 0 not null,
  "ProdBreachFlag" varchar2(1),
  "BreachDescription" nvarchar2(200),
  "CreditScore" decimal(3, 0) default 0 not null,
  "GuaranteeDate" decimal(8, 0) default 0 not null,
  "ContractNo" varchar2(10),
  "ColSetFlag" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "LastAcctDate" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "AcDate" decimal(8, 0) default 0 not null,
  "L9110Flag" varchar2(1),
  "BranchNo" varchar2(4),
  "ApprovedLevel" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacMain" add constraint "FacMain_PK" primary key("CustNo", "FacmNo");

alter table "FacMain" add constraint "FacMain_FacCaseAppl_FK1" foreign key ("ApplNo") references "FacCaseAppl" ("ApplNo") on delete cascade;

alter table "FacMain" add constraint "FacMain_FacProd_FK2" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

create index "FacMain_Index1" on "FacMain"("ApplNo" asc);

create index "FacMain_Index2" on "FacMain"("CreditSysNo" asc);

comment on table "FacMain" is '額度主檔';
comment on column "FacMain"."CustNo" is '借款人戶號';
comment on column "FacMain"."FacmNo" is '額度編號';
comment on column "FacMain"."LastBormNo" is '已撥款序號';
comment on column "FacMain"."LastBormRvNo" is '已預約序號';
comment on column "FacMain"."ApplNo" is '核准號碼';
comment on column "FacMain"."CreditSysNo" is '案件編號';
comment on column "FacMain"."ProdNo" is '商品代碼';
comment on column "FacMain"."BaseRateCode" is '指標利率代碼';
comment on column "FacMain"."RateIncr" is '加碼利率';
comment on column "FacMain"."IndividualIncr" is '個別加碼';
comment on column "FacMain"."ApproveRate" is '核准利率';
comment on column "FacMain"."AnnualIncr" is '年繳比重優惠加減碼';
comment on column "FacMain"."EmailIncr" is '提供EMAIL優惠減碼';
comment on column "FacMain"."GraceIncr" is '寬限逾一年利率加碼';
comment on column "FacMain"."RateCode" is '利率區分';
comment on column "FacMain"."FirstRateAdjFreq" is '首次利率調整週期(月)';
comment on column "FacMain"."RateAdjFreq" is '利率調整週期(月)';
comment on column "FacMain"."CurrencyCode" is '核准幣別';
comment on column "FacMain"."LineAmt" is '核准額度';
comment on column "FacMain"."UtilAmt" is '貸出金額(放款餘額)';
comment on column "FacMain"."UtilBal" is '已動用額度餘額';
comment on column "FacMain"."AcctCode" is '核准科目';
comment on column "FacMain"."LoanTermYy" is '貸款期間年';
comment on column "FacMain"."LoanTermMm" is '貸款期間月';
comment on column "FacMain"."LoanTermDd" is '貸款期間日';
comment on column "FacMain"."FirstDrawdownDate" is '初貸日';
comment on column "FacMain"."MaturityDate" is '到期日';
comment on column "FacMain"."IntCalcCode" is '計息方式';
comment on column "FacMain"."AmortizedCode" is '攤還方式';
comment on column "FacMain"."FreqBase" is '週期基準';
comment on column "FacMain"."PayIntFreq" is '繳息週期';
comment on column "FacMain"."RepayFreq" is '還本週期';
comment on column "FacMain"."UtilDeadline" is '動支期限';
comment on column "FacMain"."GracePeriod" is '寬限總月數';
comment on column "FacMain"."AcctFee" is '帳管費';
comment on column "FacMain"."HandlingFee" is '手續費';
comment on column "FacMain"."RuleCode" is '規定管制代碼';
comment on column "FacMain"."ExtraRepayCode" is '攤還額異動碼';
comment on column "FacMain"."CustTypeCode" is '客戶別';
comment on column "FacMain"."RecycleCode" is '循環動用';
comment on column "FacMain"."RecycleDeadline" is '循環動用期限';
comment on column "FacMain"."UsageCode" is '資金用途別';
comment on column "FacMain"."DepartmentCode" is '案件隸屬單位';
comment on column "FacMain"."IncomeTaxFlag" is '代繳所得稅';
comment on column "FacMain"."CompensateFlag" is '代償碼';
comment on column "FacMain"."IrrevocableFlag" is '不可撤銷';
comment on column "FacMain"."RateAdjNoticeCode" is '利率調整通知';
comment on column "FacMain"."PieceCode" is '計件代碼';
comment on column "FacMain"."RepayCode" is '繳款方式';
comment on column "FacMain"."Introducer" is '介紹人';
comment on column "FacMain"."District" is '區部';
comment on column "FacMain"."FireOfficer" is '火險服務';
comment on column "FacMain"."Estimate" is '估價';
comment on column "FacMain"."CreditOfficer" is '授信';
comment on column "FacMain"."LoanOfficer" is '放款業務專員';
comment on column "FacMain"."BusinessOfficer" is '放款專員/房貸專員/企金人員';
comment on column "FacMain"."Supervisor" is '核決主管';
comment on column "FacMain"."InvestigateOfficer" is '徵信';
comment on column "FacMain"."EstimateReview" is '估價覆核';
comment on column "FacMain"."Coorgnizer" is '協辦人';
comment on column "FacMain"."AdvanceCloseCode" is '提前清償原因';
comment on column "FacMain"."ProdBreachFlag" is '違約適用方式是否按商品設定';
comment on column "FacMain"."BreachDescription" is '違約適用說明';
comment on column "FacMain"."CreditScore" is '信用評分';
comment on column "FacMain"."GuaranteeDate" is '對保日期';
comment on column "FacMain"."ContractNo" is '合約編號';
comment on column "FacMain"."ColSetFlag" is '擔保品設定記號';
comment on column "FacMain"."ActFg" is '交易進行記號';
comment on column "FacMain"."LastAcctDate" is '上次交易日';
comment on column "FacMain"."LastKinbr" is '上次交易行別';
comment on column "FacMain"."LastTlrNo" is '上次櫃員編號';
comment on column "FacMain"."LastTxtNo" is '上次交易序號';
comment on column "FacMain"."AcDate" is '會計日期';
comment on column "FacMain"."L9110Flag" is '是否已列印[撥款審核資料表]';
comment on column "FacMain"."BranchNo" is '單位別';
comment on column "FacMain"."ApprovedLevel" is '核准層級';
comment on column "FacMain"."CreateDate" is '建檔日期時間';
comment on column "FacMain"."CreateEmpNo" is '建檔人員';
comment on column "FacMain"."LastUpdate" is '最後更新日期時間';
comment on column "FacMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacProd" purge;

create table "FacProd" (
  "ProdNo" varchar2(5),
  "ProdName" nvarchar2(60),
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "AgreementFg" varchar2(1),
  "EnterpriseFg" varchar2(1),
  "CurrencyCode" varchar2(3),
  "BaseRateCode" varchar2(2),
  "ProdIncr" decimal(6, 4) default 0 not null,
  "LowLimitRate" decimal(6, 4) default 0 not null,
  "IncrFlag" varchar2(1),
  "RateCode" varchar2(1),
  "GovOfferFlag" varchar2(1),
  "FinancialFlag" varchar2(1),
  "EmpFlag" varchar2(1),
  "BreachFlag" varchar2(1),
  "BreachCode" varchar2(3),
  "BreachGetCode" varchar2(1),
  "ProhibitMonth" decimal(3, 0) default 0 not null,
  "BreachPercent" decimal(5, 2) default 0 not null,
  "BreachDecreaseMonth" decimal(3, 0) default 0 not null,
  "BreachDecrease" decimal(5, 2) default 0 not null,
  "BreachStartPercent" decimal(3, 0) default 0 not null,
  "IfrsStepProdCode" varchar2(1),
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProd" add constraint "FacProd_PK" primary key("ProdNo");

comment on table "FacProd" is '商品參數主檔';
comment on column "FacProd"."ProdNo" is '商品代碼';
comment on column "FacProd"."ProdName" is '商品名稱';
comment on column "FacProd"."StartDate" is '商品生效日期';
comment on column "FacProd"."EndDate" is '商品截止日期';
comment on column "FacProd"."StatusCode" is '商品狀態';
comment on column "FacProd"."AgreementFg" is '是否為協議商品';
comment on column "FacProd"."EnterpriseFg" is '企金可使用記號';
comment on column "FacProd"."CurrencyCode" is '幣別';
comment on column "FacProd"."BaseRateCode" is '指標利率代碼';
comment on column "FacProd"."ProdIncr" is '商品加碼利率';
comment on column "FacProd"."LowLimitRate" is '利率下限';
comment on column "FacProd"."IncrFlag" is '加減碼是否依合約';
comment on column "FacProd"."RateCode" is '利率區分';
comment on column "FacProd"."GovOfferFlag" is '政府優惠房貸';
comment on column "FacProd"."FinancialFlag" is '理財型房貸';
comment on column "FacProd"."EmpFlag" is '員工優惠貸款';
comment on column "FacProd"."BreachFlag" is '是否限制清償';
comment on column "FacProd"."BreachCode" is '違約適用方式';
comment on column "FacProd"."BreachGetCode" is '違約金收取方式';
comment on column "FacProd"."ProhibitMonth" is '限制清償期限';
comment on column "FacProd"."BreachPercent" is '違約金百分比';
comment on column "FacProd"."BreachDecreaseMonth" is '違約金分段月數';
comment on column "FacProd"."BreachDecrease" is '分段遞減百分比';
comment on column "FacProd"."BreachStartPercent" is '還款起算比例%';
comment on column "FacProd"."IfrsStepProdCode" is 'IFRS階梯商品別';
comment on column "FacProd"."IfrsProdCode" is 'IFRS產品別';
comment on column "FacProd"."CreateDate" is '建檔日期時間';
comment on column "FacProd"."CreateEmpNo" is '建檔人員';
comment on column "FacProd"."LastUpdate" is '最後更新日期時間';
comment on column "FacProd"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacProdAcctFee" purge;

create table "FacProdAcctFee" (
  "ProdNo" varchar2(9),
  "FeeType" varchar2(1),
  "LoanLow" decimal(16, 2) default 0 not null,
  "LoanHigh" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProdAcctFee" add constraint "FacProdAcctFee_PK" primary key("ProdNo", "FeeType", "LoanLow");

alter table "FacProdAcctFee" add constraint "FacProdAcctFee_FacProd_FK1" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

comment on table "FacProdAcctFee" is '商品參數副檔帳管費';
comment on column "FacProdAcctFee"."ProdNo" is '商品代碼';
comment on column "FacProdAcctFee"."FeeType" is '費用類別';
comment on column "FacProdAcctFee"."LoanLow" is '貸款金額(含)以上';
comment on column "FacProdAcctFee"."LoanHigh" is '貸款金額(含)以下';
comment on column "FacProdAcctFee"."AcctFee" is '帳管費';
comment on column "FacProdAcctFee"."CreateDate" is '建檔日期時間';
comment on column "FacProdAcctFee"."CreateEmpNo" is '建檔人員';
comment on column "FacProdAcctFee"."LastUpdate" is '最後更新日期時間';
comment on column "FacProdAcctFee"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacProdPremium" purge;

create table "FacProdPremium" (
  "ProdNo" varchar2(5),
  "PremiumLow" decimal(16, 2) default 0 not null,
  "PremiumHigh" decimal(16, 2) default 0 not null,
  "PremiumIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProdPremium" add constraint "FacProdPremium_PK" primary key("ProdNo", "PremiumLow");

alter table "FacProdPremium" add constraint "FacProdPremium_FacProd_FK1" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

comment on table "FacProdPremium" is '商品參數副檔年繳保費優惠減碼';
comment on column "FacProdPremium"."ProdNo" is '商品代碼';
comment on column "FacProdPremium"."PremiumLow" is '保戶壽險年繳化保費(含)以上';
comment on column "FacProdPremium"."PremiumHigh" is '保戶壽險年繳化保費(含)以下';
comment on column "FacProdPremium"."PremiumIncr" is '優惠減碼';
comment on column "FacProdPremium"."CreateDate" is '建檔日期時間';
comment on column "FacProdPremium"."CreateEmpNo" is '建檔人員';
comment on column "FacProdPremium"."LastUpdate" is '最後更新日期時間';
comment on column "FacProdPremium"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacProdStepRate" purge;

create table "FacProdStepRate" (
  "ProdNo" varchar2(10),
  "MonthStart" decimal(3, 0) default 0 not null,
  "MonthEnd" decimal(3, 0) default 0 not null,
  "RateType" varchar2(1),
  "RateIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProdStepRate" add constraint "FacProdStepRate_PK" primary key("ProdNo", "MonthStart");

comment on table "FacProdStepRate" is '商品參數副檔階梯式利率';
comment on column "FacProdStepRate"."ProdNo" is '商品代碼或戶號+額度編號';
comment on column "FacProdStepRate"."MonthStart" is '月數(含)以上';
comment on column "FacProdStepRate"."MonthEnd" is '月數(含)以下';
comment on column "FacProdStepRate"."RateType" is '利率型態';
comment on column "FacProdStepRate"."RateIncr" is '加碼利率';
comment on column "FacProdStepRate"."CreateDate" is '建檔日期時間';
comment on column "FacProdStepRate"."CreateEmpNo" is '建檔人員';
comment on column "FacProdStepRate"."LastUpdate" is '最後更新日期時間';
comment on column "FacProdStepRate"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacRelation" purge;

create table "FacRelation" (
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "FacRelationCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacRelation" add constraint "FacRelation_PK" primary key("CreditSysNo", "CustUKey");

comment on table "FacRelation" is '交易關係人檔';
comment on column "FacRelation"."CreditSysNo" is '案件編號';
comment on column "FacRelation"."CustUKey" is '客戶識別碼';
comment on column "FacRelation"."FacRelationCode" is '掃描類別';
comment on column "FacRelation"."CreateDate" is '建檔日期時間';
comment on column "FacRelation"."CreateEmpNo" is '建檔人員';
comment on column "FacRelation"."LastUpdate" is '最後更新日期時間';
comment on column "FacRelation"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacShareAppl" purge;

create table "FacShareAppl" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "MainApplNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(3, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "KeyinSeq" decimal(2, 0) default 0 not null,
  "JcicMergeFlag" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacShareAppl" add constraint "FacShareAppl_PK" primary key("ApplNo");

comment on table "FacShareAppl" is '共同借款人資料檔';
comment on column "FacShareAppl"."ApplNo" is '核准號碼';
comment on column "FacShareAppl"."MainApplNo" is '主核准號碼(登錄順序=1)';
comment on column "FacShareAppl"."CustNo" is '戶號';
comment on column "FacShareAppl"."FacmNo" is '額度';
comment on column "FacShareAppl"."KeyinSeq" is '登錄順序(由1起編)';
comment on column "FacShareAppl"."JcicMergeFlag" is '是否合併申報(Y/N)';
comment on column "FacShareAppl"."CreateDate" is '建檔日期時間';
comment on column "FacShareAppl"."CreateEmpNo" is '建檔人員';
comment on column "FacShareAppl"."LastUpdate" is '最後更新日期時間';
comment on column "FacShareAppl"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacShareLimit" purge;

create table "FacShareLimit" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "MainApplNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(3, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "KeyinSeq" decimal(2, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "LineAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacShareLimit" add constraint "FacShareLimit_PK" primary key("ApplNo");

comment on table "FacShareLimit" is '合併額度控管資料檔';
comment on column "FacShareLimit"."ApplNo" is '核准號碼';
comment on column "FacShareLimit"."MainApplNo" is '主核准號碼(登錄順序=1)';
comment on column "FacShareLimit"."CustNo" is '戶號';
comment on column "FacShareLimit"."FacmNo" is '額度';
comment on column "FacShareLimit"."KeyinSeq" is '登錄順序(由1起編)';
comment on column "FacShareLimit"."CurrencyCode" is '幣別';
comment on column "FacShareLimit"."LineAmt" is '總額度';
comment on column "FacShareLimit"."CreateDate" is '建檔日期時間';
comment on column "FacShareLimit"."CreateEmpNo" is '建檔人員';
comment on column "FacShareLimit"."LastUpdate" is '最後更新日期時間';
comment on column "FacShareLimit"."LastUpdateEmpNo" is '最後更新人員';
drop table "FacShareRelation" purge;

create table "FacShareRelation" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "RelApplNo" decimal(7, 0) default 0 not null,
  "RelCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacShareRelation" add constraint "FacShareRelation_PK" primary key("ApplNo", "RelApplNo");

comment on table "FacShareRelation" is '共同借款人闗係檔';
comment on column "FacShareRelation"."ApplNo" is '核准號碼';
comment on column "FacShareRelation"."RelApplNo" is '共同借款人核准號碼';
comment on column "FacShareRelation"."RelCode" is '與共同借款人關係';
comment on column "FacShareRelation"."CreateDate" is '建檔日期時間';
comment on column "FacShareRelation"."CreateEmpNo" is '建檔人員';
comment on column "FacShareRelation"."LastUpdate" is '最後更新日期時間';
comment on column "FacShareRelation"."LastUpdateEmpNo" is '最後更新人員';
drop table "FinReportCashFlow" purge;

create table "FinReportCashFlow" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "BusCash" decimal(18, 0) default 0 not null,
  "InvestCash" decimal(18, 0) default 0 not null,
  "FinCash" decimal(18, 0) default 0 not null,
  "AccountItem01" nvarchar2(20),
  "AccountItem02" nvarchar2(20),
  "AccountValue01" decimal(18, 0) default 0 not null,
  "AccountValue02" decimal(18, 0) default 0 not null,
  "EndCash" decimal(18, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FinReportCashFlow" add constraint "FinReportCashFlow_PK" primary key("CustUKey", "UKey");

comment on table "FinReportCashFlow" is '客戶財務報表.現金流量表';
comment on column "FinReportCashFlow"."CustUKey" is '客戶識別碼';
comment on column "FinReportCashFlow"."UKey" is '識別碼';
comment on column "FinReportCashFlow"."BusCash" is '營業活動淨現金流入(出)';
comment on column "FinReportCashFlow"."InvestCash" is '投資活動淨現金流入(出)';
comment on column "FinReportCashFlow"."FinCash" is '理財活動淨現金流入(出)';
comment on column "FinReportCashFlow"."AccountItem01" is '會計科目01';
comment on column "FinReportCashFlow"."AccountItem02" is '會計科目02';
comment on column "FinReportCashFlow"."AccountValue01" is '會計科目值01';
comment on column "FinReportCashFlow"."AccountValue02" is '會計科目值02';
comment on column "FinReportCashFlow"."EndCash" is '期末現金餘額';
comment on column "FinReportCashFlow"."CreateDate" is '建檔日期時間';
comment on column "FinReportCashFlow"."CreateEmpNo" is '建檔人員';
comment on column "FinReportCashFlow"."LastUpdate" is '最後更新日期時間';
comment on column "FinReportCashFlow"."LastUpdateEmpNo" is '最後更新人員';
drop table "FinReportDebt" purge;

create table "FinReportDebt" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "StartYY" decimal(4, 0) default 0 not null,
  "StartMM" decimal(2, 0) default 0 not null,
  "EndYY" decimal(4, 0) default 0 not null,
  "EndMM" decimal(2, 0) default 0 not null,
  "AssetTotal" decimal(18, 0) default 0 not null,
  "FlowAsset" decimal(18, 0) default 0 not null,
  "Cash" decimal(18, 0) default 0 not null,
  "FinAsset" decimal(18, 0) default 0 not null,
  "ReceiveTicket" decimal(18, 0) default 0 not null,
  "ReceiveAccount" decimal(18, 0) default 0 not null,
  "ReceiveRelation" decimal(18, 0) default 0 not null,
  "OtherReceive" decimal(18, 0) default 0 not null,
  "Stock" decimal(18, 0) default 0 not null,
  "PrepayItem" decimal(18, 0) default 0 not null,
  "OtherFlowAsset" decimal(18, 0) default 0 not null,
  "AccountItem01" nvarchar2(20),
  "AccountItem02" nvarchar2(20),
  "AccountItem03" nvarchar2(20),
  "AccountValue01" decimal(18, 0) default 0 not null,
  "AccountValue02" decimal(18, 0) default 0 not null,
  "AccountValue03" decimal(18, 0) default 0 not null,
  "LongInvest" decimal(18, 0) default 0 not null,
  "FixedAsset" decimal(18, 0) default 0 not null,
  "Land" decimal(18, 0) default 0 not null,
  "HouseBuild" decimal(18, 0) default 0 not null,
  "MachineEquip" decimal(18, 0) default 0 not null,
  "OtherEquip" decimal(18, 0) default 0 not null,
  "PrepayEquip" decimal(18, 0) default 0 not null,
  "UnFinish" decimal(18, 0) default 0 not null,
  "Depreciation" decimal(18, 0) default 0 not null,
  "InvisibleAsset" decimal(18, 0) default 0 not null,
  "OtherAsset" decimal(18, 0) default 0 not null,
  "AccountItem04" nvarchar2(20),
  "AccountItem05" nvarchar2(20),
  "AccountItem06" nvarchar2(20),
  "AccountValue04" decimal(18, 0) default 0 not null,
  "AccountValue05" decimal(18, 0) default 0 not null,
  "AccountValue06" decimal(18, 0) default 0 not null,
  "DebtNetTotal" decimal(18, 0) default 0 not null,
  "FlowDebt" decimal(18, 0) default 0 not null,
  "ShortLoan" decimal(18, 0) default 0 not null,
  "PayShortTicket" decimal(18, 0) default 0 not null,
  "PayTicket" decimal(18, 0) default 0 not null,
  "PayAccount" decimal(18, 0) default 0 not null,
  "PayRelation" decimal(18, 0) default 0 not null,
  "OtherPay" decimal(18, 0) default 0 not null,
  "PreReceiveItem" decimal(18, 0) default 0 not null,
  "LongDebtOneYear" decimal(18, 0) default 0 not null,
  "Shareholder" decimal(18, 0) default 0 not null,
  "OtherFlowDebt" decimal(18, 0) default 0 not null,
  "AccountItem07" nvarchar2(20),
  "AccountItem08" nvarchar2(20),
  "AccountItem09" nvarchar2(20),
  "AccountValue07" decimal(18, 0) default 0 not null,
  "AccountValue08" decimal(18, 0) default 0 not null,
  "AccountValue09" decimal(18, 0) default 0 not null,
  "LongDebt" decimal(18, 0) default 0 not null,
  "OtherDebt" decimal(18, 0) default 0 not null,
  "DebtTotal" decimal(18, 0) default 0 not null,
  "NetValue" decimal(18, 0) default 0 not null,
  "Capital" decimal(18, 0) default 0 not null,
  "CapitalSurplus" decimal(18, 0) default 0 not null,
  "RetainProfit" decimal(18, 0) default 0 not null,
  "OtherRight" decimal(18, 0) default 0 not null,
  "TreasuryStock" decimal(18, 0) default 0 not null,
  "UnControlRight" decimal(18, 0) default 0 not null,
  "AccountItem10" nvarchar2(20),
  "AccountItem11" nvarchar2(20),
  "AccountValue10" decimal(18, 0) default 0 not null,
  "AccountValue11" decimal(18, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FinReportDebt" add constraint "FinReportDebt_PK" primary key("CustUKey", "UKey");

comment on table "FinReportDebt" is '客戶財務報表.資產負債表';
comment on column "FinReportDebt"."CustUKey" is '客戶識別碼';
comment on column "FinReportDebt"."UKey" is '識別碼';
comment on column "FinReportDebt"."StartYY" is '年度';
comment on column "FinReportDebt"."StartMM" is '年度_起月';
comment on column "FinReportDebt"."EndYY" is '年度_迄年';
comment on column "FinReportDebt"."EndMM" is '年度_迄月';
comment on column "FinReportDebt"."AssetTotal" is '資產總額';
comment on column "FinReportDebt"."FlowAsset" is '流動資產';
comment on column "FinReportDebt"."Cash" is '現金及約當現金';
comment on column "FinReportDebt"."FinAsset" is '金融資產(含其他)-流動';
comment on column "FinReportDebt"."ReceiveTicket" is '應收票據(淨額)';
comment on column "FinReportDebt"."ReceiveAccount" is '應收帳款(淨額)';
comment on column "FinReportDebt"."ReceiveRelation" is '應收關係人款';
comment on column "FinReportDebt"."OtherReceive" is '其他應收款';
comment on column "FinReportDebt"."Stock" is '存貨';
comment on column "FinReportDebt"."PrepayItem" is '預付款項';
comment on column "FinReportDebt"."OtherFlowAsset" is '其他流動資產';
comment on column "FinReportDebt"."AccountItem01" is '流動資產_會計科目01';
comment on column "FinReportDebt"."AccountItem02" is '流動資產_會計科目02';
comment on column "FinReportDebt"."AccountItem03" is '流動資產_會計科目03';
comment on column "FinReportDebt"."AccountValue01" is '流動資產_會計科目值01';
comment on column "FinReportDebt"."AccountValue02" is '流動資產_會計科目值02';
comment on column "FinReportDebt"."AccountValue03" is '流動資產_會計科目值03';
comment on column "FinReportDebt"."LongInvest" is '基金及長期投資';
comment on column "FinReportDebt"."FixedAsset" is '固定資產';
comment on column "FinReportDebt"."Land" is '土地';
comment on column "FinReportDebt"."HouseBuild" is '房屋及建築';
comment on column "FinReportDebt"."MachineEquip" is '機器設備';
comment on column "FinReportDebt"."OtherEquip" is '運輸、辦公、其他設備';
comment on column "FinReportDebt"."PrepayEquip" is '預付設備款';
comment on column "FinReportDebt"."UnFinish" is '未完成工程';
comment on column "FinReportDebt"."Depreciation" is '減︰累計折舊';
comment on column "FinReportDebt"."InvisibleAsset" is '無形資產';
comment on column "FinReportDebt"."OtherAsset" is '其他資產';
comment on column "FinReportDebt"."AccountItem04" is '其他資產_會計科目04';
comment on column "FinReportDebt"."AccountItem05" is '其他資產_會計科目05';
comment on column "FinReportDebt"."AccountItem06" is '其他資產_會計科目06';
comment on column "FinReportDebt"."AccountValue04" is '其他資產_會計科目值04';
comment on column "FinReportDebt"."AccountValue05" is '其他資產_會計科目值05';
comment on column "FinReportDebt"."AccountValue06" is '其他資產_會計科目值06';
comment on column "FinReportDebt"."DebtNetTotal" is '負債及淨值總額';
comment on column "FinReportDebt"."FlowDebt" is '流動負債';
comment on column "FinReportDebt"."ShortLoan" is '短期借款';
comment on column "FinReportDebt"."PayShortTicket" is '應付短期票券';
comment on column "FinReportDebt"."PayTicket" is '應付票據(淨額)';
comment on column "FinReportDebt"."PayAccount" is '應付帳款(淨額)';
comment on column "FinReportDebt"."PayRelation" is '應付關係人款';
comment on column "FinReportDebt"."OtherPay" is '其他應付款';
comment on column "FinReportDebt"."PreReceiveItem" is '預收款項';
comment on column "FinReportDebt"."LongDebtOneYear" is '長期負債(一年內)';
comment on column "FinReportDebt"."Shareholder" is '股東墊款';
comment on column "FinReportDebt"."OtherFlowDebt" is '其他流動負債';
comment on column "FinReportDebt"."AccountItem07" is '流動負債 _會計科目07';
comment on column "FinReportDebt"."AccountItem08" is '流動負債 _會計科目08';
comment on column "FinReportDebt"."AccountItem09" is '流動負債 _會計科目09';
comment on column "FinReportDebt"."AccountValue07" is '流動負債 _會計科目值07';
comment on column "FinReportDebt"."AccountValue08" is '流動負債 _會計科目值08';
comment on column "FinReportDebt"."AccountValue09" is '流動負債 _會計科目值09';
comment on column "FinReportDebt"."LongDebt" is '長期負債';
comment on column "FinReportDebt"."OtherDebt" is '其它負債';
comment on column "FinReportDebt"."DebtTotal" is '負債總額';
comment on column "FinReportDebt"."NetValue" is '淨值';
comment on column "FinReportDebt"."Capital" is '資本';
comment on column "FinReportDebt"."CapitalSurplus" is '資本公積';
comment on column "FinReportDebt"."RetainProfit" is '保留盈餘';
comment on column "FinReportDebt"."OtherRight" is '其他權益';
comment on column "FinReportDebt"."TreasuryStock" is '庫藏股票';
comment on column "FinReportDebt"."UnControlRight" is '非控制權益';
comment on column "FinReportDebt"."AccountItem10" is '淨值_會計科目10';
comment on column "FinReportDebt"."AccountItem11" is '淨值_會計科目11';
comment on column "FinReportDebt"."AccountValue10" is '淨值_會計科目值10';
comment on column "FinReportDebt"."AccountValue11" is '淨值_會計科目值11';
comment on column "FinReportDebt"."CreateDate" is '建檔日期時間';
comment on column "FinReportDebt"."CreateEmpNo" is '建檔人員';
comment on column "FinReportDebt"."LastUpdate" is '最後更新日期時間';
comment on column "FinReportDebt"."LastUpdateEmpNo" is '最後更新人員';
drop table "FinReportProfit" purge;

create table "FinReportProfit" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "BusIncome" decimal(18, 0) default 0 not null,
  "GrowRate" decimal(18, 2) default 0 not null,
  "BusCost" decimal(18, 0) default 0 not null,
  "BusGrossProfit" decimal(18, 0) default 0 not null,
  "ManageFee" decimal(18, 0) default 0 not null,
  "BusLossProfit" decimal(18, 0) default 0 not null,
  "BusOtherIncome" decimal(18, 0) default 0 not null,
  "Interest" decimal(18, 0) default 0 not null,
  "BusOtherFee" decimal(18, 0) default 0 not null,
  "BeforeTaxNet" decimal(18, 0) default 0 not null,
  "BusTax" decimal(18, 0) default 0 not null,
  "HomeLossProfit" decimal(18, 0) default 0 not null,
  "OtherComLossProfit" decimal(18, 0) default 0 not null,
  "HomeComLossProfit" decimal(18, 0) default 0 not null,
  "UncontrolRight" decimal(18, 0) default 0 not null,
  "ParentCompanyRight" decimal(18, 0) default 0 not null,
  "EPS" decimal(18, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FinReportProfit" add constraint "FinReportProfit_PK" primary key("CustUKey", "UKey");

comment on table "FinReportProfit" is '客戶財務報表.損益表';
comment on column "FinReportProfit"."CustUKey" is '客戶識別碼';
comment on column "FinReportProfit"."UKey" is '識別碼';
comment on column "FinReportProfit"."BusIncome" is '營業收入';
comment on column "FinReportProfit"."GrowRate" is '較去年同期營收成長率';
comment on column "FinReportProfit"."BusCost" is '減︰營業成本';
comment on column "FinReportProfit"."BusGrossProfit" is '營業毛利';
comment on column "FinReportProfit"."ManageFee" is '減:管銷費用';
comment on column "FinReportProfit"."BusLossProfit" is '營業損益';
comment on column "FinReportProfit"."BusOtherIncome" is '加︰營業外收入';
comment on column "FinReportProfit"."Interest" is '減︰利息支出';
comment on column "FinReportProfit"."BusOtherFee" is '營業外費用';
comment on column "FinReportProfit"."BeforeTaxNet" is '稅前淨利';
comment on column "FinReportProfit"."BusTax" is '減︰營利事業所得稅';
comment on column "FinReportProfit"."HomeLossProfit" is '本期損益';
comment on column "FinReportProfit"."OtherComLossProfit" is '其他綜合損益';
comment on column "FinReportProfit"."HomeComLossProfit" is '本期綜合損益總額';
comment on column "FinReportProfit"."UncontrolRight" is '非控制權益';
comment on column "FinReportProfit"."ParentCompanyRight" is '歸屬於母公司之權益';
comment on column "FinReportProfit"."EPS" is '每股盈餘EPS(元)';
comment on column "FinReportProfit"."CreateDate" is '建檔日期時間';
comment on column "FinReportProfit"."CreateEmpNo" is '建檔人員';
comment on column "FinReportProfit"."LastUpdate" is '最後更新日期時間';
comment on column "FinReportProfit"."LastUpdateEmpNo" is '最後更新人員';
drop table "FinReportQuality" purge;

create table "FinReportQuality" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "ReportType" varchar2(1),
  "Opinion" varchar2(1),
  "IsCheck" varchar2(1),
  "IsChange" varchar2(1),
  "OfficeType" varchar2(1),
  "PunishRecord" varchar2(1),
  "ChangeReason" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FinReportQuality" add constraint "FinReportQuality_PK" primary key("CustUKey", "UKey");

comment on table "FinReportQuality" is '客戶財務報表.財報品質';
comment on column "FinReportQuality"."CustUKey" is '客戶識別碼';
comment on column "FinReportQuality"."UKey" is '識別碼';
comment on column "FinReportQuality"."ReportType" is '年度財務報表類型';
comment on column "FinReportQuality"."Opinion" is '會計師查核意見';
comment on column "FinReportQuality"."IsCheck" is '是否經會計師查核';
comment on column "FinReportQuality"."IsChange" is '近兩年是否曾換會計師';
comment on column "FinReportQuality"."OfficeType" is '會計師事務所類型';
comment on column "FinReportQuality"."PunishRecord" is '會計師懲戒紀錄';
comment on column "FinReportQuality"."ChangeReason" is '更換會計師原因';
comment on column "FinReportQuality"."CreateDate" is '建檔日期時間';
comment on column "FinReportQuality"."CreateEmpNo" is '建檔人員';
comment on column "FinReportQuality"."LastUpdate" is '最後更新日期時間';
comment on column "FinReportQuality"."LastUpdateEmpNo" is '最後更新人員';
drop table "FinReportRate" purge;

create table "FinReportRate" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "IsSameTrade" varchar2(1),
  "TradeType" varchar2(20),
  "Flow" decimal(18, 4) default 0 not null,
  "Speed" decimal(18, 4) default 0 not null,
  "RateGuar" decimal(18, 4) default 0 not null,
  "Debt" decimal(18, 4) default 0 not null,
  "Net" decimal(18, 4) default 0 not null,
  "CashFlow" decimal(18, 4) default 0 not null,
  "FixLong" decimal(18, 4) default 0 not null,
  "FinSpend" decimal(18, 4) default 0 not null,
  "GrossProfit" decimal(18, 4) default 0 not null,
  "AfterTaxNet" decimal(18, 4) default 0 not null,
  "NetReward" decimal(18, 4) default 0 not null,
  "TotalAssetReward" decimal(18, 4) default 0 not null,
  "Stock" decimal(18, 4) default 0 not null,
  "ReceiveAccount" decimal(18, 4) default 0 not null,
  "TotalAsset" decimal(18, 4) default 0 not null,
  "PayAccount" decimal(18, 4) default 0 not null,
  "AveTotalAsset" decimal(18, 4) default 0 not null,
  "AveNetBusCycle" decimal(18, 4) default 0 not null,
  "FinLever" decimal(18, 4) default 0 not null,
  "LoanDebtNet" decimal(18, 4) default 0 not null,
  "BusRate" decimal(18, 4) default 0 not null,
  "PayFinLever" decimal(18, 4) default 0 not null,
  "ADE" decimal(18, 4) default 0 not null,
  "CashGuar" decimal(18, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FinReportRate" add constraint "FinReportRate_PK" primary key("CustUKey", "UKey");

comment on table "FinReportRate" is '客戶財務報表.財務比率表';
comment on column "FinReportRate"."CustUKey" is '客戶識別碼';
comment on column "FinReportRate"."UKey" is '識別碼';
comment on column "FinReportRate"."IsSameTrade" is '是否為同業值';
comment on column "FinReportRate"."TradeType" is '行業別';
comment on column "FinReportRate"."Flow" is '流動比率';
comment on column "FinReportRate"."Speed" is '速動比率';
comment on column "FinReportRate"."RateGuar" is '利息保障倍數';
comment on column "FinReportRate"."Debt" is '負債比率';
comment on column "FinReportRate"."Net" is '淨值比率';
comment on column "FinReportRate"."CashFlow" is '現金流量比率';
comment on column "FinReportRate"."FixLong" is '固定長期適合率';
comment on column "FinReportRate"."FinSpend" is '財務支出率';
comment on column "FinReportRate"."GrossProfit" is '毛利率';
comment on column "FinReportRate"."AfterTaxNet" is '稅後淨利率';
comment on column "FinReportRate"."NetReward" is '淨值報酬率';
comment on column "FinReportRate"."TotalAssetReward" is '總資產報酬率';
comment on column "FinReportRate"."Stock" is '存貨週轉率';
comment on column "FinReportRate"."ReceiveAccount" is '應收帳款週轉率';
comment on column "FinReportRate"."TotalAsset" is '總資產週轉率';
comment on column "FinReportRate"."PayAccount" is '應付帳款週轉率';
comment on column "FinReportRate"."AveTotalAsset" is '平均總資產週轉率：營業收入/((上期總資產+本期總資產)/2)';
comment on column "FinReportRate"."AveNetBusCycle" is '平均淨營業週期：平均存貨週轉天數+平均應收帳款及應收票據週轉天數-平均應付帳款及應付票據週轉天數';
comment on column "FinReportRate"."FinLever" is '財務結構-財務槓桿：總負債/淨值';
comment on column "FinReportRate"."LoanDebtNet" is '長期負債對淨值比：長期負債/淨值';
comment on column "FinReportRate"."BusRate" is '營授比率：總借款/營收';
comment on column "FinReportRate"."PayFinLever" is '償債能力-財務槓桿度：營業利益/(營業利益-利息支出)';
comment on column "FinReportRate"."ADE" is '借款依存度(ADE)：(短期借款+應付短期票券+股東墊款+長期負債+一年內到期之長期負債)/淨值合計';
comment on column "FinReportRate"."CashGuar" is '現金保障倍數：營業活動現金流量/利息支出';
comment on column "FinReportRate"."CreateDate" is '建檔日期時間';
comment on column "FinReportRate"."CreateEmpNo" is '建檔人員';
comment on column "FinReportRate"."LastUpdate" is '最後更新日期時間';
comment on column "FinReportRate"."LastUpdateEmpNo" is '最後更新人員';
drop table "FinReportReview" purge;

create table "FinReportReview" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "CurrentAsset" decimal(18, 0) default 0 not null,
  "TotalAsset" decimal(18, 0) default 0 not null,
  "PropertyAsset" decimal(18, 0) default 0 not null,
  "Investment" decimal(18, 0) default 0 not null,
  "InvestmentProperty" decimal(18, 0) default 0 not null,
  "Depreciation" decimal(18, 0) default 0 not null,
  "CurrentDebt" decimal(18, 0) default 0 not null,
  "TotalDebt" decimal(18, 0) default 0 not null,
  "TotalEquity" decimal(18, 0) default 0 not null,
  "BondsPayable" decimal(18, 0) default 0 not null,
  "LongTermBorrowings" decimal(18, 0) default 0 not null,
  "NonCurrentLease" decimal(18, 0) default 0 not null,
  "LongTermPayable" decimal(18, 0) default 0 not null,
  "Preference" decimal(18, 0) default 0 not null,
  "OperatingRevenue" decimal(18, 0) default 0 not null,
  "InterestExpense" decimal(18, 0) default 0 not null,
  "ProfitBeforeTax" decimal(18, 0) default 0 not null,
  "ProfitAfterTax" decimal(18, 0) default 0 not null,
  "WorkingCapitalRatio" decimal(18, 4) default 0 not null,
  "InterestCoverageRatio1" decimal(18, 4) default 0 not null,
  "InterestCoverageRatio2" decimal(18, 4) default 0 not null,
  "LeverageRatio" decimal(18, 4) default 0 not null,
  "EquityRatio" decimal(18, 4) default 0 not null,
  "LongFitRatio" decimal(18, 4) default 0 not null,
  "NetProfitRatio" decimal(18, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FinReportReview" add constraint "FinReportReview_PK" primary key("CustUKey", "UKey");

comment on table "FinReportReview" is '客戶財務報表.覆審比率表';
comment on column "FinReportReview"."CustUKey" is '客戶識別碼';
comment on column "FinReportReview"."UKey" is '識別碼';
comment on column "FinReportReview"."CurrentAsset" is '流動資產';
comment on column "FinReportReview"."TotalAsset" is '資產總額';
comment on column "FinReportReview"."PropertyAsset" is '不動產、廠房及設備淨額';
comment on column "FinReportReview"."Investment" is '權益法之投資';
comment on column "FinReportReview"."InvestmentProperty" is '投資性不動產';
comment on column "FinReportReview"."Depreciation" is '折舊及攤銷';
comment on column "FinReportReview"."CurrentDebt" is '流動負債';
comment on column "FinReportReview"."TotalDebt" is '負債合計';
comment on column "FinReportReview"."TotalEquity" is '權益合計';
comment on column "FinReportReview"."BondsPayable" is '應付公司債';
comment on column "FinReportReview"."LongTermBorrowings" is '長期借款';
comment on column "FinReportReview"."NonCurrentLease" is '應付租賃款-非流動';
comment on column "FinReportReview"."LongTermPayable" is '長期應付票據及款項-關係人';
comment on column "FinReportReview"."Preference" is '特別股負債';
comment on column "FinReportReview"."OperatingRevenue" is '營業收入';
comment on column "FinReportReview"."InterestExpense" is '利息支出';
comment on column "FinReportReview"."ProfitBeforeTax" is '稅前淨利';
comment on column "FinReportReview"."ProfitAfterTax" is '本期淨利(稅後)';
comment on column "FinReportReview"."WorkingCapitalRatio" is '流動比率';
comment on column "FinReportReview"."InterestCoverageRatio1" is '利息保障倍數1';
comment on column "FinReportReview"."InterestCoverageRatio2" is '利息保障倍數2';
comment on column "FinReportReview"."LeverageRatio" is '槓桿比率';
comment on column "FinReportReview"."EquityRatio" is '權益比率';
comment on column "FinReportReview"."LongFitRatio" is '固定長期適合率';
comment on column "FinReportReview"."NetProfitRatio" is '純益率(稅後)';
comment on column "FinReportReview"."CreateDate" is '建檔日期時間';
comment on column "FinReportReview"."CreateEmpNo" is '建檔人員';
comment on column "FinReportReview"."LastUpdate" is '最後更新日期時間';
comment on column "FinReportReview"."LastUpdateEmpNo" is '最後更新人員';
drop table "ForeclosureFee" purge;

create table "ForeclosureFee" (
  "RecordNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "DocDate" decimal(8, 0) default 0 not null,
  "OpenAcDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "FeeCode" varchar2(2),
  "LegalStaff" varchar2(6),
  "CloseNo" decimal(7, 0) default 0 not null,
  "Rmk" nvarchar2(60),
  "CaseCode" decimal(1, 0) default 0 not null,
  "RemitBranch" varchar2(3),
  "Remitter" varchar2(10),
  "CaseNo" varchar2(3),
  "OverdueDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ForeclosureFee" add constraint "ForeclosureFee_PK" primary key("RecordNo");

create index "ForeclosureFee_Index1" on "ForeclosureFee"("CustNo" asc, "ReceiveDate" asc);

comment on table "ForeclosureFee" is '法拍費用檔';
comment on column "ForeclosureFee"."RecordNo" is '記錄號碼';
comment on column "ForeclosureFee"."CustNo" is '借款人戶號';
comment on column "ForeclosureFee"."FacmNo" is '額度編號';
comment on column "ForeclosureFee"."ReceiveDate" is '收件日期';
comment on column "ForeclosureFee"."DocDate" is '單據日期';
comment on column "ForeclosureFee"."OpenAcDate" is '起帳日期';
comment on column "ForeclosureFee"."CloseDate" is '銷號日期';
comment on column "ForeclosureFee"."Fee" is '法拍費用';
comment on column "ForeclosureFee"."FeeCode" is '科目';
comment on column "ForeclosureFee"."LegalStaff" is '法務人員';
comment on column "ForeclosureFee"."CloseNo" is '銷帳編號';
comment on column "ForeclosureFee"."Rmk" is '備註';
comment on column "ForeclosureFee"."CaseCode" is '件別';
comment on column "ForeclosureFee"."RemitBranch" is '匯款單位';
comment on column "ForeclosureFee"."Remitter" is '匯款人';
comment on column "ForeclosureFee"."CaseNo" is '案號';
comment on column "ForeclosureFee"."OverdueDate" is '轉催收日';
comment on column "ForeclosureFee"."CreateDate" is '建檔日期時間';
comment on column "ForeclosureFee"."CreateEmpNo" is '建檔人員';
comment on column "ForeclosureFee"."LastUpdate" is '最後更新日期時間';
comment on column "ForeclosureFee"."LastUpdateEmpNo" is '最後更新人員';
drop table "ForeclosureFinished" purge;

create table "ForeclosureFinished" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FinishedDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ForeclosureFinished" add constraint "ForeclosureFinished_PK" primary key("CustNo", "FacmNo");

comment on table "ForeclosureFinished" is '法拍完成資料檔';
comment on column "ForeclosureFinished"."CustNo" is '借款人戶號';
comment on column "ForeclosureFinished"."FacmNo" is '額度編號';
comment on column "ForeclosureFinished"."FinishedDate" is '完成日期';
comment on column "ForeclosureFinished"."CreateDate" is '建檔日期時間';
comment on column "ForeclosureFinished"."CreateEmpNo" is '建檔人員';
comment on column "ForeclosureFinished"."LastUpdate" is '最後更新日期時間';
comment on column "ForeclosureFinished"."LastUpdateEmpNo" is '最後更新人員';
drop table "GraceCondition" purge;

create table "GraceCondition" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ActUse" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "GraceCondition" add constraint "GraceCondition_PK" primary key("CustNo", "FacmNo");

comment on table "GraceCondition" is '寬限條件控管繳息檔';
comment on column "GraceCondition"."CustNo" is '借款人戶號';
comment on column "GraceCondition"."FacmNo" is '額度編號';
comment on column "GraceCondition"."ActUse" is '使用碼';
comment on column "GraceCondition"."CreateDate" is '建檔日期時間';
comment on column "GraceCondition"."CreateEmpNo" is '建檔人員';
comment on column "GraceCondition"."LastUpdate" is '最後更新日期時間';
comment on column "GraceCondition"."LastUpdateEmpNo" is '最後更新人員';
drop table "Guarantor" purge;

create table "Guarantor" (
  "ApproveNo" decimal(7, 0) default 0 not null,
  "GuaUKey" varchar2(32),
  "GuaRelCode" varchar2(2),
  "GuaAmt" decimal(16, 2) default 0 not null,
  "GuaTypeCode" varchar2(2),
  "GuaDate" decimal(8, 0) default 0 not null,
  "GuaStatCode" varchar2(1),
  "CancelDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Guarantor" add constraint "Guarantor_PK" primary key("ApproveNo", "GuaUKey");

alter table "Guarantor" add constraint "Guarantor_CustMain_FK1" foreign key ("GuaUKey") references "CustMain" ("CustUKey") on delete cascade;

alter table "Guarantor" add constraint "Guarantor_FacCaseAppl_FK2" foreign key ("ApproveNo") references "FacCaseAppl" ("ApplNo") on delete cascade;

create index "Guarantor_Index1" on "Guarantor"("ApproveNo" asc);

create index "Guarantor_Index2" on "Guarantor"("GuaUKey" asc);

comment on table "Guarantor" is '保證人檔';
comment on column "Guarantor"."ApproveNo" is '核准號碼';
comment on column "Guarantor"."GuaUKey" is '保證人客戶識別碼';
comment on column "Guarantor"."GuaRelCode" is '保證人關係代碼';
comment on column "Guarantor"."GuaAmt" is '保證金額';
comment on column "Guarantor"."GuaTypeCode" is '保證類別代碼';
comment on column "Guarantor"."GuaDate" is '對保日期';
comment on column "Guarantor"."GuaStatCode" is '保證狀況碼';
comment on column "Guarantor"."CancelDate" is '解除日期';
comment on column "Guarantor"."CreateDate" is '建檔日期時間';
comment on column "Guarantor"."CreateEmpNo" is '建檔人員';
comment on column "Guarantor"."LastUpdate" is '最後更新日期時間';
comment on column "Guarantor"."LastUpdateEmpNo" is '最後更新人員';
drop table "GuildBuilders" purge;

create table "GuildBuilders" (
  "CustNo" decimal(7, 0) default 0 not null,
  "BuilderStatus" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "GuildBuilders" add constraint "GuildBuilders_PK" primary key("CustNo");

comment on table "GuildBuilders" is '公會餘額統計建商名單檔';
comment on column "GuildBuilders"."CustNo" is '戶號';
comment on column "GuildBuilders"."BuilderStatus" is '建商狀況';
comment on column "GuildBuilders"."CreateDate" is '建檔日期時間';
comment on column "GuildBuilders"."CreateEmpNo" is '建檔人員';
comment on column "GuildBuilders"."LastUpdate" is '最後更新日期時間';
comment on column "GuildBuilders"."LastUpdateEmpNo" is '最後更新人員';
drop table "HlAreaData" purge;

create table "HlAreaData" (
  "AreaUnitNo" varchar2(6),
  "AreaName" varchar2(20),
  "AreaChiefEmpNo" varchar2(6),
  "AreaChiefName" nvarchar2(15),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlAreaData" add constraint "HlAreaData_PK" primary key("AreaUnitNo");

comment on table "HlAreaData" is '區域資料主檔';
comment on column "HlAreaData"."AreaUnitNo" is '區域代碼';
comment on column "HlAreaData"."AreaName" is '區域名稱';
comment on column "HlAreaData"."AreaChiefEmpNo" is '區域主管員編';
comment on column "HlAreaData"."AreaChiefName" is '區域主管名稱';
comment on column "HlAreaData"."CreateDate" is '建檔日期時間';
comment on column "HlAreaData"."CreateEmpNo" is '建檔人員';
comment on column "HlAreaData"."LastUpdate" is '最後更新日期時間';
comment on column "HlAreaData"."LastUpdateEmpNo" is '最後更新人員';
drop table "HlAreaLnYg6Pt" purge;

create table "HlAreaLnYg6Pt" (
  "WorkYM" varchar2(10),
  "AreaUnitNo" varchar2(6),
  "LstAppNum" decimal(14, 2) default 0 not null,
  "LstAppAmt" decimal(14, 2) default 0 not null,
  "TisAppNum" decimal(14, 2) default 0 not null,
  "TisAppAmt" decimal(14, 2) default 0 not null,
  "CalDate" varchar2(10),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlAreaLnYg6Pt" add constraint "HlAreaLnYg6Pt_PK" primary key("WorkYM", "AreaUnitNo");

comment on table "HlAreaLnYg6Pt" is '匯出用HlAreaLnYg6Pt';
comment on column "HlAreaLnYg6Pt"."WorkYM" is '年月份';
comment on column "HlAreaLnYg6Pt"."AreaUnitNo" is '單位代號';
comment on column "HlAreaLnYg6Pt"."LstAppNum" is '上月達成件數';
comment on column "HlAreaLnYg6Pt"."LstAppAmt" is '上月達成金額';
comment on column "HlAreaLnYg6Pt"."TisAppNum" is '本月達成件數';
comment on column "HlAreaLnYg6Pt"."TisAppAmt" is '本月達成金額';
comment on column "HlAreaLnYg6Pt"."CalDate" is '年月日';
comment on column "HlAreaLnYg6Pt"."UpNo" is 'UpdateIdentifier';
comment on column "HlAreaLnYg6Pt"."ProcessDate" is '更新日期';
comment on column "HlAreaLnYg6Pt"."CreateDate" is '建檔日期時間';
comment on column "HlAreaLnYg6Pt"."CreateEmpNo" is '建檔人員';
comment on column "HlAreaLnYg6Pt"."LastUpdate" is '最後更新日期時間';
comment on column "HlAreaLnYg6Pt"."LastUpdateEmpNo" is '最後更新人員';
drop table "HlCusData" purge;

create table "HlCusData" (
  "HlCusNo" decimal(10, 0) default 0 not null,
  "HlCusName" nvarchar2(50),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlCusData" add constraint "HlCusData_PK" primary key("HlCusNo");

comment on table "HlCusData" is '借款人資料';
comment on column "HlCusData"."HlCusNo" is '借款人戶號';
comment on column "HlCusData"."HlCusName" is '客戶姓名';
comment on column "HlCusData"."ProcessDate" is '更新日期';
comment on column "HlCusData"."CreateDate" is '建檔日期時間';
comment on column "HlCusData"."CreateEmpNo" is '建檔人員';
comment on column "HlCusData"."LastUpdate" is '最後更新日期時間';
comment on column "HlCusData"."LastUpdateEmpNo" is '最後更新人員';
drop table "HlEmpLnYg5Pt" purge;

create table "HlEmpLnYg5Pt" (
  "WorkYM" varchar2(10),
  "AreaUnitNo" varchar2(6),
  "HlEmpNo" varchar2(6),
  "HlEmpName" nvarchar2(15),
  "DeptNo" varchar2(6),
  "DeptName" varchar2(20),
  "Area" varchar2(20),
  "BranchName" varchar2(20),
  "GoalAmt" decimal(14, 2) default 0 not null,
  "HlAppNum" decimal(14, 2) default 0 not null,
  "HlAppAmt" decimal(14, 2) default 0 not null,
  "ClAppNum" decimal(14, 2) default 0 not null,
  "ClAppAmt" decimal(14, 2) default 0 not null,
  "ServiceAppNum" decimal(14, 2) default 0 not null,
  "ServiceAppAmt" decimal(14, 2) default 0 not null,
  "CalDate" varchar2(10),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlEmpLnYg5Pt" add constraint "HlEmpLnYg5Pt_PK" primary key("WorkYM", "AreaUnitNo", "HlEmpNo");

comment on table "HlEmpLnYg5Pt" is '員工目標檔案';
comment on column "HlEmpLnYg5Pt"."WorkYM" is '年月份';
comment on column "HlEmpLnYg5Pt"."AreaUnitNo" is '單位代號';
comment on column "HlEmpLnYg5Pt"."HlEmpNo" is '員工代號';
comment on column "HlEmpLnYg5Pt"."HlEmpName" is '員工姓名';
comment on column "HlEmpLnYg5Pt"."DeptNo" is '部室代號';
comment on column "HlEmpLnYg5Pt"."DeptName" is '部室中文';
comment on column "HlEmpLnYg5Pt"."Area" is '駐在地';
comment on column "HlEmpLnYg5Pt"."BranchName" is '區部中文';
comment on column "HlEmpLnYg5Pt"."GoalAmt" is '目標金額';
comment on column "HlEmpLnYg5Pt"."HlAppNum" is '房貸撥款件數';
comment on column "HlEmpLnYg5Pt"."HlAppAmt" is '房貸撥款金額';
comment on column "HlEmpLnYg5Pt"."ClAppNum" is '車貸撥款件數';
comment on column "HlEmpLnYg5Pt"."ClAppAmt" is '車貸撥款金額';
comment on column "HlEmpLnYg5Pt"."ServiceAppNum" is '信義撥款件數';
comment on column "HlEmpLnYg5Pt"."ServiceAppAmt" is '信義撥款金額';
comment on column "HlEmpLnYg5Pt"."CalDate" is '年月日';
comment on column "HlEmpLnYg5Pt"."UpNo" is 'UpdateIdentifier';
comment on column "HlEmpLnYg5Pt"."ProcessDate" is '更新日期';
comment on column "HlEmpLnYg5Pt"."CreateDate" is '建檔日期時間';
comment on column "HlEmpLnYg5Pt"."CreateEmpNo" is '建檔人員';
comment on column "HlEmpLnYg5Pt"."LastUpdate" is '最後更新日期時間';
comment on column "HlEmpLnYg5Pt"."LastUpdateEmpNo" is '最後更新人員';
drop table "HlThreeDetail" purge;

create table "HlThreeDetail" (
  "CusBNo" varchar2(2),
  "HlCusNo" decimal(14, 0) default 0 not null,
  "AmountNo" varchar2(3),
  "AplAmount" decimal(14, 2) default 0 not null,
  "CaseNo" varchar2(1),
  "IfCal" varchar2(1),
  "TActAmt" varchar2(30),
  "EmpNo" varchar2(10),
  "EmpId" varchar2(10),
  "HlEmpName" nvarchar2(15),
  "DeptNo" varchar2(6),
  "BranchNo" varchar2(50),
  "UnitNo" varchar2(6),
  "DeptName" varchar2(20),
  "BranchName" varchar2(20),
  "UnitName" varchar2(20),
  "FirAppDate" varchar2(8),
  "BiReteNo" varchar2(2),
  "TwoYag" decimal(14, 2) default 0 not null,
  "ThreeYag" decimal(14, 2) default 0 not null,
  "TwoPay" decimal(14, 2) default 0 not null,
  "ThreePay" decimal(14, 2) default 0 not null,
  "UnitChiefNo" varchar2(10),
  "UnitChiefName" nvarchar2(15),
  "AreaChiefNo" varchar2(10),
  "AreaChiefName" nvarchar2(15),
  "Id3" varchar2(10),
  "Id3Name" nvarchar2(15),
  "TeamChiefNo" varchar2(10),
  "TeamChiefName" nvarchar2(15),
  "Id0" varchar2(10),
  "Id0Name" nvarchar2(15),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlThreeDetail" add constraint "HlThreeDetail_PK" primary key("CusBNo", "HlCusNo", "AmountNo", "CaseNo");

comment on table "HlThreeDetail" is '房貸換算業績網頁查詢檔';
comment on column "HlThreeDetail"."CusBNo" is '營業單位別';
comment on column "HlThreeDetail"."HlCusNo" is '借款人戶號';
comment on column "HlThreeDetail"."AmountNo" is '額度編號';
comment on column "HlThreeDetail"."AplAmount" is '已用額度';
comment on column "HlThreeDetail"."CaseNo" is '計件代碼';
comment on column "HlThreeDetail"."IfCal" is '是否已計件';
comment on column "HlThreeDetail"."TActAmt" is '累計達成金額';
comment on column "HlThreeDetail"."EmpNo" is '員工代號';
comment on column "HlThreeDetail"."EmpId" is '統一編號';
comment on column "HlThreeDetail"."HlEmpName" is '員工姓名';
comment on column "HlThreeDetail"."DeptNo" is '部室代號';
comment on column "HlThreeDetail"."BranchNo" is '區部代號';
comment on column "HlThreeDetail"."UnitNo" is '單位代號';
comment on column "HlThreeDetail"."DeptName" is '部室中文';
comment on column "HlThreeDetail"."BranchName" is '區部中文';
comment on column "HlThreeDetail"."UnitName" is '單位中文';
comment on column "HlThreeDetail"."FirAppDate" is '首次撥款日';
comment on column "HlThreeDetail"."BiReteNo" is '基本利率代碼';
comment on column "HlThreeDetail"."TwoYag" is '二階換算業績';
comment on column "HlThreeDetail"."ThreeYag" is '三階換算業績';
comment on column "HlThreeDetail"."TwoPay" is '二階業務報酬';
comment on column "HlThreeDetail"."ThreePay" is '三階業務報酬';
comment on column "HlThreeDetail"."UnitChiefNo" is '統一編號';
comment on column "HlThreeDetail"."UnitChiefName" is '員工姓名';
comment on column "HlThreeDetail"."AreaChiefNo" is '統一編號';
comment on column "HlThreeDetail"."AreaChiefName" is '員工姓名';
comment on column "HlThreeDetail"."Id3" is '統一編號';
comment on column "HlThreeDetail"."Id3Name" is '員工姓名';
comment on column "HlThreeDetail"."TeamChiefNo" is '統一編號';
comment on column "HlThreeDetail"."TeamChiefName" is '員工姓名';
comment on column "HlThreeDetail"."Id0" is '統一編號';
comment on column "HlThreeDetail"."Id0Name" is '員工姓名';
comment on column "HlThreeDetail"."UpNo" is 'UpdateIdentifier';
comment on column "HlThreeDetail"."ProcessDate" is '更新日期';
comment on column "HlThreeDetail"."CreateDate" is '建檔日期時間';
comment on column "HlThreeDetail"."CreateEmpNo" is '建檔人員';
comment on column "HlThreeDetail"."LastUpdate" is '最後更新日期時間';
comment on column "HlThreeDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "HlThreeLaqhcp" purge;

create table "HlThreeLaqhcp" (
  "CalDate" varchar2(10),
  "EmpNo" varchar2(6),
  "UnitNo" varchar2(6),
  "BranchNo" varchar2(6),
  "DeptNo" varchar2(6),
  "UnitName" varchar2(20),
  "BranchName" varchar2(20),
  "DeptName" varchar2(20),
  "ChiefName" nvarchar2(15),
  "HlEmpName" nvarchar2(15),
  "MType" varchar2(1),
  "GoalNum" decimal(14, 2) default 0 not null,
  "GoalAmt" decimal(14, 2) default 0 not null,
  "ActNum" decimal(14, 2) default 0 not null,
  "ActAmt" decimal(14, 2) default 0 not null,
  "ActRate" decimal(14, 2) default 0 not null,
  "TGoalNum" decimal(14, 2) default 0 not null,
  "TGoalAmt" decimal(14, 2) default 0 not null,
  "TActNum" decimal(14, 2) default 0 not null,
  "TActAmt" decimal(14, 2) default 0 not null,
  "TActRate" decimal(14, 2) default 0 not null,
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlThreeLaqhcp" add constraint "HlThreeLaqhcp_PK" primary key("CalDate", "EmpNo", "BranchNo", "DeptNo", "UnitNo");

comment on table "HlThreeLaqhcp" is '房貸排行邏輯檔';
comment on column "HlThreeLaqhcp"."CalDate" is '年月日';
comment on column "HlThreeLaqhcp"."EmpNo" is '員工代號';
comment on column "HlThreeLaqhcp"."UnitNo" is '單位代號';
comment on column "HlThreeLaqhcp"."BranchNo" is '區部代號';
comment on column "HlThreeLaqhcp"."DeptNo" is '部室代號';
comment on column "HlThreeLaqhcp"."UnitName" is '單位中文';
comment on column "HlThreeLaqhcp"."BranchName" is '區部中文';
comment on column "HlThreeLaqhcp"."DeptName" is '部室中文';
comment on column "HlThreeLaqhcp"."ChiefName" is '員工姓名';
comment on column "HlThreeLaqhcp"."HlEmpName" is '專員姓名';
comment on column "HlThreeLaqhcp"."MType" is '處長主任別';
comment on column "HlThreeLaqhcp"."GoalNum" is '目標件數';
comment on column "HlThreeLaqhcp"."GoalAmt" is '目標金額';
comment on column "HlThreeLaqhcp"."ActNum" is '達成件數';
comment on column "HlThreeLaqhcp"."ActAmt" is '達成金額';
comment on column "HlThreeLaqhcp"."ActRate" is '本月達成率';
comment on column "HlThreeLaqhcp"."TGoalNum" is '累計目標件數';
comment on column "HlThreeLaqhcp"."TGoalAmt" is '累計目標金額';
comment on column "HlThreeLaqhcp"."TActNum" is '累計達成件數';
comment on column "HlThreeLaqhcp"."TActAmt" is '累計達成金額';
comment on column "HlThreeLaqhcp"."TActRate" is '累計達成率';
comment on column "HlThreeLaqhcp"."UpNo" is 'UpdateIdentifier';
comment on column "HlThreeLaqhcp"."ProcessDate" is '更新日期';
comment on column "HlThreeLaqhcp"."CreateDate" is '建檔日期時間';
comment on column "HlThreeLaqhcp"."CreateEmpNo" is '建檔人員';
comment on column "HlThreeLaqhcp"."LastUpdate" is '最後更新日期時間';
comment on column "HlThreeLaqhcp"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias34Ap" purge;

create table "Ias34Ap" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "Rate" decimal(8, 6) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerCode" decimal(2, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "AmortizedCode" decimal(1, 0) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetClass" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Ap" add constraint "Ias34Ap_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "Ias34Ap" is 'IAS34欄位清單A檔';
comment on column "Ias34Ap"."DataYM" is '年月份';
comment on column "Ias34Ap"."CustNo" is '戶號';
comment on column "Ias34Ap"."CustId" is '借款人ID / 統編';
comment on column "Ias34Ap"."FacmNo" is '額度編號';
comment on column "Ias34Ap"."ApplNo" is '核准號碼';
comment on column "Ias34Ap"."BormNo" is '撥款序號';
comment on column "Ias34Ap"."AcCode" is '會計科目';
comment on column "Ias34Ap"."Status" is '戶況';
comment on column "Ias34Ap"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias34Ap"."DrawdownDate" is '撥款日期';
comment on column "Ias34Ap"."FacLineDate" is '到期日(額度)';
comment on column "Ias34Ap"."MaturityDate" is '到期日(撥款)';
comment on column "Ias34Ap"."LineAmt" is '核准金額';
comment on column "Ias34Ap"."DrawdownAmt" is '撥款金額';
comment on column "Ias34Ap"."AcctFee" is '帳管費';
comment on column "Ias34Ap"."LoanBal" is '本金餘額(撥款)';
comment on column "Ias34Ap"."IntAmt" is '應收利息';
comment on column "Ias34Ap"."Fee" is '法拍及火險費用';
comment on column "Ias34Ap"."Rate" is '利率(撥款)';
comment on column "Ias34Ap"."OvduDays" is '逾期繳款天數';
comment on column "Ias34Ap"."OvduDate" is '轉催收款日期';
comment on column "Ias34Ap"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ias34Ap"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ias34Ap"."DerCode" is '符合減損客觀證據之條件';
comment on column "Ias34Ap"."GracePeriod" is '初貸時約定還本寬限期';
comment on column "Ias34Ap"."ApproveRate" is '核准利率';
comment on column "Ias34Ap"."AmortizedCode" is '契約當時還款方式';
comment on column "Ias34Ap"."RateCode" is '契約當時利率調整方式';
comment on column "Ias34Ap"."RepayFreq" is '契約約定當時還本週期';
comment on column "Ias34Ap"."PayIntFreq" is '契約約定當時繳息週期';
comment on column "Ias34Ap"."IndustryCode" is '授信行業別';
comment on column "Ias34Ap"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias34Ap"."Zip3" is '擔保品地區別';
comment on column "Ias34Ap"."ProdNo" is '商品利率代碼';
comment on column "Ias34Ap"."CustKind" is '企業戶/個人戶';
comment on column "Ias34Ap"."AssetClass" is '五類資產分類';
comment on column "Ias34Ap"."IfrsProdCode" is '產品別';
comment on column "Ias34Ap"."EvaAmt" is '原始鑑價金額';
comment on column "Ias34Ap"."FirstDueDate" is '首次應繳日';
comment on column "Ias34Ap"."TotalPeriod" is '總期數';
comment on column "Ias34Ap"."AgreeBefFacmNo" is '協議前之額度編號';
comment on column "Ias34Ap"."AgreeBefBormNo" is '協議前之撥款序號';
comment on column "Ias34Ap"."CreateDate" is '建檔日期時間';
comment on column "Ias34Ap"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Ap"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Ap"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias34Bp" purge;

create table "Ias34Bp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LoanRate" decimal(8, 6) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Bp" add constraint "Ias34Bp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "Ias34Bp" is 'IAS34欄位清單B檔';
comment on column "Ias34Bp"."DataYM" is '年月份';
comment on column "Ias34Bp"."CustNo" is '戶號';
comment on column "Ias34Bp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Bp"."FacmNo" is '額度編號';
comment on column "Ias34Bp"."BormNo" is '撥款序號';
comment on column "Ias34Bp"."LoanRate" is '貸放利率';
comment on column "Ias34Bp"."RateCode" is '利率調整方式';
comment on column "Ias34Bp"."EffectDate" is '利率欄位生效日';
comment on column "Ias34Bp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Bp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Bp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Bp"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias34Cp" purge;

create table "Ias34Cp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Cp" add constraint "Ias34Cp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "Ias34Cp" is 'IAS34欄位清單C檔';
comment on column "Ias34Cp"."DataYM" is '年月份';
comment on column "Ias34Cp"."CustNo" is '戶號';
comment on column "Ias34Cp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Cp"."FacmNo" is '額度編號';
comment on column "Ias34Cp"."BormNo" is '撥款序號';
comment on column "Ias34Cp"."AmortizedCode" is '約定還款方式';
comment on column "Ias34Cp"."PayIntFreq" is '繳息週期';
comment on column "Ias34Cp"."RepayFreq" is '還本週期';
comment on column "Ias34Cp"."EffectDate" is '生效日期';
comment on column "Ias34Cp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Cp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Cp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Cp"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias34Dp" purge;

create table "Ias34Dp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerDate" decimal(8, 0) default 0 not null,
  "DerRate" decimal(8, 6) default 0 not null,
  "DerLoanBal" decimal(16, 2) default 0 not null,
  "DerIntAmt" decimal(16, 2) default 0 not null,
  "DerFee" decimal(16, 2) default 0 not null,
  "DerY1Amt" decimal(16, 2) default 0 not null,
  "DerY2Amt" decimal(16, 2) default 0 not null,
  "DerY3Amt" decimal(16, 2) default 0 not null,
  "DerY4Amt" decimal(16, 2) default 0 not null,
  "DerY5Amt" decimal(16, 2) default 0 not null,
  "DerY1Int" decimal(16, 2) default 0 not null,
  "DerY2Int" decimal(16, 2) default 0 not null,
  "DerY3Int" decimal(16, 2) default 0 not null,
  "DerY4Int" decimal(16, 2) default 0 not null,
  "DerY5Int" decimal(16, 2) default 0 not null,
  "DerY1Fee" decimal(16, 2) default 0 not null,
  "DerY2Fee" decimal(16, 2) default 0 not null,
  "DerY3Fee" decimal(16, 2) default 0 not null,
  "DerY4Fee" decimal(16, 2) default 0 not null,
  "DerY5Fee" decimal(16, 2) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdCode" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Dp" add constraint "Ias34Dp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "Ias34Dp" is 'IAS34欄位清單D檔';
comment on column "Ias34Dp"."DataYM" is '年月份';
comment on column "Ias34Dp"."CustNo" is '戶號';
comment on column "Ias34Dp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Dp"."FacmNo" is '額度編號';
comment on column "Ias34Dp"."BormNo" is '撥款序號';
comment on column "Ias34Dp"."AcCode" is '會計科目';
comment on column "Ias34Dp"."Status" is '案件狀態';
comment on column "Ias34Dp"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias34Dp"."DrawdownDate" is '貸放日期';
comment on column "Ias34Dp"."MaturityDate" is '到期日';
comment on column "Ias34Dp"."LineAmt" is '核准金額';
comment on column "Ias34Dp"."DrawdownAmt" is '撥款金額';
comment on column "Ias34Dp"."LoanBal" is '本金餘額(撥款)';
comment on column "Ias34Dp"."IntAmt" is '應收利息';
comment on column "Ias34Dp"."Fee" is '法拍及火險費用';
comment on column "Ias34Dp"."OvduDays" is '逾期繳款天數';
comment on column "Ias34Dp"."OvduDate" is '轉催收款日期';
comment on column "Ias34Dp"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ias34Dp"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ias34Dp"."DerDate" is '個案減損客觀證據發生日期';
comment on column "Ias34Dp"."DerRate" is '上述發生日期前之最近一次利率';
comment on column "Ias34Dp"."DerLoanBal" is '上述發生日期時之本金餘額';
comment on column "Ias34Dp"."DerIntAmt" is '上述發生日期時之應收利息';
comment on column "Ias34Dp"."DerFee" is '上述發生日期時之法拍及火險費用';
comment on column "Ias34Dp"."DerY1Amt" is '個案減損客觀證據發生後第一年本金回收金額';
comment on column "Ias34Dp"."DerY2Amt" is '個案減損客觀證據發生後第二年本金回收金額';
comment on column "Ias34Dp"."DerY3Amt" is '個案減損客觀證據發生後第三年本金回收金額';
comment on column "Ias34Dp"."DerY4Amt" is '個案減損客觀證據發生後第四年本金回收金額';
comment on column "Ias34Dp"."DerY5Amt" is '個案減損客觀證據發生後第五年本金回收金額';
comment on column "Ias34Dp"."DerY1Int" is '個案減損客觀證據發生後第一年應收利息回收金額';
comment on column "Ias34Dp"."DerY2Int" is '個案減損客觀證據發生後第二年應收利息回收金額';
comment on column "Ias34Dp"."DerY3Int" is '個案減損客觀證據發生後第三年應收利息回收金額';
comment on column "Ias34Dp"."DerY4Int" is '個案減損客觀證據發生後第四年應收利息回收金額';
comment on column "Ias34Dp"."DerY5Int" is '個案減損客觀證據發生後第五年應收利息回收金額';
comment on column "Ias34Dp"."DerY1Fee" is '個案減損客觀證據發生後第一年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY2Fee" is '個案減損客觀證據發生後第二年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY3Fee" is '個案減損客觀證據發生後第三年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY4Fee" is '個案減損客觀證據發生後第四年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY5Fee" is '個案減損客觀證據發生後第五年法拍及火險費用回收金額';
comment on column "Ias34Dp"."IndustryCode" is '授信行業別';
comment on column "Ias34Dp"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias34Dp"."Zip3" is '擔保品地區別';
comment on column "Ias34Dp"."ProdCode" is '商品利率代碼';
comment on column "Ias34Dp"."CustKind" is '企業戶/個人戶';
comment on column "Ias34Dp"."IfrsProdCode" is '產品別';
comment on column "Ias34Dp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Dp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Dp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Dp"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias34Ep" purge;

create table "Ias34Ep" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "DerFg" varchar2(1),
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Ep" add constraint "Ias34Ep_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "AcCode", "Status");

comment on table "Ias34Ep" is 'IAS34欄位清單E檔';
comment on column "Ias34Ep"."DataYM" is '資料時點(年月)';
comment on column "Ias34Ep"."CustNo" is '戶號';
comment on column "Ias34Ep"."CustId" is '借款人ID / 統編';
comment on column "Ias34Ep"."FacmNo" is '額度編號(核准號碼)';
comment on column "Ias34Ep"."BormNo" is '撥款序號';
comment on column "Ias34Ep"."AcCode" is '會計科目';
comment on column "Ias34Ep"."Status" is '狀態';
comment on column "Ias34Ep"."IndustryCode" is '授信行業別';
comment on column "Ias34Ep"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias34Ep"."Zip3" is '擔保品地區別(郵遞區號)';
comment on column "Ias34Ep"."ProdNo" is '商品利率代碼';
comment on column "Ias34Ep"."CustKind" is '企業戶/個人戶';
comment on column "Ias34Ep"."DerFg" is '資料時點是否符合減損客觀證據';
comment on column "Ias34Ep"."IfrsProdCode" is '產品別';
comment on column "Ias34Ep"."CreateDate" is '建檔日期時間';
comment on column "Ias34Ep"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Ep"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Ep"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias34Gp" purge;

create table "Ias34Gp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "AgreeNo" decimal(3, 0) default 0 not null,
  "AgreeFg" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Gp" add constraint "Ias34Gp_PK" primary key("DataYM", "CustNo", "AgreeNo", "AgreeFg", "FacmNo", "BormNo");

comment on table "Ias34Gp" is 'IAS34欄位清單G檔';
comment on column "Ias34Gp"."DataYM" is '年月份';
comment on column "Ias34Gp"."CustNo" is '戶號';
comment on column "Ias34Gp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Gp"."AgreeNo" is '協議編號';
comment on column "Ias34Gp"."AgreeFg" is '協議前後';
comment on column "Ias34Gp"."FacmNo" is '額度編號';
comment on column "Ias34Gp"."BormNo" is '撥款序號';
comment on column "Ias34Gp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Gp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Gp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Gp"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias39IntMethod" purge;

create table "Ias39IntMethod" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "Principal" decimal(16, 4) default 0 not null,
  "BookValue" decimal(16, 4) default 0 not null,
  "AccumDPAmortized" decimal(16, 4) default 0 not null,
  "AccumDPunAmortized" decimal(16, 4) default 0 not null,
  "DPAmortized" decimal(16, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39IntMethod" add constraint "Ias39IntMethod_PK" primary key("YearMonth", "CustNo", "FacmNo", "BormNo");

comment on table "Ias39IntMethod" is '利息法帳面資料檔';
comment on column "Ias39IntMethod"."YearMonth" is '年月份';
comment on column "Ias39IntMethod"."CustNo" is '戶號';
comment on column "Ias39IntMethod"."FacmNo" is '額度編號';
comment on column "Ias39IntMethod"."BormNo" is '撥款序號';
comment on column "Ias39IntMethod"."Principal" is '本期本金餘額';
comment on column "Ias39IntMethod"."BookValue" is '本期帳面價值';
comment on column "Ias39IntMethod"."AccumDPAmortized" is '本期累應攤銷折溢價';
comment on column "Ias39IntMethod"."AccumDPunAmortized" is '本期累未攤銷折溢價';
comment on column "Ias39IntMethod"."DPAmortized" is '本期折溢價攤銷數';
comment on column "Ias39IntMethod"."CreateDate" is '建檔日期時間';
comment on column "Ias39IntMethod"."CreateEmpNo" is '建檔人員';
comment on column "Ias39IntMethod"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39IntMethod"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias39LGD" purge;

create table "Ias39LGD" (
  "Date" decimal(8, 0) default 0 not null,
  "Type" varchar2(2),
  "TypeDesc" nvarchar2(10),
  "LGDPercent" decimal(7, 5) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39LGD" add constraint "Ias39LGD_PK" primary key("Date", "Type");

comment on table "Ias39LGD" is '違約損失率檔';
comment on column "Ias39LGD"."Date" is '生效日期';
comment on column "Ias39LGD"."Type" is '類別';
comment on column "Ias39LGD"."TypeDesc" is '類別說明';
comment on column "Ias39LGD"."LGDPercent" is '違約損失率％';
comment on column "Ias39LGD"."Enable" is '啟用記號';
comment on column "Ias39LGD"."CreateDate" is '建檔日期時間';
comment on column "Ias39LGD"."CreateEmpNo" is '建檔人員';
comment on column "Ias39LGD"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39LGD"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias39Loan34Data" purge;

create table "Ias39Loan34Data" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "Status" decimal(2, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(13, 2) default 0 not null,
  "DrawdownAmt" decimal(13, 2) default 0 not null,
  "AcctFee" decimal(13, 2) default 0 not null,
  "LoanBal" decimal(13, 2) default 0 not null,
  "IntAmt" decimal(13, 2) default 0 not null,
  "Fee" decimal(13, 2) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(13, 2) default 0 not null,
  "DerCode" decimal(2, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AmortizedCode" decimal(1, 0) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "Zip3" varchar2(3),
  "BaseRateCode" varchar2(2),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetKind" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(2),
  "EvaAmt" decimal(13, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "UtilAmt" decimal(13, 2) default 0 not null,
  "UtilBal" decimal(13, 2) default 0 not null,
  "TempAmt" decimal(13, 2) default 0 not null,
  "AvblBal" decimal(13, 2) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ExchangeRate" decimal(8, 5) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "LoanTerm" decimal(6, 0) default 0 not null,
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "FacAmortizedCode" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39Loan34Data" add constraint "Ias39Loan34Data_PK" primary key("DataYM", "CustNo", "FacmNo", "ApplNo", "BormNo");

comment on table "Ias39Loan34Data" is 'IAS39放款34號公報資料檔';
comment on column "Ias39Loan34Data"."DataYM" is '年月份';
comment on column "Ias39Loan34Data"."CustNo" is '戶號';
comment on column "Ias39Loan34Data"."FacmNo" is '額度編號';
comment on column "Ias39Loan34Data"."ApplNo" is '核准號碼';
comment on column "Ias39Loan34Data"."BormNo" is '撥款序號';
comment on column "Ias39Loan34Data"."CustId" is '借款人ID / 統編';
comment on column "Ias39Loan34Data"."DrawdownFg" is '已核撥記號';
comment on column "Ias39Loan34Data"."AcctCode" is '業務科目代號';
comment on column "Ias39Loan34Data"."Status" is '戶況';
comment on column "Ias39Loan34Data"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias39Loan34Data"."DrawdownDate" is '撥款日期';
comment on column "Ias39Loan34Data"."FacLineDate" is '到期日(額度)';
comment on column "Ias39Loan34Data"."MaturityDate" is '到期日(撥款)';
comment on column "Ias39Loan34Data"."LineAmt" is '核准金額';
comment on column "Ias39Loan34Data"."DrawdownAmt" is '撥款金額';
comment on column "Ias39Loan34Data"."AcctFee" is '帳管費';
comment on column "Ias39Loan34Data"."LoanBal" is '本金餘額(撥款)';
comment on column "Ias39Loan34Data"."IntAmt" is '應收利息';
comment on column "Ias39Loan34Data"."Fee" is '法拍及火險費用';
comment on column "Ias39Loan34Data"."Rate" is '利率(撥款)';
comment on column "Ias39Loan34Data"."OvduDays" is '逾期繳款天數';
comment on column "Ias39Loan34Data"."OvduDate" is '轉催收款日期';
comment on column "Ias39Loan34Data"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ias39Loan34Data"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ias39Loan34Data"."DerCode" is '符合減損客觀證據之條件';
comment on column "Ias39Loan34Data"."GracePeriod" is '初貸時約定還本寬限期';
comment on column "Ias39Loan34Data"."ApproveRate" is '核准利率';
comment on column "Ias39Loan34Data"."AmortizedCode" is '契約當時還款方式';
comment on column "Ias39Loan34Data"."RateCode" is '契約當時利率調整方式';
comment on column "Ias39Loan34Data"."RepayFreq" is '契約約定當時還本週期';
comment on column "Ias39Loan34Data"."PayIntFreq" is '契約約定當時繳息週期';
comment on column "Ias39Loan34Data"."IndustryCode" is '授信行業別';
comment on column "Ias39Loan34Data"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias39Loan34Data"."CityCode" is '擔保品地區別';
comment on column "Ias39Loan34Data"."AreaCode" is '擔保品鄉鎮區';
comment on column "Ias39Loan34Data"."Zip3" is '擔保品郵遞區號';
comment on column "Ias39Loan34Data"."BaseRateCode" is '商品利率代碼';
comment on column "Ias39Loan34Data"."CustKind" is '企業戶/個人戶';
comment on column "Ias39Loan34Data"."AssetKind" is '五類資產分類';
comment on column "Ias39Loan34Data"."ProdNo" is '產品別';
comment on column "Ias39Loan34Data"."EvaAmt" is '原始鑑價金額';
comment on column "Ias39Loan34Data"."FirstDueDate" is '首次應繳日';
comment on column "Ias39Loan34Data"."TotalPeriod" is '總期數';
comment on column "Ias39Loan34Data"."AgreeBefFacmNo" is '協議前之額度編號';
comment on column "Ias39Loan34Data"."AgreeBefBormNo" is '協議前之撥款序號';
comment on column "Ias39Loan34Data"."UtilAmt" is '累計撥款金額(額度)';
comment on column "Ias39Loan34Data"."UtilBal" is '已動用餘額(額度)';
comment on column "Ias39Loan34Data"."TempAmt" is '暫收款金額(台幣)';
comment on column "Ias39Loan34Data"."AvblBal" is '可動用餘額';
comment on column "Ias39Loan34Data"."CurrencyCode" is '記帳幣別';
comment on column "Ias39Loan34Data"."ExchangeRate" is '報導日匯率';
comment on column "Ias39Loan34Data"."ApproveDate" is '核准日期';
comment on column "Ias39Loan34Data"."LoanTerm" is '貸款期間';
comment on column "Ias39Loan34Data"."RecycleDeadline" is '循環動用期限';
comment on column "Ias39Loan34Data"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "Ias39Loan34Data"."IrrevocableFlag" is '該筆額度是否為不可徹銷';
comment on column "Ias39Loan34Data"."AcBookCode" is '帳冊別';
comment on column "Ias39Loan34Data"."AcNoCode" is '會計科目(8碼)';
comment on column "Ias39Loan34Data"."FacAmortizedCode" is '還款方式(額度)';
comment on column "Ias39Loan34Data"."CreateDate" is '建檔日期時間';
comment on column "Ias39Loan34Data"."CreateEmpNo" is '建檔人員';
comment on column "Ias39Loan34Data"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39Loan34Data"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias39LoanCommit" purge;

create table "Ias39LoanCommit" (
  "DataYm" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(13, 2) default 0 not null,
  "UtilBal" decimal(13, 2) default 0 not null,
  "AvblBal" decimal(13, 2) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "Ccf" decimal(5, 2) default 0 not null,
  "ExpLimitAmt" decimal(13, 2) default 0 not null,
  "DbAcNoCode" varchar2(11),
  "CrAcNoCode" varchar2(11),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39LoanCommit" add constraint "Ias39LoanCommit_PK" primary key("DataYm", "CustNo", "FacmNo", "ApplNo");

comment on table "Ias39LoanCommit" is 'IAS39放款承諾明細檔';
comment on column "Ias39LoanCommit"."DataYm" is '年月份';
comment on column "Ias39LoanCommit"."CustNo" is '戶號';
comment on column "Ias39LoanCommit"."FacmNo" is '額度編號';
comment on column "Ias39LoanCommit"."ApplNo" is '核准號碼';
comment on column "Ias39LoanCommit"."ApproveDate" is '核准日期';
comment on column "Ias39LoanCommit"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias39LoanCommit"."MaturityDate" is '到期日';
comment on column "Ias39LoanCommit"."LoanTermYy" is '貸款期間年';
comment on column "Ias39LoanCommit"."LoanTermMm" is '貸款期間月';
comment on column "Ias39LoanCommit"."LoanTermDd" is '貸款期間日';
comment on column "Ias39LoanCommit"."UtilDeadline" is '動支期限';
comment on column "Ias39LoanCommit"."RecycleDeadline" is '循環動用期限';
comment on column "Ias39LoanCommit"."LineAmt" is '核准額度';
comment on column "Ias39LoanCommit"."UtilBal" is '放款餘額';
comment on column "Ias39LoanCommit"."AvblBal" is '可動用餘額';
comment on column "Ias39LoanCommit"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "Ias39LoanCommit"."IrrevocableFlag" is '該筆額度是否為不可撤銷';
comment on column "Ias39LoanCommit"."AcBookCode" is '帳冊別';
comment on column "Ias39LoanCommit"."AcSubBookCode" is '區隔帳冊';
comment on column "Ias39LoanCommit"."Ccf" is '信用風險轉換係數';
comment on column "Ias39LoanCommit"."ExpLimitAmt" is '表外曝險金額';
comment on column "Ias39LoanCommit"."DbAcNoCode" is '借方：備忘分錄會計科目';
comment on column "Ias39LoanCommit"."CrAcNoCode" is '貸方：備忘分錄會計科目';
comment on column "Ias39LoanCommit"."DrawdownFg" is '已核撥記號';
comment on column "Ias39LoanCommit"."CreateDate" is '建檔日期時間';
comment on column "Ias39LoanCommit"."CreateEmpNo" is '建檔人員';
comment on column "Ias39LoanCommit"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39LoanCommit"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ias39Loss" purge;

create table "Ias39Loss" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "MarkDate" decimal(8, 0) default 0 not null,
  "MarkCode" decimal(2, 0) default 0 not null,
  "MarkCodeDesc" nvarchar2(20),
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias39Loss" add constraint "Ias39Loss_PK" primary key("CustNo", "FacmNo", "MarkDate");

comment on table "Ias39Loss" is '特殊客觀減損狀況檔';
comment on column "Ias39Loss"."CustNo" is '戶號';
comment on column "Ias39Loss"."FacmNo" is '額度編號';
comment on column "Ias39Loss"."MarkDate" is '發生日期';
comment on column "Ias39Loss"."MarkCode" is '註記碼';
comment on column "Ias39Loss"."MarkCodeDesc" is '註記碼說明';
comment on column "Ias39Loss"."StartDate" is '起始日期';
comment on column "Ias39Loss"."EndDate" is '終止日期';
comment on column "Ias39Loss"."CreateDate" is '建檔日期時間';
comment on column "Ias39Loss"."CreateEmpNo" is '建檔人員';
comment on column "Ias39Loss"."LastUpdate" is '最後更新日期時間';
comment on column "Ias39Loss"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ifrs9FacData" purge;

create table "Ifrs9FacData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LawFee" decimal(16, 2) default 0 not null,
  "FireFee" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IfrsStepProdCode" varchar2(1),
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "AgreementFg" varchar2(1),
  "EntCode" varchar2(1),
  "AssetClass" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "TotalLoanBal" decimal(16, 2) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ifrs9FacData" add constraint "Ifrs9FacData_PK" primary key("DataYM", "CustNo", "FacmNo");

comment on table "Ifrs9FacData" is 'IFRS9額度資料檔';
comment on column "Ifrs9FacData"."DataYM" is '資料年月';
comment on column "Ifrs9FacData"."CustNo" is '戶號';
comment on column "Ifrs9FacData"."FacmNo" is '額度編號';
comment on column "Ifrs9FacData"."ApplNo" is '核准號碼';
comment on column "Ifrs9FacData"."CustId" is '借款人ID / 統編';
comment on column "Ifrs9FacData"."DrawdownFg" is '已核撥記號';
comment on column "Ifrs9FacData"."ApproveDate" is '核准日期(額度)';
comment on column "Ifrs9FacData"."UtilDeadline" is '動支期限';
comment on column "Ifrs9FacData"."FirstDrawdownDate" is '初貸日期';
comment on column "Ifrs9FacData"."MaturityDate" is '到期日(額度)';
comment on column "Ifrs9FacData"."LineAmt" is '核准金額';
comment on column "Ifrs9FacData"."AcctFee" is '帳管費';
comment on column "Ifrs9FacData"."LawFee" is '法務費';
comment on column "Ifrs9FacData"."FireFee" is '火險費';
comment on column "Ifrs9FacData"."GracePeriod" is '初貸時約定還本寬限期';
comment on column "Ifrs9FacData"."AmortizedCode" is '契約當時還款方式(月底日)';
comment on column "Ifrs9FacData"."RateCode" is '契約當時利率調整方式(月底日)';
comment on column "Ifrs9FacData"."RepayFreq" is '契約約定當時還本週期(月底日)';
comment on column "Ifrs9FacData"."PayIntFreq" is '契約約定當時繳息週期(月底日)';
comment on column "Ifrs9FacData"."IfrsStepProdCode" is 'IFRS階梯商品別';
comment on column "Ifrs9FacData"."IndustryCode" is '授信行業別';
comment on column "Ifrs9FacData"."ClTypeJCIC" is '擔保品類別';
comment on column "Ifrs9FacData"."CityCode" is '擔保品地區別';
comment on column "Ifrs9FacData"."AreaCode" is '擔保品鄉鎮區';
comment on column "Ifrs9FacData"."Zip3" is '擔保品郵遞區號';
comment on column "Ifrs9FacData"."ProdNo" is '商品利率代碼';
comment on column "Ifrs9FacData"."AgreementFg" is '是否為協議商品';
comment on column "Ifrs9FacData"."EntCode" is '企金別';
comment on column "Ifrs9FacData"."AssetClass" is '資產五分類代號';
comment on column "Ifrs9FacData"."IfrsProdCode" is '產品別';
comment on column "Ifrs9FacData"."EvaAmt" is '原始鑑價金額';
comment on column "Ifrs9FacData"."UtilAmt" is '累計撥款金額(額度層)';
comment on column "Ifrs9FacData"."UtilBal" is '已動用餘額(額度層)';
comment on column "Ifrs9FacData"."TotalLoanBal" is '本金餘額(額度層)合計';
comment on column "Ifrs9FacData"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "Ifrs9FacData"."IrrevocableFlag" is '該筆額度是否為不可撤銷';
comment on column "Ifrs9FacData"."TempAmt" is '暫收款金額(台幣)';
comment on column "Ifrs9FacData"."AcBookCode" is '帳冊別';
comment on column "Ifrs9FacData"."AcSubBookCode" is '區隔帳冊';
comment on column "Ifrs9FacData"."CreateDate" is '建檔日期時間';
comment on column "Ifrs9FacData"."CreateEmpNo" is '建檔人員';
comment on column "Ifrs9FacData"."LastUpdate" is '最後更新日期時間';
comment on column "Ifrs9FacData"."LastUpdateEmpNo" is '最後更新人員';
drop table "Ifrs9LoanData" purge;

create table "Ifrs9LoanData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "AcctCode" varchar2(3),
  "AcCode" varchar2(11),
  "AcCodeOld" varchar2(8),
  "Status" decimal(2, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ifrs9LoanData" add constraint "Ifrs9LoanData_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "Ifrs9LoanData" is 'IFRS9撥款資料檔';
comment on column "Ifrs9LoanData"."DataYM" is '年月份';
comment on column "Ifrs9LoanData"."CustNo" is '戶號';
comment on column "Ifrs9LoanData"."FacmNo" is '額度編號';
comment on column "Ifrs9LoanData"."BormNo" is '撥款序號';
comment on column "Ifrs9LoanData"."CustId" is '借款人ID / 統編';
comment on column "Ifrs9LoanData"."AcctCode" is '業務科目代號';
comment on column "Ifrs9LoanData"."AcCode" is '新會計科目(11碼)';
comment on column "Ifrs9LoanData"."AcCodeOld" is '舊會計科目(8碼)';
comment on column "Ifrs9LoanData"."Status" is '戶況';
comment on column "Ifrs9LoanData"."DrawdownDate" is '撥款日期';
comment on column "Ifrs9LoanData"."MaturityDate" is '到期日(撥款)';
comment on column "Ifrs9LoanData"."DrawdownAmt" is '撥款金額';
comment on column "Ifrs9LoanData"."LoanBal" is '本金餘額(撥款)';
comment on column "Ifrs9LoanData"."IntAmt" is '應收利息';
comment on column "Ifrs9LoanData"."Rate" is '利率(撥款)';
comment on column "Ifrs9LoanData"."OvduDays" is '逾期繳款天數';
comment on column "Ifrs9LoanData"."OvduDate" is '轉催收款日期';
comment on column "Ifrs9LoanData"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ifrs9LoanData"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ifrs9LoanData"."ApproveRate" is '核准利率';
comment on column "Ifrs9LoanData"."AmortizedCode" is '契約當時還款方式(月底日)';
comment on column "Ifrs9LoanData"."RateCode" is '契約當時利率調整方式(月底日)';
comment on column "Ifrs9LoanData"."RepayFreq" is '契約約定當時還本週期(月底日)';
comment on column "Ifrs9LoanData"."PayIntFreq" is '契約約定當時繳息週期(月底日)';
comment on column "Ifrs9LoanData"."FirstDueDate" is '首次應繳日';
comment on column "Ifrs9LoanData"."TotalPeriod" is '總期數';
comment on column "Ifrs9LoanData"."AgreeBefFacmNo" is '協議前之額度編號';
comment on column "Ifrs9LoanData"."AgreeBefBormNo" is '協議前之撥款序號';
comment on column "Ifrs9LoanData"."AcBookCode" is '帳冊別';
comment on column "Ifrs9LoanData"."PrevPayIntDate" is '上次繳息日(繳息迄日)';
comment on column "Ifrs9LoanData"."CreateDate" is '建檔日期時間';
comment on column "Ifrs9LoanData"."CreateEmpNo" is '建檔人員';
comment on column "Ifrs9LoanData"."LastUpdate" is '最後更新日期時間';
comment on column "Ifrs9LoanData"."LastUpdateEmpNo" is '最後更新人員';
drop table "InnDocRecord" purge;

create table "InnDocRecord" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplSeq" varchar2(3),
  "TitaActFg" varchar2(1),
  "ApplCode" varchar2(1),
  "ApplEmpNo" varchar2(6),
  "KeeperEmpNo" varchar2(6),
  "UsageCode" varchar2(2),
  "CopyCode" varchar2(1),
  "ApplDate" decimal(8, 0) default 0 not null,
  "ReturnDate" decimal(8, 0) default 0 not null,
  "ReturnEmpNo" varchar2(6),
  "Remark" nvarchar2(60),
  "ApplObj" varchar2(1),
  "TitaEntDy" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InnDocRecord" add constraint "InnDocRecord_PK" primary key("CustNo", "FacmNo", "ApplSeq");

create index "InnDocRecord_Index1" on "InnDocRecord"("CustNo" asc, "ApplDate" asc, "UsageCode" asc, "ApplCode" asc);

comment on table "InnDocRecord" is '檔案借閱檔';
comment on column "InnDocRecord"."CustNo" is '借款人戶號';
comment on column "InnDocRecord"."FacmNo" is '額度號碼';
comment on column "InnDocRecord"."ApplSeq" is '申請序號';
comment on column "InnDocRecord"."TitaActFg" is '登放記號';
comment on column "InnDocRecord"."ApplCode" is '申請或歸還';
comment on column "InnDocRecord"."ApplEmpNo" is '借閱人';
comment on column "InnDocRecord"."KeeperEmpNo" is '管理人';
comment on column "InnDocRecord"."UsageCode" is '用途';
comment on column "InnDocRecord"."CopyCode" is '正本/影本';
comment on column "InnDocRecord"."ApplDate" is '借閱日期';
comment on column "InnDocRecord"."ReturnDate" is '歸還日期';
comment on column "InnDocRecord"."ReturnEmpNo" is '歸還人';
comment on column "InnDocRecord"."Remark" is '備註';
comment on column "InnDocRecord"."ApplObj" is '借閱項目';
comment on column "InnDocRecord"."TitaEntDy" is '登錄日期';
comment on column "InnDocRecord"."TitaTlrNo" is '登錄經辦';
comment on column "InnDocRecord"."TitaTxtNo" is '登錄交易序號';
comment on column "InnDocRecord"."CreateDate" is '建檔日期時間';
comment on column "InnDocRecord"."CreateEmpNo" is '建檔人員';
comment on column "InnDocRecord"."LastUpdate" is '最後更新日期時間';
comment on column "InnDocRecord"."LastUpdateEmpNo" is '最後更新人員';
drop table "InnFundApl" purge;

create table "InnFundApl" (
  "AcDate" decimal(8, 0) default 0 not null,
  "ResrvStndrd" decimal(14, 0) default 0 not null,
  "PosbleBorPsn" decimal(7, 4) default 0 not null,
  "PosbleBorAmt" decimal(16, 2) default 0 not null,
  "AlrdyBorAmt" decimal(16, 2) default 0 not null,
  "StockHoldersEqt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InnFundApl" add constraint "InnFundApl_PK" primary key("AcDate");

comment on table "InnFundApl" is '資金運用概況檔';
comment on column "InnFundApl"."AcDate" is '日期';
comment on column "InnFundApl"."ResrvStndrd" is '責任準備金';
comment on column "InnFundApl"."PosbleBorPsn" is '可放款比率%';
comment on column "InnFundApl"."PosbleBorAmt" is '可放款金額';
comment on column "InnFundApl"."AlrdyBorAmt" is '已放款金額';
comment on column "InnFundApl"."StockHoldersEqt" is '股東權益';
comment on column "InnFundApl"."CreateDate" is '建檔日期時間';
comment on column "InnFundApl"."CreateEmpNo" is '建檔人員';
comment on column "InnFundApl"."LastUpdate" is '最後更新日期時間';
comment on column "InnFundApl"."LastUpdateEmpNo" is '最後更新人員';
drop table "InnLoanMeeting" purge;

create table "InnLoanMeeting" (
  "MeetNo" decimal(6, 0) default 0 not null,
  "MeetingDate" decimal(8, 0) default 0 not null,
  "CustCode" varchar2(1),
  "Amount" decimal(14, 0) default 0 not null,
  "Issue" varchar2(50),
  "Remark" varchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InnLoanMeeting" add constraint "InnLoanMeeting_PK" primary key("MeetNo");

comment on table "InnLoanMeeting" is '放審會記錄檔';
comment on column "InnLoanMeeting"."MeetNo" is '放審會流水號';
comment on column "InnLoanMeeting"."MeetingDate" is '日期';
comment on column "InnLoanMeeting"."CustCode" is '戶別';
comment on column "InnLoanMeeting"."Amount" is '金額';
comment on column "InnLoanMeeting"."Issue" is '議題';
comment on column "InnLoanMeeting"."Remark" is '備註';
comment on column "InnLoanMeeting"."CreateDate" is '建檔日期時間';
comment on column "InnLoanMeeting"."CreateEmpNo" is '建檔人員';
comment on column "InnLoanMeeting"."LastUpdate" is '最後更新日期時間';
comment on column "InnLoanMeeting"."LastUpdateEmpNo" is '最後更新人員';
drop table "InnReCheck" purge;

create table "InnReCheck" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ReCheckCode" varchar2(1),
  "FollowMark" varchar2(1),
  "ReChkYearMonth" decimal(6, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "Evaluation" decimal(2, 0) default 0 not null,
  "CustTypeItem" nvarchar2(10),
  "UsageItem" nvarchar2(10),
  "CityItem" nvarchar2(10),
  "ReChkUnit" nvarchar2(10),
  "Remark" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InnReCheck" add constraint "InnReCheck_PK" primary key("YearMonth", "ConditionCode", "CustNo", "FacmNo");

comment on table "InnReCheck" is '覆審案件明細檔';
comment on column "InnReCheck"."YearMonth" is '資料年月';
comment on column "InnReCheck"."ConditionCode" is '條件代碼';
comment on column "InnReCheck"."CustNo" is '借款人戶號';
comment on column "InnReCheck"."FacmNo" is '額度號碼';
comment on column "InnReCheck"."ReCheckCode" is '覆審記號';
comment on column "InnReCheck"."FollowMark" is '追蹤記號';
comment on column "InnReCheck"."ReChkYearMonth" is '覆審年月';
comment on column "InnReCheck"."DrawdownDate" is '撥款日期';
comment on column "InnReCheck"."LoanBal" is '貸放餘額';
comment on column "InnReCheck"."Evaluation" is '評等';
comment on column "InnReCheck"."CustTypeItem" is '客戶別';
comment on column "InnReCheck"."UsageItem" is '用途別';
comment on column "InnReCheck"."CityItem" is '地區別';
comment on column "InnReCheck"."ReChkUnit" is '應覆審單位';
comment on column "InnReCheck"."Remark" is '備註';
comment on column "InnReCheck"."CreateDate" is '建檔日期時間';
comment on column "InnReCheck"."CreateEmpNo" is '建檔人員';
comment on column "InnReCheck"."LastUpdate" is '最後更新日期時間';
comment on column "InnReCheck"."LastUpdateEmpNo" is '最後更新人員';
drop table "InsuComm" purge;

create table "InsuComm" (
  "InsuYearMonth" decimal(6, 0) default 0 not null,
  "InsuCommSeq" decimal(6, 0) default 0 not null,
  "ManagerCode" varchar2(3),
  "NowInsuNo" varchar2(20),
  "BatchNo" varchar2(20),
  "InsuType" decimal(2, 0) default 0 not null,
  "InsuSignDate" decimal(8, 0) default 0 not null,
  "InsuredName" nvarchar2(60),
  "InsuredAddr" nvarchar2(60),
  "InsuredTeleph" varchar2(20),
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "InsuCate" decimal(2, 0) default 0 not null,
  "InsuPrem" decimal(14, 0) default 0 not null,
  "CommRate" decimal(5, 3) default 0 not null,
  "Commision" decimal(14, 0) default 0 not null,
  "TotInsuPrem" decimal(14, 0) default 0 not null,
  "TotComm" decimal(14, 0) default 0 not null,
  "RecvSeq" varchar2(14),
  "ChargeDate" decimal(8, 0) default 0 not null,
  "CommDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FireOfficer" varchar2(6),
  "EmpId" varchar2(10),
  "EmpName" nvarchar2(20),
  "DueAmt" decimal(14, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InsuComm" add constraint "InsuComm_PK" primary key("InsuYearMonth", "InsuCommSeq");

comment on table "InsuComm" is '火險佣金檔';
comment on column "InsuComm"."InsuYearMonth" is '年月份';
comment on column "InsuComm"."InsuCommSeq" is '佣金媒體檔序號';
comment on column "InsuComm"."ManagerCode" is '經紀人代號';
comment on column "InsuComm"."NowInsuNo" is '保單號碼';
comment on column "InsuComm"."BatchNo" is '批號';
comment on column "InsuComm"."InsuType" is '險別';
comment on column "InsuComm"."InsuSignDate" is '簽單日期';
comment on column "InsuComm"."InsuredName" is '被保險人';
comment on column "InsuComm"."InsuredAddr" is '被保險人地址';
comment on column "InsuComm"."InsuredTeleph" is '被保險人電話';
comment on column "InsuComm"."InsuStartDate" is '起保日期';
comment on column "InsuComm"."InsuEndDate" is '到期日期';
comment on column "InsuComm"."InsuCate" is '險種';
comment on column "InsuComm"."InsuPrem" is '保費';
comment on column "InsuComm"."CommRate" is '佣金率';
comment on column "InsuComm"."Commision" is '佣金';
comment on column "InsuComm"."TotInsuPrem" is '合計保費';
comment on column "InsuComm"."TotComm" is '合計佣金';
comment on column "InsuComm"."RecvSeq" is '收件號碼';
comment on column "InsuComm"."ChargeDate" is '收費日期';
comment on column "InsuComm"."CommDate" is '佣金日期';
comment on column "InsuComm"."CustNo" is '戶號';
comment on column "InsuComm"."FacmNo" is '額度';
comment on column "InsuComm"."FireOfficer" is '火險服務';
comment on column "InsuComm"."EmpId" is '統一編號';
comment on column "InsuComm"."EmpName" is '員工姓名';
comment on column "InsuComm"."DueAmt" is '應領金額';
comment on column "InsuComm"."CreateDate" is '建檔日期時間';
comment on column "InsuComm"."CreateEmpNo" is '建檔人員';
comment on column "InsuComm"."LastUpdate" is '最後更新日期時間';
comment on column "InsuComm"."LastUpdateEmpNo" is '最後更新人員';
drop table "InsuOrignal" purge;

create table "InsuOrignal" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OrigInsuNo" varchar2(17),
  "EndoInsuNo" varchar2(17),
  "InsuCompany" varchar2(2),
  "InsuTypeCode" varchar2(2),
  "FireInsuCovrg" decimal(16, 2) default 0 not null,
  "EthqInsuCovrg" decimal(16, 2) default 0 not null,
  "FireInsuPrem" decimal(16, 2) default 0 not null,
  "EthqInsuPrem" decimal(16, 2) default 0 not null,
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InsuOrignal" add constraint "InsuOrignal_PK" primary key("ClCode1", "ClCode2", "ClNo", "OrigInsuNo", "EndoInsuNo");

comment on table "InsuOrignal" is '火險初保檔';
comment on column "InsuOrignal"."ClCode1" is '擔保品-代號1';
comment on column "InsuOrignal"."ClCode2" is '擔保品-代號2';
comment on column "InsuOrignal"."ClNo" is '擔保品編號';
comment on column "InsuOrignal"."OrigInsuNo" is '原始保險單號碼';
comment on column "InsuOrignal"."EndoInsuNo" is '批單號碼';
comment on column "InsuOrignal"."InsuCompany" is '保險公司';
comment on column "InsuOrignal"."InsuTypeCode" is '保險類別';
comment on column "InsuOrignal"."FireInsuCovrg" is '火災險保險金額';
comment on column "InsuOrignal"."EthqInsuCovrg" is '地震險保險金額';
comment on column "InsuOrignal"."FireInsuPrem" is '火災險保費';
comment on column "InsuOrignal"."EthqInsuPrem" is '地震險保費';
comment on column "InsuOrignal"."InsuStartDate" is '保險起日';
comment on column "InsuOrignal"."InsuEndDate" is '保險迄日';
comment on column "InsuOrignal"."CreateDate" is '建檔日期時間';
comment on column "InsuOrignal"."CreateEmpNo" is '建檔人員';
comment on column "InsuOrignal"."LastUpdate" is '最後更新日期時間';
comment on column "InsuOrignal"."LastUpdateEmpNo" is '最後更新人員';
drop table "InsuRenew" purge;

create table "InsuRenew" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PrevInsuNo" varchar2(17),
  "EndoInsuNo" varchar2(17),
  "InsuYearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "NowInsuNo" varchar2(17),
  "OrigInsuNo" varchar2(17),
  "RenewCode" decimal(1, 0) default 0 not null,
  "InsuCompany" varchar2(2),
  "InsuTypeCode" varchar2(2),
  "RepayCode" decimal(1, 0) default 0 not null,
  "FireInsuCovrg" decimal(14, 0) default 0 not null,
  "EthqInsuCovrg" decimal(14, 0) default 0 not null,
  "FireInsuPrem" decimal(14, 0) default 0 not null,
  "EthqInsuPrem" decimal(14, 0) default 0 not null,
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "TotInsuPrem" decimal(14, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "NotiTempFg" varchar2(1),
  "StatusCode" decimal(1, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "OvduNo" decimal(10, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InsuRenew" add constraint "InsuRenew_PK" primary key("ClCode1", "ClCode2", "ClNo", "PrevInsuNo", "EndoInsuNo");

create index "InsuRenew_Index1" on "InsuRenew"("InsuYearMonth" asc, "RepayCode" asc, "AcDate" asc, "StatusCode" asc);

create index "InsuRenew_Index2" on "InsuRenew"("NowInsuNo" asc);

create index "InsuRenew_Index3" on "InsuRenew"("InsuCompany" asc);

create index "InsuRenew_Index4" on "InsuRenew"("InsuTypeCode" asc);

create index "InsuRenew_Index5" on "InsuRenew"("InsuEndDate" asc);

comment on table "InsuRenew" is '火險單續保檔';
comment on column "InsuRenew"."ClCode1" is '擔保品-代號1';
comment on column "InsuRenew"."ClCode2" is '擔保品-代號2';
comment on column "InsuRenew"."ClNo" is '擔保品編號';
comment on column "InsuRenew"."PrevInsuNo" is '原保單號碼';
comment on column "InsuRenew"."EndoInsuNo" is '批單號碼';
comment on column "InsuRenew"."InsuYearMonth" is '火險單年月';
comment on column "InsuRenew"."CustNo" is '借款人戶號';
comment on column "InsuRenew"."FacmNo" is '額度';
comment on column "InsuRenew"."NowInsuNo" is '保險單號碼';
comment on column "InsuRenew"."OrigInsuNo" is '原始保險單號碼';
comment on column "InsuRenew"."RenewCode" is '是否續保';
comment on column "InsuRenew"."InsuCompany" is '保險公司';
comment on column "InsuRenew"."InsuTypeCode" is '保險類別';
comment on column "InsuRenew"."RepayCode" is '繳款方式';
comment on column "InsuRenew"."FireInsuCovrg" is '火災險保險金額';
comment on column "InsuRenew"."EthqInsuCovrg" is '地震險保險金額';
comment on column "InsuRenew"."FireInsuPrem" is '火災險保費';
comment on column "InsuRenew"."EthqInsuPrem" is '地震險保費';
comment on column "InsuRenew"."InsuStartDate" is '保險起日';
comment on column "InsuRenew"."InsuEndDate" is '保險迄日';
comment on column "InsuRenew"."TotInsuPrem" is '總保費';
comment on column "InsuRenew"."AcDate" is '會計日期';
comment on column "InsuRenew"."TitaTlrNo" is '經辦';
comment on column "InsuRenew"."TitaTxtNo" is '交易序號';
comment on column "InsuRenew"."NotiTempFg" is '入通知檔';
comment on column "InsuRenew"."StatusCode" is '處理代碼';
comment on column "InsuRenew"."OvduDate" is '轉催收日';
comment on column "InsuRenew"."OvduNo" is '轉催編號';
comment on column "InsuRenew"."CreateDate" is '建檔日期時間';
comment on column "InsuRenew"."CreateEmpNo" is '建檔人員';
comment on column "InsuRenew"."LastUpdate" is '最後更新日期時間';
comment on column "InsuRenew"."LastUpdateEmpNo" is '最後更新人員';
drop table "InsuRenewMediaTemp" purge;

drop sequence "InsuRenewMediaTemp_SEQ";

create table "InsuRenewMediaTemp" (
  "LogNo" decimal(11,0) not null,
  "FireInsuMonth" nvarchar2(6),
  "ReturnCode" nvarchar2(2),
  "InsuCampCode" nvarchar2(2),
  "InsuCustId" nvarchar2(10),
  "InsuCustName" nvarchar2(12),
  "LoanCustId" nvarchar2(10),
  "LoanCustName" nvarchar2(12),
  "PostalCode" nvarchar2(5),
  "Address" nvarchar2(58),
  "BuildingSquare" nvarchar2(9),
  "BuildingCode" nvarchar2(2),
  "BuildingYears" nvarchar2(3),
  "BuildingFloors" nvarchar2(2),
  "RoofCode" nvarchar2(2),
  "BusinessUnit" nvarchar2(4),
  "ClCode1" nvarchar2(1),
  "ClCode2" nvarchar2(2),
  "ClNo" nvarchar2(7),
  "Seq" nvarchar2(2),
  "InsuNo" nvarchar2(16),
  "InsuStartDate" nvarchar2(10),
  "InsuEndDate" nvarchar2(10),
  "FireInsuAmt" nvarchar2(11),
  "FireInsuFee" nvarchar2(7),
  "EqInsuAmt" nvarchar2(7),
  "EqInsuFee" nvarchar2(6),
  "CustNo" nvarchar2(7),
  "FacmNo" nvarchar2(3),
  "Space" nvarchar2(4),
  "SendDate" nvarchar2(14),
  "NewInusNo" nvarchar2(16),
  "NewInsuStartDate" nvarchar2(10),
  "NewInsuEndDate" nvarchar2(10),
  "NewFireInsuAmt" nvarchar2(11),
  "NewFireInsuFee" nvarchar2(7),
  "NewEqInsuAmt" nvarchar2(8),
  "NewEqInsuFee" nvarchar2(6),
  "NewTotalFee" nvarchar2(7),
  "Remark1" nvarchar2(16),
  "MailingAddress" nvarchar2(60),
  "Remark2" nvarchar2(39),
  "SklSalesName" nvarchar2(20),
  "SklUnitCode" nvarchar2(6),
  "SklUnitName" nvarchar2(20),
  "SklSalesCode" nvarchar2(6),
  "RenewTrlCode" nvarchar2(8),
  "RenewUnit" nvarchar2(7),
  "CheckResultA" nvarchar2(30),
  "CheckResultB" nvarchar2(30),
  "CheckResultC" nvarchar2(30),
  "RepayCode" decimal(1, 0) default 0 not null,
  "NoticeFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "InsuRenewMediaTemp" add constraint "InsuRenewMediaTemp_PK" primary key("LogNo");

create sequence "InsuRenewMediaTemp_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

comment on table "InsuRenewMediaTemp" is '火險詢價媒體檔';
comment on column "InsuRenewMediaTemp"."LogNo" is '序號';
comment on column "InsuRenewMediaTemp"."FireInsuMonth" is '火險到期年月';
comment on column "InsuRenewMediaTemp"."ReturnCode" is '回傳碼';
comment on column "InsuRenewMediaTemp"."InsuCampCode" is '保險公司代碼';
comment on column "InsuRenewMediaTemp"."InsuCustId" is '提供人統一編號';
comment on column "InsuRenewMediaTemp"."InsuCustName" is '提供人姓名';
comment on column "InsuRenewMediaTemp"."LoanCustId" is '借款人統一編號';
comment on column "InsuRenewMediaTemp"."LoanCustName" is '借款人姓名';
comment on column "InsuRenewMediaTemp"."PostalCode" is '郵遞區號';
comment on column "InsuRenewMediaTemp"."Address" is '門牌號碼';
comment on column "InsuRenewMediaTemp"."BuildingSquare" is '主建物坪數';
comment on column "InsuRenewMediaTemp"."BuildingCode" is '建物結構代碼';
comment on column "InsuRenewMediaTemp"."BuildingYears" is '建造年份';
comment on column "InsuRenewMediaTemp"."BuildingFloors" is '樓層數';
comment on column "InsuRenewMediaTemp"."RoofCode" is '屋頂結構代碼';
comment on column "InsuRenewMediaTemp"."BusinessUnit" is '營業單位別';
comment on column "InsuRenewMediaTemp"."ClCode1" is '押品別１';
comment on column "InsuRenewMediaTemp"."ClCode2" is '押品別２';
comment on column "InsuRenewMediaTemp"."ClNo" is '押品號碼';
comment on column "InsuRenewMediaTemp"."Seq" is '序號';
comment on column "InsuRenewMediaTemp"."InsuNo" is '保單號碼';
comment on column "InsuRenewMediaTemp"."InsuStartDate" is '保險起日';
comment on column "InsuRenewMediaTemp"."InsuEndDate" is '保險迄日';
comment on column "InsuRenewMediaTemp"."FireInsuAmt" is '火險保額';
comment on column "InsuRenewMediaTemp"."FireInsuFee" is '火險保費';
comment on column "InsuRenewMediaTemp"."EqInsuAmt" is '地震險保額';
comment on column "InsuRenewMediaTemp"."EqInsuFee" is '地震險保費';
comment on column "InsuRenewMediaTemp"."CustNo" is '借款人戶號';
comment on column "InsuRenewMediaTemp"."FacmNo" is '額度編號';
comment on column "InsuRenewMediaTemp"."Space" is '空白';
comment on column "InsuRenewMediaTemp"."SendDate" is '傳檔日期';
comment on column "InsuRenewMediaTemp"."NewInusNo" is '保單號碼(新)';
comment on column "InsuRenewMediaTemp"."NewInsuStartDate" is '保險起日(新)';
comment on column "InsuRenewMediaTemp"."NewInsuEndDate" is '保險迄日(新)';
comment on column "InsuRenewMediaTemp"."NewFireInsuAmt" is '火險保額(新)';
comment on column "InsuRenewMediaTemp"."NewFireInsuFee" is '火險保費(新)';
comment on column "InsuRenewMediaTemp"."NewEqInsuAmt" is '地震險保額(新)';
comment on column "InsuRenewMediaTemp"."NewEqInsuFee" is '地震險保費(新)';
comment on column "InsuRenewMediaTemp"."NewTotalFee" is '總保費(新)';
comment on column "InsuRenewMediaTemp"."Remark1" is '備註一';
comment on column "InsuRenewMediaTemp"."MailingAddress" is '通訊地址';
comment on column "InsuRenewMediaTemp"."Remark2" is '備註二';
comment on column "InsuRenewMediaTemp"."SklSalesName" is '新光人壽業務員名稱';
comment on column "InsuRenewMediaTemp"."SklUnitCode" is '新光人壽單位代號';
comment on column "InsuRenewMediaTemp"."SklUnitName" is '新光人壽單位中文';
comment on column "InsuRenewMediaTemp"."SklSalesCode" is '新光人壽業務員代號';
comment on column "InsuRenewMediaTemp"."RenewTrlCode" is '新產續保經辦代號';
comment on column "InsuRenewMediaTemp"."RenewUnit" is '新產續保單位';
comment on column "InsuRenewMediaTemp"."CheckResultA" is '檢核結果A';
comment on column "InsuRenewMediaTemp"."CheckResultB" is '檢核結果B';
comment on column "InsuRenewMediaTemp"."CheckResultC" is '檢核結果C';
comment on column "InsuRenewMediaTemp"."RepayCode" is '繳款方式';
comment on column "InsuRenewMediaTemp"."NoticeFlag" is '通知方式';
comment on column "InsuRenewMediaTemp"."CreateDate" is '建檔日期時間';
comment on column "InsuRenewMediaTemp"."CreateEmpNo" is '建檔人員';
comment on column "InsuRenewMediaTemp"."LastUpdate" is '最後更新日期時間';
comment on column "InsuRenewMediaTemp"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicAtomDetail" purge;

create table "JcicAtomDetail" (
  "FunctionCode" varchar2(6),
  "DataOrder" decimal(3, 0) default 0 not null,
  "FiledName" nvarchar2(50),
  "FiledType" nvarchar2(20),
  "Remark" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicAtomDetail" add constraint "JcicAtomDetail_PK" primary key("FunctionCode", "DataOrder");

comment on table "JcicAtomDetail" is '債務匯入資料功能明細檔';
comment on column "JcicAtomDetail"."FunctionCode" is '功能代碼';
comment on column "JcicAtomDetail"."DataOrder" is '順序';
comment on column "JcicAtomDetail"."FiledName" is '欄位名稱';
comment on column "JcicAtomDetail"."FiledType" is '格式與長度';
comment on column "JcicAtomDetail"."Remark" is '中文說明';
comment on column "JcicAtomDetail"."CreateDate" is '建檔日期時間';
comment on column "JcicAtomDetail"."CreateEmpNo" is '建檔人員';
comment on column "JcicAtomDetail"."LastUpdate" is '最後更新日期時間';
comment on column "JcicAtomDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicAtomMain" purge;

create table "JcicAtomMain" (
  "FunctionCode" varchar2(6),
  "DataType" nvarchar2(45),
  "Remark" nvarchar2(300),
  "SearchPoint" varchar2(3),
  "FunctionKey" nvarchar2(200),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicAtomMain" add constraint "JcicAtomMain_PK" primary key("FunctionCode");

comment on table "JcicAtomMain" is '債務匯入資料功能主檔';
comment on column "JcicAtomMain"."FunctionCode" is '功能代碼';
comment on column "JcicAtomMain"."DataType" is '功能類別';
comment on column "JcicAtomMain"."Remark" is '功能說明';
comment on column "JcicAtomMain"."SearchPoint" is '查詢點數';
comment on column "JcicAtomMain"."FunctionKey" is '輸入鍵值';
comment on column "JcicAtomMain"."CreateDate" is '建檔日期時間';
comment on column "JcicAtomMain"."CreateEmpNo" is '建檔人員';
comment on column "JcicAtomMain"."LastUpdate" is '最後更新日期時間';
comment on column "JcicAtomMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB080" purge;

create table "JcicB080" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "Filler4" varchar2(4),
  "CustId" varchar2(10),
  "FacmNo" varchar2(50),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmtFx" decimal(10, 0) default 0 not null,
  "DrawdownDate" decimal(5, 0) default 0 not null,
  "MaturityDate" decimal(5, 0) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "UpFacmNo" varchar2(50),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "ClTypeCode" varchar2(2),
  "Filler18" varchar2(24),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB080" add constraint "JcicB080_PK" primary key("DataYM", "BankItem", "FacmNo");

comment on table "JcicB080" is '聯徵授信額度資料檔';
comment on column "JcicB080"."DataYM" is '資料年月';
comment on column "JcicB080"."DataType" is '資料別';
comment on column "JcicB080"."BankItem" is '總行代號';
comment on column "JcicB080"."BranchItem" is '分行代號';
comment on column "JcicB080"."TranCode" is '交易代碼';
comment on column "JcicB080"."Filler4" is '空白';
comment on column "JcicB080"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB080"."FacmNo" is '本階共用額度控制編碼';
comment on column "JcicB080"."CurrencyCode" is '授信幣別';
comment on column "JcicB080"."DrawdownAmt" is '本階訂約金額(台幣)';
comment on column "JcicB080"."DrawdownAmtFx" is '本階訂約金額(外幣)';
comment on column "JcicB080"."DrawdownDate" is '本階額度開始年月';
comment on column "JcicB080"."MaturityDate" is '本階額度約定截止年月';
comment on column "JcicB080"."RecycleCode" is '循環信用註記';
comment on column "JcicB080"."IrrevocableFlag" is '額度可否撤銷';
comment on column "JcicB080"."UpFacmNo" is '上階共用額度控制編碼';
comment on column "JcicB080"."AcctCode" is '科目別';
comment on column "JcicB080"."SubAcctCode" is '科目別註記';
comment on column "JcicB080"."ClTypeCode" is '擔保品類別';
comment on column "JcicB080"."Filler18" is '空白';
comment on column "JcicB080"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB080"."CreateDate" is '建檔日期時間';
comment on column "JcicB080"."CreateEmpNo" is '建檔人員';
comment on column "JcicB080"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB080"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB085" purge;

create table "JcicB085" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "RenewYM" decimal(5, 0) default 0 not null,
  "CustId" varchar2(10),
  "BefBankItem" varchar2(3),
  "BefBranchItem" varchar2(4),
  "Filler6" varchar2(2),
  "BefAcctNo" varchar2(50),
  "AftBankItem" varchar2(3),
  "AftBranchItem" varchar2(4),
  "Filler10" varchar2(2),
  "AftAcctNo" varchar2(50),
  "Filler12" varchar2(25),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB085" add constraint "JcicB085_PK" primary key("DataYM", "BefAcctNo", "AftAcctNo");

comment on table "JcicB085" is '聯徵帳號轉換資料檔';
comment on column "JcicB085"."DataYM" is '資料日期';
comment on column "JcicB085"."DataType" is '資料別';
comment on column "JcicB085"."RenewYM" is '轉換帳號年月';
comment on column "JcicB085"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB085"."BefBankItem" is '轉換前總行代號';
comment on column "JcicB085"."BefBranchItem" is '轉換前分行代號';
comment on column "JcicB085"."Filler6" is '空白';
comment on column "JcicB085"."BefAcctNo" is '轉換前帳號';
comment on column "JcicB085"."AftBankItem" is '轉換後總行代號';
comment on column "JcicB085"."AftBranchItem" is '轉換後分行代號';
comment on column "JcicB085"."Filler10" is '空白';
comment on column "JcicB085"."AftAcctNo" is '轉換後帳號';
comment on column "JcicB085"."Filler12" is '空白';
comment on column "JcicB085"."CreateDate" is '建檔日期時間';
comment on column "JcicB085"."CreateEmpNo" is '建檔人員';
comment on column "JcicB085"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB085"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB090" purge;

create table "JcicB090" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "CustId" varchar2(10),
  "ClActNo" varchar2(50),
  "FacmNo" varchar2(50),
  "GlOverseas" varchar2(2),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB090" add constraint "JcicB090_PK" primary key("DataYM", "CustId", "ClActNo", "FacmNo");

comment on table "JcicB090" is '擔保品關聯檔資料檔';
comment on column "JcicB090"."DataYM" is '資料日期';
comment on column "JcicB090"."DataType" is '資料別';
comment on column "JcicB090"."BankItem" is '總行代號';
comment on column "JcicB090"."BranchItem" is '分行代號';
comment on column "JcicB090"."Filler4" is '空白';
comment on column "JcicB090"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB090"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB090"."FacmNo" is '額度控制編碼';
comment on column "JcicB090"."GlOverseas" is '海外不動產擔保品資料註記';
comment on column "JcicB090"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB090"."CreateDate" is '建檔日期時間';
comment on column "JcicB090"."CreateEmpNo" is '建檔人員';
comment on column "JcicB090"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB090"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB091" purge;

create table "JcicB091" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(7, 0) default 0 not null,
  "LoanLimitAmt" decimal(10, 0) default 0 not null,
  "SettingDate" decimal(7, 0) default 0 not null,
  "CompanyId" varchar2(8),
  "CompanyCountry" varchar2(2),
  "StockCode" varchar2(10),
  "Currency" varchar2(3),
  "PledgeEndYM" decimal(5, 0) default 0 not null,
  "DispPrice" decimal(8, 0) default 0 not null,
  "Filler19" varchar2(14),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB091" add constraint "JcicB091_PK" primary key("DataYM", "ClActNo", "OwnerId", "CompanyId");

comment on table "JcicB091" is '聯徵有價證券(股票除外)擔保品明細檔';
comment on column "JcicB091"."DataYM" is '資料日期';
comment on column "JcicB091"."DataType" is '資料別';
comment on column "JcicB091"."BankItem" is '總行代號';
comment on column "JcicB091"."BranchItem" is '分行代號';
comment on column "JcicB091"."Filler4" is '空白';
comment on column "JcicB091"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB091"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB091"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB091"."EvaAmt" is '鑑估值';
comment on column "JcicB091"."EvaDate" is '鑑估日期';
comment on column "JcicB091"."LoanLimitAmt" is '可放款值';
comment on column "JcicB091"."SettingDate" is '設質日期';
comment on column "JcicB091"."CompanyId" is '發行機構 BAN';
comment on column "JcicB091"."CompanyCountry" is '發行機構所在國別';
comment on column "JcicB091"."StockCode" is '證券代號';
comment on column "JcicB091"."Currency" is '幣別';
comment on column "JcicB091"."PledgeEndYM" is '到期年月';
comment on column "JcicB091"."DispPrice" is '處分價格';
comment on column "JcicB091"."Filler19" is '空白';
comment on column "JcicB091"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB091"."CreateDate" is '建檔日期時間';
comment on column "JcicB091"."CreateEmpNo" is '建檔人員';
comment on column "JcicB091"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB091"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB092" purge;

create table "JcicB092" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" varchar2(9),
  "EvaDate" decimal(5, 0) default 0 not null,
  "LoanLimitAmt" varchar2(9),
  "SettingDate" decimal(5, 0) default 0 not null,
  "MonthSettingAmt" varchar2(9),
  "SettingSeq" decimal(1, 0) default 0 not null,
  "SettingAmt" varchar2(9),
  "PreSettingAmt" varchar2(9),
  "DispPrice" varchar2(9),
  "IssueEndDate" decimal(5, 0) default 0 not null,
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "LandNo1" decimal(4, 0) default 0 not null,
  "LandNo2" decimal(4, 0) default 0 not null,
  "BdNo1" decimal(5, 0) default 0 not null,
  "BdNo2" decimal(3, 0) default 0 not null,
  "Zip" varchar2(5),
  "InsuFg" varchar2(1),
  "LVITax" varchar2(9),
  "LVITaxYearMonth" varchar2(5),
  "ContractPrice" varchar2(9),
  "ContractDate" varchar2(7),
  "ParkingTypeCode" varchar2(1),
  "Area" varchar2(9),
  "LandOwnedArea" varchar2(10),
  "BdTypeCode" varchar2(2),
  "Filler33" varchar2(29),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB092" add constraint "JcicB092_PK" primary key("DataYM", "ClActNo", "ClTypeJCIC", "OwnerId", "CityJCICCode", "AreaJCICCode", "IrCode", "LandNo1", "LandNo2", "BdNo1", "BdNo2");

comment on table "JcicB092" is '聯徵不動產擔保品明細檔';
comment on column "JcicB092"."DataYM" is '資料日期';
comment on column "JcicB092"."DataType" is '資料別';
comment on column "JcicB092"."BankItem" is '總行代號';
comment on column "JcicB092"."BranchItem" is '分行代號';
comment on column "JcicB092"."Filler4" is '空白';
comment on column "JcicB092"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB092"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB092"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB092"."EvaAmt" is '鑑估(總市)值';
comment on column "JcicB092"."EvaDate" is '鑑估日期';
comment on column "JcicB092"."LoanLimitAmt" is '可放款值';
comment on column "JcicB092"."SettingDate" is '設定日期';
comment on column "JcicB092"."MonthSettingAmt" is '本行本月設定金額';
comment on column "JcicB092"."SettingSeq" is '本行設定抵押順位';
comment on column "JcicB092"."SettingAmt" is '本行累計已設定總金額';
comment on column "JcicB092"."PreSettingAmt" is '其他債權人已設定金額';
comment on column "JcicB092"."DispPrice" is '處分價格';
comment on column "JcicB092"."IssueEndDate" is '權利到期年月';
comment on column "JcicB092"."CityJCICCode" is '縣市別';
comment on column "JcicB092"."AreaJCICCode" is '鄉鎮市區別';
comment on column "JcicB092"."IrCode" is '段、小段號';
comment on column "JcicB092"."LandNo1" is '地號-前四碼';
comment on column "JcicB092"."LandNo2" is '地號-後四碼';
comment on column "JcicB092"."BdNo1" is '建號-前五碼';
comment on column "JcicB092"."BdNo2" is '建號-後三碼';
comment on column "JcicB092"."Zip" is '郵遞區號';
comment on column "JcicB092"."InsuFg" is '是否有保險';
comment on column "JcicB092"."LVITax" is '預估應計土地增值稅';
comment on column "JcicB092"."LVITaxYearMonth" is '應計土地增值稅之預估年月';
comment on column "JcicB092"."ContractPrice" is '買賣契約價格';
comment on column "JcicB092"."ContractDate" is '買賣契約日期';
comment on column "JcicB092"."ParkingTypeCode" is '停車位形式';
comment on column "JcicB092"."Area" is '車位單獨登記面積';
comment on column "JcicB092"."LandOwnedArea" is '土地持份面積';
comment on column "JcicB092"."BdTypeCode" is '建物類別';
comment on column "JcicB092"."Filler33" is '空白';
comment on column "JcicB092"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB092"."CreateDate" is '建檔日期時間';
comment on column "JcicB092"."CreateEmpNo" is '建檔人員';
comment on column "JcicB092"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB092"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB093" purge;

create table "JcicB093" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(5, 0) default 0 not null,
  "LoanLimitAmt" decimal(8, 0) default 0 not null,
  "SettingDate" decimal(5, 0) default 0 not null,
  "MonthSettingAmt" decimal(8, 0) default 0 not null,
  "SettingSeq" decimal(1, 0) default 0 not null,
  "SettingAmt" decimal(8, 0) default 0 not null,
  "PreSettingAmt" decimal(8, 0) default 0 not null,
  "DispPrice" decimal(8, 0) default 0 not null,
  "IssueEndDate" decimal(5, 0) default 0 not null,
  "InsuFg" varchar2(1),
  "Filler19" varchar2(17),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB093" add constraint "JcicB093_PK" primary key("DataYM", "ClActNo");

comment on table "JcicB093" is '聯徵動產及貴重物品擔保品明細檔';
comment on column "JcicB093"."DataYM" is '資料日期';
comment on column "JcicB093"."DataType" is '資料別';
comment on column "JcicB093"."BankItem" is '總行代號';
comment on column "JcicB093"."BranchItem" is '分行代號';
comment on column "JcicB093"."Filler4" is '空白';
comment on column "JcicB093"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB093"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB093"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB093"."EvaAmt" is '鑑估值';
comment on column "JcicB093"."EvaDate" is '鑑估日期';
comment on column "JcicB093"."LoanLimitAmt" is '可放款值';
comment on column "JcicB093"."SettingDate" is '設定日期';
comment on column "JcicB093"."MonthSettingAmt" is '本行本月設定金額';
comment on column "JcicB093"."SettingSeq" is '本月設定抵押順位';
comment on column "JcicB093"."SettingAmt" is '本行累計已設定總金額';
comment on column "JcicB093"."PreSettingAmt" is '其他債權人前已設定金額';
comment on column "JcicB093"."DispPrice" is '處分價格';
comment on column "JcicB093"."IssueEndDate" is '權利到期年月';
comment on column "JcicB093"."InsuFg" is '是否有保險';
comment on column "JcicB093"."Filler19" is '空白';
comment on column "JcicB093"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB093"."CreateDate" is '建檔日期時間';
comment on column "JcicB093"."CreateEmpNo" is '建檔人員';
comment on column "JcicB093"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB093"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB094" purge;

create table "JcicB094" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(7, 0) default 0 not null,
  "LoanLimitAmt" decimal(10, 0) default 0 not null,
  "SettingDate" decimal(7, 0) default 0 not null,
  "CompanyId" varchar2(8),
  "CompanyCountry" varchar2(2),
  "StockCode" varchar2(10),
  "StockType" decimal(1, 0) default 0 not null,
  "Currency" varchar2(3),
  "SettingBalance" decimal(14, 0) default 0 not null,
  "LoanBal" decimal(10, 0) default 0 not null,
  "InsiderJobTitle" varchar2(1),
  "InsiderPosition" varchar2(1),
  "LegalPersonId" varchar2(10),
  "DispPrice" decimal(8, 0) default 0 not null,
  "Filler19" varchar2(14),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB094" add constraint "JcicB094_PK" primary key("DataYM", "ClActNo", "OwnerId", "CompanyId", "StockCode", "StockType");

comment on table "JcicB094" is '聯徵股票擔保品明細檔';
comment on column "JcicB094"."DataYM" is '資料日期';
comment on column "JcicB094"."DataType" is '資料別';
comment on column "JcicB094"."BankItem" is '總行代號';
comment on column "JcicB094"."BranchItem" is '分行代號';
comment on column "JcicB094"."Filler4" is '空白';
comment on column "JcicB094"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB094"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB094"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB094"."EvaAmt" is '鑑估值';
comment on column "JcicB094"."EvaDate" is '鑑估日期';
comment on column "JcicB094"."LoanLimitAmt" is '可放款值';
comment on column "JcicB094"."SettingDate" is '設質日期';
comment on column "JcicB094"."CompanyId" is '發行機構 BAN';
comment on column "JcicB094"."CompanyCountry" is '發行機構所在國別';
comment on column "JcicB094"."StockCode" is '股票代號';
comment on column "JcicB094"."StockType" is '股票種類';
comment on column "JcicB094"."Currency" is '幣別';
comment on column "JcicB094"."SettingBalance" is '設定股數餘額';
comment on column "JcicB094"."LoanBal" is '股票質押授信餘額';
comment on column "JcicB094"."InsiderJobTitle" is '公司內部人職稱';
comment on column "JcicB094"."InsiderPosition" is '公司內部人身分註記';
comment on column "JcicB094"."LegalPersonId" is '公司內部人法定關係人';
comment on column "JcicB094"."DispPrice" is '處分價格';
comment on column "JcicB094"."Filler19" is '空白';
comment on column "JcicB094"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB094"."CreateDate" is '建檔日期時間';
comment on column "JcicB094"."CreateEmpNo" is '建檔人員';
comment on column "JcicB094"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB094"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB095" purge;

create table "JcicB095" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "OwnerId" varchar2(10),
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "BdNo1" decimal(5, 0) default 0 not null,
  "BdNo2" decimal(3, 0) default 0 not null,
  "CityName" varchar2(36),
  "AreaName" varchar2(36),
  "Addr" varchar2(228),
  "BdMainUseCode" varchar2(1),
  "BdMtrlCode" varchar2(1),
  "BdSubUsageCode" varchar2(6),
  "TotalFloor" decimal(3, 0) default 0 not null,
  "FloorNo" varchar2(7),
  "BdDate" varchar2(7),
  "TotalArea" decimal(10, 2) default 0 not null,
  "FloorArea" decimal(10, 2) default 0 not null,
  "BdSubArea" decimal(10, 2) default 0 not null,
  "PublicArea" decimal(10, 2) default 0 not null,
  "Filler33" varchar2(44),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB095" add constraint "JcicB095_PK" primary key("DataYM", "ClActNo", "OwnerId", "CityJCICCode", "AreaJCICCode", "IrCode", "BdNo1", "BdNo2");

comment on table "JcicB095" is '聯徵不動產擔保品明細-建號附加檔';
comment on column "JcicB095"."DataYM" is '資料日期';
comment on column "JcicB095"."DataType" is '資料別';
comment on column "JcicB095"."BankItem" is '總行代號';
comment on column "JcicB095"."BranchItem" is '分行代號';
comment on column "JcicB095"."Filler4" is '空白';
comment on column "JcicB095"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB095"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB095"."CityJCICCode" is '縣市別';
comment on column "JcicB095"."AreaJCICCode" is '鄉鎮市區別';
comment on column "JcicB095"."IrCode" is '段、小段號';
comment on column "JcicB095"."BdNo1" is '建號-前五碼';
comment on column "JcicB095"."BdNo2" is '建號-後三碼';
comment on column "JcicB095"."CityName" is '縣市名稱';
comment on column "JcicB095"."AreaName" is '鄉鎮市區名稱';
comment on column "JcicB095"."Addr" is '村里/街路/段/巷/弄/號/樓';
comment on column "JcicB095"."BdMainUseCode" is '主要用途';
comment on column "JcicB095"."BdMtrlCode" is '主要建材(結構體)';
comment on column "JcicB095"."BdSubUsageCode" is '附屬建物用途';
comment on column "JcicB095"."TotalFloor" is '層數(標的所在樓高)';
comment on column "JcicB095"."FloorNo" is '層次(標的所在樓層)';
comment on column "JcicB095"."BdDate" is '建築完成日期(屋齡)';
comment on column "JcicB095"."TotalArea" is '建物總面積';
comment on column "JcicB095"."FloorArea" is '主建物(層次)面積';
comment on column "JcicB095"."BdSubArea" is '附屬建物面積';
comment on column "JcicB095"."PublicArea" is '共同部份持分面積';
comment on column "JcicB095"."Filler33" is '空白';
comment on column "JcicB095"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB095"."CreateDate" is '建檔日期時間';
comment on column "JcicB095"."CreateEmpNo" is '建檔人員';
comment on column "JcicB095"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB095"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB096" purge;

create table "JcicB096" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "LandSeq" decimal(3, 0) default 0 not null,
  "OwnerId" varchar2(10),
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "LandNo1" decimal(4, 0) default 0 not null,
  "LandNo2" decimal(4, 0) default 0 not null,
  "LandCode" varchar2(1),
  "Area" decimal(10, 2) default 0 not null,
  "LandZoningCode" varchar2(1),
  "LandUsageType" varchar2(2),
  "PostedLandValue" decimal(10, 0) default 0 not null,
  "PostedLandValueYearMonth" decimal(5, 0) default 0 not null,
  "Filler18" varchar2(30),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB096" add constraint "JcicB096_PK" primary key("DataYM", "ClActNo", "LandSeq", "OwnerId", "CityJCICCode", "AreaJCICCode", "IrCode", "LandNo1", "LandNo2");

comment on table "JcicB096" is '聯徵不動產擔保品明細-地號附加檔';
comment on column "JcicB096"."DataYM" is '資料日期';
comment on column "JcicB096"."DataType" is '資料別';
comment on column "JcicB096"."BankItem" is '總行代號';
comment on column "JcicB096"."BranchItem" is '分行代號';
comment on column "JcicB096"."Filler4" is '空白';
comment on column "JcicB096"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB096"."LandSeq" is '土地序號';
comment on column "JcicB096"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB096"."CityJCICCode" is '縣市別';
comment on column "JcicB096"."AreaJCICCode" is '鄉鎮市區別';
comment on column "JcicB096"."IrCode" is '段、小段號';
comment on column "JcicB096"."LandNo1" is '地號-前四碼';
comment on column "JcicB096"."LandNo2" is '地號-後四碼';
comment on column "JcicB096"."LandCode" is '地目';
comment on column "JcicB096"."Area" is '面積';
comment on column "JcicB096"."LandZoningCode" is '使用分區';
comment on column "JcicB096"."LandUsageType" is '使用地類別';
comment on column "JcicB096"."PostedLandValue" is '公告土地現值';
comment on column "JcicB096"."PostedLandValueYearMonth" is '公告土地現值年月';
comment on column "JcicB096"."Filler18" is '空白';
comment on column "JcicB096"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB096"."CreateDate" is '建檔日期時間';
comment on column "JcicB096"."CreateEmpNo" is '建檔人員';
comment on column "JcicB096"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB096"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB201" purge;

create table "JcicB201" (
  "DataYM" decimal(6, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "SubTranCode" varchar2(1),
  "AcctNo" varchar2(50),
  "SeqNo" decimal(2, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "CustId" varchar2(10),
  "CustIdErr" varchar2(1),
  "SuvId" varchar2(10),
  "SuvIdErr" varchar2(1),
  "OverseasId" varchar2(10),
  "IndustryCode" varchar2(6),
  "Filler12" varchar2(3),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "OrigAcctCode" varchar2(1),
  "ConsumeFg" varchar2(1),
  "FinCode" varchar2(1),
  "ProjCode" varchar2(2),
  "NonCreditCode" varchar2(1),
  "UsageCode" varchar2(1),
  "ApproveRate" decimal(7, 5) default 0 not null,
  "DrawdownDate" decimal(5, 0) default 0 not null,
  "MaturityDate" decimal(5, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmtFx" decimal(10, 0) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "FacmNo" varchar2(50),
  "UnDelayBal" decimal(10, 0) default 0 not null,
  "UnDelayBalFx" decimal(10, 0) default 0 not null,
  "DelayBal" decimal(10, 0) default 0 not null,
  "DelayBalFx" decimal(10, 0) default 0 not null,
  "DelayPeriodCode" varchar2(1),
  "RepayCode" varchar2(1),
  "PayAmt" decimal(16, 3) default 0 not null,
  "Principal" decimal(16, 3) default 0 not null,
  "Interest" decimal(16, 3) default 0 not null,
  "Fee" decimal(16, 3) default 0 not null,
  "FirstDelayCode" varchar2(3),
  "SecondDelayCode" varchar2(1),
  "BadDebtCode" varchar2(3),
  "NegStatus" varchar2(3),
  "NegCreditor" varchar2(10),
  "NegNo" varchar2(14),
  "NegTransYM" varchar2(5),
  "Filler443" varchar2(6),
  "ClType" varchar2(1),
  "ClEvaAmt" decimal(10, 0) default 0 not null,
  "ClTypeCode" varchar2(2),
  "SyndKind" varchar2(1),
  "SyndContractDate" varchar2(8),
  "SyndRatio" decimal(5, 2) default 0 not null,
  "Filler51" varchar2(2),
  "Filler52" varchar2(6),
  "PayablesFg" varchar2(1),
  "NegFg" varchar2(1),
  "Filler533" varchar2(1),
  "GuaTypeCode1" varchar2(1),
  "GuaId1" varchar2(10),
  "GuaIdErr1" varchar2(1),
  "GuaRelCode1" varchar2(2),
  "GuaTypeCode2" varchar2(1),
  "GuaId2" varchar2(10),
  "GuaIdErr2" varchar2(1),
  "GuaRelCode2" varchar2(2),
  "GuaTypeCode3" varchar2(1),
  "GuaId3" varchar2(10),
  "GuaIdErr3" varchar2(1),
  "GuaRelCode3" varchar2(2),
  "GuaTypeCode4" varchar2(1),
  "GuaId4" varchar2(10),
  "GuaIdErr4" varchar2(1),
  "GuaRelCode4" varchar2(2),
  "GuaTypeCode5" varchar2(1),
  "GuaId5" varchar2(10),
  "GuaIdErr5" varchar2(1),
  "GuaRelCode5" varchar2(2),
  "Filler741" varchar2(10),
  "Filler742" varchar2(10),
  "BadDebtDate" decimal(5, 0) default 0 not null,
  "SyndCode" varchar2(5),
  "BankruptDate" decimal(7, 0) default 0 not null,
  "BdLoanFg" varchar2(1),
  "SmallAmt" decimal(4, 0) default 0 not null,
  "ExtraAttrCode" varchar2(1),
  "ExtraStatusCode" varchar2(2),
  "Filler74A" varchar2(9),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "DataEnd" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB201" add constraint "JcicB201_PK" primary key("DataYM", "BankItem", "BranchItem", "TranCode", "SubTranCode", "AcctNo", "SeqNo");

comment on table "JcicB201" is '聯徵授信餘額月報資料檔';
comment on column "JcicB201"."DataYM" is '資料年月';
comment on column "JcicB201"."BankItem" is '總行代號';
comment on column "JcicB201"."BranchItem" is '分行代號';
comment on column "JcicB201"."TranCode" is '交易代碼';
comment on column "JcicB201"."SubTranCode" is '帳號屬性註記';
comment on column "JcicB201"."AcctNo" is '本筆撥款帳號';
comment on column "JcicB201"."SeqNo" is '本筆撥款帳號序號';
comment on column "JcicB201"."TotalAmt" is '金額合計';
comment on column "JcicB201"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB201"."CustIdErr" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."SuvId" is '負責人IDN/負責之事業體BAN';
comment on column "JcicB201"."SuvIdErr" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."OverseasId" is '外僑兼具中華民國國籍IDN';
comment on column "JcicB201"."IndustryCode" is '授信戶行業別';
comment on column "JcicB201"."Filler12" is '空白';
comment on column "JcicB201"."AcctCode" is '科目別';
comment on column "JcicB201"."SubAcctCode" is '科目別註記';
comment on column "JcicB201"."OrigAcctCode" is '轉催收款(或呆帳)前原科目別';
comment on column "JcicB201"."ConsumeFg" is '個人消費性貸款註記';
comment on column "JcicB201"."FinCode" is '融資分類';
comment on column "JcicB201"."ProjCode" is '政府專業補助貸款分類';
comment on column "JcicB201"."NonCreditCode" is '不計入授信項目';
comment on column "JcicB201"."UsageCode" is '用途別';
comment on column "JcicB201"."ApproveRate" is '本筆撥款利率';
comment on column "JcicB201"."DrawdownDate" is '本筆撥款開始年月';
comment on column "JcicB201"."MaturityDate" is '本筆撥款約定清償年月';
comment on column "JcicB201"."CurrencyCode" is '授信餘額幣別';
comment on column "JcicB201"."DrawdownAmt" is '訂約金額(台幣)';
comment on column "JcicB201"."DrawdownAmtFx" is '訂約金額(外幣)';
comment on column "JcicB201"."RecycleCode" is '循環信用註記';
comment on column "JcicB201"."IrrevocableFlag" is '額度可否撤銷';
comment on column "JcicB201"."FacmNo" is '上階共用額度控制編碼';
comment on column "JcicB201"."UnDelayBal" is '未逾期/乙類逾期/應予觀察授信餘額(台幣)';
comment on column "JcicB201"."UnDelayBalFx" is '未逾期/乙類逾期/應予觀察授信餘額(外幣)';
comment on column "JcicB201"."DelayBal" is '逾期未還餘額（台幣）';
comment on column "JcicB201"."DelayBalFx" is '逾期未還餘額（外幣）';
comment on column "JcicB201"."DelayPeriodCode" is '逾期期限';
comment on column "JcicB201"."RepayCode" is '本月還款紀錄';
comment on column "JcicB201"."PayAmt" is '本月（累計）應繳金額';
comment on column "JcicB201"."Principal" is '本月收回本金';
comment on column "JcicB201"."Interest" is '本月收取利息';
comment on column "JcicB201"."Fee" is '本月收取其他費用';
comment on column "JcicB201"."FirstDelayCode" is '甲類逾期放款分類';
comment on column "JcicB201"."SecondDelayCode" is '乙類逾期放款分類';
comment on column "JcicB201"."BadDebtCode" is '不良債權處理註記';
comment on column "JcicB201"."NegStatus" is '債權結束註記';
comment on column "JcicB201"."NegCreditor" is '債權處理後新債權人ID/債權轉讓後前手債權人ID/信保基金退理賠信用保證機構BAN';
comment on column "JcicB201"."NegNo" is '債權處理案號';
comment on column "JcicB201"."NegTransYM" is '債權轉讓年月/債權轉讓後原債權機構買回年月';
comment on column "JcicB201"."Filler443" is '空白';
comment on column "JcicB201"."ClType" is '擔保品組合型態';
comment on column "JcicB201"."ClEvaAmt" is '擔保品(合計)鑑估值';
comment on column "JcicB201"."ClTypeCode" is '擔保品類別';
comment on column "JcicB201"."SyndKind" is '國內或國際連貸';
comment on column "JcicB201"."SyndContractDate" is '聯貸合約訂定日期';
comment on column "JcicB201"."SyndRatio" is '聯貸參貸比例';
comment on column "JcicB201"."Filler51" is '空白';
comment on column "JcicB201"."Filler52" is '空白';
comment on column "JcicB201"."PayablesFg" is '代放款註記';
comment on column "JcicB201"."NegFg" is '債務協商註記';
comment on column "JcicB201"."Filler533" is '空白';
comment on column "JcicB201"."GuaTypeCode1" is '共同債務人或債務關係人身份代號1';
comment on column "JcicB201"."GuaId1" is '共同債務人或債務關係人身份統一編號1';
comment on column "JcicB201"."GuaIdErr1" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."GuaRelCode1" is '與主債務人關係1';
comment on column "JcicB201"."GuaTypeCode2" is '共同債務人或債務關係人身份代號2';
comment on column "JcicB201"."GuaId2" is '共同債務人或債務關係人身份統一編號2';
comment on column "JcicB201"."GuaIdErr2" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."GuaRelCode2" is '與主債務人關係2';
comment on column "JcicB201"."GuaTypeCode3" is '共同債務人或債務關係人身份代號3';
comment on column "JcicB201"."GuaId3" is '共同債務人或債務關係人身份統一編號3';
comment on column "JcicB201"."GuaIdErr3" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."GuaRelCode3" is '與主債務人關係3';
comment on column "JcicB201"."GuaTypeCode4" is '共同債務人或債務關係人身份代號4';
comment on column "JcicB201"."GuaId4" is '共同債務人或債務關係人身份統一編號4';
comment on column "JcicB201"."GuaIdErr4" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."GuaRelCode4" is '與主債務人關係4';
comment on column "JcicB201"."GuaTypeCode5" is '共同債務人或債務關係人身份代號5';
comment on column "JcicB201"."GuaId5" is '共同債務人或債務關係人身份統一編號5';
comment on column "JcicB201"."GuaIdErr5" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB201"."GuaRelCode5" is '與主債務人關係5';
comment on column "JcicB201"."Filler741" is '空白';
comment on column "JcicB201"."Filler742" is '空白';
comment on column "JcicB201"."BadDebtDate" is '呆帳轉銷年月';
comment on column "JcicB201"."SyndCode" is '聯貸主辦(管理)行註記';
comment on column "JcicB201"."BankruptDate" is '破產宣告日(或法院裁定開始清算日)';
comment on column "JcicB201"."BdLoanFg" is '建築貸款註記';
comment on column "JcicB201"."SmallAmt" is '授信餘額列報1（千元）之原始金額（元）';
comment on column "JcicB201"."ExtraAttrCode" is '補充揭露案件註記－案件屬性';
comment on column "JcicB201"."ExtraStatusCode" is '補充揭露案件註記－案件情形';
comment on column "JcicB201"."Filler74A" is '空白';
comment on column "JcicB201"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB201"."DataEnd" is '資料結束註記';
comment on column "JcicB201"."CreateDate" is '建檔日期時間';
comment on column "JcicB201"."CreateEmpNo" is '建檔人員';
comment on column "JcicB201"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB201"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB204" purge;

create table "JcicB204" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "DataDate" decimal(7, 0) default 0 not null,
  "AcctNo" varchar2(50),
  "CustId" varchar2(10),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "SubTranCode" varchar2(1),
  "LineAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DBR22Amt" decimal(10, 0) default 0 not null,
  "SeqNo" varchar2(1),
  "Filler13" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB204" add constraint "JcicB204_PK" primary key("DataYMD", "BankItem", "BranchItem", "DataDate", "AcctNo", "CustId", "AcctCode", "SubAcctCode", "SubTranCode", "SeqNo");

comment on table "JcicB204" is '聯徵授信餘額日報檔';
comment on column "JcicB204"."DataYMD" is '資料日期';
comment on column "JcicB204"."BankItem" is '總行代號';
comment on column "JcicB204"."BranchItem" is '分行代號';
comment on column "JcicB204"."DataDate" is '新增核准額度日期／清償日期／額度到期或解約日期';
comment on column "JcicB204"."AcctNo" is '額度控制編碼／帳號';
comment on column "JcicB204"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB204"."AcctCode" is '科目別';
comment on column "JcicB204"."SubAcctCode" is '科目別註記';
comment on column "JcicB204"."SubTranCode" is '交易別';
comment on column "JcicB204"."LineAmt" is '訂約金額';
comment on column "JcicB204"."DrawdownAmt" is '新增核准額度當日動撥／清償金額';
comment on column "JcicB204"."DBR22Amt" is '本筆新增核准額度應計入DBR22倍規範之金額';
comment on column "JcicB204"."SeqNo" is '1~7欄資料值相同之交易序號';
comment on column "JcicB204"."Filler13" is '空白';
comment on column "JcicB204"."CreateDate" is '建檔日期時間';
comment on column "JcicB204"."CreateEmpNo" is '建檔人員';
comment on column "JcicB204"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB204"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB207" purge;

create table "JcicB207" (
  "DataYM" decimal(6, 0) default 0 not null,
  "TranCode" varchar2(1),
  "BankItem" varchar2(3),
  "Filler3" varchar2(4),
  "DataDate" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "CustName" varchar2(30),
  "EName" varchar2(20),
  "Birthday" decimal(7, 0) default 0 not null,
  "RegAddr" varchar2(99),
  "CurrZip" varchar2(5),
  "CurrAddr" varchar2(99),
  "Tel" varchar2(30),
  "Mobile" varchar2(16),
  "Filler14" varchar2(5),
  "EduCode" varchar2(1),
  "OwnedHome" varchar2(1),
  "CurrCompName" varchar2(45),
  "CurrCompId" varchar2(8),
  "JobCode" varchar2(6),
  "CurrCompTel" varchar2(16),
  "JobTitle" varchar2(15),
  "JobTenure" varchar2(2),
  "IncomeOfYearly" decimal(6, 0) default 0 not null,
  "IncomeDataDate" decimal(5, 0) default 0 not null,
  "Sex" varchar2(1),
  "NationalityCode" varchar2(2),
  "PassportNo" varchar2(20),
  "PreTaxNo" varchar2(10),
  "FullCustName" varchar2(300),
  "Filler30" varchar2(36),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB207" add constraint "JcicB207_PK" primary key("DataYM", "BankItem", "CustId");

comment on table "JcicB207" is '聯徵授信戶基本資料檔';
comment on column "JcicB207"."DataYM" is '資料年月';
comment on column "JcicB207"."TranCode" is '交易代碼';
comment on column "JcicB207"."BankItem" is '總行代號';
comment on column "JcicB207"."Filler3" is '空白';
comment on column "JcicB207"."DataDate" is '資料日期';
comment on column "JcicB207"."CustId" is '授信戶IDN';
comment on column "JcicB207"."CustName" is '中文姓名';
comment on column "JcicB207"."EName" is '英文姓名';
comment on column "JcicB207"."Birthday" is '出生日期';
comment on column "JcicB207"."RegAddr" is '戶籍地址';
comment on column "JcicB207"."CurrZip" is '聯絡地址郵遞區號';
comment on column "JcicB207"."CurrAddr" is '聯絡地址';
comment on column "JcicB207"."Tel" is '聯絡電話';
comment on column "JcicB207"."Mobile" is '行動電話';
comment on column "JcicB207"."Filler14" is '空白';
comment on column "JcicB207"."EduCode" is '教育程度代號';
comment on column "JcicB207"."OwnedHome" is '自有住宅有無';
comment on column "JcicB207"."CurrCompName" is '任職機構名稱';
comment on column "JcicB207"."CurrCompId" is '任職機構統一編號';
comment on column "JcicB207"."JobCode" is '職業類別';
comment on column "JcicB207"."CurrCompTel" is '任職機構電話';
comment on column "JcicB207"."JobTitle" is '職位名稱';
comment on column "JcicB207"."JobTenure" is '服務年資';
comment on column "JcicB207"."IncomeOfYearly" is '年收入';
comment on column "JcicB207"."IncomeDataDate" is '年收入資料年月';
comment on column "JcicB207"."Sex" is '性別';
comment on column "JcicB207"."NationalityCode" is '國籍';
comment on column "JcicB207"."PassportNo" is '護照號碼';
comment on column "JcicB207"."PreTaxNo" is '舊有稅籍編號';
comment on column "JcicB207"."FullCustName" is '中文姓名超逾10個字之全名';
comment on column "JcicB207"."Filler30" is '空白';
comment on column "JcicB207"."CreateDate" is '建檔日期時間';
comment on column "JcicB207"."CreateEmpNo" is '建檔人員';
comment on column "JcicB207"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB207"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB211" purge;

create table "JcicB211" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "CustId" varchar2(10),
  "SubTranCode" varchar2(1),
  "AcDate" decimal(7, 0) default 0 not null,
  "AcctNo" varchar2(50),
  "BorxNo" decimal(4, 0) default 0 not null,
  "TxAmt" decimal(10, 0) default 0 not null,
  "LoanBal" decimal(10, 0) default 0 not null,
  "RepayCode" varchar2(1),
  "NegStatus" varchar2(3),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "BadDebtDate" decimal(5, 0) default 0 not null,
  "ConsumeFg" varchar2(1),
  "FinCode" varchar2(1),
  "UsageCode" varchar2(1),
  "Filler18" varchar2(130),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB211" add constraint "JcicB211_PK" primary key("DataYMD", "BankItem", "BranchItem", "CustId", "AcDate", "AcctNo", "BorxNo");

comment on table "JcicB211" is '聯徵每日授信餘額變動資料檔';
comment on column "JcicB211"."DataYMD" is '資料日期';
comment on column "JcicB211"."BankItem" is '總行代號';
comment on column "JcicB211"."BranchItem" is '分行代號';
comment on column "JcicB211"."TranCode" is '交易代碼';
comment on column "JcicB211"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB211"."SubTranCode" is '交易屬性';
comment on column "JcicB211"."AcDate" is '交易日期';
comment on column "JcicB211"."AcctNo" is '本筆撥款／還款帳號';
comment on column "JcicB211"."BorxNo" is '交易內容檔序號';
comment on column "JcicB211"."TxAmt" is '本筆撥款／還款金額';
comment on column "JcicB211"."LoanBal" is '本筆撥款／還款餘額';
comment on column "JcicB211"."RepayCode" is '本筆還款後之還款紀錄';
comment on column "JcicB211"."NegStatus" is '本筆還款後之債權結案註記';
comment on column "JcicB211"."AcctCode" is '科目別';
comment on column "JcicB211"."SubAcctCode" is '科目別註記';
comment on column "JcicB211"."BadDebtDate" is '呆帳轉銷年月';
comment on column "JcicB211"."ConsumeFg" is '個人消費性貸款註記';
comment on column "JcicB211"."FinCode" is '融資業務分類';
comment on column "JcicB211"."UsageCode" is '用途別';
comment on column "JcicB211"."Filler18" is '空白';
comment on column "JcicB211"."CreateDate" is '建檔日期時間';
comment on column "JcicB211"."CreateEmpNo" is '建檔人員';
comment on column "JcicB211"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB211"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicB680" purge;

create table "JcicB680" (
  "DataYM" decimal(6, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "CustId" varchar2(10),
  "CustIdErr" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "Filler6" varchar2(40),
  "Amt" decimal(10, 0) default 0 not null,
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "Filler9" varchar2(54),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB680" add constraint "JcicB680_PK" primary key("DataYM", "TranCode", "CustId", "CustNo", "FacmNo", "BormNo");

comment on table "JcicB680" is '貸款餘額扣除擔保品鑑估值之金額資料檔';
comment on column "JcicB680"."DataYM" is '資料日期';
comment on column "JcicB680"."BankItem" is '總行代號';
comment on column "JcicB680"."BranchItem" is '分行代號';
comment on column "JcicB680"."TranCode" is '交易代碼';
comment on column "JcicB680"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB680"."CustIdErr" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB680"."CustNo" is '借款人戶號';
comment on column "JcicB680"."FacmNo" is '額度編號';
comment on column "JcicB680"."BormNo" is '撥款序號';
comment on column "JcicB680"."Filler6" is '空白';
comment on column "JcicB680"."Amt" is '貸款餘額扣除擔保品鑑估值之金額';
comment on column "JcicB680"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB680"."Filler9" is '空白';
comment on column "JcicB680"."CreateDate" is '建檔日期時間';
comment on column "JcicB680"."CreateEmpNo" is '建檔人員';
comment on column "JcicB680"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB680"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicMonthlyLoanData" purge;

create table "JcicMonthlyLoanData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "Status" decimal(2, 0) default 0 not null,
  "EntCode" varchar2(1),
  "SuvId" varchar2(10),
  "OverseasId" varchar2(10),
  "IndustryCode" varchar2(6),
  "AcctCode" varchar2(3),
  "SubAcctCode" varchar2(1),
  "OrigAcctCode" varchar2(3),
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "IrrevocableFlag" varchar2(1),
  "FinCode" varchar2(1),
  "ProjCode" varchar2(2),
  "NonCreditCode" varchar2(1),
  "UsageCode" varchar2(2),
  "ApproveRate" decimal(6, 4) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "PrevAmt" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "PrevAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "FeeAmtRcv" decimal(16, 2) default 0 not null,
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "PrevRepaidDate" decimal(8, 0) default 0 not null,
  "NextPayIntDate" decimal(8, 0) default 0 not null,
  "NextRepayDate" decimal(8, 0) default 0 not null,
  "IntDelayMon" decimal(3, 0) default 0 not null,
  "RepayDelayMon" decimal(3, 0) default 0 not null,
  "RepaidEndMon" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ClTypeCode" varchar2(3),
  "ClType" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "DispDate" decimal(8, 0) default 0 not null,
  "SyndNo" decimal(3, 0) default 0 not null,
  "SyndCode" varchar2(1),
  "SigningDate" decimal(8, 0) default 0 not null,
  "SyndAmt" decimal(16, 2) default 0 not null,
  "PartAmt" decimal(16, 2) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtSkipFg" varchar2(1),
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicMonthlyLoanData" add constraint "JcicMonthlyLoanData_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "JcicMonthlyLoanData" is '聯徵放款月報資料檔';
comment on column "JcicMonthlyLoanData"."DataYM" is '資料年月';
comment on column "JcicMonthlyLoanData"."CustNo" is '戶號';
comment on column "JcicMonthlyLoanData"."FacmNo" is '額度編號';
comment on column "JcicMonthlyLoanData"."BormNo" is '撥款序號';
comment on column "JcicMonthlyLoanData"."CustId" is '借款人ID / 統編';
comment on column "JcicMonthlyLoanData"."Status" is '戶況';
comment on column "JcicMonthlyLoanData"."EntCode" is '企金別';
comment on column "JcicMonthlyLoanData"."SuvId" is '負責人IDN/負責之事業體BAN';
comment on column "JcicMonthlyLoanData"."OverseasId" is '外僑兼具中華民國國籍IDN';
comment on column "JcicMonthlyLoanData"."IndustryCode" is '授信戶行業別';
comment on column "JcicMonthlyLoanData"."AcctCode" is '科目別';
comment on column "JcicMonthlyLoanData"."SubAcctCode" is '科目別註記';
comment on column "JcicMonthlyLoanData"."OrigAcctCode" is '轉催收款(或呆帳)前原科目別';
comment on column "JcicMonthlyLoanData"."UtilAmt" is '(額度)貸出金額(放款餘額)';
comment on column "JcicMonthlyLoanData"."UtilBal" is '(額度)已動用額度餘額';
comment on column "JcicMonthlyLoanData"."RecycleCode" is '循環動用';
comment on column "JcicMonthlyLoanData"."RecycleDeadline" is '循環動用期限';
comment on column "JcicMonthlyLoanData"."IrrevocableFlag" is '不可撤銷';
comment on column "JcicMonthlyLoanData"."FinCode" is '融資分類';
comment on column "JcicMonthlyLoanData"."ProjCode" is '政府專業補助貸款分類';
comment on column "JcicMonthlyLoanData"."NonCreditCode" is '不計入授信項目';
comment on column "JcicMonthlyLoanData"."UsageCode" is '用途別';
comment on column "JcicMonthlyLoanData"."ApproveRate" is '本筆撥款利率';
comment on column "JcicMonthlyLoanData"."StoreRate" is '計息利率';
comment on column "JcicMonthlyLoanData"."DrawdownDate" is '撥款日期';
comment on column "JcicMonthlyLoanData"."MaturityDate" is '到期日';
comment on column "JcicMonthlyLoanData"."AmortizedCode" is '攤還方式';
comment on column "JcicMonthlyLoanData"."CurrencyCode" is '幣別';
comment on column "JcicMonthlyLoanData"."DrawdownAmt" is '撥款金額';
comment on column "JcicMonthlyLoanData"."LoanBal" is '放款餘額';
comment on column "JcicMonthlyLoanData"."PrevAmt" is '本月應收本金';
comment on column "JcicMonthlyLoanData"."IntAmt" is '本月應收利息';
comment on column "JcicMonthlyLoanData"."PrevAmtRcv" is '本月實收本金';
comment on column "JcicMonthlyLoanData"."IntAmtRcv" is '本月實收利息';
comment on column "JcicMonthlyLoanData"."FeeAmtRcv" is '本月收取費用';
comment on column "JcicMonthlyLoanData"."PrevPayIntDate" is '上次繳息日';
comment on column "JcicMonthlyLoanData"."PrevRepaidDate" is '上次還本日';
comment on column "JcicMonthlyLoanData"."NextPayIntDate" is '下次繳息日';
comment on column "JcicMonthlyLoanData"."NextRepayDate" is '下次還本日';
comment on column "JcicMonthlyLoanData"."IntDelayMon" is '利息逾期月數';
comment on column "JcicMonthlyLoanData"."RepayDelayMon" is '本金逾期月數';
comment on column "JcicMonthlyLoanData"."RepaidEndMon" is '本金逾到期日(清償期)月數';
comment on column "JcicMonthlyLoanData"."ClCode1" is '主要擔保品代號1';
comment on column "JcicMonthlyLoanData"."ClCode2" is '主要擔保品代號2';
comment on column "JcicMonthlyLoanData"."ClNo" is '主要擔保品編號';
comment on column "JcicMonthlyLoanData"."ClTypeCode" is '主要擔保品類別代碼';
comment on column "JcicMonthlyLoanData"."ClType" is '擔保品組合型態';
comment on column "JcicMonthlyLoanData"."EvaAmt" is '鑑估總值';
comment on column "JcicMonthlyLoanData"."DispDate" is '擔保品處分日期';
comment on column "JcicMonthlyLoanData"."SyndNo" is '聯貸案序號';
comment on column "JcicMonthlyLoanData"."SyndCode" is '聯貸案類型';
comment on column "JcicMonthlyLoanData"."SigningDate" is '聯貸合約訂定日期';
comment on column "JcicMonthlyLoanData"."SyndAmt" is '聯貸總金額';
comment on column "JcicMonthlyLoanData"."PartAmt" is '參貸金額';
comment on column "JcicMonthlyLoanData"."OvduDate" is '轉催收日期';
comment on column "JcicMonthlyLoanData"."BadDebtDate" is '轉呆帳日期';
comment on column "JcicMonthlyLoanData"."BadDebtSkipFg" is '不報送呆帳記號';
comment on column "JcicMonthlyLoanData"."AcBookCode" is '帳冊別';
comment on column "JcicMonthlyLoanData"."AcSubBookCode" is '區隔帳冊';
comment on column "JcicMonthlyLoanData"."CreateDate" is '建檔日期時間';
comment on column "JcicMonthlyLoanData"."CreateEmpNo" is '建檔人員';
comment on column "JcicMonthlyLoanData"."LastUpdate" is '最後更新日期時間';
comment on column "JcicMonthlyLoanData"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicRel" purge;

create table "JcicRel" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "RelYM" decimal(5, 0) default 0 not null,
  "TranCode" varchar2(1),
  "CustId" varchar2(8),
  "Filler6" varchar2(1),
  "RelId" varchar2(8),
  "Filler8" varchar2(1),
  "RelationCode" varchar2(3),
  "Filler10" varchar2(5),
  "EndCode" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicRel" add constraint "JcicRel_PK" primary key("DataYMD", "BankItem", "BranchItem", "CustId", "RelId", "TranCode");

comment on table "JcicRel" is '聯徵授信「同一關係企業及集團企業」資料報送檔';
comment on column "JcicRel"."DataYMD" is '資料年月日';
comment on column "JcicRel"."BankItem" is '總行代號';
comment on column "JcicRel"."BranchItem" is '分行代號';
comment on column "JcicRel"."RelYM" is '客戶填表年月';
comment on column "JcicRel"."TranCode" is '報送時機';
comment on column "JcicRel"."CustId" is '授信企業統編';
comment on column "JcicRel"."Filler6" is '空白';
comment on column "JcicRel"."RelId" is '關係企業統編';
comment on column "JcicRel"."Filler8" is '空白';
comment on column "JcicRel"."RelationCode" is '關係企業關係代號';
comment on column "JcicRel"."Filler10" is '空白';
comment on column "JcicRel"."EndCode" is '結束註記碼';
comment on column "JcicRel"."CreateDate" is '建檔日期時間';
comment on column "JcicRel"."CreateEmpNo" is '建檔人員';
comment on column "JcicRel"."LastUpdate" is '最後更新日期時間';
comment on column "JcicRel"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ040" purge;

create table "JcicZ040" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "RbDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "RefBankId" nvarchar2(3),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ040" add constraint "JcicZ040_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ040_Index1" on "JcicZ040"("SubmitKey" asc);

create index "JcicZ040_Index2" on "JcicZ040"("CustId" asc);

create index "JcicZ040_Index3" on "JcicZ040"("RcDate" asc);

comment on table "JcicZ040" is '前置協商受理申請暨請求回報償權通知資料';
comment on column "JcicZ040"."TranKey" is '交易代碼';
comment on column "JcicZ040"."SubmitKey" is '報送單位代號';
comment on column "JcicZ040"."CustId" is '債務人IDN';
comment on column "JcicZ040"."RcDate" is '協商申請日';
comment on column "JcicZ040"."RbDate" is '止息基準日';
comment on column "JcicZ040"."ApplyType" is '受理方式';
comment on column "JcicZ040"."RefBankId" is '轉介金融機構代號';
comment on column "JcicZ040"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ040"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ040"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ040"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ040"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ040"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ040"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ040"."Ukey" is '流水號';
comment on column "JcicZ040"."CreateDate" is '建檔日期時間';
comment on column "JcicZ040"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ040"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ040"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ040Log" purge;

create table "JcicZ040Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "RbDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "RefBankId" nvarchar2(3),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ040Log" add constraint "JcicZ040Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ040Log" is '前置協商受理申請暨請求回報償權通知資料';
comment on column "JcicZ040Log"."Ukey" is '流水號';
comment on column "JcicZ040Log"."TxSeq" is '交易序號';
comment on column "JcicZ040Log"."TranKey" is '交易代碼';
comment on column "JcicZ040Log"."RbDate" is '止息基準日';
comment on column "JcicZ040Log"."ApplyType" is '受理方式';
comment on column "JcicZ040Log"."RefBankId" is '轉介金融機構代號';
comment on column "JcicZ040Log"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ040Log"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ040Log"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ040Log"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ040Log"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ040Log"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ040Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ040Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ040Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ040Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ040Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ041" purge;

create table "JcicZ041" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ScDate" decimal(8, 0) default 0 not null,
  "NegoStartDate" decimal(8, 0) default 0 not null,
  "NonFinClaimAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ041" add constraint "JcicZ041_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ041_Index1" on "JcicZ041"("SubmitKey" asc);

create index "JcicZ041_Index2" on "JcicZ041"("CustId" asc);

create index "JcicZ041_Index3" on "JcicZ041"("RcDate" asc);

comment on table "JcicZ041" is '協商開始暨停催通知資料';
comment on column "JcicZ041"."TranKey" is '交易代碼';
comment on column "JcicZ041"."SubmitKey" is '報送單位代號';
comment on column "JcicZ041"."CustId" is '債務人IDN';
comment on column "JcicZ041"."RcDate" is '協商申請日';
comment on column "JcicZ041"."ScDate" is '停催日期';
comment on column "JcicZ041"."NegoStartDate" is '協商開始日';
comment on column "JcicZ041"."NonFinClaimAmt" is '非金融機構債權金額';
comment on column "JcicZ041"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ041"."Ukey" is '流水號';
comment on column "JcicZ041"."CreateDate" is '建檔日期時間';
comment on column "JcicZ041"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ041"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ041"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ041Log" purge;

create table "JcicZ041Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ScDate" decimal(8, 0) default 0 not null,
  "NegoStartDate" decimal(8, 0) default 0 not null,
  "NonFinClaimAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ041Log" add constraint "JcicZ041Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ041Log" is '協商開始暨停催通知資料';
comment on column "JcicZ041Log"."Ukey" is '流水號';
comment on column "JcicZ041Log"."TxSeq" is '交易序號';
comment on column "JcicZ041Log"."TranKey" is '交易代碼';
comment on column "JcicZ041Log"."ScDate" is '停催日期';
comment on column "JcicZ041Log"."NegoStartDate" is '協商開始日';
comment on column "JcicZ041Log"."NonFinClaimAmt" is '非金融機構債權金額';
comment on column "JcicZ041Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ041Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ041Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ041Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ041Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ042" purge;

create table "JcicZ042" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ReceExpAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "ReceCashAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "ReceCreditAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ042" add constraint "JcicZ042_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode");

create index "JcicZ042_Index1" on "JcicZ042"("SubmitKey" asc);

create index "JcicZ042_Index2" on "JcicZ042"("CustId" asc);

create index "JcicZ042_Index3" on "JcicZ042"("RcDate" asc);

create index "JcicZ042_Index4" on "JcicZ042"("MaxMainCode" asc);

comment on table "JcicZ042" is '回報無擔保債權金額資料';
comment on column "JcicZ042"."TranKey" is '交易代碼';
comment on column "JcicZ042"."SubmitKey" is '報送單位代號';
comment on column "JcicZ042"."CustId" is '債務人IDN';
comment on column "JcicZ042"."RcDate" is '協商申請日';
comment on column "JcicZ042"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ042"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ042"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ042"."ExpLoanAmt" is '信用貸款對內本息餘額';
comment on column "JcicZ042"."Civil323ExpAmt" is '依民法第323條計算之信用貸款本息餘額';
comment on column "JcicZ042"."ReceExpAmt" is '信用貸款最近一期繳款金額';
comment on column "JcicZ042"."CashCardAmt" is '現金卡放款對內本息餘額';
comment on column "JcicZ042"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ042"."ReceCashAmt" is '現金卡最近一期繳款金額';
comment on column "JcicZ042"."CreditCardAmt" is '信用卡對內本息餘額';
comment on column "JcicZ042"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ042"."ReceCreditAmt" is '信用卡最近一期繳款金額';
comment on column "JcicZ042"."ReceExpPrin" is '信用貸款本金';
comment on column "JcicZ042"."ReceExpInte" is '信用貸款利息';
comment on column "JcicZ042"."ReceExpPena" is '信用貸款違約金';
comment on column "JcicZ042"."ReceExpOther" is '信用貸款其他費用';
comment on column "JcicZ042"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ042"."CashCardInte" is '信金卡利息';
comment on column "JcicZ042"."CashCardPena" is '信金卡違約金';
comment on column "JcicZ042"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ042"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ042"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ042"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ042"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ042"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ042"."Ukey" is '流水號';
comment on column "JcicZ042"."CreateDate" is '建檔日期時間';
comment on column "JcicZ042"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ042"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ042"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ042Log" purge;

create table "JcicZ042Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ReceExpAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "ReceCashAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "ReceCreditAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ042Log" add constraint "JcicZ042Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ042Log" is '回報無擔保債權金額資料';
comment on column "JcicZ042Log"."Ukey" is '流水號';
comment on column "JcicZ042Log"."TxSeq" is '交易序號';
comment on column "JcicZ042Log"."TranKey" is '交易代碼';
comment on column "JcicZ042Log"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ042Log"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ042Log"."ExpLoanAmt" is '信用貸款對內本息餘額';
comment on column "JcicZ042Log"."Civil323ExpAmt" is '依民法第323條計算之信用貸款本息餘額';
comment on column "JcicZ042Log"."ReceExpAmt" is '信用貸款最近一期繳款金額';
comment on column "JcicZ042Log"."CashCardAmt" is '現金卡放款對內本息餘額';
comment on column "JcicZ042Log"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ042Log"."ReceCashAmt" is '現金卡最近一期繳款金額';
comment on column "JcicZ042Log"."CreditCardAmt" is '信用卡對內本息餘額';
comment on column "JcicZ042Log"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ042Log"."ReceCreditAmt" is '信用卡最近一期繳款金額';
comment on column "JcicZ042Log"."ReceExpPrin" is '信用貸款本金';
comment on column "JcicZ042Log"."ReceExpInte" is '信用貸款利息';
comment on column "JcicZ042Log"."ReceExpPena" is '信用貸款違約金';
comment on column "JcicZ042Log"."ReceExpOther" is '信用貸款其他費用';
comment on column "JcicZ042Log"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ042Log"."CashCardInte" is '信金卡利息';
comment on column "JcicZ042Log"."CashCardPena" is '信金卡違約金';
comment on column "JcicZ042Log"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ042Log"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ042Log"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ042Log"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ042Log"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ042Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ042Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ042Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ042Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ042Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ043" purge;

create table "JcicZ043" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" varchar2(3),
  "Account" varchar2(50),
  "CollateralType" varchar2(2),
  "OriginLoanAmt" decimal(12, 0) default 0 not null,
  "CreditBalance" decimal(12, 0) default 0 not null,
  "PerPeriordAmt" decimal(10, 0) default 0 not null,
  "LastPayAmt" decimal(10, 0) default 0 not null,
  "LastPayDate" decimal(8, 0) default 0 not null,
  "OutstandAmt" decimal(10, 0) default 0 not null,
  "RepayPerMonDay" decimal(2, 0) default 0 not null,
  "ContractStartYM" decimal(6, 0) default 0 not null,
  "ContractEndYM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ043" add constraint "JcicZ043_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode", "Account");

create index "JcicZ043_Index1" on "JcicZ043"("SubmitKey" asc);

create index "JcicZ043_Index2" on "JcicZ043"("CustId" asc);

create index "JcicZ043_Index3" on "JcicZ043"("RcDate" asc);

create index "JcicZ043_Index4" on "JcicZ043"("MaxMainCode" asc);

create index "JcicZ043_Index5" on "JcicZ043"("Account" asc);

comment on table "JcicZ043" is '回報有擔保債權金額資料';
comment on column "JcicZ043"."TranKey" is '交易代碼';
comment on column "JcicZ043"."SubmitKey" is '報送單位代號';
comment on column "JcicZ043"."CustId" is '債務人IDN';
comment on column "JcicZ043"."RcDate" is '協商申請日';
comment on column "JcicZ043"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ043"."Account" is '帳號';
comment on column "JcicZ043"."CollateralType" is '擔保品類別';
comment on column "JcicZ043"."OriginLoanAmt" is '原借款金額';
comment on column "JcicZ043"."CreditBalance" is '授信餘額';
comment on column "JcicZ043"."PerPeriordAmt" is '每期應付金額';
comment on column "JcicZ043"."LastPayAmt" is '最近一期繳款金額';
comment on column "JcicZ043"."LastPayDate" is '最後繳息日';
comment on column "JcicZ043"."OutstandAmt" is '已到期尚未償還金額';
comment on column "JcicZ043"."RepayPerMonDay" is '每月應還款日';
comment on column "JcicZ043"."ContractStartYM" is '契約起始年月';
comment on column "JcicZ043"."ContractEndYM" is '契約截止年月';
comment on column "JcicZ043"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ043"."Ukey" is '流水號';
comment on column "JcicZ043"."CreateDate" is '建檔日期時間';
comment on column "JcicZ043"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ043"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ043"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ043Log" purge;

create table "JcicZ043Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CollateralType" varchar2(2),
  "OriginLoanAmt" decimal(12, 0) default 0 not null,
  "CreditBalance" decimal(12, 0) default 0 not null,
  "PerPeriordAmt" decimal(10, 0) default 0 not null,
  "LastPayAmt" decimal(10, 0) default 0 not null,
  "LastPayDate" decimal(8, 0) default 0 not null,
  "OutstandAmt" decimal(10, 0) default 0 not null,
  "RepayPerMonDay" decimal(2, 0) default 0 not null,
  "ContractStartYM" decimal(6, 0) default 0 not null,
  "ContractEndYM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ043Log" add constraint "JcicZ043Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ043Log" is '回報有擔保債權金額資料';
comment on column "JcicZ043Log"."Ukey" is '流水號';
comment on column "JcicZ043Log"."TxSeq" is '交易序號';
comment on column "JcicZ043Log"."TranKey" is '交易代碼';
comment on column "JcicZ043Log"."CollateralType" is '擔保品類別';
comment on column "JcicZ043Log"."OriginLoanAmt" is '原借款金額';
comment on column "JcicZ043Log"."CreditBalance" is '授信餘額';
comment on column "JcicZ043Log"."PerPeriordAmt" is '每期應付金額';
comment on column "JcicZ043Log"."LastPayAmt" is '最近一期繳款金額';
comment on column "JcicZ043Log"."LastPayDate" is '最後繳息日';
comment on column "JcicZ043Log"."OutstandAmt" is '已到期尚未償還金額';
comment on column "JcicZ043Log"."RepayPerMonDay" is '每月應還款日';
comment on column "JcicZ043Log"."ContractStartYM" is '契約起始年月';
comment on column "JcicZ043Log"."ContractEndYM" is '契約截止年月';
comment on column "JcicZ043Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ043Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ043Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ043Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ043Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ044" purge;

create table "JcicZ044" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "DebtCode" varchar2(2),
  "NonGageAmt" decimal(9, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "ReceYearIncome" decimal(9, 0) default 0 not null,
  "ReceYear" decimal(4, 0) default 0 not null,
  "ReceYear2Income" decimal(9, 0) default 0 not null,
  "ReceYear2" decimal(4, 0) default 0 not null,
  "CurrentMonthIncome" decimal(9, 0) default 0 not null,
  "LivingCost" decimal(9, 0) default 0 not null,
  "CompName" nvarchar2(40),
  "CompId" varchar2(8),
  "CarCnt" decimal(2, 0) default 0 not null,
  "HouseCnt" decimal(2, 0) default 0 not null,
  "LandCnt" decimal(2, 0) default 0 not null,
  "ChildCnt" decimal(2, 0) default 0 not null,
  "ChildRate" decimal(5, 1) default 0 not null,
  "ParentCnt" decimal(2, 0) default 0 not null,
  "ParentRate" decimal(5, 1) default 0 not null,
  "MouthCnt" decimal(2, 0) default 0 not null,
  "MouthRate" decimal(5, 1) default 0 not null,
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ044" add constraint "JcicZ044_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ044_Index1" on "JcicZ044"("SubmitKey" asc);

create index "JcicZ044_Index2" on "JcicZ044"("CustId" asc);

create index "JcicZ044_Index3" on "JcicZ044"("RcDate" asc);

comment on table "JcicZ044" is '請求同意債務清償方案通知資料';
comment on column "JcicZ044"."TranKey" is '交易代碼';
comment on column "JcicZ044"."SubmitKey" is '報送單位代號';
comment on column "JcicZ044"."CustId" is '債務人IDN';
comment on column "JcicZ044"."RcDate" is '協商申請日';
comment on column "JcicZ044"."DebtCode" is '負債主因';
comment on column "JcicZ044"."NonGageAmt" is '無擔保金融債務協商總金額';
comment on column "JcicZ044"."Period" is '期數';
comment on column "JcicZ044"."Rate" is '利率';
comment on column "JcicZ044"."MonthPayAmt" is '協商方案估計月付金';
comment on column "JcicZ044"."ReceYearIncome" is '最近年度綜合所得總額';
comment on column "JcicZ044"."ReceYear" is '最近年度別';
comment on column "JcicZ044"."ReceYear2Income" is '前二年度綜合所得總額';
comment on column "JcicZ044"."ReceYear2" is '前二年度別';
comment on column "JcicZ044"."CurrentMonthIncome" is '目前每月收入';
comment on column "JcicZ044"."LivingCost" is '生活支出總額';
comment on column "JcicZ044"."CompName" is '目前主要所得來源公司名稱';
comment on column "JcicZ044"."CompId" is '目前主要所得公司統編';
comment on column "JcicZ044"."CarCnt" is '債務人名下車輛數量';
comment on column "JcicZ044"."HouseCnt" is '債務人名下建物筆數';
comment on column "JcicZ044"."LandCnt" is '債務人名下土地筆數';
comment on column "JcicZ044"."ChildCnt" is '撫養子女數';
comment on column "JcicZ044"."ChildRate" is '撫養子女責任比率';
comment on column "JcicZ044"."ParentCnt" is '撫養父母人數';
comment on column "JcicZ044"."ParentRate" is '撫養父母責任比率';
comment on column "JcicZ044"."MouthCnt" is '其他法定撫養人數';
comment on column "JcicZ044"."MouthRate" is '其他法定撫養人之責任比率';
comment on column "JcicZ044"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ044"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ044"."Period2" is '第二段期數';
comment on column "JcicZ044"."Rate2" is '第二階段利率';
comment on column "JcicZ044"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ044"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ044"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ044"."Ukey" is '流水號';
comment on column "JcicZ044"."CreateDate" is '建檔日期時間';
comment on column "JcicZ044"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ044"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ044"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ044Log" purge;

create table "JcicZ044Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DebtCode" varchar2(2),
  "NonGageAmt" decimal(9, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "ReceYearIncome" decimal(9, 0) default 0 not null,
  "ReceYear" decimal(4, 0) default 0 not null,
  "ReceYear2Income" decimal(9, 0) default 0 not null,
  "ReceYear2" decimal(4, 0) default 0 not null,
  "CurrentMonthIncome" decimal(9, 0) default 0 not null,
  "LivingCost" decimal(9, 0) default 0 not null,
  "CompName" nvarchar2(40),
  "CompId" varchar2(8),
  "CarCnt" decimal(2, 0) default 0 not null,
  "HouseCnt" decimal(2, 0) default 0 not null,
  "LandCnt" decimal(2, 0) default 0 not null,
  "ChildCnt" decimal(2, 0) default 0 not null,
  "ChildRate" decimal(5, 1) default 0 not null,
  "ParentCnt" decimal(2, 0) default 0 not null,
  "ParentRate" decimal(5, 1) default 0 not null,
  "MouthCnt" decimal(2, 0) default 0 not null,
  "MouthRate" decimal(5, 1) default 0 not null,
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ044Log" add constraint "JcicZ044Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ044Log" is '請求同意債務清償方案通知資料';
comment on column "JcicZ044Log"."Ukey" is '流水號';
comment on column "JcicZ044Log"."TxSeq" is '交易序號';
comment on column "JcicZ044Log"."TranKey" is '交易代碼';
comment on column "JcicZ044Log"."DebtCode" is '負債主因';
comment on column "JcicZ044Log"."NonGageAmt" is '無擔保金融債務協商總金額';
comment on column "JcicZ044Log"."Period" is '期數';
comment on column "JcicZ044Log"."Rate" is '利率';
comment on column "JcicZ044Log"."MonthPayAmt" is '協商方案估計月付金';
comment on column "JcicZ044Log"."ReceYearIncome" is '最近年度綜合所得總額';
comment on column "JcicZ044Log"."ReceYear" is '最近年度別';
comment on column "JcicZ044Log"."ReceYear2Income" is '前二年度綜合所得總額';
comment on column "JcicZ044Log"."ReceYear2" is '前二年度別';
comment on column "JcicZ044Log"."CurrentMonthIncome" is '目前每月收入';
comment on column "JcicZ044Log"."LivingCost" is '生活支出總額';
comment on column "JcicZ044Log"."CompName" is '目前主要所得來源公司名稱';
comment on column "JcicZ044Log"."CompId" is '目前主要所得公司統編';
comment on column "JcicZ044Log"."CarCnt" is '債務人名下車輛數量';
comment on column "JcicZ044Log"."HouseCnt" is '債務人名下建物筆數';
comment on column "JcicZ044Log"."LandCnt" is '債務人名下土地筆數';
comment on column "JcicZ044Log"."ChildCnt" is '撫養子女數';
comment on column "JcicZ044Log"."ChildRate" is '撫養子女責任比率';
comment on column "JcicZ044Log"."ParentCnt" is '撫養父母人數';
comment on column "JcicZ044Log"."ParentRate" is '撫養父母責任比率';
comment on column "JcicZ044Log"."MouthCnt" is '其他法定撫養人數';
comment on column "JcicZ044Log"."MouthRate" is '其他法定撫養人之責任比率';
comment on column "JcicZ044Log"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ044Log"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ044Log"."Period2" is '第二段期數';
comment on column "JcicZ044Log"."Rate2" is '第二階段利率';
comment on column "JcicZ044Log"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ044Log"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ044Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ044Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ044Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ044Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ044Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ045" purge;

create table "JcicZ045" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "AgreeCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ045" add constraint "JcicZ045_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode");

create index "JcicZ045_Index1" on "JcicZ045"("SubmitKey" asc);

create index "JcicZ045_Index2" on "JcicZ045"("CustId" asc);

create index "JcicZ045_Index3" on "JcicZ045"("RcDate" asc);

create index "JcicZ045_Index4" on "JcicZ045"("MaxMainCode" asc);

comment on table "JcicZ045" is '回報是否同意債務清償方案資料';
comment on column "JcicZ045"."TranKey" is '交易代碼';
comment on column "JcicZ045"."SubmitKey" is '報送單位代號';
comment on column "JcicZ045"."CustId" is '債務人IDN';
comment on column "JcicZ045"."RcDate" is '協商申請日';
comment on column "JcicZ045"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ045"."AgreeCode" is '是否同意債務清償方案';
comment on column "JcicZ045"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ045"."Ukey" is '流水號';
comment on column "JcicZ045"."CreateDate" is '建檔日期時間';
comment on column "JcicZ045"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ045"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ045"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ045Log" purge;

create table "JcicZ045Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ045Log" add constraint "JcicZ045Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ045Log" is '回報是否同意債務清償方案資料';
comment on column "JcicZ045Log"."Ukey" is '流水號';
comment on column "JcicZ045Log"."TxSeq" is '交易序號';
comment on column "JcicZ045Log"."TranKey" is '交易代碼';
comment on column "JcicZ045Log"."AgreeCode" is '是否同意債務清償方案';
comment on column "JcicZ045Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ045Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ045Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ045Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ045Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ046" purge;

create table "JcicZ046" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "CloseCode" varchar2(2),
  "BreakCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ046" add constraint "JcicZ046_PK" primary key("SubmitKey", "CustId", "RcDate", "CloseDate");

create index "JcicZ046_Index1" on "JcicZ046"("SubmitKey" asc);

create index "JcicZ046_Index2" on "JcicZ046"("CustId" asc);

create index "JcicZ046_Index3" on "JcicZ046"("RcDate" asc);

create index "JcicZ046_Index4" on "JcicZ046"("CloseDate" asc);

comment on table "JcicZ046" is '結案通知資料檔案格式';
comment on column "JcicZ046"."TranKey" is '交易代碼';
comment on column "JcicZ046"."SubmitKey" is '報送單位代號';
comment on column "JcicZ046"."CustId" is '債務人IDN';
comment on column "JcicZ046"."RcDate" is '協商申請日';
comment on column "JcicZ046"."CloseCode" is '結案原因代號';
comment on column "JcicZ046"."BreakCode" is '毀諾原因代號';
comment on column "JcicZ046"."CloseDate" is '結案日期';
comment on column "JcicZ046"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ046"."Ukey" is '流水號';
comment on column "JcicZ046"."CreateDate" is '建檔日期時間';
comment on column "JcicZ046"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ046"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ046"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ046Log" purge;

create table "JcicZ046Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "BreakCode" varchar2(2),
  "CloseCode" varchar2(2),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ046Log" add constraint "JcicZ046Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ046Log" is '結案通知資料檔案格式';
comment on column "JcicZ046Log"."Ukey" is '流水號';
comment on column "JcicZ046Log"."TxSeq" is '交易序號';
comment on column "JcicZ046Log"."TranKey" is '交易代碼';
comment on column "JcicZ046Log"."BreakCode" is '毀諾原因代號';
comment on column "JcicZ046Log"."CloseCode" is '結案原因代號';
comment on column "JcicZ046Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ046Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ046Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ046Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ046Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ047" purge;

create table "JcicZ047" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "PassDate" decimal(8, 0) default 0 not null,
  "InterviewDate" decimal(8, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "LimitDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(38),
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ047" add constraint "JcicZ047_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ047_Index1" on "JcicZ047"("SubmitKey" asc);

create index "JcicZ047_Index2" on "JcicZ047"("CustId" asc);

create index "JcicZ047_Index3" on "JcicZ047"("RcDate" asc);

comment on table "JcicZ047" is '金融機構無擔保債務協議資料檔案';
comment on column "JcicZ047"."TranKey" is '交易代碼';
comment on column "JcicZ047"."SubmitKey" is '報送單位代號';
comment on column "JcicZ047"."CustId" is '債務人IDN';
comment on column "JcicZ047"."RcDate" is '協商申請日';
comment on column "JcicZ047"."Period" is '期數';
comment on column "JcicZ047"."Rate" is '利率';
comment on column "JcicZ047"."Civil323ExpAmt" is '依民法第323條計算之信用貸款債務總金額';
comment on column "JcicZ047"."ExpLoanAmt" is '信用貸款債務簽約總金額';
comment on column "JcicZ047"."Civil323CashAmt" is '依民法第323條計算之現金卡債務總金額';
comment on column "JcicZ047"."CashCardAmt" is '現金卡債務簽約總金額';
comment on column "JcicZ047"."Civil323CreditAmt" is '依民法第323條計算之信用卡債務總金額';
comment on column "JcicZ047"."CreditCardAmt" is '信用卡債務簽約總金額';
comment on column "JcicZ047"."Civil323Amt" is '依民法第323條計算之債務總金額';
comment on column "JcicZ047"."TotalAmt" is '簽約總債務金額';
comment on column "JcicZ047"."PassDate" is '協議完成日';
comment on column "JcicZ047"."InterviewDate" is '面談日期';
comment on column "JcicZ047"."SignDate" is '簽約完成日期';
comment on column "JcicZ047"."LimitDate" is '前置協商註記訊息揭露期限';
comment on column "JcicZ047"."FirstPayDate" is '首期應繳款日';
comment on column "JcicZ047"."MonthPayAmt" is '月付金';
comment on column "JcicZ047"."PayAccount" is '繳款帳號';
comment on column "JcicZ047"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ047"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ047"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ047"."Period2" is '第二段期數';
comment on column "JcicZ047"."Rate2" is '第二階段利率';
comment on column "JcicZ047"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ047"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ047"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ047"."Ukey" is '流水號';
comment on column "JcicZ047"."CreateDate" is '建檔日期時間';
comment on column "JcicZ047"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ047"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ047"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ047Log" purge;

create table "JcicZ047Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "PassDate" decimal(8, 0) default 0 not null,
  "InterviewDate" decimal(8, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "LimitDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(38),
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ047Log" add constraint "JcicZ047Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ047Log" is '金融機構無擔保債務協議資料檔案';
comment on column "JcicZ047Log"."Ukey" is '流水號';
comment on column "JcicZ047Log"."TxSeq" is '交易序號';
comment on column "JcicZ047Log"."TranKey" is '交易代碼';
comment on column "JcicZ047Log"."Period" is '期數';
comment on column "JcicZ047Log"."Rate" is '利率';
comment on column "JcicZ047Log"."Civil323ExpAmt" is '依民法第323條計算之信用貸款債務總金額';
comment on column "JcicZ047Log"."ExpLoanAmt" is '信用貸款債務簽約總金額';
comment on column "JcicZ047Log"."Civil323CashAmt" is '依民法第323條計算之現金卡債務總金額';
comment on column "JcicZ047Log"."CashCardAmt" is '現金卡債務簽約總金額';
comment on column "JcicZ047Log"."Civil323CreditAmt" is '依民法第323條計算之信用卡債務總金額';
comment on column "JcicZ047Log"."CreditCardAmt" is '信用卡債務簽約總金額';
comment on column "JcicZ047Log"."Civil323Amt" is '依民法第323條計算之債務總金額';
comment on column "JcicZ047Log"."TotalAmt" is '簽約總債務金額';
comment on column "JcicZ047Log"."PassDate" is '協議完成日';
comment on column "JcicZ047Log"."InterviewDate" is '面談日期';
comment on column "JcicZ047Log"."SignDate" is '簽約完成日期';
comment on column "JcicZ047Log"."LimitDate" is '前置協商註記訊息揭露期限';
comment on column "JcicZ047Log"."FirstPayDate" is '首期應繳款日';
comment on column "JcicZ047Log"."MonthPayAmt" is '月付金';
comment on column "JcicZ047Log"."PayAccount" is '繳款帳號';
comment on column "JcicZ047Log"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ047Log"."GradeType" is '屬二階段還款方案之階段註記';
comment on column "JcicZ047Log"."PayLastAmt" is '第一階段最後一期應繳金額';
comment on column "JcicZ047Log"."Period2" is '第二段期數';
comment on column "JcicZ047Log"."Rate2" is '第二階段利率';
comment on column "JcicZ047Log"."MonthPayAmt2" is '第二階段協商方案估計月付金';
comment on column "JcicZ047Log"."PayLastAmt2" is '第二階段最後一期應繳金額';
comment on column "JcicZ047Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ047Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ047Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ047Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ047Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ048" purge;

create table "JcicZ048" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "CustRegAddr" nvarchar2(114),
  "CustComAddr" nvarchar2(114),
  "CustRegTelNo" varchar2(16),
  "CustComTelNo" varchar2(16),
  "CustMobilNo" varchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ048" add constraint "JcicZ048_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ048_Index1" on "JcicZ048"("SubmitKey" asc);

create index "JcicZ048_Index2" on "JcicZ048"("CustId" asc);

create index "JcicZ048_Index3" on "JcicZ048"("RcDate" asc);

comment on table "JcicZ048" is '債務人基本資料';
comment on column "JcicZ048"."TranKey" is '交易代碼';
comment on column "JcicZ048"."SubmitKey" is '報送單位代號';
comment on column "JcicZ048"."CustId" is '債務人IDN';
comment on column "JcicZ048"."RcDate" is '協商申請日';
comment on column "JcicZ048"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ048"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ048"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ048"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ048"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ048"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ048"."Ukey" is '流水號';
comment on column "JcicZ048"."CreateDate" is '建檔日期時間';
comment on column "JcicZ048"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ048"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ048"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ048Log" purge;

create table "JcicZ048Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CustRegAddr" nvarchar2(114),
  "CustComAddr" nvarchar2(114),
  "CustRegTelNo" varchar2(16),
  "CustComTelNo" varchar2(16),
  "CustMobilNo" varchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ048Log" add constraint "JcicZ048Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ048Log" is '債務人基本資料';
comment on column "JcicZ048Log"."Ukey" is '流水號';
comment on column "JcicZ048Log"."TxSeq" is '交易序號';
comment on column "JcicZ048Log"."TranKey" is '交易代碼';
comment on column "JcicZ048Log"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ048Log"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ048Log"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ048Log"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ048Log"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ048Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ048Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ048Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ048Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ048Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ049" purge;

create table "JcicZ049" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ClaimStatus" decimal(1, 0) default 0 not null,
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(6),
  "CourtCaseNo" nvarchar2(20),
  "Approve" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ049" add constraint "JcicZ049_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ049_Index1" on "JcicZ049"("SubmitKey" asc);

create index "JcicZ049_Index2" on "JcicZ049"("CustId" asc);

create index "JcicZ049_Index3" on "JcicZ049"("RcDate" asc);

comment on table "JcicZ049" is '債務清償方案法院認可資料檔案';
comment on column "JcicZ049"."TranKey" is '交易代碼';
comment on column "JcicZ049"."SubmitKey" is '報送單位代號';
comment on column "JcicZ049"."CustId" is '債務人IDN';
comment on column "JcicZ049"."RcDate" is '協商申請日';
comment on column "JcicZ049"."ClaimStatus" is '案件進度';
comment on column "JcicZ049"."ApplyDate" is '遞狀日';
comment on column "JcicZ049"."CourtCode" is '承審法院代碼';
comment on column "JcicZ049"."Year" is '年度別';
comment on column "JcicZ049"."CourtDiv" is '法院承審股別';
comment on column "JcicZ049"."CourtCaseNo" is '法院案號';
comment on column "JcicZ049"."Approve" is '法院認可與否';
comment on column "JcicZ049"."ClaimDate" is '法院裁定日期';
comment on column "JcicZ049"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ049"."Ukey" is '流水號';
comment on column "JcicZ049"."CreateDate" is '建檔日期時間';
comment on column "JcicZ049"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ049"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ049"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ049Log" purge;

create table "JcicZ049Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ClaimStatus" decimal(1, 0) default 0 not null,
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(6),
  "CourtCaseNo" nvarchar2(20),
  "Approve" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ049Log" add constraint "JcicZ049Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ049Log" is '債務清償方案法院認可資料檔案';
comment on column "JcicZ049Log"."Ukey" is '流水號';
comment on column "JcicZ049Log"."TxSeq" is '交易序號';
comment on column "JcicZ049Log"."TranKey" is '交易代碼';
comment on column "JcicZ049Log"."ClaimStatus" is '案件進度';
comment on column "JcicZ049Log"."ApplyDate" is '遞狀日';
comment on column "JcicZ049Log"."CourtCode" is '承審法院代碼';
comment on column "JcicZ049Log"."Year" is '年度別';
comment on column "JcicZ049Log"."CourtDiv" is '法院承審股別';
comment on column "JcicZ049Log"."CourtCaseNo" is '法院案號';
comment on column "JcicZ049Log"."Approve" is '法院認可與否';
comment on column "JcicZ049Log"."ClaimDate" is '法院裁定日期';
comment on column "JcicZ049Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ049Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ049Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ049Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ049Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ050" purge;

create table "JcicZ050" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "Status" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "SecondRepayYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ050" add constraint "JcicZ050_PK" primary key("CustId", "RcDate", "PayDate", "SubmitKey");

create index "JcicZ050_Index1" on "JcicZ050"("CustId" asc);

create index "JcicZ050_Index2" on "JcicZ050"("RcDate" asc);

create index "JcicZ050_Index3" on "JcicZ050"("PayDate" asc);

create index "JcicZ050_Index4" on "JcicZ050"("SubmitKey" asc);

comment on table "JcicZ050" is '債務人繳款資料檔案';
comment on column "JcicZ050"."TranKey" is '交易代碼';
comment on column "JcicZ050"."SubmitKey" is '報送單位代號';
comment on column "JcicZ050"."CustId" is '債務人IDN';
comment on column "JcicZ050"."RcDate" is '協商申請日';
comment on column "JcicZ050"."PayDate" is '繳款日期';
comment on column "JcicZ050"."PayAmt" is '本次繳款金額';
comment on column "JcicZ050"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ050"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ050"."Status" is '債權結案註記';
comment on column "JcicZ050"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ050"."Ukey" is '流水號';
comment on column "JcicZ050"."SecondRepayYM" is '進入第二階梯還款年月';
comment on column "JcicZ050"."CreateDate" is '建檔日期時間';
comment on column "JcicZ050"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ050"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ050"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ050Log" purge;

create table "JcicZ050Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "Status" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "SecondRepayYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ050Log" add constraint "JcicZ050Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ050Log" is '債務人繳款資料檔案';
comment on column "JcicZ050Log"."Ukey" is '流水號';
comment on column "JcicZ050Log"."TxSeq" is '交易序號';
comment on column "JcicZ050Log"."TranKey" is '交易代碼';
comment on column "JcicZ050Log"."PayAmt" is '本次繳款金額';
comment on column "JcicZ050Log"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ050Log"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ050Log"."Status" is '債權結案註記';
comment on column "JcicZ050Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ050Log"."SecondRepayYM" is '進入第二階梯還款年月';
comment on column "JcicZ050Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ050Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ050Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ050Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ051" purge;

create table "JcicZ051" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "DelayCode" nvarchar2(1),
  "DelayYM" decimal(6, 0) default 0 not null,
  "DelayDesc" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ051" add constraint "JcicZ051_PK" primary key("SubmitKey", "CustId", "RcDate", "DelayYM");

create index "JcicZ051_Index1" on "JcicZ051"("SubmitKey" asc);

create index "JcicZ051_Index2" on "JcicZ051"("CustId" asc);

create index "JcicZ051_Index3" on "JcicZ051"("RcDate" asc);

create index "JcicZ051_Index4" on "JcicZ051"("DelayYM" asc);

comment on table "JcicZ051" is '延期繳款（喘息期）資料檔案';
comment on column "JcicZ051"."TranKey" is '交易代碼';
comment on column "JcicZ051"."SubmitKey" is '報送單位代號';
comment on column "JcicZ051"."CustId" is '債務人IDN';
comment on column "JcicZ051"."RcDate" is '協商申請日';
comment on column "JcicZ051"."DelayCode" is '延期繳款原因';
comment on column "JcicZ051"."DelayYM" is '延期繳款年月';
comment on column "JcicZ051"."DelayDesc" is '延期繳款案情說明';
comment on column "JcicZ051"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ051"."Ukey" is '流水號';
comment on column "JcicZ051"."CreateDate" is '建檔日期時間';
comment on column "JcicZ051"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ051"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ051"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ051Log" purge;

create table "JcicZ051Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DelayCode" nvarchar2(1),
  "DelayDesc" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ051Log" add constraint "JcicZ051Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ051Log" is '延期繳款（喘息期）資料檔案';
comment on column "JcicZ051Log"."Ukey" is '流水號';
comment on column "JcicZ051Log"."TxSeq" is '交易序號';
comment on column "JcicZ051Log"."TranKey" is '交易代碼';
comment on column "JcicZ051Log"."DelayCode" is '延期繳款原因';
comment on column "JcicZ051Log"."DelayDesc" is '延期繳款案情說明';
comment on column "JcicZ051Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ051Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ051Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ051Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ051Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ052" purge;

create table "JcicZ052" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "BankCode1" nvarchar2(3),
  "DataCode1" nvarchar2(2),
  "BankCode2" nvarchar2(3),
  "DataCode2" nvarchar2(2),
  "BankCode3" nvarchar2(3),
  "DataCode3" nvarchar2(2),
  "BankCode4" nvarchar2(3),
  "DataCode4" nvarchar2(2),
  "BankCode5" nvarchar2(3),
  "DataCode5" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ052" add constraint "JcicZ052_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ052_Index1" on "JcicZ052"("SubmitKey" asc);

create index "JcicZ052_Index2" on "JcicZ052"("CustId" asc);

create index "JcicZ052_Index3" on "JcicZ052"("RcDate" asc);

comment on table "JcicZ052" is '前置協商相關資料報送例外處理';
comment on column "JcicZ052"."TranKey" is '交易代碼';
comment on column "JcicZ052"."SubmitKey" is '報送單位代號';
comment on column "JcicZ052"."CustId" is '債務人IDN';
comment on column "JcicZ052"."RcDate" is '協商申請日';
comment on column "JcicZ052"."BankCode1" is '補報送債權機構代號1';
comment on column "JcicZ052"."DataCode1" is '補報送檔案格式資料別1';
comment on column "JcicZ052"."BankCode2" is '補報送債權機構代號2';
comment on column "JcicZ052"."DataCode2" is '補報送檔案格式資料別2';
comment on column "JcicZ052"."BankCode3" is '補報送債權機構代號3';
comment on column "JcicZ052"."DataCode3" is '補報送檔案格式資料別3';
comment on column "JcicZ052"."BankCode4" is '補報送債權機構代號4';
comment on column "JcicZ052"."DataCode4" is '補報送檔案格式資料別4';
comment on column "JcicZ052"."BankCode5" is '補報送債權機構代號5';
comment on column "JcicZ052"."DataCode5" is '補報送檔案格式資料別5';
comment on column "JcicZ052"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ052"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ052"."Ukey" is '流水號';
comment on column "JcicZ052"."CreateDate" is '建檔日期時間';
comment on column "JcicZ052"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ052"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ052"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ052Log" purge;

create table "JcicZ052Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "BankCode1" nvarchar2(3),
  "DataCode1" nvarchar2(2),
  "BankCode2" nvarchar2(3),
  "DataCode2" nvarchar2(2),
  "BankCode3" nvarchar2(3),
  "DataCode3" nvarchar2(2),
  "BankCode4" nvarchar2(3),
  "DataCode4" nvarchar2(2),
  "BankCode5" nvarchar2(3),
  "DataCode5" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ052Log" add constraint "JcicZ052Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ052Log" is '前置協商相關資料報送例外處理';
comment on column "JcicZ052Log"."Ukey" is '流水號';
comment on column "JcicZ052Log"."TxSeq" is '交易序號';
comment on column "JcicZ052Log"."TranKey" is '交易代碼';
comment on column "JcicZ052Log"."BankCode1" is '補報送債權機構代號1';
comment on column "JcicZ052Log"."DataCode1" is '補報送檔案格式資料別1';
comment on column "JcicZ052Log"."BankCode2" is '補報送債權機構代號2';
comment on column "JcicZ052Log"."DataCode2" is '補報送檔案格式資料別2';
comment on column "JcicZ052Log"."BankCode3" is '補報送債權機構代號3';
comment on column "JcicZ052Log"."DataCode3" is '補報送檔案格式資料別3';
comment on column "JcicZ052Log"."BankCode4" is '補報送債權機構代號4';
comment on column "JcicZ052Log"."DataCode4" is '補報送檔案格式資料別4';
comment on column "JcicZ052Log"."BankCode5" is '補報送債權機構代號5';
comment on column "JcicZ052Log"."DataCode5" is '補報送檔案格式資料別5';
comment on column "JcicZ052Log"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ052Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ052Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ052Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ052Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ052Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ053" purge;

create table "JcicZ053" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "AgreeSend" varchar2(1),
  "AgreeSendData1" nvarchar2(2),
  "AgreeSendData2" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ053" add constraint "JcicZ053_PK" primary key("SubmitKey", "CustId", "RcDate", "MaxMainCode");

create index "JcicZ053_Index1" on "JcicZ053"("SubmitKey" asc);

create index "JcicZ053_Index2" on "JcicZ053"("CustId" asc);

create index "JcicZ053_Index3" on "JcicZ053"("RcDate" asc);

create index "JcicZ053_Index4" on "JcicZ053"("MaxMainCode" asc);

comment on table "JcicZ053" is '同意報送例外處理檔案';
comment on column "JcicZ053"."TranKey" is '交易代碼';
comment on column "JcicZ053"."SubmitKey" is '報送單位代號';
comment on column "JcicZ053"."CustId" is '債務人IDN';
comment on column "JcicZ053"."RcDate" is '協商申請日';
comment on column "JcicZ053"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ053"."AgreeSend" is '是否同意報送例外處理檔案格式';
comment on column "JcicZ053"."AgreeSendData1" is '同意補報送檔案格式資料別1';
comment on column "JcicZ053"."AgreeSendData2" is '同意補報送檔案格式資料別2';
comment on column "JcicZ053"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ053"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ053"."Ukey" is '流水號';
comment on column "JcicZ053"."CreateDate" is '建檔日期時間';
comment on column "JcicZ053"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ053"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ053"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ053Log" purge;

create table "JcicZ053Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeSend" varchar2(1),
  "AgreeSendData1" nvarchar2(2),
  "AgreeSendData2" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ053Log" add constraint "JcicZ053Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ053Log" is '同意報送例外處理檔案';
comment on column "JcicZ053Log"."Ukey" is '流水號';
comment on column "JcicZ053Log"."TxSeq" is '交易序號';
comment on column "JcicZ053Log"."TranKey" is '交易代碼';
comment on column "JcicZ053Log"."AgreeSend" is '是否同意報送例外處理檔案格式';
comment on column "JcicZ053Log"."AgreeSendData1" is '同意補報送檔案格式資料別1';
comment on column "JcicZ053Log"."AgreeSendData2" is '同意補報送檔案格式資料別2';
comment on column "JcicZ053Log"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ053Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ053Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ053Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ053Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ053Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ054" purge;

create table "JcicZ054" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ054" add constraint "JcicZ054_PK" primary key("CustId", "SubmitKey", "RcDate", "MaxMainCode", "PayOffDate");

create index "JcicZ054_Index1" on "JcicZ054"("CustId" asc);

create index "JcicZ054_Index2" on "JcicZ054"("SubmitKey" asc);

create index "JcicZ054_Index3" on "JcicZ054"("RcDate" asc);

create index "JcicZ054_Index4" on "JcicZ054"("MaxMainCode" asc);

create index "JcicZ054_Index5" on "JcicZ054"("PayOffDate" asc);

comment on table "JcicZ054" is '單獨全數受清償資料檔案';
comment on column "JcicZ054"."TranKey" is '交易代碼';
comment on column "JcicZ054"."CustId" is '債務人IDN';
comment on column "JcicZ054"."SubmitKey" is '報送單位代號';
comment on column "JcicZ054"."RcDate" is '協商申請日';
comment on column "JcicZ054"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ054"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ054"."PayOffDate" is '單獨全數受清償日期';
comment on column "JcicZ054"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ054"."Ukey" is '流水號';
comment on column "JcicZ054"."CreateDate" is '建檔日期時間';
comment on column "JcicZ054"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ054"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ054"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ054Log" purge;

create table "JcicZ054Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayOffResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ054Log" add constraint "JcicZ054Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ054Log" is '單獨全數受清償資料檔案';
comment on column "JcicZ054Log"."Ukey" is '流水號';
comment on column "JcicZ054Log"."TxSeq" is '交易序號';
comment on column "JcicZ054Log"."TranKey" is '交易代碼';
comment on column "JcicZ054Log"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ054Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ054Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ054Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ054Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ054Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ055" purge;

create table "JcicZ055" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "CaseStatus" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayEndDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "IsImplement" varchar2(1),
  "InspectName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ055" add constraint "JcicZ055_PK" primary key("SubmitKey", "CustId", "CaseStatus", "ClaimDate", "CourtCode");

create index "JcicZ055_Index1" on "JcicZ055"("SubmitKey" asc);

create index "JcicZ055_Index2" on "JcicZ055"("CustId" asc);

create index "JcicZ055_Index3" on "JcicZ055"("CaseStatus" asc);

create index "JcicZ055_Index4" on "JcicZ055"("ClaimDate" asc);

create index "JcicZ055_Index5" on "JcicZ055"("CourtCode" asc);

comment on table "JcicZ055" is '消債條例更生案件資料報送';
comment on column "JcicZ055"."TranKey" is '交易代碼';
comment on column "JcicZ055"."CustId" is '債務人IDN';
comment on column "JcicZ055"."SubmitKey" is '報送單位代號';
comment on column "JcicZ055"."CaseStatus" is '案件狀態';
comment on column "JcicZ055"."ClaimDate" is '裁定日或履行完畢日或發文日';
comment on column "JcicZ055"."CourtCode" is '承審法院代碼';
comment on column "JcicZ055"."Year" is '年度別';
comment on column "JcicZ055"."CourtDiv" is '法院承審股別';
comment on column "JcicZ055"."CourtCaseNo" is '法院案號';
comment on column "JcicZ055"."PayDate" is '更生方案首期應繳款日';
comment on column "JcicZ055"."PayEndDate" is '更生方案末期應繳款日';
comment on column "JcicZ055"."Period" is '更生條件(期數)';
comment on column "JcicZ055"."Rate" is '更生條件(利率)';
comment on column "JcicZ055"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ055"."SubAmt" is '更生損失金額';
comment on column "JcicZ055"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ055"."SaveDate" is '保全處分起始日';
comment on column "JcicZ055"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ055"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ055"."IsImplement" is '是否依更生條件履行';
comment on column "JcicZ055"."InspectName" is '監督人姓名';
comment on column "JcicZ055"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ055"."Ukey" is '流水號';
comment on column "JcicZ055"."CreateDate" is '建檔日期時間';
comment on column "JcicZ055"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ055"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ055"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ055Log" purge;

create table "JcicZ055Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayEndDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "IsImplement" varchar2(1),
  "InspectName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ055Log" add constraint "JcicZ055Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ055Log" is '消債條例更生案件資料報送';
comment on column "JcicZ055Log"."Ukey" is '流水號';
comment on column "JcicZ055Log"."TxSeq" is '交易序號';
comment on column "JcicZ055Log"."TranKey" is '交易代碼';
comment on column "JcicZ055Log"."Year" is '年度別';
comment on column "JcicZ055Log"."CourtDiv" is '法院承審股別';
comment on column "JcicZ055Log"."CourtCaseNo" is '法院案號';
comment on column "JcicZ055Log"."PayDate" is '更生方案首期應繳款日';
comment on column "JcicZ055Log"."PayEndDate" is '更生方案末期應繳款日';
comment on column "JcicZ055Log"."Period" is '更生條件(期數)';
comment on column "JcicZ055Log"."Rate" is '更生條件(利率)';
comment on column "JcicZ055Log"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ055Log"."SubAmt" is '更生損失金額';
comment on column "JcicZ055Log"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ055Log"."SaveDate" is '保全處分起始日';
comment on column "JcicZ055Log"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ055Log"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ055Log"."IsImplement" is '是否依更生條件履行';
comment on column "JcicZ055Log"."InspectName" is '監督人姓名';
comment on column "JcicZ055Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ055Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ055Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ055Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ055Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ056" purge;

create table "JcicZ056" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "CaseStatus" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "Approve" varchar2(1),
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "AdminName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ056" add constraint "JcicZ056_PK" primary key("SubmitKey", "CustId", "CaseStatus", "ClaimDate", "CourtCode");

create index "JcicZ056_Index1" on "JcicZ056"("SubmitKey" asc);

create index "JcicZ056_Index2" on "JcicZ056"("CustId" asc);

create index "JcicZ056_Index3" on "JcicZ056"("CaseStatus" asc);

create index "JcicZ056_Index4" on "JcicZ056"("ClaimDate" asc);

create index "JcicZ056_Index5" on "JcicZ056"("CourtCode" asc);

comment on table "JcicZ056" is '清算案件資料報送';
comment on column "JcicZ056"."TranKey" is '交易代碼';
comment on column "JcicZ056"."CustId" is '債務人IDN';
comment on column "JcicZ056"."SubmitKey" is '報送單位代號';
comment on column "JcicZ056"."CaseStatus" is '案件狀態';
comment on column "JcicZ056"."ClaimDate" is '裁定日期或發文日期';
comment on column "JcicZ056"."CourtCode" is '承審法院代碼';
comment on column "JcicZ056"."Year" is '年度別';
comment on column "JcicZ056"."CourtDiv" is '法院承審股別';
comment on column "JcicZ056"."CourtCaseNo" is '法院案號';
comment on column "JcicZ056"."Approve" is '法院裁定免責確定';
comment on column "JcicZ056"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ056"."SubAmt" is '清算損失金額';
comment on column "JcicZ056"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ056"."SaveDate" is '保全處分起始日';
comment on column "JcicZ056"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ056"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ056"."AdminName" is '管理人姓名';
comment on column "JcicZ056"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ056"."Ukey" is '流水號';
comment on column "JcicZ056"."CreateDate" is '建檔日期時間';
comment on column "JcicZ056"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ056"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ056"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ056Log" purge;

create table "JcicZ056Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "Approve" varchar2(1),
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "AdminName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ056Log" add constraint "JcicZ056Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ056Log" is '清算案件資料報送';
comment on column "JcicZ056Log"."Ukey" is '流水號';
comment on column "JcicZ056Log"."TxSeq" is '交易序號';
comment on column "JcicZ056Log"."TranKey" is '交易代碼';
comment on column "JcicZ056Log"."Year" is '年度別';
comment on column "JcicZ056Log"."CourtDiv" is '法院承審股別';
comment on column "JcicZ056Log"."CourtCaseNo" is '法院案號';
comment on column "JcicZ056Log"."Approve" is '法院裁定免責確定';
comment on column "JcicZ056Log"."OutstandAmt" is '原始債權金額';
comment on column "JcicZ056Log"."SubAmt" is '清算損失金額';
comment on column "JcicZ056Log"."ClaimStatus1" is '法院裁定保全處分';
comment on column "JcicZ056Log"."SaveDate" is '保全處分起始日';
comment on column "JcicZ056Log"."ClaimStatus2" is '法院裁定撤銷保全處分';
comment on column "JcicZ056Log"."SaveEndDate" is '保全處分撤銷日';
comment on column "JcicZ056Log"."AdminName" is '管理人姓名';
comment on column "JcicZ056Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ056Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ056Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ056Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ056Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ060" purge;

create table "JcicZ060" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "YM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ060" add constraint "JcicZ060_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate");

create index "JcicZ060_Index1" on "JcicZ060"("SubmitKey" asc);

create index "JcicZ060_Index2" on "JcicZ060"("CustId" asc);

create index "JcicZ060_Index3" on "JcicZ060"("RcDate" asc);

create index "JcicZ060_Index4" on "JcicZ060"("ChangePayDate" asc);

comment on table "JcicZ060" is '債務人繳款資料檔案';
comment on column "JcicZ060"."TranKey" is '交易代碼';
comment on column "JcicZ060"."SubmitKey" is '報送單位代號';
comment on column "JcicZ060"."CustId" is '債務人IDN';
comment on column "JcicZ060"."RcDate" is '原前置協商申請日';
comment on column "JcicZ060"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ060"."YM" is '已清分足月期付金年月';
comment on column "JcicZ060"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ060"."Ukey" is '流水號';
comment on column "JcicZ060"."CreateDate" is '建檔日期時間';
comment on column "JcicZ060"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ060"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ060"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ060Log" purge;

create table "JcicZ060Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "YM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ060Log" add constraint "JcicZ060Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ060Log" is '債務人繳款資料檔案';
comment on column "JcicZ060Log"."Ukey" is '流水號';
comment on column "JcicZ060Log"."TxSeq" is '交易序號';
comment on column "JcicZ060Log"."TranKey" is '交易代碼';
comment on column "JcicZ060Log"."YM" is '已清分足月期付金年月';
comment on column "JcicZ060Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ060Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ060Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ060Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ060Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ061" purge;

create table "JcicZ061" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "MaxMainNote" varchar2(1),
  "IsGuarantor" varchar2(1),
  "IsChangePayment" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ061" add constraint "JcicZ061_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate", "MaxMainCode");

create index "JcicZ061_Index1" on "JcicZ061"("SubmitKey" asc);

create index "JcicZ061_Index2" on "JcicZ061"("CustId" asc);

create index "JcicZ061_Index3" on "JcicZ061"("RcDate" asc);

create index "JcicZ061_Index4" on "JcicZ061"("ChangePayDate" asc);

create index "JcicZ061_Index5" on "JcicZ061"("MaxMainCode" asc);

comment on table "JcicZ061" is '回報協商剩餘債權金額資料';
comment on column "JcicZ061"."TranKey" is '交易代碼';
comment on column "JcicZ061"."SubmitKey" is '債權金融機構代號';
comment on column "JcicZ061"."CustId" is '債務人IDN';
comment on column "JcicZ061"."RcDate" is '原前置協商申請日';
comment on column "JcicZ061"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ061"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ061"."ExpBalanceAmt" is '信用貸款協商剩餘債權餘額';
comment on column "JcicZ061"."CashBalanceAmt" is '現金卡協商剩餘債權餘額';
comment on column "JcicZ061"."CreditBalanceAmt" is '信用卡協商剩餘債權餘額';
comment on column "JcicZ061"."MaxMainNote" is '最大債權金融機構報送註記';
comment on column "JcicZ061"."IsGuarantor" is '是否有保證人';
comment on column "JcicZ061"."IsChangePayment" is '是否同意債務人申請變更還款條件方案';
comment on column "JcicZ061"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ061"."Ukey" is '流水號';
comment on column "JcicZ061"."CreateDate" is '建檔日期時間';
comment on column "JcicZ061"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ061"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ061"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ061Log" purge;

create table "JcicZ061Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "MaxMainNote" varchar2(1),
  "IsGuarantor" varchar2(1),
  "IsChangePayment" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ061Log" add constraint "JcicZ061Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ061Log" is '回報協商剩餘債權金額資料';
comment on column "JcicZ061Log"."Ukey" is '流水號';
comment on column "JcicZ061Log"."TxSeq" is '交易序號';
comment on column "JcicZ061Log"."TranKey" is '交易代碼';
comment on column "JcicZ061Log"."ExpBalanceAmt" is '信用貸款協商剩餘債權餘額';
comment on column "JcicZ061Log"."CashBalanceAmt" is '現金卡協商剩餘債權餘額';
comment on column "JcicZ061Log"."CreditBalanceAmt" is '信用卡協商剩餘債權餘額';
comment on column "JcicZ061Log"."MaxMainNote" is '最大債權金融機構報送註記';
comment on column "JcicZ061Log"."IsGuarantor" is '是否有保證人';
comment on column "JcicZ061Log"."IsChangePayment" is '是否同意債務人申請變更還款條件方案';
comment on column "JcicZ061Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ061Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ061Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ061Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ061Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ062" purge;

create table "JcicZ062" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "CompletePeriod" decimal(3, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "ChaRepayAmt" decimal(10, 0) default 0 not null,
  "ChaRepayAgreeDate" decimal(8, 0) default 0 not null,
  "ChaRepayViewDate" decimal(8, 0) default 0 not null,
  "ChaRepayEndDate" decimal(8, 0) default 0 not null,
  "ChaRepayFirstDate" decimal(8, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(76),
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "GradeType" varchar2(1),
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ062" add constraint "JcicZ062_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate");

create index "JcicZ062_Index1" on "JcicZ062"("SubmitKey" asc);

create index "JcicZ062_Index2" on "JcicZ062"("CustId" asc);

create index "JcicZ062_Index3" on "JcicZ062"("RcDate" asc);

create index "JcicZ062_Index4" on "JcicZ062"("ChangePayDate" asc);

comment on table "JcicZ062" is '金融機構無擔保債務變更還款條件協議資料';
comment on column "JcicZ062"."TranKey" is '交易代碼';
comment on column "JcicZ062"."CustId" is '債務人IDN';
comment on column "JcicZ062"."SubmitKey" is '報送單位代號';
comment on column "JcicZ062"."RcDate" is '協商申請日';
comment on column "JcicZ062"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ062"."CompletePeriod" is '變更還款條件已履約期數';
comment on column "JcicZ062"."Period" is '(第一階梯)期數';
comment on column "JcicZ062"."Rate" is '(第一階梯)利率';
comment on column "JcicZ062"."ExpBalanceAmt" is '信用貸款協商剩餘債務簽約餘額';
comment on column "JcicZ062"."CashBalanceAmt" is '現金卡協商剩餘債務簽約餘額';
comment on column "JcicZ062"."CreditBalanceAmt" is '信用卡協商剩餘債務簽約餘額';
comment on column "JcicZ062"."ChaRepayAmt" is '變更還款條件簽約總債務金額';
comment on column "JcicZ062"."ChaRepayAgreeDate" is '變更還款條件協議完成日';
comment on column "JcicZ062"."ChaRepayViewDate" is '變更還款條件面談日期';
comment on column "JcicZ062"."ChaRepayEndDate" is '變更還款條件簽約完成日期';
comment on column "JcicZ062"."ChaRepayFirstDate" is '變更還款條件首期應繳款日';
comment on column "JcicZ062"."PayAccount" is '繳款帳號';
comment on column "JcicZ062"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ062"."MonthPayAmt" is '月付金';
comment on column "JcicZ062"."GradeType" is '屬階梯式還款註記';
comment on column "JcicZ062"."Period2" is '第二階梯期數';
comment on column "JcicZ062"."Rate2" is '第二階梯利率';
comment on column "JcicZ062"."MonthPayAmt2" is '第二階段月付金';
comment on column "JcicZ062"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ062"."Ukey" is '流水號';
comment on column "JcicZ062"."CreateDate" is '建檔日期時間';
comment on column "JcicZ062"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ062"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ062"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ062Log" purge;

create table "JcicZ062Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CompletePeriod" decimal(3, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "ChaRepayAmt" decimal(10, 0) default 0 not null,
  "ChaRepayAgreeDate" decimal(8, 0) default 0 not null,
  "ChaRepayViewDate" decimal(8, 0) default 0 not null,
  "ChaRepayEndDate" decimal(8, 0) default 0 not null,
  "ChaRepayFirstDate" decimal(8, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(76),
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "GradeType" varchar2(1),
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ062Log" add constraint "JcicZ062Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ062Log" is '金融機構無擔保債務變更還款條件協議資料';
comment on column "JcicZ062Log"."Ukey" is '流水號';
comment on column "JcicZ062Log"."TxSeq" is '交易序號';
comment on column "JcicZ062Log"."TranKey" is '交易代碼';
comment on column "JcicZ062Log"."CompletePeriod" is '變更還款條件已履約期數';
comment on column "JcicZ062Log"."Period" is '(第一階梯)期數';
comment on column "JcicZ062Log"."Rate" is '(第一階梯)利率';
comment on column "JcicZ062Log"."ExpBalanceAmt" is '信用貸款協商剩餘債務簽約餘額';
comment on column "JcicZ062Log"."CashBalanceAmt" is '現金卡協商剩餘債務簽約餘額';
comment on column "JcicZ062Log"."CreditBalanceAmt" is '信用卡協商剩餘債務簽約餘額';
comment on column "JcicZ062Log"."ChaRepayAmt" is '變更還款條件簽約總債務金額';
comment on column "JcicZ062Log"."ChaRepayAgreeDate" is '變更還款條件協議完成日';
comment on column "JcicZ062Log"."ChaRepayViewDate" is '變更還款條件面談日期';
comment on column "JcicZ062Log"."ChaRepayEndDate" is '變更還款條件簽約完成日期';
comment on column "JcicZ062Log"."ChaRepayFirstDate" is '變更還款條件首期應繳款日';
comment on column "JcicZ062Log"."PayAccount" is '繳款帳號';
comment on column "JcicZ062Log"."PostAddr" is '最大債權金融機構聲請狀送達地址';
comment on column "JcicZ062Log"."MonthPayAmt" is '月付金';
comment on column "JcicZ062Log"."GradeType" is '屬階梯式還款註記';
comment on column "JcicZ062Log"."Period2" is '第二階梯期數';
comment on column "JcicZ062Log"."Rate2" is '第二階梯利率';
comment on column "JcicZ062Log"."MonthPayAmt2" is '第二階段月付金';
comment on column "JcicZ062Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ062Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ062Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ062Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ062Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ063" purge;

create table "JcicZ063" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "ClosedDate" decimal(8, 0) default 0 not null,
  "ClosedResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ063" add constraint "JcicZ063_PK" primary key("SubmitKey", "CustId", "RcDate", "ChangePayDate");

create index "JcicZ063_Index1" on "JcicZ063"("SubmitKey" asc);

create index "JcicZ063_Index2" on "JcicZ063"("CustId" asc);

create index "JcicZ063_Index3" on "JcicZ063"("RcDate" asc);

create index "JcicZ063_Index4" on "JcicZ063"("ChangePayDate" asc);

comment on table "JcicZ063" is '變更還款方案結案通知資料';
comment on column "JcicZ063"."TranKey" is '交易代碼';
comment on column "JcicZ063"."CustId" is '債務人IDN';
comment on column "JcicZ063"."SubmitKey" is '報送單位代號';
comment on column "JcicZ063"."RcDate" is '原前置協商申請日';
comment on column "JcicZ063"."ChangePayDate" is '申請變更還款條件日';
comment on column "JcicZ063"."ClosedDate" is '變更還款條件結案日期';
comment on column "JcicZ063"."ClosedResult" is '結案原因';
comment on column "JcicZ063"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ063"."Ukey" is '流水號';
comment on column "JcicZ063"."CreateDate" is '建檔日期時間';
comment on column "JcicZ063"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ063"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ063"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ063Log" purge;

create table "JcicZ063Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ClosedDate" decimal(8, 0) default 0 not null,
  "ClosedResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ063Log" add constraint "JcicZ063Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ063Log" is '變更還款方案結案通知資料';
comment on column "JcicZ063Log"."Ukey" is '流水號';
comment on column "JcicZ063Log"."TxSeq" is '交易序號';
comment on column "JcicZ063Log"."TranKey" is '交易代碼';
comment on column "JcicZ063Log"."ClosedDate" is '變更還款條件結案日期';
comment on column "JcicZ063Log"."ClosedResult" is '結案原因';
comment on column "JcicZ063Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ063Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ063Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ063Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ063Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ440" purge;

create table "JcicZ440" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "AgreeDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "RemindDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "ReportYn" varchar2(1),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ440" add constraint "JcicZ440_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ440_Index1" on "JcicZ440"("SubmitKey" asc);

create index "JcicZ440_Index2" on "JcicZ440"("CustId" asc);

create index "JcicZ440_Index3" on "JcicZ440"("ApplyDate" asc);

create index "JcicZ440_Index4" on "JcicZ440"("CourtCode" asc);

comment on table "JcicZ440" is '前置調解受理申請暨請求回報債權通知資料';
comment on column "JcicZ440"."TranKey" is '交易代碼';
comment on column "JcicZ440"."CustId" is '債務人IDN';
comment on column "JcicZ440"."SubmitKey" is '報送單位代號';
comment on column "JcicZ440"."ApplyDate" is '調解申請日';
comment on column "JcicZ440"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ440"."AgreeDate" is '同意書取得日期';
comment on column "JcicZ440"."StartDate" is '首次調解日';
comment on column "JcicZ440"."RemindDate" is '債權計算基準日';
comment on column "JcicZ440"."ApplyType" is '受理方式';
comment on column "JcicZ440"."ReportYn" is '協辦行是否需自行回報債權';
comment on column "JcicZ440"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ440"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ440"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ440"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ440"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ440"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ440"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ440"."Ukey" is '流水號';
comment on column "JcicZ440"."CreateDate" is '建檔日期時間';
comment on column "JcicZ440"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ440"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ440"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ440Log" purge;

create table "JcicZ440Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "RemindDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "ReportYn" varchar2(1),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ440Log" add constraint "JcicZ440Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ440Log" is '前置調解受理申請暨請求回報債權通知資料';
comment on column "JcicZ440Log"."Ukey" is '流水號';
comment on column "JcicZ440Log"."TxSeq" is '交易序號';
comment on column "JcicZ440Log"."TranKey" is '交易代碼';
comment on column "JcicZ440Log"."AgreeDate" is '同意書取得日期';
comment on column "JcicZ440Log"."StartDate" is '首次調解日';
comment on column "JcicZ440Log"."RemindDate" is '債權計算基準日';
comment on column "JcicZ440Log"."ApplyType" is '受理方式';
comment on column "JcicZ440Log"."ReportYn" is '協辦行是否需自行回報債權';
comment on column "JcicZ440Log"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ440Log"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ440Log"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ440Log"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ440Log"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ440Log"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ440Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ440Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ440Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ440Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ440Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ442" purge;

create table "JcicZ442" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "IsMaxMain" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "Civil323GuarAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "GuarObliPrin" decimal(9, 0) default 0 not null,
  "GuarObliInte" decimal(9, 0) default 0 not null,
  "GuarObliPena" decimal(9, 0) default 0 not null,
  "GuarObliOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ442" add constraint "JcicZ442_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode");

create index "JcicZ442_Index1" on "JcicZ442"("SubmitKey" asc);

create index "JcicZ442_Index2" on "JcicZ442"("CustId" asc);

create index "JcicZ442_Index3" on "JcicZ442"("ApplyDate" asc);

create index "JcicZ442_Index4" on "JcicZ442"("CourtCode" asc);

create index "JcicZ442_Index5" on "JcicZ442"("MaxMainCode" asc);

comment on table "JcicZ442" is '前置調解回報無擔保債權金額資料';
comment on column "JcicZ442"."TranKey" is '交易代碼';
comment on column "JcicZ442"."CustId" is '債務人IDN';
comment on column "JcicZ442"."SubmitKey" is '報送單位代號';
comment on column "JcicZ442"."ApplyDate" is '調解申請日';
comment on column "JcicZ442"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ442"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ442"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ442"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ442"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ442"."Civil323ExpAmt" is '依民法第323條計算之信用放款本息餘額';
comment on column "JcicZ442"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ442"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ442"."Civil323GuarAmt" is '依民法第323條計算之保證債權本息餘額';
comment on column "JcicZ442"."ReceExpPrin" is '信用放款本金';
comment on column "JcicZ442"."ReceExpInte" is '信用放款利息';
comment on column "JcicZ442"."ReceExpPena" is '信用放款違約金';
comment on column "JcicZ442"."ReceExpOther" is '信用放款其他費用';
comment on column "JcicZ442"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ442"."CashCardInte" is '現金卡利息';
comment on column "JcicZ442"."CashCardPena" is '現金卡違約金';
comment on column "JcicZ442"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ442"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ442"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ442"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ442"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ442"."GuarObliPrin" is '保證債權本金';
comment on column "JcicZ442"."GuarObliInte" is '保證債權利息';
comment on column "JcicZ442"."GuarObliPena" is '保證債權違約金';
comment on column "JcicZ442"."GuarObliOther" is '保證債權其他費用';
comment on column "JcicZ442"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ442"."Ukey" is '流水號';
comment on column "JcicZ442"."CreateDate" is '建檔日期時間';
comment on column "JcicZ442"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ442"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ442"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ442Log" purge;

create table "JcicZ442Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsMaxMain" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "Civil323GuarAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "GuarObliPrin" decimal(9, 0) default 0 not null,
  "GuarObliInte" decimal(9, 0) default 0 not null,
  "GuarObliPena" decimal(9, 0) default 0 not null,
  "GuarObliOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ442Log" add constraint "JcicZ442Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ442Log" is '前置調解回報無擔保債權金額資料';
comment on column "JcicZ442Log"."Ukey" is '流水號';
comment on column "JcicZ442Log"."TxSeq" is '交易序號';
comment on column "JcicZ442Log"."TranKey" is '交易代碼';
comment on column "JcicZ442Log"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ442Log"."IsClaims" is '是否為本金融機構債務人';
comment on column "JcicZ442Log"."GuarLoanCnt" is '本金融機構有擔保債權筆數';
comment on column "JcicZ442Log"."Civil323ExpAmt" is '依民法第323條計算之信用放款本息餘額';
comment on column "JcicZ442Log"."Civil323CashAmt" is '依民法第323條計算之現金卡放款本息餘額';
comment on column "JcicZ442Log"."Civil323CreditAmt" is '依民法第323條計算之信用卡本息餘額';
comment on column "JcicZ442Log"."Civil323GuarAmt" is '依民法第323條計算之保證債權本息餘額';
comment on column "JcicZ442Log"."ReceExpPrin" is '信用放款本金';
comment on column "JcicZ442Log"."ReceExpInte" is '信用放款利息';
comment on column "JcicZ442Log"."ReceExpPena" is '信用放款違約金';
comment on column "JcicZ442Log"."ReceExpOther" is '信用放款其他費用';
comment on column "JcicZ442Log"."CashCardPrin" is '現金卡本金';
comment on column "JcicZ442Log"."CashCardInte" is '現金卡利息';
comment on column "JcicZ442Log"."CashCardPena" is '現金卡違約金';
comment on column "JcicZ442Log"."CashCardOther" is '現金卡其他費用';
comment on column "JcicZ442Log"."CreditCardPrin" is '信用卡本金';
comment on column "JcicZ442Log"."CreditCardInte" is '信用卡利息';
comment on column "JcicZ442Log"."CreditCardPena" is '信用卡違約金';
comment on column "JcicZ442Log"."CreditCardOther" is '信用卡其他費用';
comment on column "JcicZ442Log"."GuarObliPrin" is '保證債權本金';
comment on column "JcicZ442Log"."GuarObliInte" is '保證債權利息';
comment on column "JcicZ442Log"."GuarObliPena" is '保證債權違約金';
comment on column "JcicZ442Log"."GuarObliOther" is '保證債權其他費用';
comment on column "JcicZ442Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ442Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ442Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ442Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ442Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ443" purge;

create table "JcicZ443" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "IsMaxMain" varchar2(1),
  "Account" nvarchar2(50),
  "GuarantyType" nvarchar2(2),
  "LoanAmt" decimal(12, 0) default 0 not null,
  "CreditAmt" decimal(12, 0) default 0 not null,
  "Principal" decimal(10, 0) default 0 not null,
  "Interest" decimal(10, 0) default 0 not null,
  "Penalty" decimal(10, 0) default 0 not null,
  "Other" decimal(10, 0) default 0 not null,
  "TerminalPayAmt" decimal(10, 0) default 0 not null,
  "LatestPayAmt" decimal(10, 0) default 0 not null,
  "FinalPayDay" decimal(8, 0) default 0 not null,
  "NotyetacQuit" decimal(10, 0) default 0 not null,
  "MothPayDay" decimal(2, 0) default 0 not null,
  "BeginDate" decimal(6, 0) default 0 not null,
  "EndDate" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ443" add constraint "JcicZ443_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode", "Account");

create index "JcicZ443_Index1" on "JcicZ443"("SubmitKey" asc);

create index "JcicZ443_Index2" on "JcicZ443"("CustId" asc);

create index "JcicZ443_Index3" on "JcicZ443"("ApplyDate" asc);

create index "JcicZ443_Index4" on "JcicZ443"("CourtCode" asc);

create index "JcicZ443_Index5" on "JcicZ443"("MaxMainCode" asc);

create index "JcicZ443_Index6" on "JcicZ443"("Account" asc);

comment on table "JcicZ443" is '前置調解回報有擔保債權金額資料';
comment on column "JcicZ443"."TranKey" is '交易代碼';
comment on column "JcicZ443"."CustId" is '債務人IDN';
comment on column "JcicZ443"."SubmitKey" is '報送單位代號';
comment on column "JcicZ443"."ApplyDate" is '調解申請日';
comment on column "JcicZ443"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ443"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ443"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ443"."Account" is '帳號';
comment on column "JcicZ443"."GuarantyType" is '擔保品類別';
comment on column "JcicZ443"."LoanAmt" is '原借款金額';
comment on column "JcicZ443"."CreditAmt" is '授信餘額';
comment on column "JcicZ443"."Principal" is '本金';
comment on column "JcicZ443"."Interest" is '利息';
comment on column "JcicZ443"."Penalty" is '違約金';
comment on column "JcicZ443"."Other" is '其他費用';
comment on column "JcicZ443"."TerminalPayAmt" is '每期應付金額';
comment on column "JcicZ443"."LatestPayAmt" is '最近一期繳款金額';
comment on column "JcicZ443"."FinalPayDay" is '最後繳息日';
comment on column "JcicZ443"."NotyetacQuit" is '已到期尚未清償金額';
comment on column "JcicZ443"."MothPayDay" is '每月應還款日';
comment on column "JcicZ443"."BeginDate" is '契約起始年月';
comment on column "JcicZ443"."EndDate" is '契約截止年月';
comment on column "JcicZ443"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ443"."Ukey" is '流水號';
comment on column "JcicZ443"."CreateDate" is '建檔日期時間';
comment on column "JcicZ443"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ443"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ443"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ443Log" purge;

create table "JcicZ443Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsMaxMain" varchar2(1),
  "Account" nvarchar2(50),
  "GuarantyType" nvarchar2(2),
  "LoanAmt" decimal(12, 0) default 0 not null,
  "CreditAmt" decimal(12, 0) default 0 not null,
  "Principal" decimal(10, 0) default 0 not null,
  "Interest" decimal(10, 0) default 0 not null,
  "Penalty" decimal(10, 0) default 0 not null,
  "Other" decimal(10, 0) default 0 not null,
  "TerminalPayAmt" decimal(10, 0) default 0 not null,
  "LatestPayAmt" decimal(10, 0) default 0 not null,
  "FinalPayDay" decimal(8, 0) default 0 not null,
  "NotyetacQuit" decimal(10, 0) default 0 not null,
  "MothPayDay" decimal(2, 0) default 0 not null,
  "BeginDate" decimal(6, 0) default 0 not null,
  "EndDate" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ443Log" add constraint "JcicZ443Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ443Log" is '前置調解回報有擔保債權金額資料';
comment on column "JcicZ443Log"."Ukey" is '流水號';
comment on column "JcicZ443Log"."TxSeq" is '交易序號';
comment on column "JcicZ443Log"."TranKey" is '交易代碼';
comment on column "JcicZ443Log"."IsMaxMain" is '是否為最大債權金融機構報送';
comment on column "JcicZ443Log"."Account" is '帳號';
comment on column "JcicZ443Log"."GuarantyType" is '擔保品類別';
comment on column "JcicZ443Log"."LoanAmt" is '原借款金額';
comment on column "JcicZ443Log"."CreditAmt" is '授信餘額';
comment on column "JcicZ443Log"."Principal" is '本金';
comment on column "JcicZ443Log"."Interest" is '利息';
comment on column "JcicZ443Log"."Penalty" is '違約金';
comment on column "JcicZ443Log"."Other" is '其他費用';
comment on column "JcicZ443Log"."TerminalPayAmt" is '每期應付金額';
comment on column "JcicZ443Log"."LatestPayAmt" is '最近一期繳款金額';
comment on column "JcicZ443Log"."FinalPayDay" is '最後繳息日';
comment on column "JcicZ443Log"."NotyetacQuit" is '已到期尚未清償金額';
comment on column "JcicZ443Log"."MothPayDay" is '每月應還款日';
comment on column "JcicZ443Log"."BeginDate" is '契約起始年月';
comment on column "JcicZ443Log"."EndDate" is '契約截止年月';
comment on column "JcicZ443Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ443Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ443Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ443Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ443Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ444" purge;

create table "JcicZ444" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "CustRegAddr" nvarchar2(76),
  "CustComAddr" nvarchar2(76),
  "CustRegTelNo" nvarchar2(16),
  "CustComTelNo" nvarchar2(16),
  "CustMobilNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ444" add constraint "JcicZ444_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ444_Index1" on "JcicZ444"("SubmitKey" asc);

create index "JcicZ444_Index2" on "JcicZ444"("CustId" asc);

create index "JcicZ444_Index3" on "JcicZ444"("ApplyDate" asc);

create index "JcicZ444_Index4" on "JcicZ444"("CourtCode" asc);

comment on table "JcicZ444" is '前置調解債務人基本資料';
comment on column "JcicZ444"."TranKey" is '交易代碼';
comment on column "JcicZ444"."CustId" is '債務人IDN';
comment on column "JcicZ444"."SubmitKey" is '報送單位代號';
comment on column "JcicZ444"."ApplyDate" is '調解申請日';
comment on column "JcicZ444"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ444"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ444"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ444"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ444"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ444"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ444"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ444"."Ukey" is '流水號';
comment on column "JcicZ444"."CreateDate" is '建檔日期時間';
comment on column "JcicZ444"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ444"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ444"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ444Log" purge;

create table "JcicZ444Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CustRegAddr" nvarchar2(76),
  "CustComAddr" nvarchar2(76),
  "CustRegTelNo" nvarchar2(16),
  "CustComTelNo" nvarchar2(16),
  "CustMobilNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ444Log" add constraint "JcicZ444Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ444Log" is '前置調解債務人基本資料';
comment on column "JcicZ444Log"."Ukey" is '流水號';
comment on column "JcicZ444Log"."TxSeq" is '交易序號';
comment on column "JcicZ444Log"."TranKey" is '交易代碼';
comment on column "JcicZ444Log"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ444Log"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ444Log"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ444Log"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ444Log"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ444Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ444Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ444Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ444Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ444Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ446" purge;

create table "JcicZ446" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "CloseCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ446" add constraint "JcicZ446_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ446_Index1" on "JcicZ446"("SubmitKey" asc);

create index "JcicZ446_Index2" on "JcicZ446"("CustId" asc);

create index "JcicZ446_Index3" on "JcicZ446"("ApplyDate" asc);

create index "JcicZ446_Index4" on "JcicZ446"("CourtCode" asc);

comment on table "JcicZ446" is '前置調解結案通知資料';
comment on column "JcicZ446"."TranKey" is '交易代碼';
comment on column "JcicZ446"."CustId" is '債務人IDN';
comment on column "JcicZ446"."SubmitKey" is '報送單位代號';
comment on column "JcicZ446"."ApplyDate" is '調解申請日';
comment on column "JcicZ446"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ446"."CloseCode" is '結案原因代號';
comment on column "JcicZ446"."CloseDate" is '結案日期';
comment on column "JcicZ446"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ446"."Ukey" is '流水號';
comment on column "JcicZ446"."CreateDate" is '建檔日期時間';
comment on column "JcicZ446"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ446"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ446"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ446Log" purge;

create table "JcicZ446Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CloseCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ446Log" add constraint "JcicZ446Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ446Log" is '前置調解結案通知資料';
comment on column "JcicZ446Log"."Ukey" is '流水號';
comment on column "JcicZ446Log"."TxSeq" is '交易序號';
comment on column "JcicZ446Log"."TranKey" is '交易代碼';
comment on column "JcicZ446Log"."CloseCode" is '結案原因代號';
comment on column "JcicZ446Log"."CloseDate" is '結案日期';
comment on column "JcicZ446Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ446Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ446Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ446Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ446Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ447" purge;

create table "JcicZ447" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ447" add constraint "JcicZ447_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode");

create index "JcicZ447_Index1" on "JcicZ447"("SubmitKey" asc);

create index "JcicZ447_Index2" on "JcicZ447"("CustId" asc);

create index "JcicZ447_Index3" on "JcicZ447"("ApplyDate" asc);

create index "JcicZ447_Index4" on "JcicZ447"("CourtCode" asc);

comment on table "JcicZ447" is '前置調解金融機構無擔保債務協議資料';
comment on column "JcicZ447"."TranKey" is '交易代碼';
comment on column "JcicZ447"."CustId" is '債務人IDN';
comment on column "JcicZ447"."SubmitKey" is '報送單位代號';
comment on column "JcicZ447"."ApplyDate" is '調解申請日';
comment on column "JcicZ447"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ447"."Civil323Amt" is '依民法第323條計算之債務總金額';
comment on column "JcicZ447"."TotalAmt" is '簽約總債務金額';
comment on column "JcicZ447"."SignDate" is '簽約完成日期';
comment on column "JcicZ447"."FirstPayDate" is '首期應繳款日';
comment on column "JcicZ447"."Period" is '期數';
comment on column "JcicZ447"."Rate" is '利率';
comment on column "JcicZ447"."MonthPayAmt" is '月付金';
comment on column "JcicZ447"."PayAccount" is '繳款帳號';
comment on column "JcicZ447"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ447"."Ukey" is '流水號';
comment on column "JcicZ447"."CreateDate" is '建檔日期時間';
comment on column "JcicZ447"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ447"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ447"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ447Log" purge;

create table "JcicZ447Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ447Log" add constraint "JcicZ447Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ447Log" is '前置調解金融機構無擔保債務協議資料';
comment on column "JcicZ447Log"."Ukey" is '流水號';
comment on column "JcicZ447Log"."TxSeq" is '交易序號';
comment on column "JcicZ447Log"."TranKey" is '交易代碼';
comment on column "JcicZ447Log"."Civil323Amt" is '依民法第323條計算之債務總金額';
comment on column "JcicZ447Log"."TotalAmt" is '簽約總債務金額';
comment on column "JcicZ447Log"."SignDate" is '簽約完成日期';
comment on column "JcicZ447Log"."FirstPayDate" is '首期應繳款日';
comment on column "JcicZ447Log"."Period" is '期數';
comment on column "JcicZ447Log"."Rate" is '利率';
comment on column "JcicZ447Log"."MonthPayAmt" is '月付金';
comment on column "JcicZ447Log"."PayAccount" is '繳款帳號';
comment on column "JcicZ447Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ447Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ447Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ447Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ447Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ448" purge;

create table "JcicZ448" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "SignPrin" decimal(9, 0) default 0 not null,
  "SignOther" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "AcQuitAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ448" add constraint "JcicZ448_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode");

create index "JcicZ448_Index1" on "JcicZ448"("SubmitKey" asc);

create index "JcicZ448_Index2" on "JcicZ448"("CustId" asc);

create index "JcicZ448_Index3" on "JcicZ448"("ApplyDate" asc);

create index "JcicZ448_Index4" on "JcicZ448"("CourtCode" asc);

create index "JcicZ448_Index5" on "JcicZ448"("MaxMainCode" asc);

comment on table "JcicZ448" is '前置調解無擔保債務還款分配資料';
comment on column "JcicZ448"."TranKey" is '交易代碼';
comment on column "JcicZ448"."CustId" is '債務人IDN';
comment on column "JcicZ448"."SubmitKey" is '報送單位代號';
comment on column "JcicZ448"."ApplyDate" is '調解申請日';
comment on column "JcicZ448"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ448"."MaxMainCode" is '債權金融機構代號';
comment on column "JcicZ448"."SignPrin" is '簽約金額-本金';
comment on column "JcicZ448"."SignOther" is '簽約金額-利息、違約金及其他費用';
comment on column "JcicZ448"."OwnPercentage" is '債權比例';
comment on column "JcicZ448"."AcQuitAmt" is '每月清償金額';
comment on column "JcicZ448"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ448"."Ukey" is '流水號';
comment on column "JcicZ448"."CreateDate" is '建檔日期時間';
comment on column "JcicZ448"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ448"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ448"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ448Log" purge;

create table "JcicZ448Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "SignPrin" decimal(9, 0) default 0 not null,
  "SignOther" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "AcQuitAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ448Log" add constraint "JcicZ448Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ448Log" is '前置調解無擔保債務還款分配資料';
comment on column "JcicZ448Log"."Ukey" is '流水號';
comment on column "JcicZ448Log"."TxSeq" is '交易序號';
comment on column "JcicZ448Log"."TranKey" is '交易代碼';
comment on column "JcicZ448Log"."SignPrin" is '簽約金額-本金';
comment on column "JcicZ448Log"."SignOther" is '簽約金額-利息、違約金及其他費用';
comment on column "JcicZ448Log"."OwnPercentage" is '債權比例';
comment on column "JcicZ448Log"."AcQuitAmt" is '每月清償金額';
comment on column "JcicZ448Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ448Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ448Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ448Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ448Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ450" purge;

create table "JcicZ450" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "PayStatus" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ450" add constraint "JcicZ450_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "PayDate");

create index "JcicZ450_Index1" on "JcicZ450"("SubmitKey" asc);

create index "JcicZ450_Index2" on "JcicZ450"("CustId" asc);

create index "JcicZ450_Index3" on "JcicZ450"("ApplyDate" asc);

create index "JcicZ450_Index4" on "JcicZ450"("CourtCode" asc);

create index "JcicZ450_Index5" on "JcicZ450"("PayDate" asc);

comment on table "JcicZ450" is '前置調解債務人繳款資料';
comment on column "JcicZ450"."TranKey" is '交易代碼';
comment on column "JcicZ450"."CustId" is '債務人IDN';
comment on column "JcicZ450"."SubmitKey" is '報送單位代號';
comment on column "JcicZ450"."ApplyDate" is '調解申請日';
comment on column "JcicZ450"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ450"."PayDate" is '繳款日期';
comment on column "JcicZ450"."PayAmt" is '本次繳款金額';
comment on column "JcicZ450"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ450"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ450"."PayStatus" is '債權結案註記';
comment on column "JcicZ450"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ450"."Ukey" is '流水號';
comment on column "JcicZ450"."CreateDate" is '建檔日期時間';
comment on column "JcicZ450"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ450"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ450"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ450Log" purge;

create table "JcicZ450Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "PayStatus" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ450Log" add constraint "JcicZ450Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ450Log" is '前置調解債務人繳款資料';
comment on column "JcicZ450Log"."Ukey" is '流水號';
comment on column "JcicZ450Log"."TxSeq" is '交易序號';
comment on column "JcicZ450Log"."TranKey" is '交易代碼';
comment on column "JcicZ450Log"."PayAmt" is '本次繳款金額';
comment on column "JcicZ450Log"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ450Log"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ450Log"."PayStatus" is '債權結案註記';
comment on column "JcicZ450Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ450Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ450Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ450Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ450Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ451" purge;

create table "JcicZ451" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "DelayYM" decimal(6, 0) default 0 not null,
  "DelayCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ451" add constraint "JcicZ451_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "DelayYM");

create index "JcicZ451_Index1" on "JcicZ451"("SubmitKey" asc);

create index "JcicZ451_Index2" on "JcicZ451"("CustId" asc);

create index "JcicZ451_Index3" on "JcicZ451"("ApplyDate" asc);

create index "JcicZ451_Index4" on "JcicZ451"("CourtCode" asc);

create index "JcicZ451_Index5" on "JcicZ451"("DelayYM" asc);

comment on table "JcicZ451" is '前置調解延期繳款資料';
comment on column "JcicZ451"."TranKey" is '交易代碼';
comment on column "JcicZ451"."CustId" is '債務人IDN';
comment on column "JcicZ451"."SubmitKey" is '報送單位代號';
comment on column "JcicZ451"."ApplyDate" is '調解申請日';
comment on column "JcicZ451"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ451"."DelayYM" is '延期繳款年月';
comment on column "JcicZ451"."DelayCode" is '延期繳款原因';
comment on column "JcicZ451"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ451"."Ukey" is '流水號';
comment on column "JcicZ451"."CreateDate" is '建檔日期時間';
comment on column "JcicZ451"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ451"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ451"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ451Log" purge;

create table "JcicZ451Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DelayCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ451Log" add constraint "JcicZ451Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ451Log" is '前置調解延期繳款資料';
comment on column "JcicZ451Log"."Ukey" is '流水號';
comment on column "JcicZ451Log"."TxSeq" is '交易序號';
comment on column "JcicZ451Log"."TranKey" is '交易代碼';
comment on column "JcicZ451Log"."DelayCode" is '延期繳款原因';
comment on column "JcicZ451Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ451Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ451Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ451Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ451Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ454" purge;

create table "JcicZ454" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ454" add constraint "JcicZ454_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode");

create index "JcicZ454_Index1" on "JcicZ454"("SubmitKey" asc);

create index "JcicZ454_Index2" on "JcicZ454"("CustId" asc);

create index "JcicZ454_Index3" on "JcicZ454"("ApplyDate" asc);

create index "JcicZ454_Index4" on "JcicZ454"("CourtCode" asc);

create index "JcicZ454_Index5" on "JcicZ454"("MaxMainCode" asc);

comment on table "JcicZ454" is '前置調解單獨全數受清償資料';
comment on column "JcicZ454"."TranKey" is '交易代碼';
comment on column "JcicZ454"."CustId" is '債務人IDN';
comment on column "JcicZ454"."SubmitKey" is '報送單位代號';
comment on column "JcicZ454"."ApplyDate" is '調解申請日';
comment on column "JcicZ454"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ454"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ454"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ454"."PayOffDate" is '單獨全數受清償日期';
comment on column "JcicZ454"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ454"."Ukey" is '流水號';
comment on column "JcicZ454"."CreateDate" is '建檔日期時間';
comment on column "JcicZ454"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ454"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ454"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ454Log" purge;

create table "JcicZ454Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ454Log" add constraint "JcicZ454Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ454Log" is '前置調解單獨全數受清償資料';
comment on column "JcicZ454Log"."Ukey" is '流水號';
comment on column "JcicZ454Log"."TxSeq" is '交易序號';
comment on column "JcicZ454Log"."TranKey" is '交易代碼';
comment on column "JcicZ454Log"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ454Log"."PayOffDate" is '單獨全數受清償日期';
comment on column "JcicZ454Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ454Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ454Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ454Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ454Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ570" purge;

create table "JcicZ570" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "AdjudicateDate" decimal(8, 0) default 0 not null,
  "BankCount" decimal(2, 0) default 0 not null,
  "Bank1" nvarchar2(3),
  "Bank2" nvarchar2(3),
  "Bank3" nvarchar2(3),
  "Bank4" nvarchar2(3),
  "Bank5" nvarchar2(3),
  "Bank6" nvarchar2(3),
  "Bank7" nvarchar2(3),
  "Bank8" nvarchar2(3),
  "Bank9" nvarchar2(3),
  "Bank10" nvarchar2(3),
  "Bank11" nvarchar2(3),
  "Bank12" nvarchar2(3),
  "Bank13" nvarchar2(3),
  "Bank14" nvarchar2(3),
  "Bank15" nvarchar2(3),
  "Bank16" nvarchar2(3),
  "Bank17" nvarchar2(3),
  "Bank18" nvarchar2(3),
  "Bank19" nvarchar2(3),
  "Bank20" nvarchar2(3),
  "Bank21" nvarchar2(3),
  "Bank22" nvarchar2(3),
  "Bank23" nvarchar2(3),
  "Bank24" nvarchar2(3),
  "Bank25" nvarchar2(3),
  "Bank26" nvarchar2(3),
  "Bank27" nvarchar2(3),
  "Bank28" nvarchar2(3),
  "Bank29" nvarchar2(3),
  "Bank30" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ570" add constraint "JcicZ570_PK" primary key("SubmitKey", "CustId", "ApplyDate");

create index "JcicZ570_Index1" on "JcicZ570"("SubmitKey" asc);

create index "JcicZ570_Index2" on "JcicZ570"("CustId" asc);

create index "JcicZ570_Index3" on "JcicZ570"("ApplyDate" asc);

comment on table "JcicZ570" is '受理更生款項統一收付通知資料';
comment on column "JcicZ570"."TranKey" is '交易代碼';
comment on column "JcicZ570"."CustId" is '債務人IDN';
comment on column "JcicZ570"."SubmitKey" is '報送單位代號';
comment on column "JcicZ570"."ApplyDate" is '申請日期';
comment on column "JcicZ570"."AdjudicateDate" is '更生方案認可裁定日';
comment on column "JcicZ570"."BankCount" is '更生債權金融機構家數';
comment on column "JcicZ570"."Bank1" is '債權金融機構代號1';
comment on column "JcicZ570"."Bank2" is '債權金融機構代號2';
comment on column "JcicZ570"."Bank3" is '債權金融機構代號3';
comment on column "JcicZ570"."Bank4" is '債權金融機構代號4';
comment on column "JcicZ570"."Bank5" is '債權金融機構代號5';
comment on column "JcicZ570"."Bank6" is '債權金融機構代號6';
comment on column "JcicZ570"."Bank7" is '債權金融機構代號7';
comment on column "JcicZ570"."Bank8" is '債權金融機構代號8';
comment on column "JcicZ570"."Bank9" is '債權金融機構代號9';
comment on column "JcicZ570"."Bank10" is '債權金融機構代號10';
comment on column "JcicZ570"."Bank11" is '債權金融機構代號11';
comment on column "JcicZ570"."Bank12" is '債權金融機構代號12';
comment on column "JcicZ570"."Bank13" is '債權金融機構代號13';
comment on column "JcicZ570"."Bank14" is '債權金融機構代號14';
comment on column "JcicZ570"."Bank15" is '債權金融機構代號15';
comment on column "JcicZ570"."Bank16" is '債權金融機構代號16';
comment on column "JcicZ570"."Bank17" is '債權金融機構代號17';
comment on column "JcicZ570"."Bank18" is '債權金融機構代號18';
comment on column "JcicZ570"."Bank19" is '債權金融機構代號19';
comment on column "JcicZ570"."Bank20" is '債權金融機構代號20';
comment on column "JcicZ570"."Bank21" is '債權金融機構代號21';
comment on column "JcicZ570"."Bank22" is '債權金融機構代號22';
comment on column "JcicZ570"."Bank23" is '債權金融機構代號23';
comment on column "JcicZ570"."Bank24" is '債權金融機構代號24';
comment on column "JcicZ570"."Bank25" is '債權金融機構代號25';
comment on column "JcicZ570"."Bank26" is '債權金融機構代號26';
comment on column "JcicZ570"."Bank27" is '債權金融機構代號27';
comment on column "JcicZ570"."Bank28" is '債權金融機構代號28';
comment on column "JcicZ570"."Bank29" is '債權金融機構代號29';
comment on column "JcicZ570"."Bank30" is '債權金融機構代號30';
comment on column "JcicZ570"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ570"."Ukey" is '流水號';
comment on column "JcicZ570"."CreateDate" is '建檔日期時間';
comment on column "JcicZ570"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ570"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ570"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ570Log" purge;

create table "JcicZ570Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AdjudicateDate" decimal(8, 0) default 0 not null,
  "BankCount" decimal(2, 0) default 0 not null,
  "Bank1" nvarchar2(3),
  "Bank2" nvarchar2(3),
  "Bank3" nvarchar2(3),
  "Bank4" nvarchar2(3),
  "Bank5" nvarchar2(3),
  "Bank6" nvarchar2(3),
  "Bank7" nvarchar2(3),
  "Bank8" nvarchar2(3),
  "Bank9" nvarchar2(3),
  "Bank10" nvarchar2(3),
  "Bank11" nvarchar2(3),
  "Bank12" nvarchar2(3),
  "Bank13" nvarchar2(3),
  "Bank14" nvarchar2(3),
  "Bank15" nvarchar2(3),
  "Bank16" nvarchar2(3),
  "Bank17" nvarchar2(3),
  "Bank18" nvarchar2(3),
  "Bank19" nvarchar2(3),
  "Bank20" nvarchar2(3),
  "Bank21" nvarchar2(3),
  "Bank22" nvarchar2(3),
  "Bank23" nvarchar2(3),
  "Bank24" nvarchar2(3),
  "Bank25" nvarchar2(3),
  "Bank26" nvarchar2(3),
  "Bank27" nvarchar2(3),
  "Bank28" nvarchar2(3),
  "Bank29" nvarchar2(3),
  "Bank30" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ570Log" add constraint "JcicZ570Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ570Log" is '受理更生款項統一收付通知資料';
comment on column "JcicZ570Log"."Ukey" is '流水號';
comment on column "JcicZ570Log"."TxSeq" is '交易序號';
comment on column "JcicZ570Log"."TranKey" is '交易代碼';
comment on column "JcicZ570Log"."AdjudicateDate" is '更生方案認可裁定日';
comment on column "JcicZ570Log"."BankCount" is '更生債權金融機構家數';
comment on column "JcicZ570Log"."Bank1" is '債權金融機構代號1';
comment on column "JcicZ570Log"."Bank2" is '債權金融機構代號2';
comment on column "JcicZ570Log"."Bank3" is '債權金融機構代號3';
comment on column "JcicZ570Log"."Bank4" is '債權金融機構代號4';
comment on column "JcicZ570Log"."Bank5" is '債權金融機構代號5';
comment on column "JcicZ570Log"."Bank6" is '債權金融機構代號6';
comment on column "JcicZ570Log"."Bank7" is '債權金融機構代號7';
comment on column "JcicZ570Log"."Bank8" is '債權金融機構代號8';
comment on column "JcicZ570Log"."Bank9" is '債權金融機構代號9';
comment on column "JcicZ570Log"."Bank10" is '債權金融機構代號10';
comment on column "JcicZ570Log"."Bank11" is '債權金融機構代號11';
comment on column "JcicZ570Log"."Bank12" is '債權金融機構代號12';
comment on column "JcicZ570Log"."Bank13" is '債權金融機構代號13';
comment on column "JcicZ570Log"."Bank14" is '債權金融機構代號14';
comment on column "JcicZ570Log"."Bank15" is '債權金融機構代號15';
comment on column "JcicZ570Log"."Bank16" is '債權金融機構代號16';
comment on column "JcicZ570Log"."Bank17" is '債權金融機構代號17';
comment on column "JcicZ570Log"."Bank18" is '債權金融機構代號18';
comment on column "JcicZ570Log"."Bank19" is '債權金融機構代號19';
comment on column "JcicZ570Log"."Bank20" is '債權金融機構代號20';
comment on column "JcicZ570Log"."Bank21" is '債權金融機構代號21';
comment on column "JcicZ570Log"."Bank22" is '債權金融機構代號22';
comment on column "JcicZ570Log"."Bank23" is '債權金融機構代號23';
comment on column "JcicZ570Log"."Bank24" is '債權金融機構代號24';
comment on column "JcicZ570Log"."Bank25" is '債權金融機構代號25';
comment on column "JcicZ570Log"."Bank26" is '債權金融機構代號26';
comment on column "JcicZ570Log"."Bank27" is '債權金融機構代號27';
comment on column "JcicZ570Log"."Bank28" is '債權金融機構代號28';
comment on column "JcicZ570Log"."Bank29" is '債權金融機構代號29';
comment on column "JcicZ570Log"."Bank30" is '債權金融機構代號30';
comment on column "JcicZ570Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ570Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ570Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ570Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ570Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ571" purge;

create table "JcicZ571" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "BankId" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "OwnerYn" varchar2(1),
  "PayYn" varchar2(1),
  "OwnerAmt" decimal(9, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "UnallotAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ571" add constraint "JcicZ571_PK" primary key("SubmitKey", "CustId", "ApplyDate", "BankId");

create index "JcicZ571_Index1" on "JcicZ571"("SubmitKey" asc);

create index "JcicZ571_Index2" on "JcicZ571"("CustId" asc);

create index "JcicZ571_Index3" on "JcicZ571"("ApplyDate" asc);

create index "JcicZ571_Index4" on "JcicZ571"("BankId" asc);

comment on table "JcicZ571" is '更生款項統一收付回報債權資料';
comment on column "JcicZ571"."TranKey" is '交易代碼';
comment on column "JcicZ571"."CustId" is '債務人IDN';
comment on column "JcicZ571"."SubmitKey" is '報送單位代號';
comment on column "JcicZ571"."BankId" is '受理款項統一收付之債權金融機構代號';
comment on column "JcicZ571"."ApplyDate" is '申請日期';
comment on column "JcicZ571"."OwnerYn" is '是否為更生債權人';
comment on column "JcicZ571"."PayYn" is '債務人是否仍依更生方案正常還款予本金融機構';
comment on column "JcicZ571"."OwnerAmt" is '本金融機構更生債權總金額';
comment on column "JcicZ571"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ571"."UnallotAmt" is '未參與分配債權金額';
comment on column "JcicZ571"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ571"."Ukey" is '流水號';
comment on column "JcicZ571"."CreateDate" is '建檔日期時間';
comment on column "JcicZ571"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ571"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ571"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ571Log" purge;

create table "JcicZ571Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "OwnerYn" varchar2(1),
  "PayYn" varchar2(1),
  "OwnerAmt" decimal(9, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "UnallotAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ571Log" add constraint "JcicZ571Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ571Log" is '更生款項統一收付回報債權資料';
comment on column "JcicZ571Log"."Ukey" is '流水號';
comment on column "JcicZ571Log"."TxSeq" is '交易序號';
comment on column "JcicZ571Log"."TranKey" is '交易代碼';
comment on column "JcicZ571Log"."OwnerYn" is '是否為更生債權人';
comment on column "JcicZ571Log"."PayYn" is '債務人是否仍依更生方案正常還款予本金融機構';
comment on column "JcicZ571Log"."OwnerAmt" is '本金融機構更生債權總金額';
comment on column "JcicZ571Log"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ571Log"."UnallotAmt" is '未參與分配債權金額';
comment on column "JcicZ571Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ571Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ571Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ571Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ571Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ572" purge;

create table "JcicZ572" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "BankId" nvarchar2(3),
  "AllotAmt" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ572" add constraint "JcicZ572_PK" primary key("SubmitKey", "CustId", "ApplyDate", "PayDate", "BankId");

create index "JcicZ572_Index1" on "JcicZ572"("SubmitKey" asc);

create index "JcicZ572_Index2" on "JcicZ572"("CustId" asc);

create index "JcicZ572_Index3" on "JcicZ572"("ApplyDate" asc);

create index "JcicZ572_Index4" on "JcicZ572"("PayDate" asc);

create index "JcicZ572_Index5" on "JcicZ572"("BankId" asc);

comment on table "JcicZ572" is '受理更生款項統一收付款項分配表資料';
comment on column "JcicZ572"."TranKey" is '交易代碼';
comment on column "JcicZ572"."SubmitKey" is '報送單位代號';
comment on column "JcicZ572"."CustId" is '債務人IDN';
comment on column "JcicZ572"."ApplyDate" is '申請日期';
comment on column "JcicZ572"."StartDate" is '生效日期';
comment on column "JcicZ572"."PayDate" is '本分配表首繳日';
comment on column "JcicZ572"."BankId" is '債權金融機構代號';
comment on column "JcicZ572"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ572"."OwnPercentage" is '債權比例';
comment on column "JcicZ572"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ572"."Ukey" is '流水號';
comment on column "JcicZ572"."CreateDate" is '建檔日期時間';
comment on column "JcicZ572"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ572"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ572"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ572Log" purge;

create table "JcicZ572Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "StartDate" decimal(8, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ572Log" add constraint "JcicZ572Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ572Log" is '受理更生款項統一收付款項分配表資料';
comment on column "JcicZ572Log"."Ukey" is '流水號';
comment on column "JcicZ572Log"."TxSeq" is '交易序號';
comment on column "JcicZ572Log"."TranKey" is '交易代碼';
comment on column "JcicZ572Log"."StartDate" is '生效日期';
comment on column "JcicZ572Log"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ572Log"."OwnPercentage" is '債權比例';
comment on column "JcicZ572Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ572Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ572Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ572Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ572Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ573" purge;

create table "JcicZ573" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "TotalPayAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ573" add constraint "JcicZ573_PK" primary key("SubmitKey", "CustId", "ApplyDate", "PayDate");

create index "JcicZ573_Index1" on "JcicZ573"("SubmitKey" asc);

create index "JcicZ573_Index2" on "JcicZ573"("CustId" asc);

create index "JcicZ573_Index3" on "JcicZ573"("ApplyDate" asc);

create index "JcicZ573_Index4" on "JcicZ573"("PayDate" asc);

comment on table "JcicZ573" is '更生債務人繳款資料';
comment on column "JcicZ573"."TranKey" is '交易代碼';
comment on column "JcicZ573"."CustId" is '債務人IDN';
comment on column "JcicZ573"."SubmitKey" is '報送單位代號';
comment on column "JcicZ573"."ApplyDate" is '申請日期';
comment on column "JcicZ573"."PayDate" is '繳款日期';
comment on column "JcicZ573"."PayAmt" is '本日繳款金額';
comment on column "JcicZ573"."TotalPayAmt" is '累計繳款金額';
comment on column "JcicZ573"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ573"."Ukey" is '流水號';
comment on column "JcicZ573"."CreateDate" is '建檔日期時間';
comment on column "JcicZ573"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ573"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ573"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ573Log" purge;

create table "JcicZ573Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "TotalPayAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ573Log" add constraint "JcicZ573Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ573Log" is '更生債務人繳款資料';
comment on column "JcicZ573Log"."Ukey" is '流水號';
comment on column "JcicZ573Log"."TxSeq" is '交易序號';
comment on column "JcicZ573Log"."TranKey" is '交易代碼';
comment on column "JcicZ573Log"."PayAmt" is '本日繳款金額';
comment on column "JcicZ573Log"."TotalPayAmt" is '累計繳款金額';
comment on column "JcicZ573Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ573Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ573Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ573Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ573Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ574" purge;

create table "JcicZ574" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseMark" varchar2(2),
  "PhoneNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ574" add constraint "JcicZ574_PK" primary key("CustId", "SubmitKey", "ApplyDate");

create index "JcicZ574_Index1" on "JcicZ574"("CustId" asc);

create index "JcicZ574_Index2" on "JcicZ574"("SubmitKey" asc);

create index "JcicZ574_Index3" on "JcicZ574"("ApplyDate" asc);

comment on table "JcicZ574" is '更生款項統一收付結案通知資料';
comment on column "JcicZ574"."TranKey" is '交易代碼';
comment on column "JcicZ574"."CustId" is '債務人IDN';
comment on column "JcicZ574"."SubmitKey" is '報送單位代號';
comment on column "JcicZ574"."ApplyDate" is '申請日期';
comment on column "JcicZ574"."CloseDate" is '結案日期';
comment on column "JcicZ574"."CloseMark" is '結案原因';
comment on column "JcicZ574"."PhoneNo" is '通訊電話';
comment on column "JcicZ574"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ574"."Ukey" is '流水號';
comment on column "JcicZ574"."CreateDate" is '建檔日期時間';
comment on column "JcicZ574"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ574"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ574"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ574Log" purge;

create table "JcicZ574Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseMark" varchar2(2),
  "PhoneNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ574Log" add constraint "JcicZ574Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ574Log" is '更生款項統一收付結案通知資料';
comment on column "JcicZ574Log"."Ukey" is '流水號';
comment on column "JcicZ574Log"."TxSeq" is '交易序號';
comment on column "JcicZ574Log"."TranKey" is '交易代碼';
comment on column "JcicZ574Log"."CloseDate" is '結案日期';
comment on column "JcicZ574Log"."CloseMark" is '結案原因';
comment on column "JcicZ574Log"."PhoneNo" is '通訊電話';
comment on column "JcicZ574Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ574Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ574Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ574Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ574Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ575" purge;

create table "JcicZ575" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "BankId" nvarchar2(3),
  "ModifyType" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ575" add constraint "JcicZ575_PK" primary key("SubmitKey", "CustId", "ApplyDate", "BankId");

create index "JcicZ575_Index1" on "JcicZ575"("SubmitKey" asc);

create index "JcicZ575_Index2" on "JcicZ575"("CustId" asc);

create index "JcicZ575_Index3" on "JcicZ575"("ApplyDate" asc);

create index "JcicZ575_Index4" on "JcicZ575"("BankId" asc);

comment on table "JcicZ575" is '更生債權金額異動通知資料';
comment on column "JcicZ575"."TranKey" is '交易代碼';
comment on column "JcicZ575"."CustId" is '債務人IDN';
comment on column "JcicZ575"."SubmitKey" is '報送單位代號';
comment on column "JcicZ575"."ApplyDate" is '申請日期';
comment on column "JcicZ575"."BankId" is '異動債權金機構代號';
comment on column "JcicZ575"."ModifyType" is '債權異動類別';
comment on column "JcicZ575"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ575"."Ukey" is '流水號';
comment on column "JcicZ575"."CreateDate" is '建檔日期時間';
comment on column "JcicZ575"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ575"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ575"."LastUpdateEmpNo" is '最後更新人員';
drop table "JcicZ575Log" purge;

create table "JcicZ575Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ModifyType" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ575Log" add constraint "JcicZ575Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ575Log" is '更生債權金額異動通知資料';
comment on column "JcicZ575Log"."Ukey" is '流水號';
comment on column "JcicZ575Log"."TxSeq" is '交易序號';
comment on column "JcicZ575Log"."TranKey" is '交易代碼';
comment on column "JcicZ575Log"."ModifyType" is '債權異動類別';
comment on column "JcicZ575Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ575Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ575Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ575Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ575Log"."LastUpdateEmpNo" is '最後更新人員';
drop table "JobDetail" purge;

create table "JobDetail" (
  "ExecDate" decimal(8, 0) default 0 not null,
  "JobCode" varchar2(10),
  "StepId" varchar2(30),
  "BatchType" varchar2(1),
  "Status" varchar2(1),
  "ErrCode" varchar2(15),
  "ErrContent" clob,
  "StepStartTime" timestamp,
  "StepEndTime" timestamp,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "JobDetail" add constraint "JobDetail_PK" primary key("ExecDate", "JobCode", "StepId");

alter table "JobDetail" add constraint "JobDetail_JobMain_FK1" foreign key ("ExecDate", "JobCode") references "JobMain" ("ExecDate", "JobCode") on delete cascade;

comment on table "JobDetail" is '批次工作明細檔';
comment on column "JobDetail"."ExecDate" is '批次執行日期';
comment on column "JobDetail"."JobCode" is '批次代號';
comment on column "JobDetail"."StepId" is 'StepId';
comment on column "JobDetail"."BatchType" is '類別';
comment on column "JobDetail"."Status" is '執行結果';
comment on column "JobDetail"."ErrCode" is '錯誤碼';
comment on column "JobDetail"."ErrContent" is '錯誤內容';
comment on column "JobDetail"."StepStartTime" is '啟動時間';
comment on column "JobDetail"."StepEndTime" is '結束時間';
comment on column "JobDetail"."CreateEmpNo" is '建檔人員';
comment on column "JobDetail"."CreateDate" is '建檔日期';
comment on column "JobDetail"."LastUpdateEmpNo" is '最後維護人員';
comment on column "JobDetail"."LastUpdate" is '最後維護日期';
drop table "JobMain" purge;

create table "JobMain" (
  "ExecDate" decimal(8, 0) default 0 not null,
  "JobCode" varchar2(10),
  "StartTime" timestamp,
  "EndTime" timestamp,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "JobMain" add constraint "JobMain_PK" primary key("ExecDate", "JobCode");

comment on table "JobMain" is '批次工作主檔';
comment on column "JobMain"."ExecDate" is '批次執行日期';
comment on column "JobMain"."JobCode" is '批次代號';
comment on column "JobMain"."StartTime" is '啟動時間';
comment on column "JobMain"."EndTime" is '結束時間';
comment on column "JobMain"."CreateEmpNo" is '建檔人員';
comment on column "JobMain"."CreateDate" is '建檔日期';
comment on column "JobMain"."LastUpdateEmpNo" is '最後維護人員';
comment on column "JobMain"."LastUpdate" is '最後維護日期';
drop table "LoanBook" purge;

create table "LoanBook" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BookDate" decimal(8, 0) default 0 not null,
  "ActualDate" decimal(8, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "IncludeIntFlag" varchar2(1),
  "UnpaidIntFlag" varchar2(1),
  "BookAmt" decimal(16, 2) default 0 not null,
  "RepayAmt" decimal(16, 2) default 0 not null,
  "PayMethod" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanBook" add constraint "LoanBook_PK" primary key("CustNo", "FacmNo", "BormNo", "BookDate");

alter table "LoanBook" add constraint "LoanBook_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

comment on table "LoanBook" is '放款約定還本檔';
comment on column "LoanBook"."CustNo" is '借款人戶號';
comment on column "LoanBook"."FacmNo" is '額度編號';
comment on column "LoanBook"."BormNo" is '撥款序號';
comment on column "LoanBook"."BookDate" is '約定還本日期';
comment on column "LoanBook"."ActualDate" is '實際還本日期';
comment on column "LoanBook"."Status" is '狀態';
comment on column "LoanBook"."CurrencyCode" is '幣別';
comment on column "LoanBook"."IncludeIntFlag" is '是否內含利息';
comment on column "LoanBook"."UnpaidIntFlag" is '利息是否可欠繳';
comment on column "LoanBook"."BookAmt" is '約定還本金額';
comment on column "LoanBook"."RepayAmt" is '實際還本金額';
comment on column "LoanBook"."PayMethod" is '繳納方式';
comment on column "LoanBook"."CreateDate" is '建檔日期時間';
comment on column "LoanBook"."CreateEmpNo" is '建檔人員';
comment on column "LoanBook"."LastUpdate" is '最後更新日期時間';
comment on column "LoanBook"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanBorMain" purge;

create table "LoanBorMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LastBorxNo" decimal(4, 0) default 0 not null,
  "LastOvduNo" decimal(3, 0) default 0 not null,
  "Status" decimal(2, 0) default 0 not null,
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "RateCode" varchar2(1),
  "RateAdjFreq" decimal(2, 0) default 0 not null,
  "DrawdownCode" varchar2(1),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "IntCalcCode" varchar2(1),
  "AmortizedCode" varchar2(1),
  "FreqBase" decimal(1, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "PaidTerms" decimal(3, 0) default 0 not null,
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "PrevRepaidDate" decimal(8, 0) default 0 not null,
  "NextPayIntDate" decimal(8, 0) default 0 not null,
  "NextRepayDate" decimal(8, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "GraceDate" decimal(8, 0) default 0 not null,
  "SpecificDd" decimal(2, 0) default 0 not null,
  "SpecificDate" decimal(8, 0) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "FirstAdjRateDate" decimal(8, 0) default 0 not null,
  "NextAdjRateDate" decimal(8, 0) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "HandlingFee" decimal(16, 2) default 0 not null,
  "FinalBal" decimal(16, 2) default 0 not null,
  "NotYetFlag" varchar2(1),
  "RenewFlag" varchar2(1),
  "PieceCode" varchar2(1),
  "PieceCodeSecond" varchar2(1),
  "PieceCodeSecondAmt" decimal(16, 2) default 0 not null,
  "UsageCode" varchar2(2),
  "SyndNo" decimal(3, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelationName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelationBirthday" decimal(8, 0) default 0 not null,
  "RelationGender" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "LastEntDy" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "RemitBank" varchar2(3),
  "RemitBranch" varchar2(4),
  "RemitAcctNo" decimal(14, 0) default 0 not null,
  "CompensateAcct" nvarchar2(60),
  "PaymentBank" varchar2(7),
  "Remark" nvarchar2(40),
  "AcDate" decimal(8, 0) default 0 not null,
  "NextAcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanBorMain" add constraint "LoanBorMain_PK" primary key("CustNo", "FacmNo", "BormNo");

alter table "LoanBorMain" add constraint "LoanBorMain_FacMain_FK1" foreign key ("CustNo", "FacmNo") references "FacMain" ("CustNo", "FacmNo") on delete cascade;

create index "LoanBorMain_Index1" on "LoanBorMain"("Status" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc);

comment on table "LoanBorMain" is '放款主檔';
comment on column "LoanBorMain"."CustNo" is '借款人戶號';
comment on column "LoanBorMain"."FacmNo" is '額度編號';
comment on column "LoanBorMain"."BormNo" is '撥款序號, 預約序號';
comment on column "LoanBorMain"."LastBorxNo" is '已編BorTx流水號';
comment on column "LoanBorMain"."LastOvduNo" is '已編Overdue流水號';
comment on column "LoanBorMain"."Status" is '戶況';
comment on column "LoanBorMain"."RateIncr" is '加碼利率';
comment on column "LoanBorMain"."IndividualIncr" is '個別加碼利率';
comment on column "LoanBorMain"."ApproveRate" is '核准利率';
comment on column "LoanBorMain"."StoreRate" is '實際計息利率';
comment on column "LoanBorMain"."RateCode" is '利率區分';
comment on column "LoanBorMain"."RateAdjFreq" is '利率調整週期';
comment on column "LoanBorMain"."DrawdownCode" is '撥款方式';
comment on column "LoanBorMain"."CurrencyCode" is '幣別';
comment on column "LoanBorMain"."DrawdownAmt" is '撥款金額';
comment on column "LoanBorMain"."LoanBal" is '放款餘額';
comment on column "LoanBorMain"."DrawdownDate" is '撥款日期, 預約日期';
comment on column "LoanBorMain"."LoanTermYy" is '貸款期間年';
comment on column "LoanBorMain"."LoanTermMm" is '貸款期間月';
comment on column "LoanBorMain"."LoanTermDd" is '貸款期間日';
comment on column "LoanBorMain"."MaturityDate" is '到期日';
comment on column "LoanBorMain"."IntCalcCode" is '計息方式';
comment on column "LoanBorMain"."AmortizedCode" is '攤還方式';
comment on column "LoanBorMain"."FreqBase" is '週期基準';
comment on column "LoanBorMain"."PayIntFreq" is '繳息週期';
comment on column "LoanBorMain"."RepayFreq" is '還本週期';
comment on column "LoanBorMain"."TotalPeriod" is '總期數';
comment on column "LoanBorMain"."RepaidPeriod" is '已還本期數';
comment on column "LoanBorMain"."PaidTerms" is '已繳息期數';
comment on column "LoanBorMain"."PrevPayIntDate" is '上次繳息日,繳息迄日';
comment on column "LoanBorMain"."PrevRepaidDate" is '上次還本日,最後還本日';
comment on column "LoanBorMain"."NextPayIntDate" is '下次繳息日,應繳息日';
comment on column "LoanBorMain"."NextRepayDate" is '下次還本日,應還本日';
comment on column "LoanBorMain"."DueAmt" is '每期攤還金額';
comment on column "LoanBorMain"."GracePeriod" is '寬限期';
comment on column "LoanBorMain"."GraceDate" is '寬限到期日';
comment on column "LoanBorMain"."SpecificDd" is '指定應繳日';
comment on column "LoanBorMain"."SpecificDate" is '指定基準日期';
comment on column "LoanBorMain"."FirstDueDate" is '首次應繳日';
comment on column "LoanBorMain"."FirstAdjRateDate" is '首次利率調整日期';
comment on column "LoanBorMain"."NextAdjRateDate" is '下次利率調整日期';
comment on column "LoanBorMain"."AcctFee" is '帳管費';
comment on column "LoanBorMain"."HandlingFee" is '手續費';
comment on column "LoanBorMain"."FinalBal" is '最後一期本金餘額';
comment on column "LoanBorMain"."NotYetFlag" is '未齊件';
comment on column "LoanBorMain"."RenewFlag" is '展期/借新還舊';
comment on column "LoanBorMain"."PieceCode" is '計件代碼';
comment on column "LoanBorMain"."PieceCodeSecond" is '計件代碼2';
comment on column "LoanBorMain"."PieceCodeSecondAmt" is '計件代碼2金額';
comment on column "LoanBorMain"."UsageCode" is '資金用途別';
comment on column "LoanBorMain"."SyndNo" is '聯貸案序號';
comment on column "LoanBorMain"."RelationCode" is '與借款人關係';
comment on column "LoanBorMain"."RelationName" is '第三人帳戶戶名';
comment on column "LoanBorMain"."RelationId" is '第三人身份證字號';
comment on column "LoanBorMain"."RelationBirthday" is '第三人生日';
comment on column "LoanBorMain"."RelationGender" is '第三人性別';
comment on column "LoanBorMain"."ActFg" is '交易進行記號';
comment on column "LoanBorMain"."LastEntDy" is '上次交易日';
comment on column "LoanBorMain"."LastKinbr" is '上次交易行別';
comment on column "LoanBorMain"."LastTlrNo" is '上次櫃員編號';
comment on column "LoanBorMain"."LastTxtNo" is '上次交易序號';
comment on column "LoanBorMain"."RemitBank" is '匯款銀行';
comment on column "LoanBorMain"."RemitBranch" is '匯款分行';
comment on column "LoanBorMain"."RemitAcctNo" is '匯款帳號';
comment on column "LoanBorMain"."CompensateAcct" is '匯款戶名(代償專戶)';
comment on column "LoanBorMain"."PaymentBank" is '解付單位代號';
comment on column "LoanBorMain"."Remark" is '附言';
comment on column "LoanBorMain"."AcDate" is '會計日期';
comment on column "LoanBorMain"."NextAcDate" is '次日交易會計日期';
comment on column "LoanBorMain"."BranchNo" is '單位別';
comment on column "LoanBorMain"."CreateDate" is '建檔日期時間';
comment on column "LoanBorMain"."CreateEmpNo" is '建檔人員';
comment on column "LoanBorMain"."LastUpdate" is '最後更新日期時間';
comment on column "LoanBorMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanBorTx" purge;

create table "LoanBorTx" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BorxNo" decimal(4, 0) default 0 not null,
  "TitaCalDy" decimal(8, 0) default 0 not null,
  "TitaCalTm" decimal(8, 0) default 0 not null,
  "TitaKinBr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "TitaTxCd" varchar2(5),
  "TitaCrDb" varchar2(1),
  "TitaHCode" varchar2(1),
  "TitaCurCd" varchar2(3),
  "TitaEmpNoS" varchar2(6),
  "RepayCode" decimal(2, 0) default 0 not null,
  "Desc" nvarchar2(15),
  "AcDate" decimal(8, 0) default 0 not null,
  "CorrectSeq" varchar2(26),
  "Displayflag" varchar2(1),
  "EntryDate" decimal(8, 0) default 0 not null,
  "DueDate" decimal(8, 0) default 0 not null,
  "TxAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "CloseBreachAmt" decimal(16, 2) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "ExtraRepay" decimal(16, 2) default 0 not null,
  "UnpaidInterest" decimal(16, 2) default 0 not null,
  "UnpaidPrincipal" decimal(16, 2) default 0 not null,
  "UnpaidCloseBreach" decimal(16, 2) default 0 not null,
  "Shortfall" decimal(16, 2) default 0 not null,
  "Overflow" decimal(16, 2) default 0 not null,
  "OtherFields" varchar2(2000),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanBorTx" add constraint "LoanBorTx_PK" primary key("CustNo", "FacmNo", "BormNo", "BorxNo");

comment on table "LoanBorTx" is '放款交易內容檔';
comment on column "LoanBorTx"."CustNo" is '借款人戶號';
comment on column "LoanBorTx"."FacmNo" is '額度編號';
comment on column "LoanBorTx"."BormNo" is '撥款序號';
comment on column "LoanBorTx"."BorxNo" is '交易內容檔序號';
comment on column "LoanBorTx"."TitaCalDy" is '交易日期';
comment on column "LoanBorTx"."TitaCalTm" is '交易時間';
comment on column "LoanBorTx"."TitaKinBr" is '單位別';
comment on column "LoanBorTx"."TitaTlrNo" is '經辦';
comment on column "LoanBorTx"."TitaTxtNo" is '交易序號';
comment on column "LoanBorTx"."TitaTxCd" is '交易代號';
comment on column "LoanBorTx"."TitaCrDb" is '借貸別';
comment on column "LoanBorTx"."TitaHCode" is '訂正別';
comment on column "LoanBorTx"."TitaCurCd" is '幣別';
comment on column "LoanBorTx"."TitaEmpNoS" is '主管編號';
comment on column "LoanBorTx"."RepayCode" is '還款來源';
comment on column "LoanBorTx"."Desc" is '摘要';
comment on column "LoanBorTx"."AcDate" is '會計日期';
comment on column "LoanBorTx"."CorrectSeq" is '更正序號, 原交易序號';
comment on column "LoanBorTx"."Displayflag" is '查詢時顯示否';
comment on column "LoanBorTx"."EntryDate" is '入帳日期';
comment on column "LoanBorTx"."DueDate" is '應繳日期';
comment on column "LoanBorTx"."TxAmt" is '交易金額';
comment on column "LoanBorTx"."LoanBal" is '放款餘額';
comment on column "LoanBorTx"."IntStartDate" is '計息起日';
comment on column "LoanBorTx"."IntEndDate" is '計息迄日';
comment on column "LoanBorTx"."RepaidPeriod" is '回收期數';
comment on column "LoanBorTx"."Rate" is '利率';
comment on column "LoanBorTx"."Principal" is '實收本金';
comment on column "LoanBorTx"."Interest" is '實收利息';
comment on column "LoanBorTx"."DelayInt" is '實收延滯息';
comment on column "LoanBorTx"."BreachAmt" is '實收違約金';
comment on column "LoanBorTx"."CloseBreachAmt" is '實收清償違約金';
comment on column "LoanBorTx"."TempAmt" is '暫收款金額';
comment on column "LoanBorTx"."ExtraRepay" is '提前償還本金';
comment on column "LoanBorTx"."UnpaidInterest" is '短繳利息';
comment on column "LoanBorTx"."UnpaidPrincipal" is '短繳本金';
comment on column "LoanBorTx"."UnpaidCloseBreach" is '短繳清償違約金';
comment on column "LoanBorTx"."Shortfall" is '短收金額';
comment on column "LoanBorTx"."Overflow" is '溢收金額';
comment on column "LoanBorTx"."OtherFields" is '其他欄位';
comment on column "LoanBorTx"."CreateDate" is '建檔日期時間';
comment on column "LoanBorTx"."CreateEmpNo" is '建檔人員';
comment on column "LoanBorTx"."LastUpdate" is '最後更新日期時間';
comment on column "LoanBorTx"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanCheque" purge;

create table "LoanCheque" (
  "CustNo" decimal(7, 0) default 0 not null,
  "ChequeAcct" decimal(9, 0) default 0 not null,
  "ChequeNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "ProcessCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "Kinbr" varchar2(4),
  "TellerNo" varchar2(6),
  "TxtNo" varchar2(8),
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ChequeAmt" decimal(16, 2) default 0 not null,
  "ChequeName" varchar2(60),
  "ChequeDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(2),
  "BankCode" varchar2(7),
  "OutsideCode" varchar2(1),
  "BktwFlag" varchar2(1),
  "TsibFlag" varchar2(1),
  "MediaFlag" varchar2(1),
  "UsageCode" varchar2(2),
  "ServiceCenter" varchar2(1),
  "CreditorId" varchar2(10),
  "CreditorBankCode" varchar2(7),
  "OtherAcctCode" varchar2(3),
  "ReceiptNo" varchar2(5),
  "RepaidAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanCheque" add constraint "LoanCheque_PK" primary key("ChequeAcct", "ChequeNo");

comment on table "LoanCheque" is '支票檔';
comment on column "LoanCheque"."CustNo" is '借款人戶號';
comment on column "LoanCheque"."ChequeAcct" is '支票帳號';
comment on column "LoanCheque"."ChequeNo" is '支票號碼';
comment on column "LoanCheque"."StatusCode" is '票據狀況碼';
comment on column "LoanCheque"."ProcessCode" is '處理代碼';
comment on column "LoanCheque"."AcDate" is '交易序號-會計日期';
comment on column "LoanCheque"."Kinbr" is '交易單位';
comment on column "LoanCheque"."TellerNo" is '交易序號-櫃員';
comment on column "LoanCheque"."TxtNo" is '交易序號-流水號';
comment on column "LoanCheque"."ReceiveDate" is '收票日';
comment on column "LoanCheque"."EntryDate" is '入帳日';
comment on column "LoanCheque"."CurrencyCode" is '幣別';
comment on column "LoanCheque"."ChequeAmt" is '支票金額';
comment on column "LoanCheque"."ChequeName" is '發票人姓名';
comment on column "LoanCheque"."ChequeDate" is '支票到期日';
comment on column "LoanCheque"."AreaCode" is '交換區號';
comment on column "LoanCheque"."BankCode" is '行庫代號';
comment on column "LoanCheque"."OutsideCode" is '本埠外埠';
comment on column "LoanCheque"."BktwFlag" is '是否為台支';
comment on column "LoanCheque"."TsibFlag" is '是否為台新';
comment on column "LoanCheque"."MediaFlag" is '入媒體檔';
comment on column "LoanCheque"."UsageCode" is '支票用途';
comment on column "LoanCheque"."ServiceCenter" is '服務中心別';
comment on column "LoanCheque"."CreditorId" is '債權統一編號';
comment on column "LoanCheque"."CreditorBankCode" is '債權機構';
comment on column "LoanCheque"."OtherAcctCode" is '對方業務科目';
comment on column "LoanCheque"."ReceiptNo" is '收據號碼';
comment on column "LoanCheque"."RepaidAmt" is '已入帳金額';
comment on column "LoanCheque"."CreateDate" is '建檔日期時間';
comment on column "LoanCheque"."CreateEmpNo" is '建檔人員';
comment on column "LoanCheque"."LastUpdate" is '最後更新日期時間';
comment on column "LoanCheque"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsAp" purge;

create table "LoanIfrsAp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "Rate" decimal(8, 6) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetClass" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AvblBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "TempAmt" decimal(16, 2) default 0 not null,
  "AcCurcd" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "CurrencyCode" varchar2(4),
  "ExchangeRate" decimal(8, 5) default 0 not null,
  "LineAmtCurr" decimal(16, 2) default 0 not null,
  "DrawdownAmtCurr" decimal(16, 2) default 0 not null,
  "AcctFeeCurr" decimal(16, 2) default 0 not null,
  "LoanBalCurr" decimal(16, 2) default 0 not null,
  "IntAmtCurr" decimal(16, 2) default 0 not null,
  "FeeCurr" decimal(16, 2) default 0 not null,
  "AvblBalCurr" decimal(16, 2) default 0 not null,
  "TempAmtCurr" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsAp" add constraint "LoanIfrsAp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "LoanIfrsAp" is 'IFRS9欄位清單1';
comment on column "LoanIfrsAp"."DataYM" is '年月份';
comment on column "LoanIfrsAp"."CustNo" is '戶號';
comment on column "LoanIfrsAp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsAp"."FacmNo" is '額度編號';
comment on column "LoanIfrsAp"."ApplNo" is '核准號碼';
comment on column "LoanIfrsAp"."BormNo" is '撥款序號';
comment on column "LoanIfrsAp"."AcCode" is '會計科目';
comment on column "LoanIfrsAp"."Status" is '戶況';
comment on column "LoanIfrsAp"."FirstDrawdownDate" is '初貸日期';
comment on column "LoanIfrsAp"."DrawdownDate" is '撥款日期';
comment on column "LoanIfrsAp"."FacLineDate" is '到期日(額度)';
comment on column "LoanIfrsAp"."MaturityDate" is '到期日(撥款)';
comment on column "LoanIfrsAp"."LineAmt" is '核准金額';
comment on column "LoanIfrsAp"."DrawdownAmt" is '撥款金額';
comment on column "LoanIfrsAp"."AcctFee" is '帳管費';
comment on column "LoanIfrsAp"."LoanBal" is '本金餘額(撥款)';
comment on column "LoanIfrsAp"."IntAmt" is '應收利息';
comment on column "LoanIfrsAp"."Fee" is '法拍及火險費用';
comment on column "LoanIfrsAp"."Rate" is '利率(撥款)';
comment on column "LoanIfrsAp"."OvduDays" is '逾期繳款天數';
comment on column "LoanIfrsAp"."OvduDate" is '轉催收款日期';
comment on column "LoanIfrsAp"."BadDebtDate" is '轉銷呆帳日期';
comment on column "LoanIfrsAp"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "LoanIfrsAp"."GracePeriod" is '初貸時約定還本寬限期';
comment on column "LoanIfrsAp"."ApproveRate" is '核准利率';
comment on column "LoanIfrsAp"."AmortizedCode" is '契約當時還款方式';
comment on column "LoanIfrsAp"."RateCode" is '契約當時利率調整方式';
comment on column "LoanIfrsAp"."RepayFreq" is '契約約定當時還本週期';
comment on column "LoanIfrsAp"."PayIntFreq" is '契約約定當時繳息週期';
comment on column "LoanIfrsAp"."IndustryCode" is '授信行業別';
comment on column "LoanIfrsAp"."ClTypeJCIC" is '擔保品類別';
comment on column "LoanIfrsAp"."CityCode" is '擔保品地區別';
comment on column "LoanIfrsAp"."ProdNo" is '商品利率代碼';
comment on column "LoanIfrsAp"."CustKind" is '企業戶/個人戶';
comment on column "LoanIfrsAp"."AssetClass" is '五類資產分類';
comment on column "LoanIfrsAp"."IfrsProdCode" is '產品別';
comment on column "LoanIfrsAp"."EvaAmt" is '原始鑑價金額';
comment on column "LoanIfrsAp"."FirstDueDate" is '首次應繳日';
comment on column "LoanIfrsAp"."TotalPeriod" is '總期數';
comment on column "LoanIfrsAp"."AvblBal" is '可動用餘額(台幣)';
comment on column "LoanIfrsAp"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "LoanIfrsAp"."IrrevocableFlag" is '該筆額度是否為不可徹銷';
comment on column "LoanIfrsAp"."TempAmt" is '暫收款金額(台幣)';
comment on column "LoanIfrsAp"."AcCurcd" is '記帳幣別';
comment on column "LoanIfrsAp"."AcBookCode" is '會計帳冊';
comment on column "LoanIfrsAp"."CurrencyCode" is '交易幣別';
comment on column "LoanIfrsAp"."ExchangeRate" is '報導日匯率';
comment on column "LoanIfrsAp"."LineAmtCurr" is '核准金額(交易幣)';
comment on column "LoanIfrsAp"."DrawdownAmtCurr" is '撥款金額(交易幣)';
comment on column "LoanIfrsAp"."AcctFeeCurr" is '帳管費(交易幣)';
comment on column "LoanIfrsAp"."LoanBalCurr" is '本金餘額(撥款)(交易幣)';
comment on column "LoanIfrsAp"."IntAmtCurr" is '應收利息(交易幣)';
comment on column "LoanIfrsAp"."FeeCurr" is '法拍及火險費用(交易幣)';
comment on column "LoanIfrsAp"."AvblBalCurr" is '可動用餘額(交易幣)';
comment on column "LoanIfrsAp"."TempAmtCurr" is '暫收款金額(交易幣)';
comment on column "LoanIfrsAp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsAp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsAp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsAp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsBp" purge;

create table "LoanIfrsBp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LoanRate" decimal(8, 6) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsBp" add constraint "LoanIfrsBp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "LoanIfrsBp" is 'IFRS9欄位清單2';
comment on column "LoanIfrsBp"."DataYM" is '年月份';
comment on column "LoanIfrsBp"."CustNo" is '戶號';
comment on column "LoanIfrsBp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsBp"."FacmNo" is '額度編號';
comment on column "LoanIfrsBp"."BormNo" is '撥款序號';
comment on column "LoanIfrsBp"."LoanRate" is '貸放利率';
comment on column "LoanIfrsBp"."RateCode" is '利率調整方式';
comment on column "LoanIfrsBp"."EffectDate" is '利率欄位生效日';
comment on column "LoanIfrsBp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsBp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsBp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsBp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsCp" purge;

create table "LoanIfrsCp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsCp" add constraint "LoanIfrsCp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo", "EffectDate");

comment on table "LoanIfrsCp" is 'IFRS9欄位清單3';
comment on column "LoanIfrsCp"."DataYM" is '年月份';
comment on column "LoanIfrsCp"."CustNo" is '戶號';
comment on column "LoanIfrsCp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsCp"."FacmNo" is '額度編號';
comment on column "LoanIfrsCp"."BormNo" is '撥款序號';
comment on column "LoanIfrsCp"."AmortizedCode" is '約定還款方式';
comment on column "LoanIfrsCp"."PayIntFreq" is '繳息週期';
comment on column "LoanIfrsCp"."RepayFreq" is '還本週期';
comment on column "LoanIfrsCp"."EffectDate" is '生效日期';
comment on column "LoanIfrsCp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsCp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsCp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsCp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsDp" purge;

create table "LoanIfrsDp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "DataFg" decimal(1, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerDate" decimal(8, 0) default 0 not null,
  "DerRate" decimal(6, 4) default 0 not null,
  "DerLoanBal" decimal(16, 2) default 0 not null,
  "DerIntAmt" decimal(16, 2) default 0 not null,
  "DerFee" decimal(16, 2) default 0 not null,
  "DerY1Amt" decimal(16, 2) default 0 not null,
  "DerY2Amt" decimal(16, 2) default 0 not null,
  "DerY3Amt" decimal(16, 2) default 0 not null,
  "DerY4Amt" decimal(16, 2) default 0 not null,
  "DerY5Amt" decimal(16, 2) default 0 not null,
  "DerY1Int" decimal(16, 2) default 0 not null,
  "DerY2Int" decimal(16, 2) default 0 not null,
  "DerY3Int" decimal(16, 2) default 0 not null,
  "DerY4Int" decimal(16, 2) default 0 not null,
  "DerY5Int" decimal(16, 2) default 0 not null,
  "DerY1Fee" decimal(16, 2) default 0 not null,
  "DerY2Fee" decimal(16, 2) default 0 not null,
  "DerY3Fee" decimal(16, 2) default 0 not null,
  "DerY4Fee" decimal(16, 2) default 0 not null,
  "DerY5Fee" decimal(16, 2) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "AreaCode" varchar2(3),
  "ProdCode" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsDp" add constraint "LoanIfrsDp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "LoanIfrsDp" is 'IFRS9欄位清單4';
comment on column "LoanIfrsDp"."DataYM" is '年月份';
comment on column "LoanIfrsDp"."CustNo" is '戶號';
comment on column "LoanIfrsDp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsDp"."FacmNo" is '額度編號';
comment on column "LoanIfrsDp"."BormNo" is '撥款序號';
comment on column "LoanIfrsDp"."DataFg" is '資料類別';
comment on column "LoanIfrsDp"."AcCode" is '會計科目';
comment on column "LoanIfrsDp"."Status" is '案件狀態';
comment on column "LoanIfrsDp"."FirstDrawdownDate" is '初貸日期';
comment on column "LoanIfrsDp"."DrawdownDate" is '貸放日期';
comment on column "LoanIfrsDp"."MaturityDate" is '到期日';
comment on column "LoanIfrsDp"."LineAmt" is '核准金額(台幣)';
comment on column "LoanIfrsDp"."DrawdownAmt" is '撥款金額(台幣)';
comment on column "LoanIfrsDp"."LoanBal" is '本金餘額(撥款)(台幣)';
comment on column "LoanIfrsDp"."IntAmt" is '應收利息(台幣)';
comment on column "LoanIfrsDp"."Fee" is '法拍及火險費用(台幣)';
comment on column "LoanIfrsDp"."OvduDays" is '逾期繳款天數';
comment on column "LoanIfrsDp"."OvduDate" is '轉催收款日期';
comment on column "LoanIfrsDp"."BadDebtDate" is '轉銷呆帳日期';
comment on column "LoanIfrsDp"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "LoanIfrsDp"."DerDate" is 'stage3發生日期';
comment on column "LoanIfrsDp"."DerRate" is '上述發生日期前之最近一次利率';
comment on column "LoanIfrsDp"."DerLoanBal" is '上述發生日期時之本金餘額(台幣)';
comment on column "LoanIfrsDp"."DerIntAmt" is '上述發生日期時之應收利息(台幣)';
comment on column "LoanIfrsDp"."DerFee" is '上述發生日期時之法拍及火險費用(台幣)';
comment on column "LoanIfrsDp"."DerY1Amt" is 'stage3發生後第一年本金回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY2Amt" is 'stage3發生後第二年本金回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY3Amt" is 'stage3發生後第三年本金回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY4Amt" is 'stage3發生後第四年本金回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY5Amt" is 'stage3發生後第五年本金回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY1Int" is 'stage3發生後第一年應收利息回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY2Int" is 'stage3發生後第二年應收利息回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY3Int" is 'stage3發生後第三年應收利息回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY4Int" is 'stage3發生後第四年應收利息回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY5Int" is 'stage3發生後第五年應收利息回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY1Fee" is 'stage3發生後第一年法拍及火險費用回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY2Fee" is 'stage3發生後第二年法拍及火險費用回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY3Fee" is 'stage3發生後第三年法拍及火險費用回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY4Fee" is 'stage3發生後第四年法拍及火險費用回收金額(台幣)';
comment on column "LoanIfrsDp"."DerY5Fee" is 'stage3發生後第五年法拍及火險費用回收金額(台幣)';
comment on column "LoanIfrsDp"."IndustryCode" is '授信行業別';
comment on column "LoanIfrsDp"."ClTypeJCIC" is '擔保品類別';
comment on column "LoanIfrsDp"."AreaCode" is '擔保品地區別';
comment on column "LoanIfrsDp"."ProdCode" is '商品利率代碼';
comment on column "LoanIfrsDp"."CustKind" is '企業戶/個人戶';
comment on column "LoanIfrsDp"."IfrsProdCode" is '產品別';
comment on column "LoanIfrsDp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsDp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsDp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsDp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsFp" purge;

create table "LoanIfrsFp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "AgreeNo" decimal(3, 0) default 0 not null,
  "AgreeFg" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsFp" add constraint "LoanIfrsFp_PK" primary key("DataYM", "CustNo", "AgreeNo", "AgreeFg", "FacmNo", "BormNo");

comment on table "LoanIfrsFp" is 'IFRS9欄位清單6';
comment on column "LoanIfrsFp"."DataYM" is '年月份';
comment on column "LoanIfrsFp"."CustNo" is '戶號';
comment on column "LoanIfrsFp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsFp"."AgreeNo" is '協議編號';
comment on column "LoanIfrsFp"."AgreeFg" is '協議前後';
comment on column "LoanIfrsFp"."FacmNo" is '額度編號';
comment on column "LoanIfrsFp"."BormNo" is '撥款序號';
comment on column "LoanIfrsFp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsFp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsFp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsFp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsGp" purge;

create table "LoanIfrsGp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustKind" decimal(1, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "OriRating" varchar2(1),
  "OriModel" varchar2(1),
  "Rating" varchar2(1),
  "Model" varchar2(1),
  "OvduDays" decimal(4, 0) default 0 not null,
  "Stage1" decimal(1, 0) default 0 not null,
  "Stage2" decimal(1, 0) default 0 not null,
  "Stage3" decimal(1, 0) default 0 not null,
  "Stage4" decimal(1, 0) default 0 not null,
  "Stage5" decimal(1, 0) default 0 not null,
  "PdFlagToD" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsGp" add constraint "LoanIfrsGp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "LoanIfrsGp" is 'IFRS9欄位清單7';
comment on column "LoanIfrsGp"."DataYM" is '年月份';
comment on column "LoanIfrsGp"."CustNo" is '戶號';
comment on column "LoanIfrsGp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsGp"."FacmNo" is '額度編號';
comment on column "LoanIfrsGp"."ApplNo" is '核准號碼';
comment on column "LoanIfrsGp"."BormNo" is '撥款序號';
comment on column "LoanIfrsGp"."CustKind" is '企業戶/個人戶';
comment on column "LoanIfrsGp"."Status" is '戶況';
comment on column "LoanIfrsGp"."OvduDate" is '轉催收款日期';
comment on column "LoanIfrsGp"."OriRating" is '原始認列時時信用評等';
comment on column "LoanIfrsGp"."OriModel" is '原始認列時信用評等模型';
comment on column "LoanIfrsGp"."Rating" is '財務報導日時信用評等';
comment on column "LoanIfrsGp"."Model" is '財務報導日時信用評等模型';
comment on column "LoanIfrsGp"."OvduDays" is '逾期繳款天數';
comment on column "LoanIfrsGp"."Stage1" is '債務人屬企業戶，且其歸戶下任一債務逾期90天(含)以上';
comment on column "LoanIfrsGp"."Stage2" is '個人消費性放款逾期超逾90天(含)以上';
comment on column "LoanIfrsGp"."Stage3" is '債務人屬企業戶，且其歸戶任一債務已經本行轉催收款、或符合列報逾期放款條件、或本行對該債務讓步(如協議)';
comment on column "LoanIfrsGp"."Stage4" is '個人消費性放款已經本行轉催收、或符合列報逾期放款條件、或本行對該債務讓步(如協議)';
comment on column "LoanIfrsGp"."Stage5" is '債務人申請重組、破產或其他等程序，而進行該等程序可能使債務人免除或延遲償還債務';
comment on column "LoanIfrsGp"."PdFlagToD" is '內部違約機率降至D評等';
comment on column "LoanIfrsGp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsGp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsGp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsGp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsHp" purge;

create table "LoanIfrsHp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustKind" decimal(1, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "AvblBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "IndustryCode" varchar2(10),
  "OriRating" varchar2(1),
  "OriModel" varchar2(1),
  "Rating" varchar2(1),
  "Model" varchar2(1),
  "LGDModel" decimal(2, 0) default 0 not null,
  "LGD" decimal(10, 8) default 0 not null,
  "LineAmtCurr" decimal(16, 2) default 0 not null,
  "AvblBalCurr" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsHp" add constraint "LoanIfrsHp_PK" primary key("DataYM", "CustNo", "FacmNo");

comment on table "LoanIfrsHp" is 'IFRS9欄位清單8';
comment on column "LoanIfrsHp"."DataYM" is '年月份';
comment on column "LoanIfrsHp"."CustNo" is '戶號';
comment on column "LoanIfrsHp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsHp"."FacmNo" is '額度編號';
comment on column "LoanIfrsHp"."ApplNo" is '核准號碼';
comment on column "LoanIfrsHp"."CustKind" is '企業戶/個人戶';
comment on column "LoanIfrsHp"."ApproveDate" is '核准日期';
comment on column "LoanIfrsHp"."FirstDrawdownDate" is '初貸日期';
comment on column "LoanIfrsHp"."LineAmt" is '核准金額(台幣)';
comment on column "LoanIfrsHp"."IfrsProdCode" is '產品別';
comment on column "LoanIfrsHp"."AvblBal" is '可動用餘額(台幣)';
comment on column "LoanIfrsHp"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "LoanIfrsHp"."IrrevocableFlag" is '該筆額度是否為不可撤銷';
comment on column "LoanIfrsHp"."IndustryCode" is '主計處行業別代碼';
comment on column "LoanIfrsHp"."OriRating" is '原始認列時時信用評等';
comment on column "LoanIfrsHp"."OriModel" is '原始認列時信用評等模型';
comment on column "LoanIfrsHp"."Rating" is '財務報導日時信用評等';
comment on column "LoanIfrsHp"."Model" is '財務報導日時信用評等模型';
comment on column "LoanIfrsHp"."LGDModel" is '違約損失率模型';
comment on column "LoanIfrsHp"."LGD" is '違約損失率';
comment on column "LoanIfrsHp"."LineAmtCurr" is '核准金額(交易幣)';
comment on column "LoanIfrsHp"."AvblBalCurr" is '可動用餘額(交易幣)';
comment on column "LoanIfrsHp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsHp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsHp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsHp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsIp" purge;

create table "LoanIfrsIp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "AvblBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "LoanTerm" varchar2(8),
  "AcCode" varchar2(11),
  "AcCurcd" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "CurrencyCode" varchar2(4),
  "ExchangeRate" decimal(10, 8) default 0 not null,
  "LineAmtCurr" decimal(16, 2) default 0 not null,
  "AcctFeeCurr" decimal(16, 2) default 0 not null,
  "FeeCurr" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsIp" add constraint "LoanIfrsIp_PK" primary key("DataYM", "CustNo", "FacmNo");

comment on table "LoanIfrsIp" is 'IFRS9欄位清單9';
comment on column "LoanIfrsIp"."DataYM" is '年月份';
comment on column "LoanIfrsIp"."CustNo" is '戶號';
comment on column "LoanIfrsIp"."CustId" is '借款人ID / 統編';
comment on column "LoanIfrsIp"."FacmNo" is '額度編號';
comment on column "LoanIfrsIp"."ApplNo" is '核准號碼';
comment on column "LoanIfrsIp"."DrawdownFg" is '已核撥記號';
comment on column "LoanIfrsIp"."ApproveDate" is '核准日期';
comment on column "LoanIfrsIp"."FirstDrawdownDate" is '初貸日期';
comment on column "LoanIfrsIp"."LineAmt" is '核准金額';
comment on column "LoanIfrsIp"."AcctFee" is '帳管費';
comment on column "LoanIfrsIp"."Fee" is '法拍及火險費用';
comment on column "LoanIfrsIp"."ApproveRate" is '核准利率';
comment on column "LoanIfrsIp"."GracePeriod" is '初貸時約定還本寬限期';
comment on column "LoanIfrsIp"."AmortizedCode" is '契約當時還款方式';
comment on column "LoanIfrsIp"."RateCode" is '契約當時利率調整方式';
comment on column "LoanIfrsIp"."RepayFreq" is '契約約定當時還本週期';
comment on column "LoanIfrsIp"."PayIntFreq" is '契約約定當時繳息週期';
comment on column "LoanIfrsIp"."IndustryCode" is '授信行業別';
comment on column "LoanIfrsIp"."ClTypeJCIC" is '擔保品類別';
comment on column "LoanIfrsIp"."CityCode" is '擔保品地區別';
comment on column "LoanIfrsIp"."ProdNo" is '商品利率代碼';
comment on column "LoanIfrsIp"."CustKind" is '企業戶/個人戶';
comment on column "LoanIfrsIp"."IfrsProdCode" is '產品別';
comment on column "LoanIfrsIp"."EvaAmt" is '原始鑑價金額';
comment on column "LoanIfrsIp"."AvblBal" is '可動用餘額(台幣)';
comment on column "LoanIfrsIp"."RecycleCode" is '該筆額度是否可循環動用';
comment on column "LoanIfrsIp"."IrrevocableFlag" is '該筆額度是否為不可撤銷';
comment on column "LoanIfrsIp"."LoanTerm" is '合約期限';
comment on column "LoanIfrsIp"."AcCode" is '備忘分錄會計科目';
comment on column "LoanIfrsIp"."AcCurcd" is '記帳幣別';
comment on column "LoanIfrsIp"."AcBookCode" is '會計帳冊';
comment on column "LoanIfrsIp"."CurrencyCode" is '交易幣別';
comment on column "LoanIfrsIp"."ExchangeRate" is '報導日匯率';
comment on column "LoanIfrsIp"."LineAmtCurr" is '核准金額(交易幣)';
comment on column "LoanIfrsIp"."AcctFeeCurr" is '帳管費(交易幣)';
comment on column "LoanIfrsIp"."FeeCurr" is '法拍及火險費用(交易幣)';
comment on column "LoanIfrsIp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsIp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsIp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsIp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIfrsJp" purge;

create table "LoanIfrsJp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "AcDateYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "NewFacmNo" decimal(3, 0) default 0 not null,
  "NewBormNo" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "OldBormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIfrsJp" add constraint "LoanIfrsJp_PK" primary key("DataYM", "AcDateYM", "CustNo", "NewFacmNo", "NewBormNo", "OldFacmNo", "OldBormNo");

comment on table "LoanIfrsJp" is 'IFRS9欄位清單10';
comment on column "LoanIfrsJp"."DataYM" is '年月份';
comment on column "LoanIfrsJp"."AcDateYM" is '發生時會計日期年月';
comment on column "LoanIfrsJp"."CustNo" is '戶號';
comment on column "LoanIfrsJp"."NewFacmNo" is '新額度編號';
comment on column "LoanIfrsJp"."NewBormNo" is '新撥款序號';
comment on column "LoanIfrsJp"."OldFacmNo" is '舊額度編號';
comment on column "LoanIfrsJp"."OldBormNo" is '舊撥款序號';
comment on column "LoanIfrsJp"."CreateDate" is '建檔日期時間';
comment on column "LoanIfrsJp"."CreateEmpNo" is '建檔人員';
comment on column "LoanIfrsJp"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIfrsJp"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanIntDetail" purge;

create table "LoanIntDetail" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TlrNo" varchar2(6),
  "TxtNo" varchar2(8),
  "IntSeq" decimal(3, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "IntDays" decimal(5, 0) default 0 not null,
  "BreachDays" decimal(5, 0) default 0 not null,
  "MonthLimit" decimal(2, 0) default 0 not null,
  "IntFlag" decimal(1, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "Amount" decimal(16, 2) default 0 not null,
  "IntRate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "CloseBreachAmt" decimal(16, 2) default 0 not null,
  "BreachGetCode" varchar2(1),
  "LoanBal" decimal(16, 2) default 0 not null,
  "ExtraRepayFlag" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanIntDetail" add constraint "LoanIntDetail_PK" primary key("CustNo", "FacmNo", "BormNo", "AcDate", "TlrNo", "TxtNo", "IntSeq");

alter table "LoanIntDetail" add constraint "LoanIntDetail_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

comment on table "LoanIntDetail" is '計息明細檔';
comment on column "LoanIntDetail"."CustNo" is '借款人戶號';
comment on column "LoanIntDetail"."FacmNo" is '額度編號';
comment on column "LoanIntDetail"."BormNo" is '撥款序號';
comment on column "LoanIntDetail"."AcDate" is '交易序號-會計日期';
comment on column "LoanIntDetail"."TlrNo" is '交易序號-櫃員別';
comment on column "LoanIntDetail"."TxtNo" is '交易序號-流水號';
comment on column "LoanIntDetail"."IntSeq" is '計息流水號';
comment on column "LoanIntDetail"."IntStartDate" is '計息起日';
comment on column "LoanIntDetail"."IntEndDate" is '計息止日';
comment on column "LoanIntDetail"."IntDays" is '計息日數';
comment on column "LoanIntDetail"."BreachDays" is '違約金日數';
comment on column "LoanIntDetail"."MonthLimit" is '當月日數';
comment on column "LoanIntDetail"."IntFlag" is '計息記號';
comment on column "LoanIntDetail"."CurrencyCode" is '幣別';
comment on column "LoanIntDetail"."Amount" is '計息本金';
comment on column "LoanIntDetail"."IntRate" is '計息利率';
comment on column "LoanIntDetail"."Principal" is '回收本金';
comment on column "LoanIntDetail"."Interest" is '利息';
comment on column "LoanIntDetail"."DelayInt" is '延滯息';
comment on column "LoanIntDetail"."BreachAmt" is '違約金';
comment on column "LoanIntDetail"."CloseBreachAmt" is '清償違約金';
comment on column "LoanIntDetail"."BreachGetCode" is '清償違約金收取方式';
comment on column "LoanIntDetail"."LoanBal" is '放款餘額';
comment on column "LoanIntDetail"."ExtraRepayFlag" is '部分償還記號';
comment on column "LoanIntDetail"."ProdNo" is '商品代碼';
comment on column "LoanIntDetail"."BaseRateCode" is '指標利率代碼';
comment on column "LoanIntDetail"."RateIncr" is '加碼利率';
comment on column "LoanIntDetail"."IndividualIncr" is '個別加碼利率';
comment on column "LoanIntDetail"."CreateDate" is '建檔日期時間';
comment on column "LoanIntDetail"."CreateEmpNo" is '建檔人員';
comment on column "LoanIntDetail"."LastUpdate" is '最後更新日期時間';
comment on column "LoanIntDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanNotYet" purge;

create table "LoanNotYet" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "NotYetCode" varchar2(2),
  "NotYetItem" nvarchar2(40),
  "YetDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "ReMark" nvarchar2(80),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanNotYet" add constraint "LoanNotYet_PK" primary key("CustNo", "FacmNo", "NotYetCode");

alter table "LoanNotYet" add constraint "LoanNotYet_FacMain_FK1" foreign key ("CustNo", "FacmNo") references "FacMain" ("CustNo", "FacmNo") on delete cascade;

comment on table "LoanNotYet" is '未齊件管理檔';
comment on column "LoanNotYet"."CustNo" is '借款人戶號';
comment on column "LoanNotYet"."FacmNo" is '額度編號';
comment on column "LoanNotYet"."NotYetCode" is '未齊件代碼';
comment on column "LoanNotYet"."NotYetItem" is '未齊件說明';
comment on column "LoanNotYet"."YetDate" is '齊件日期';
comment on column "LoanNotYet"."CloseDate" is '銷號日期';
comment on column "LoanNotYet"."ReMark" is '備註';
comment on column "LoanNotYet"."CreateDate" is '建檔日期時間';
comment on column "LoanNotYet"."CreateEmpNo" is '建檔人員';
comment on column "LoanNotYet"."LastUpdate" is '最後更新日期時間';
comment on column "LoanNotYet"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanOverdue" purge;

create table "LoanOverdue" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "OvduNo" decimal(3, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "ReplyDate" decimal(8, 0) default 0 not null,
  "OvduPrinAmt" decimal(16, 2) default 0 not null,
  "OvduIntAmt" decimal(16, 2) default 0 not null,
  "OvduBreachAmt" decimal(16, 2) default 0 not null,
  "OvduAmt" decimal(16, 2) default 0 not null,
  "OvduPrinBal" decimal(16, 2) default 0 not null,
  "OvduIntBal" decimal(16, 2) default 0 not null,
  "OvduBreachBal" decimal(16, 2) default 0 not null,
  "OvduBal" decimal(16, 2) default 0 not null,
  "ReduceInt" decimal(16, 2) default 0 not null,
  "ReduceBreach" decimal(16, 2) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "ReplyReduceAmt" decimal(16, 2) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "OvduSituaction" nvarchar2(30),
  "Remark" nvarchar2(60),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanOverdue" add constraint "LoanOverdue_PK" primary key("CustNo", "FacmNo", "BormNo", "OvduNo");

alter table "LoanOverdue" add constraint "LoanOverdue_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

comment on table "LoanOverdue" is '催收呆帳檔';
comment on column "LoanOverdue"."CustNo" is '借款人戶號';
comment on column "LoanOverdue"."FacmNo" is '額度編號';
comment on column "LoanOverdue"."BormNo" is '撥款序號';
comment on column "LoanOverdue"."OvduNo" is '催收序號';
comment on column "LoanOverdue"."Status" is '狀態';
comment on column "LoanOverdue"."AcctCode" is '帳務科目';
comment on column "LoanOverdue"."OvduDate" is '轉催收日期';
comment on column "LoanOverdue"."BadDebtDate" is '轉呆帳日期';
comment on column "LoanOverdue"."ReplyDate" is '催收回復日期';
comment on column "LoanOverdue"."OvduPrinAmt" is '轉催收本金';
comment on column "LoanOverdue"."OvduIntAmt" is '轉催收利息';
comment on column "LoanOverdue"."OvduBreachAmt" is '轉催收違約金';
comment on column "LoanOverdue"."OvduAmt" is '轉催收金額';
comment on column "LoanOverdue"."OvduPrinBal" is '催收本金餘額';
comment on column "LoanOverdue"."OvduIntBal" is '催收利息餘額';
comment on column "LoanOverdue"."OvduBreachBal" is '催收違約金餘額';
comment on column "LoanOverdue"."OvduBal" is '催收餘額';
comment on column "LoanOverdue"."ReduceInt" is '減免利息金額';
comment on column "LoanOverdue"."ReduceBreach" is '減免違約金金額';
comment on column "LoanOverdue"."BadDebtAmt" is '轉呆帳金額';
comment on column "LoanOverdue"."BadDebtBal" is '呆帳餘額';
comment on column "LoanOverdue"."ReplyReduceAmt" is '催收回復減免金額';
comment on column "LoanOverdue"."ProcessDate" is '處理日期';
comment on column "LoanOverdue"."OvduSituaction" is '催收處理情形';
comment on column "LoanOverdue"."Remark" is '附言';
comment on column "LoanOverdue"."AcDate" is '會計日期';
comment on column "LoanOverdue"."CreateDate" is '建檔日期時間';
comment on column "LoanOverdue"."CreateEmpNo" is '建檔人員';
comment on column "LoanOverdue"."LastUpdate" is '最後更新日期時間';
comment on column "LoanOverdue"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanRateChange" purge;

create table "LoanRateChange" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "RateCode" varchar2(1),
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "IncrFlag" varchar2(1),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "FitRate" decimal(6, 4) default 0 not null,
  "Remark" nvarchar2(60),
  "AcDate" decimal(8, 0) default 0 not null,
  "TellerNo" varchar2(6),
  "TxtNo" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanRateChange" add constraint "LoanRateChange_PK" primary key("CustNo", "FacmNo", "BormNo", "EffectDate");

alter table "LoanRateChange" add constraint "LoanRateChange_LoanBorMain_FK1" foreign key ("CustNo", "FacmNo", "BormNo") references "LoanBorMain" ("CustNo", "FacmNo", "BormNo") on delete cascade;

create index "LoanRateChange_Index1" on "LoanRateChange"("AcDate" asc, "TellerNo" asc, "TxSeq" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "EffectDate" asc);

comment on table "LoanRateChange" is '放款利率變動檔';
comment on column "LoanRateChange"."CustNo" is '借款人戶號';
comment on column "LoanRateChange"."FacmNo" is '額度編號';
comment on column "LoanRateChange"."BormNo" is '撥款序號';
comment on column "LoanRateChange"."EffectDate" is '生效日期';
comment on column "LoanRateChange"."Status" is '狀態';
comment on column "LoanRateChange"."RateCode" is '利率區分';
comment on column "LoanRateChange"."ProdNo" is '商品代碼';
comment on column "LoanRateChange"."BaseRateCode" is '指標利率代碼';
comment on column "LoanRateChange"."IncrFlag" is '加減碼是否依合約';
comment on column "LoanRateChange"."RateIncr" is '加碼利率';
comment on column "LoanRateChange"."IndividualIncr" is '個別加碼利率';
comment on column "LoanRateChange"."FitRate" is '適用利率';
comment on column "LoanRateChange"."Remark" is '備註';
comment on column "LoanRateChange"."AcDate" is '交易序號-會計日期';
comment on column "LoanRateChange"."TellerNo" is '交易序號-櫃員別';
comment on column "LoanRateChange"."TxtNo" is '交易序號-流水號';
comment on column "LoanRateChange"."CreateDate" is '建檔日期時間';
comment on column "LoanRateChange"."CreateEmpNo" is '建檔人員';
comment on column "LoanRateChange"."LastUpdate" is '最後更新日期時間';
comment on column "LoanRateChange"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanSynd" purge;

create table "LoanSynd" (
  "SyndNo" decimal(6, 0) default 0 not null,
  "LeadingBank" varchar2(7),
  "AgentBank" varchar2(7),
  "SigningDate" decimal(8, 0) default 0 not null,
  "SyndTypeCodeFlag" varchar2(1),
  "PartRate" decimal(6, 4) default 0 not null,
  "CurrencyCode" varchar2(3),
  "SyndAmt" decimal(16, 2) default 0 not null,
  "PartAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanSynd" add constraint "LoanSynd_PK" primary key("SyndNo");

comment on table "LoanSynd" is '聯貸案訂約檔';
comment on column "LoanSynd"."SyndNo" is '聯貸編號';
comment on column "LoanSynd"."LeadingBank" is '主辦行';
comment on column "LoanSynd"."AgentBank" is '代理行';
comment on column "LoanSynd"."SigningDate" is '簽約日';
comment on column "LoanSynd"."SyndTypeCodeFlag" is '國內或國際聯貸';
comment on column "LoanSynd"."PartRate" is '參貸費率';
comment on column "LoanSynd"."CurrencyCode" is '幣別';
comment on column "LoanSynd"."SyndAmt" is '聯貸總金額';
comment on column "LoanSynd"."PartAmt" is '參貸金額';
comment on column "LoanSynd"."CreateDate" is '建檔日期時間';
comment on column "LoanSynd"."CreateEmpNo" is '建檔人員';
comment on column "LoanSynd"."LastUpdate" is '最後更新日期時間';
comment on column "LoanSynd"."LastUpdateEmpNo" is '最後更新人員';
drop table "LoanSyndItem" purge;

create table "LoanSyndItem" (
  "SyndNo" decimal(6, 0) default 0 not null,
  "SyndSeq" decimal(3, 0) default 0 not null,
  "Item" varchar2(10),
  "SyndAmt" decimal(16, 2) default 0 not null,
  "SyndMark" nvarchar2(40),
  "SyndBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "LoanSyndItem" add constraint "LoanSyndItem_PK" primary key("SyndNo", "SyndSeq");

comment on table "LoanSyndItem" is '聯貸案費用檔';
comment on column "LoanSyndItem"."SyndNo" is '聯貸案編號';
comment on column "LoanSyndItem"."SyndSeq" is '聯貸案序號';
comment on column "LoanSyndItem"."Item" is '項別';
comment on column "LoanSyndItem"."SyndAmt" is '金額';
comment on column "LoanSyndItem"."SyndMark" is '備註';
comment on column "LoanSyndItem"."SyndBal" is '已銷金額';
comment on column "LoanSyndItem"."CreateDate" is '建檔日期時間';
comment on column "LoanSyndItem"."CreateEmpNo" is '建檔人員';
comment on column "LoanSyndItem"."LastUpdate" is '最後更新日期時間';
comment on column "LoanSyndItem"."LastUpdateEmpNo" is '最後更新人員';
drop table "MlaundryChkDtl" purge;

create table "MlaundryChkDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "Factor" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "DtlSeq" decimal(4, 0) default 0 not null,
  "DtlEntryDate" decimal(8, 0) default 0 not null,
  "RepayItem" nvarchar2(10),
  "DscptCode" varchar2(4),
  "TxAmt" decimal(16, 2) default 0 not null,
  "TotalCnt" decimal(3, 0) default 0 not null,
  "TotalAmt" decimal(16, 2) default 0 not null,
  "StartEntryDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryChkDtl" add constraint "MlaundryChkDtl_PK" primary key("EntryDate", "Factor", "CustNo", "DtlSeq");

comment on table "MlaundryChkDtl" is '疑似洗錢樣態檢核明細檔';
comment on column "MlaundryChkDtl"."EntryDate" is '入帳日期(統計期間迄日)';
comment on column "MlaundryChkDtl"."Factor" is '交易樣態';
comment on column "MlaundryChkDtl"."CustNo" is '戶號';
comment on column "MlaundryChkDtl"."DtlSeq" is '明細序號';
comment on column "MlaundryChkDtl"."DtlEntryDate" is '明細入帳日期';
comment on column "MlaundryChkDtl"."RepayItem" is '來源';
comment on column "MlaundryChkDtl"."DscptCode" is '摘要代碼';
comment on column "MlaundryChkDtl"."TxAmt" is '交易金額';
comment on column "MlaundryChkDtl"."TotalCnt" is '累積筆數';
comment on column "MlaundryChkDtl"."TotalAmt" is '累積金額';
comment on column "MlaundryChkDtl"."StartEntryDate" is '統計期間起日';
comment on column "MlaundryChkDtl"."CreateDate" is '建檔日期時間';
comment on column "MlaundryChkDtl"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryChkDtl"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryChkDtl"."LastUpdateEmpNo" is '最後更新人員';
drop table "MlaundryDetail" purge;

create table "MlaundryDetail" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "Factor" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "TotalCnt" decimal(4, 0) default 0 not null,
  "TotalAmt" decimal(16, 2) default 0 not null,
  "Rational" varchar2(1),
  "EmpNoDesc" nvarchar2(50),
  "ManagerDate" decimal(8, 0) default 0 not null,
  "ManagerCheck" varchar2(1),
  "ManagerDesc" nvarchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryDetail" add constraint "MlaundryDetail_PK" primary key("EntryDate", "Factor", "CustNo");

comment on table "MlaundryDetail" is '疑似洗錢交易合理性明細檔';
comment on column "MlaundryDetail"."EntryDate" is '入帳日期';
comment on column "MlaundryDetail"."Factor" is '交易樣態';
comment on column "MlaundryDetail"."CustNo" is '戶號';
comment on column "MlaundryDetail"."TotalCnt" is '累積筆數';
comment on column "MlaundryDetail"."TotalAmt" is '累積金額';
comment on column "MlaundryDetail"."Rational" is '合理性記號';
comment on column "MlaundryDetail"."EmpNoDesc" is '經辦合理性說明';
comment on column "MlaundryDetail"."ManagerDate" is '主管同意日期';
comment on column "MlaundryDetail"."ManagerCheck" is '主管覆核';
comment on column "MlaundryDetail"."ManagerDesc" is '主管覆核說明';
comment on column "MlaundryDetail"."CreateDate" is '建檔日期時間';
comment on column "MlaundryDetail"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryDetail"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "MlaundryParas" purge;

create table "MlaundryParas" (
  "BusinessType" varchar2(2),
  "Factor1TotLimit" decimal(16, 2) default 0 not null,
  "Factor2Count" decimal(4, 0) default 0 not null,
  "Factor2AmtStart" decimal(16, 2) default 0 not null,
  "Factor2AmtEnd" decimal(16, 2) default 0 not null,
  "Factor3TotLimit" decimal(16, 2) default 0 not null,
  "FactorDays" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryParas" add constraint "MlaundryParas_PK" primary key("BusinessType");

comment on table "MlaundryParas" is '疑似洗錢樣態條件設定檔';
comment on column "MlaundryParas"."BusinessType" is '業務類型';
comment on column "MlaundryParas"."Factor1TotLimit" is '洗錢樣態一金額合計超過';
comment on column "MlaundryParas"."Factor2Count" is '洗錢樣態二次數';
comment on column "MlaundryParas"."Factor2AmtStart" is '洗錢樣態二單筆起始金額';
comment on column "MlaundryParas"."Factor2AmtEnd" is '洗錢樣態二單筆迄止金額';
comment on column "MlaundryParas"."Factor3TotLimit" is '洗錢樣態三金額合計超過';
comment on column "MlaundryParas"."FactorDays" is '統計期間天數';
comment on column "MlaundryParas"."CreateDate" is '建檔日期時間';
comment on column "MlaundryParas"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryParas"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryParas"."LastUpdateEmpNo" is '最後更新人員';
drop table "MlaundryRecord" purge;

create table "MlaundryRecord" (
  "RecordDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayDate" decimal(8, 0) default 0 not null,
  "ActualRepayDate" decimal(8, 0) default 0 not null,
  "RepayAmt" decimal(16, 2) default 0 not null,
  "ActualRepayAmt" decimal(16, 2) default 0 not null,
  "Career" nvarchar2(20),
  "Income" nvarchar2(30),
  "RepaySource" decimal(2, 0) default 0 not null,
  "RepayBank" nvarchar2(10),
  "Description" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryRecord" add constraint "MlaundryRecord_PK" primary key("RecordDate", "CustNo", "FacmNo", "BormNo");

comment on table "MlaundryRecord" is '疑似洗錢交易訪談記錄檔';
comment on column "MlaundryRecord"."RecordDate" is '訪談日期';
comment on column "MlaundryRecord"."CustNo" is '戶號';
comment on column "MlaundryRecord"."FacmNo" is '額度編號';
comment on column "MlaundryRecord"."BormNo" is '撥款序號';
comment on column "MlaundryRecord"."RepayDate" is '預定還款日期';
comment on column "MlaundryRecord"."ActualRepayDate" is '實際還款日期';
comment on column "MlaundryRecord"."RepayAmt" is '預定還款金額';
comment on column "MlaundryRecord"."ActualRepayAmt" is '實際還款金額';
comment on column "MlaundryRecord"."Career" is '職業別';
comment on column "MlaundryRecord"."Income" is '年收入(萬)';
comment on column "MlaundryRecord"."RepaySource" is '還款來源';
comment on column "MlaundryRecord"."RepayBank" is '代償銀行';
comment on column "MlaundryRecord"."Description" is '其他說明';
comment on column "MlaundryRecord"."CreateDate" is '建檔日期時間';
comment on column "MlaundryRecord"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryRecord"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryRecord"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyFacBal" purge;

create table "MonthlyFacBal" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "DueDate" decimal(8, 0) default 0 not null,
  "OvduTerm" decimal(3, 0) default 0 not null,
  "OvduDays" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "AccCollPsn" varchar2(6),
  "LegalPsn" varchar2(6),
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "ProdNo" varchar2(5),
  "AcBookCode" varchar2(3),
  "EntCode" varchar2(1),
  "RelsCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "UnpaidPrincipal" decimal(16, 2) default 0 not null,
  "UnpaidInterest" decimal(16, 2) default 0 not null,
  "UnpaidBreachAmt" decimal(16, 2) default 0 not null,
  "UnpaidDelayInt" decimal(16, 2) default 0 not null,
  "AcdrPrincipal" decimal(16, 2) default 0 not null,
  "AcdrInterest" decimal(16, 2) default 0 not null,
  "AcdrBreachAmt" decimal(16, 2) default 0 not null,
  "AcdrDelayInt" decimal(16, 2) default 0 not null,
  "FireFee" decimal(16, 2) default 0 not null,
  "LawFee" decimal(16, 2) default 0 not null,
  "ModifyFee" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "ShortfallPrin" decimal(16, 2) default 0 not null,
  "ShortfallInt" decimal(16, 2) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "OvduDate" decimal(8, 0) default 0 not null,
  "OvduPrinBal" decimal(16, 2) default 0 not null,
  "OvduIntBal" decimal(16, 2) default 0 not null,
  "OvduBreachBal" decimal(16, 2) default 0 not null,
  "OvduBal" decimal(16, 2) default 0 not null,
  "LawAmount" decimal(16, 2) default 0 not null,
  "AssetClass" varchar2(2),
  "StoreRate" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "AcSubBookCode" varchar2(3)
);

alter table "MonthlyFacBal" add constraint "MonthlyFacBal_PK" primary key("YearMonth", "CustNo", "FacmNo");

comment on table "MonthlyFacBal" is '額度月報工作檔';
comment on column "MonthlyFacBal"."YearMonth" is '資料年月';
comment on column "MonthlyFacBal"."CustNo" is '戶號';
comment on column "MonthlyFacBal"."FacmNo" is '額度';
comment on column "MonthlyFacBal"."PrevIntDate" is '繳息迄日';
comment on column "MonthlyFacBal"."NextIntDate" is '應繳息日';
comment on column "MonthlyFacBal"."DueDate" is '最近應繳日';
comment on column "MonthlyFacBal"."OvduTerm" is '逾期期數';
comment on column "MonthlyFacBal"."OvduDays" is '逾期天數';
comment on column "MonthlyFacBal"."CurrencyCode" is '幣別';
comment on column "MonthlyFacBal"."PrinBalance" is '本金餘額';
comment on column "MonthlyFacBal"."BadDebtBal" is '呆帳餘額';
comment on column "MonthlyFacBal"."AccCollPsn" is '催收人員';
comment on column "MonthlyFacBal"."LegalPsn" is '法務人員';
comment on column "MonthlyFacBal"."Status" is '戶況';
comment on column "MonthlyFacBal"."AcctCode" is '業務科目代號';
comment on column "MonthlyFacBal"."FacAcctCode" is '額度業務科目';
comment on column "MonthlyFacBal"."ClCustNo" is '同擔保品戶號';
comment on column "MonthlyFacBal"."ClFacmNo" is '同擔保品額度';
comment on column "MonthlyFacBal"."ClRowNo" is '同擔保品序列號';
comment on column "MonthlyFacBal"."RenewCode" is '展期記號';
comment on column "MonthlyFacBal"."ProdNo" is '商品代碼';
comment on column "MonthlyFacBal"."AcBookCode" is '帳冊別';
comment on column "MonthlyFacBal"."EntCode" is '企金別';
comment on column "MonthlyFacBal"."RelsCode" is '(準)利害關係人職稱';
comment on column "MonthlyFacBal"."DepartmentCode" is '案件隸屬單位';
comment on column "MonthlyFacBal"."UnpaidPrincipal" is '已到期本金/轉催收本金';
comment on column "MonthlyFacBal"."UnpaidInterest" is '已到期利息/轉催收利息';
comment on column "MonthlyFacBal"."UnpaidBreachAmt" is '已到期違約金/轉催收違約金';
comment on column "MonthlyFacBal"."UnpaidDelayInt" is '已到期延滯息';
comment on column "MonthlyFacBal"."AcdrPrincipal" is '未到期回收本金';
comment on column "MonthlyFacBal"."AcdrInterest" is '未到期利息';
comment on column "MonthlyFacBal"."AcdrBreachAmt" is '未到期違約金';
comment on column "MonthlyFacBal"."AcdrDelayInt" is '未到期延滯息';
comment on column "MonthlyFacBal"."FireFee" is '火險費用';
comment on column "MonthlyFacBal"."LawFee" is '法務費用';
comment on column "MonthlyFacBal"."ModifyFee" is '契變手續費';
comment on column "MonthlyFacBal"."AcctFee" is '帳管費用';
comment on column "MonthlyFacBal"."ShortfallPrin" is '短繳本金';
comment on column "MonthlyFacBal"."ShortfallInt" is '短繳利息';
comment on column "MonthlyFacBal"."TempAmt" is '暫收金額';
comment on column "MonthlyFacBal"."ClCode1" is '主要擔保品代號1';
comment on column "MonthlyFacBal"."ClCode2" is '主要擔保品代號2';
comment on column "MonthlyFacBal"."ClNo" is '主要擔保品編號';
comment on column "MonthlyFacBal"."CityCode" is '主要擔保品地區別';
comment on column "MonthlyFacBal"."OvduDate" is '轉催收日期';
comment on column "MonthlyFacBal"."OvduPrinBal" is '催收本金餘額';
comment on column "MonthlyFacBal"."OvduIntBal" is '催收利息餘額';
comment on column "MonthlyFacBal"."OvduBreachBal" is '催收違約金餘額';
comment on column "MonthlyFacBal"."OvduBal" is '催收餘額';
comment on column "MonthlyFacBal"."LawAmount" is '無擔保債權設定金額(法務進度:901)';
comment on column "MonthlyFacBal"."AssetClass" is '資產五分類代號(有擔保部分)';
comment on column "MonthlyFacBal"."StoreRate" is '計息利率';
comment on column "MonthlyFacBal"."CreateDate" is '建檔日期時間';
comment on column "MonthlyFacBal"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyFacBal"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyFacBal"."LastUpdateEmpNo" is '最後更新人員';
comment on column "MonthlyFacBal"."AcSubBookCode" is '區隔帳冊';
drop table "MonthlyLM003" purge;

create table "MonthlyLM003" (
  "EntType" decimal(1, 0) default 0 not null,
  "DataYear" decimal(4, 0) default 0 not null,
  "DataMonth" decimal(2, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "CloseLoan" decimal(16, 2) default 0 not null,
  "CloseSale" decimal(16, 2) default 0 not null,
  "CloseSelfRepay" decimal(16, 2) default 0 not null,
  "ExtraRepay" decimal(16, 2) default 0 not null,
  "PrincipalAmortize" decimal(16, 2) default 0 not null,
  "Collection" decimal(16, 2) default 0 not null,
  "LoanBalance" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM003" add constraint "MonthlyLM003_PK" primary key("EntType", "DataYear", "DataMonth");

comment on table "MonthlyLM003" is '撥款還款金額比較月報工作檔';
comment on column "MonthlyLM003"."EntType" is '企金別';
comment on column "MonthlyLM003"."DataYear" is '資料年份';
comment on column "MonthlyLM003"."DataMonth" is '資料月份';
comment on column "MonthlyLM003"."DrawdownAmt" is '撥款金額';
comment on column "MonthlyLM003"."CloseLoan" is '結清-利率高轉貸';
comment on column "MonthlyLM003"."CloseSale" is '結清-買賣';
comment on column "MonthlyLM003"."CloseSelfRepay" is '結清-自行還款';
comment on column "MonthlyLM003"."ExtraRepay" is '非結清-部份還款';
comment on column "MonthlyLM003"."PrincipalAmortize" is '非結清-本金攤提';
comment on column "MonthlyLM003"."Collection" is '非結清-轉催收';
comment on column "MonthlyLM003"."LoanBalance" is '月底餘額';
comment on column "MonthlyLM003"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM003"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM003"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM003"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLM028" purge;

create table "MonthlyLM028" (
  "LMSSTS" decimal(2, 0) default 0 not null,
  "CUSENT" decimal(1, 0) default 0 not null,
  "CUSBRH" varchar2(4),
  "LMSACN" decimal(7, 0) default 0 not null,
  "LMSAPN" decimal(3, 0) default 0 not null,
  "LMSASQ" decimal(3, 0) default 0 not null,
  "IRTRAT" decimal(6, 4) default 0 not null,
  "LMSISC" decimal(2, 0) default 0 not null,
  "LMSPBK" varchar2(3),
  "APLMON" decimal(2, 0) default 0 not null,
  "APLDAY" decimal(3, 0) default 0 not null,
  "LMSLBL" decimal(16, 2) default 0 not null,
  "AILIRT" varchar2(1),
  "POSCDE" varchar2(1),
  "LMSPDY" decimal(2, 0) default 0 not null,
  "IRTFSC" decimal(2, 0) default 0 not null,
  "IRTBCD" varchar2(2),
  "IRTRATYR1" decimal(6, 4) default 0 not null,
  "IRTRATYR2" decimal(6, 4) default 0 not null,
  "IRTRATYR3" decimal(6, 4) default 0 not null,
  "IRTRATYR4" decimal(6, 4) default 0 not null,
  "IRTRATYR5" decimal(6, 4) default 0 not null,
  "GDRID1" decimal(1, 0) default 0 not null,
  "GDRID2" decimal(2, 0) default 0 not null,
  "YYYY" decimal(4, 0) default 0 not null,
  "MONTH" decimal(2, 0) default 0 not null,
  "DAY" decimal(2, 0) default 0 not null,
  "W08CDE" decimal(1, 0) default 0 not null,
  "RELATION" varchar2(1),
  "DPTLVL" varchar2(1),
  "ACTFSC" varchar2(1),
  "LIRTRATYR" decimal(6, 4) default 0 not null,
  "LIRTDAY" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM028" add constraint "MonthlyLM028_PK" primary key("LMSACN", "LMSAPN", "LMSASQ");

comment on table "MonthlyLM028" is 'LM028預估現金流量月報工作檔';
comment on column "MonthlyLM028"."LMSSTS" is '戶況';
comment on column "MonthlyLM028"."CUSENT" is '企金別';
comment on column "MonthlyLM028"."CUSBRH" is '營業單位別';
comment on column "MonthlyLM028"."LMSACN" is '借款人戶號';
comment on column "MonthlyLM028"."LMSAPN" is '額度編號';
comment on column "MonthlyLM028"."LMSASQ" is '撥款序號';
comment on column "MonthlyLM028"."IRTRAT" is '利率';
comment on column "MonthlyLM028"."LMSISC" is '繳息週期';
comment on column "MonthlyLM028"."LMSPBK" is '扣款銀行';
comment on column "MonthlyLM028"."APLMON" is '貸款期間－月';
comment on column "MonthlyLM028"."APLDAY" is '貸款期間－日';
comment on column "MonthlyLM028"."LMSLBL" is '放款餘額';
comment on column "MonthlyLM028"."AILIRT" is '利率區分';
comment on column "MonthlyLM028"."POSCDE" is '郵局存款別';
comment on column "MonthlyLM028"."LMSPDY" is '應繳日';
comment on column "MonthlyLM028"."IRTFSC" is '首次調整週期';
comment on column "MonthlyLM028"."IRTBCD" is '基本利率代碼';
comment on column "MonthlyLM028"."IRTRATYR1" is '利率1';
comment on column "MonthlyLM028"."IRTRATYR2" is '利率2';
comment on column "MonthlyLM028"."IRTRATYR3" is '利率3';
comment on column "MonthlyLM028"."IRTRATYR4" is '利率4';
comment on column "MonthlyLM028"."IRTRATYR5" is '利率5';
comment on column "MonthlyLM028"."GDRID1" is '押品別１';
comment on column "MonthlyLM028"."GDRID2" is '押品別２';
comment on column "MonthlyLM028"."YYYY" is '撥款日-年';
comment on column "MonthlyLM028"."MONTH" is '撥款日-月';
comment on column "MonthlyLM028"."DAY" is '撥款日-日';
comment on column "MonthlyLM028"."W08CDE" is '到期日碼';
comment on column "MonthlyLM028"."RELATION" is '是否為關係人';
comment on column "MonthlyLM028"."DPTLVL" is '制度別';
comment on column "MonthlyLM028"."ACTFSC" is '資金來源';
comment on column "MonthlyLM028"."LIRTRATYR" is '最新利率';
comment on column "MonthlyLM028"."LIRTDAY" is '最新利率生效起日';
comment on column "MonthlyLM028"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM028"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM028"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM028"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLM032" purge;

create table "MonthlyLM032" (
  "ADTYMT" decimal(6, 0) default 0 not null,
  "GDRID1" decimal(1, 0) default 0 not null,
  "W08PPR" decimal(5, 0) default 0 not null,
  "LMSACN" decimal(7, 0) default 0 not null,
  "LMSAPN" decimal(3, 0) default 0 not null,
  "W08LBL" decimal(16, 2) default 0 not null,
  "W08DLY" decimal(5, 0) default 0 not null,
  "STATUS" nvarchar2(2),
  "ADTYMT01" decimal(6, 0) default 0 not null,
  "GDRID101" decimal(1, 0) default 0 not null,
  "W08PPR01" decimal(5, 0) default 0 not null,
  "LMSACN01" decimal(7, 0) default 0 not null,
  "LMSAPN01" decimal(3, 0) default 0 not null,
  "W08LBL01" decimal(16, 2) default 0 not null,
  "W08DLY01" decimal(5, 0) default 0 not null,
  "ACTACT" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM032" add constraint "MonthlyLM032_PK" primary key("ADTYMT", "LMSACN", "LMSAPN");

comment on table "MonthlyLM032" is '逾期案件滾動率明細月報工作檔';
comment on column "MonthlyLM032"."ADTYMT" is '前期資料年月';
comment on column "MonthlyLM032"."GDRID1" is '前期擔保品代號1';
comment on column "MonthlyLM032"."W08PPR" is '前期逾期期數';
comment on column "MonthlyLM032"."LMSACN" is '前期戶號';
comment on column "MonthlyLM032"."LMSAPN" is '前期額度號碼';
comment on column "MonthlyLM032"."W08LBL" is '前期本金餘額';
comment on column "MonthlyLM032"."W08DLY" is '前期逾期天數';
comment on column "MonthlyLM032"."STATUS" is '當期戶況';
comment on column "MonthlyLM032"."ADTYMT01" is '當期資料年月';
comment on column "MonthlyLM032"."GDRID101" is '當期擔保品代號1';
comment on column "MonthlyLM032"."W08PPR01" is '當期逾期期數';
comment on column "MonthlyLM032"."LMSACN01" is '當期戶號';
comment on column "MonthlyLM032"."LMSAPN01" is '當期額度號碼';
comment on column "MonthlyLM032"."W08LBL01" is '當期本金餘額';
comment on column "MonthlyLM032"."W08DLY01" is '當期逾期天數';
comment on column "MonthlyLM032"."ACTACT" is '當期業務科目';
comment on column "MonthlyLM032"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM032"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM032"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM032"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLM036Portfolio" purge;

create table "MonthlyLM036Portfolio" (
  "DataMonth" decimal(6, 0) default 0 not null,
  "MonthEndDate" decimal(8, 0) default 0 not null,
  "PortfolioTotal" decimal(16, 2) default 0 not null,
  "NaturalPersonLoanBal" decimal(16, 2) default 0 not null,
  "LegalPersonLoanBal" decimal(16, 2) default 0 not null,
  "SyndLoanBal" decimal(16, 2) default 0 not null,
  "StockLoanBal" decimal(16, 2) default 0 not null,
  "OtherLoanbal" decimal(16, 2) default 0 not null,
  "AmortizeTotal" decimal(16, 2) default 0 not null,
  "OvduExpense" decimal(16, 2) default 0 not null,
  "NaturalPersonLargeCounts" decimal(16, 0) default 0 not null,
  "NaturalPersonLargeTotal" decimal(16, 2) default 0 not null,
  "LegalPersonLargeCounts" decimal(16, 0) default 0 not null,
  "LegalPersonLargeTotal" decimal(16, 2) default 0 not null,
  "NaturalPersonPercent" decimal(6, 4) default 0 not null,
  "LegalPersonPercent" decimal(6, 4) default 0 not null,
  "SyndPercent" decimal(6, 4) default 0 not null,
  "StockPercent" decimal(6, 4) default 0 not null,
  "OtherPercent" decimal(6, 4) default 0 not null,
  "EntUsedPercent" decimal(6, 4) default 0 not null,
  "InsuDividendRate" decimal(6, 4) default 0 not null,
  "NaturalPersonRate" decimal(6, 4) default 0 not null,
  "LegalPersonRate" decimal(6, 4) default 0 not null,
  "SyndRate" decimal(6, 4) default 0 not null,
  "StockRate" decimal(6, 4) default 0 not null,
  "OtherRate" decimal(6, 4) default 0 not null,
  "AvgRate" decimal(6, 4) default 0 not null,
  "HouseRateOfReturn" decimal(6, 4) default 0 not null,
  "EntRateOfReturn" decimal(6, 4) default 0 not null,
  "RateOfReturn" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM036Portfolio" add constraint "MonthlyLM036Portfolio_PK" primary key("DataMonth");

comment on table "MonthlyLM036Portfolio" is 'LM036Portfolio';
comment on column "MonthlyLM036Portfolio"."DataMonth" is '資料年月';
comment on column "MonthlyLM036Portfolio"."MonthEndDate" is '月底日期';
comment on column "MonthlyLM036Portfolio"."PortfolioTotal" is '授信組合餘額';
comment on column "MonthlyLM036Portfolio"."NaturalPersonLoanBal" is '自然人放款';
comment on column "MonthlyLM036Portfolio"."LegalPersonLoanBal" is '法人放款';
comment on column "MonthlyLM036Portfolio"."SyndLoanBal" is '聯貸案';
comment on column "MonthlyLM036Portfolio"."StockLoanBal" is '股票質押';
comment on column "MonthlyLM036Portfolio"."OtherLoanbal" is '一般法人放款';
comment on column "MonthlyLM036Portfolio"."AmortizeTotal" is '溢折價';
comment on column "MonthlyLM036Portfolio"."OvduExpense" is '催收費用';
comment on column "MonthlyLM036Portfolio"."NaturalPersonLargeCounts" is '自然人大額授信件件數';
comment on column "MonthlyLM036Portfolio"."NaturalPersonLargeTotal" is '自然人大額授信件餘額';
comment on column "MonthlyLM036Portfolio"."LegalPersonLargeCounts" is '法人大額授信件件數';
comment on column "MonthlyLM036Portfolio"."LegalPersonLargeTotal" is '法人大額授信件餘額';
comment on column "MonthlyLM036Portfolio"."NaturalPersonPercent" is '自然人放款占比';
comment on column "MonthlyLM036Portfolio"."LegalPersonPercent" is '法人放款占比';
comment on column "MonthlyLM036Portfolio"."SyndPercent" is '聯貸案占比';
comment on column "MonthlyLM036Portfolio"."StockPercent" is '股票質押占比';
comment on column "MonthlyLM036Portfolio"."OtherPercent" is '一般法人放款占比';
comment on column "MonthlyLM036Portfolio"."EntUsedPercent" is '企業放款動用率';
comment on column "MonthlyLM036Portfolio"."InsuDividendRate" is '保單分紅利率';
comment on column "MonthlyLM036Portfolio"."NaturalPersonRate" is '自然人當月平均利率';
comment on column "MonthlyLM036Portfolio"."LegalPersonRate" is '法人當月平均利率';
comment on column "MonthlyLM036Portfolio"."SyndRate" is '聯貸案平均利率';
comment on column "MonthlyLM036Portfolio"."StockRate" is '股票質押平均利率';
comment on column "MonthlyLM036Portfolio"."OtherRate" is '一般法人放款平均利率';
comment on column "MonthlyLM036Portfolio"."AvgRate" is '放款平均利率';
comment on column "MonthlyLM036Portfolio"."HouseRateOfReturn" is '房貸通路當月毛報酬率';
comment on column "MonthlyLM036Portfolio"."EntRateOfReturn" is '企金通路當月毛報酬率';
comment on column "MonthlyLM036Portfolio"."RateOfReturn" is '放款毛報酬率';
comment on column "MonthlyLM036Portfolio"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM036Portfolio"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM036Portfolio"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM036Portfolio"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLM052AssetClass" purge;

create table "MonthlyLM052AssetClass" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "AssetClassNo" varchar2(2),
  "AcSubBookCode" varchar2(3),
  "LoanBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM052AssetClass" add constraint "MonthlyLM052AssetClass_PK" primary key("YearMonth", "AssetClassNo", "AcSubBookCode");

comment on table "MonthlyLM052AssetClass" is 'LM052資產分類表';
comment on column "MonthlyLM052AssetClass"."YearMonth" is '資料年月';
comment on column "MonthlyLM052AssetClass"."AssetClassNo" is '資產五分類';
comment on column "MonthlyLM052AssetClass"."AcSubBookCode" is '區隔帳冊';
comment on column "MonthlyLM052AssetClass"."LoanBal" is '放款餘額';
comment on column "MonthlyLM052AssetClass"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM052AssetClass"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM052AssetClass"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM052AssetClass"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLM052LoanAsset" purge;

create table "MonthlyLM052LoanAsset" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "LoanAssetCode" varchar2(3),
  "LoanBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM052LoanAsset" add constraint "MonthlyLM052LoanAsset_PK" primary key("YearMonth", "LoanAssetCode");

comment on table "MonthlyLM052LoanAsset" is 'LM052放款資產表';
comment on column "MonthlyLM052LoanAsset"."YearMonth" is '資料年月';
comment on column "MonthlyLM052LoanAsset"."LoanAssetCode" is '放款資產項目';
comment on column "MonthlyLM052LoanAsset"."LoanBal" is '放款餘額';
comment on column "MonthlyLM052LoanAsset"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM052LoanAsset"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM052LoanAsset"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM052LoanAsset"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLM052Ovdu" purge;

create table "MonthlyLM052Ovdu" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "OvduNo" varchar2(1),
  "AcctCode" varchar2(3),
  "LoanBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM052Ovdu" add constraint "MonthlyLM052Ovdu_PK" primary key("YearMonth", "OvduNo", "AcctCode");

comment on table "MonthlyLM052Ovdu" is 'LM052逾期分類表';
comment on column "MonthlyLM052Ovdu"."YearMonth" is '資料年月';
comment on column "MonthlyLM052Ovdu"."OvduNo" is '逾期期數代號';
comment on column "MonthlyLM052Ovdu"."AcctCode" is '業務科目';
comment on column "MonthlyLM052Ovdu"."LoanBal" is '放款餘額';
comment on column "MonthlyLM052Ovdu"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM052Ovdu"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM052Ovdu"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM052Ovdu"."LastUpdateEmpNo" is '最後更新人員';
drop table "MonthlyLoanBal" purge;

create table "MonthlyLoanBal" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "LoanBalance" decimal(16, 2) default 0 not null,
  "MaxLoanBal" decimal(16, 2) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtAcc" decimal(16, 2) default 0 not null,
  "UnpaidInt" decimal(16, 2) default 0 not null,
  "UnexpiredInt" decimal(16, 2) default 0 not null,
  "SumRcvInt" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "ProdNo" varchar2(5),
  "AcBookCode" varchar2(3),
  "EntCode" varchar2(1),
  "RelsCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "OvduPrinAmt" decimal(16, 2) default 0 not null,
  "OvduIntAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "AcSubBookCode" varchar2(3)
);

alter table "MonthlyLoanBal" add constraint "MonthlyLoanBal_PK" primary key("YearMonth", "CustNo", "FacmNo", "BormNo");

comment on table "MonthlyLoanBal" is '每月放款餘額檔';
comment on column "MonthlyLoanBal"."YearMonth" is '資料年月';
comment on column "MonthlyLoanBal"."CustNo" is '戶號';
comment on column "MonthlyLoanBal"."FacmNo" is '額度編號';
comment on column "MonthlyLoanBal"."BormNo" is '撥款序號';
comment on column "MonthlyLoanBal"."AcctCode" is '業務科目代號';
comment on column "MonthlyLoanBal"."FacAcctCode" is '額度業務科目';
comment on column "MonthlyLoanBal"."CurrencyCode" is '幣別';
comment on column "MonthlyLoanBal"."LoanBalance" is '放款餘額';
comment on column "MonthlyLoanBal"."MaxLoanBal" is '當月最高放款餘額';
comment on column "MonthlyLoanBal"."StoreRate" is '計息利率';
comment on column "MonthlyLoanBal"."IntAmtRcv" is '實收利息';
comment on column "MonthlyLoanBal"."IntAmtAcc" is '提存利息';
comment on column "MonthlyLoanBal"."UnpaidInt" is '已到期未繳息';
comment on column "MonthlyLoanBal"."UnexpiredInt" is '未到期應收息';
comment on column "MonthlyLoanBal"."SumRcvInt" is '累計回收利息';
comment on column "MonthlyLoanBal"."IntAmt" is '本月利息';
comment on column "MonthlyLoanBal"."ProdNo" is '商品代碼';
comment on column "MonthlyLoanBal"."AcBookCode" is '帳冊別';
comment on column "MonthlyLoanBal"."EntCode" is '企金別';
comment on column "MonthlyLoanBal"."RelsCode" is '(準)利害關係人職稱';
comment on column "MonthlyLoanBal"."DepartmentCode" is '案件隸屬單位';
comment on column "MonthlyLoanBal"."ClCode1" is '主要擔保品代號1';
comment on column "MonthlyLoanBal"."ClCode2" is '主要擔保品代號2';
comment on column "MonthlyLoanBal"."ClNo" is '主要擔保品編號';
comment on column "MonthlyLoanBal"."CityCode" is '主要擔保品地區別';
comment on column "MonthlyLoanBal"."OvduPrinAmt" is '轉催收本金';
comment on column "MonthlyLoanBal"."OvduIntAmt" is '轉催收利息';
comment on column "MonthlyLoanBal"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLoanBal"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLoanBal"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLoanBal"."LastUpdateEmpNo" is '最後更新人員';
comment on column "MonthlyLoanBal"."AcSubBookCode" is '區隔帳冊';
drop table "MonthlyQ53" purge;

create table "MonthlyQ53" (
  "DataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyQ53" add constraint "MonthlyQ53_PK" primary key("DataYM");

comment on table "MonthlyQ53" is 'Q53工作檔';
comment on column "MonthlyQ53"."DataYM" is '日期年月';
comment on column "MonthlyQ53"."CreateDate" is '建檔日期時間';
comment on column "MonthlyQ53"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyQ53"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyQ53"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegAppr" purge;

create table "NegAppr" (
  "YyyyMm" decimal(6, 0) default 0 not null,
  "KindCode" decimal(1, 0) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ApprAcDate" decimal(8, 0) default 0 not null,
  "BringUpDate" decimal(8, 0) default 0 not null,
  "ExportMark" decimal(1, 0) default 0 not null,
  "ApprAcMark" decimal(1, 0) default 0 not null,
  "BringUpMark" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegAppr" add constraint "NegAppr_PK" primary key("YyyyMm", "KindCode");

comment on table "NegAppr" is '撥付日期設定';
comment on column "NegAppr"."YyyyMm" is '年月';
comment on column "NegAppr"."KindCode" is '類別';
comment on column "NegAppr"."ExportDate" is '製檔日';
comment on column "NegAppr"."ApprAcDate" is '傳票日';
comment on column "NegAppr"."BringUpDate" is '提兌日';
comment on column "NegAppr"."ExportMark" is '製檔日記號';
comment on column "NegAppr"."ApprAcMark" is '傳票日記號';
comment on column "NegAppr"."BringUpMark" is '提兌日記號';
comment on column "NegAppr"."CreateDate" is '建檔日期時間';
comment on column "NegAppr"."CreateEmpNo" is '建檔人員';
comment on column "NegAppr"."LastUpdate" is '最後更新日期時間';
comment on column "NegAppr"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegAppr01" purge;

create table "NegAppr01" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "FinCode" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "CaseKindCode" varchar2(1),
  "ApprAmt" decimal(16, 2) default 0 not null,
  "AccuApprAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ApprDate" decimal(8, 0) default 0 not null,
  "BringUpDate" decimal(8, 0) default 0 not null,
  "RemitBank" varchar2(7),
  "RemitAcct" varchar2(16),
  "DataSendUnit" varchar2(8),
  "ApprAcDate" decimal(8, 0) default 0 not null,
  "ReplyCode" varchar2(4),
  "BatchTxtNo" varchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegAppr01" add constraint "NegAppr01_PK" primary key("AcDate", "TitaTlrNo", "TitaTxtNo", "FinCode");

comment on table "NegAppr01" is '最大債權撥付資料檔';
comment on column "NegAppr01"."AcDate" is '會計日期';
comment on column "NegAppr01"."TitaTlrNo" is '經辦';
comment on column "NegAppr01"."TitaTxtNo" is '交易序號';
comment on column "NegAppr01"."FinCode" is '債權機構代號';
comment on column "NegAppr01"."CustNo" is '戶號';
comment on column "NegAppr01"."CaseSeq" is '案件序號';
comment on column "NegAppr01"."CaseKindCode" is '案件種類';
comment on column "NegAppr01"."ApprAmt" is '撥付金額';
comment on column "NegAppr01"."AccuApprAmt" is '累計撥付金額';
comment on column "NegAppr01"."AmtRatio" is '撥付比例';
comment on column "NegAppr01"."ExportDate" is '製檔日期';
comment on column "NegAppr01"."ApprDate" is '撥付日期';
comment on column "NegAppr01"."BringUpDate" is '提兌日';
comment on column "NegAppr01"."RemitBank" is '匯款銀行';
comment on column "NegAppr01"."RemitAcct" is '匯款帳號';
comment on column "NegAppr01"."DataSendUnit" is '資料傳送單位';
comment on column "NegAppr01"."ApprAcDate" is '撥付傳票日';
comment on column "NegAppr01"."ReplyCode" is '回應代碼';
comment on column "NegAppr01"."BatchTxtNo" is 'Batch交易序號';
comment on column "NegAppr01"."CreateDate" is '建檔日期時間';
comment on column "NegAppr01"."CreateEmpNo" is '建檔人員';
comment on column "NegAppr01"."LastUpdate" is '最後更新日期時間';
comment on column "NegAppr01"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegAppr02" purge;

create table "NegAppr02" (
  "BringUpDate" decimal(8, 0) default 0 not null,
  "FinCode" varchar2(8),
  "TxSeq" varchar2(10),
  "SendUnit" varchar2(8),
  "RecvUnit" varchar2(8),
  "EntryDate" decimal(8, 0) default 0 not null,
  "TransCode" varchar2(5),
  "TxAmt" decimal(16, 2) default 0 not null,
  "Consign" varchar2(8),
  "FinIns" varchar2(7),
  "RemitAcct" varchar2(16),
  "CustId" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(4),
  "AcDate" decimal(8, 0) default 0 not null,
  "TxKind" varchar2(1),
  "TxStatus" decimal(1, 0) default 0 not null,
  "NegTransAcDate" decimal(8, 0) default 0 not null,
  "NegTransTlrNo" varchar2(6),
  "NegTransTxtNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegAppr02" add constraint "NegAppr02_PK" primary key("BringUpDate", "FinCode", "TxSeq");

comment on table "NegAppr02" is '一般債權撥付資料檔';
comment on column "NegAppr02"."BringUpDate" is '提兌日';
comment on column "NegAppr02"."FinCode" is '債權機構代號';
comment on column "NegAppr02"."TxSeq" is '資料檔交易序號';
comment on column "NegAppr02"."SendUnit" is '發件單位';
comment on column "NegAppr02"."RecvUnit" is '收件單位';
comment on column "NegAppr02"."EntryDate" is '指定入/扣帳日';
comment on column "NegAppr02"."TransCode" is '轉帳類別';
comment on column "NegAppr02"."TxAmt" is '交易金額';
comment on column "NegAppr02"."Consign" is '委託單位';
comment on column "NegAppr02"."FinIns" is '金融機構';
comment on column "NegAppr02"."RemitAcct" is '轉帳帳號';
comment on column "NegAppr02"."CustId" is '帳戶ID';
comment on column "NegAppr02"."CustNo" is '戶號';
comment on column "NegAppr02"."StatusCode" is '還款狀況';
comment on column "NegAppr02"."AcDate" is '會計日期';
comment on column "NegAppr02"."TxKind" is '銷帳編號';
comment on column "NegAppr02"."TxStatus" is '交易狀態';
comment on column "NegAppr02"."NegTransAcDate" is '交易檔會計日';
comment on column "NegAppr02"."NegTransTlrNo" is '交易檔經辦';
comment on column "NegAppr02"."NegTransTxtNo" is '交易檔序號';
comment on column "NegAppr02"."CreateDate" is '建檔日期時間';
comment on column "NegAppr02"."CreateEmpNo" is '建檔人員';
comment on column "NegAppr02"."LastUpdate" is '最後更新日期時間';
comment on column "NegAppr02"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegFinAcct" purge;

create table "NegFinAcct" (
  "FinCode" varchar2(8),
  "FinItem" nvarchar2(60),
  "RemitBank" varchar2(7),
  "RemitAcct" varchar2(16),
  "DataSendSection" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegFinAcct" add constraint "NegFinAcct_PK" primary key("FinCode");

comment on table "NegFinAcct" is '債務協商債權機構帳戶檔';
comment on column "NegFinAcct"."FinCode" is '債權機構代號';
comment on column "NegFinAcct"."FinItem" is '債權機構名稱';
comment on column "NegFinAcct"."RemitBank" is '匯款銀行';
comment on column "NegFinAcct"."RemitAcct" is '匯款帳號';
comment on column "NegFinAcct"."DataSendSection" is '資料傳送單位';
comment on column "NegFinAcct"."CreateDate" is '建檔日期時間';
comment on column "NegFinAcct"."CreateEmpNo" is '建檔人員';
comment on column "NegFinAcct"."LastUpdate" is '最後更新日期時間';
comment on column "NegFinAcct"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegFinShare" purge;

create table "NegFinShare" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "FinCode" varchar2(8),
  "ContractAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegFinShare" add constraint "NegFinShare_PK" primary key("CustNo", "CaseSeq", "FinCode");

comment on table "NegFinShare" is '債務協商債權分攤檔';
comment on column "NegFinShare"."CustNo" is '債務人戶號';
comment on column "NegFinShare"."CaseSeq" is '案件序號';
comment on column "NegFinShare"."FinCode" is '債權機構';
comment on column "NegFinShare"."ContractAmt" is '簽約金額';
comment on column "NegFinShare"."AmtRatio" is '債權比例%';
comment on column "NegFinShare"."DueAmt" is '期款';
comment on column "NegFinShare"."CancelDate" is '註銷日期';
comment on column "NegFinShare"."CancelAmt" is '註銷本金';
comment on column "NegFinShare"."CreateDate" is '建檔日期時間';
comment on column "NegFinShare"."CreateEmpNo" is '建檔人員';
comment on column "NegFinShare"."LastUpdate" is '最後更新日期時間';
comment on column "NegFinShare"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegFinShareLog" purge;

create table "NegFinShareLog" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "Seq" decimal(4, 0) default 0 not null,
  "FinCode" varchar2(8),
  "ContractAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegFinShareLog" add constraint "NegFinShareLog_PK" primary key("CustNo", "CaseSeq", "Seq", "FinCode");

comment on table "NegFinShareLog" is '債務協商債權分攤檔歷程檔';
comment on column "NegFinShareLog"."CustNo" is '債務人戶號';
comment on column "NegFinShareLog"."CaseSeq" is '案件序號';
comment on column "NegFinShareLog"."Seq" is '歷程序號';
comment on column "NegFinShareLog"."FinCode" is '債權機構';
comment on column "NegFinShareLog"."ContractAmt" is '簽約金額';
comment on column "NegFinShareLog"."AmtRatio" is '債權比例%';
comment on column "NegFinShareLog"."DueAmt" is '期款';
comment on column "NegFinShareLog"."CancelDate" is '註銷日期';
comment on column "NegFinShareLog"."CancelAmt" is '註銷本金';
comment on column "NegFinShareLog"."CreateDate" is '建檔日期時間';
comment on column "NegFinShareLog"."CreateEmpNo" is '建檔人員';
comment on column "NegFinShareLog"."LastUpdate" is '最後更新日期時間';
comment on column "NegFinShareLog"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegMain" purge;

create table "NegMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "CaseKindCode" varchar2(1),
  "Status" varchar2(1),
  "CustLoanKind" varchar2(1),
  "PayerCustNo" decimal(7, 0) default 0 not null,
  "DeferYMStart" decimal(6, 0) default 0 not null,
  "DeferYMEnd" decimal(6, 0) default 0 not null,
  "ApplDate" decimal(8, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "IntRate" decimal(4, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "LastDueDate" decimal(8, 0) default 0 not null,
  "IsMainFin" varchar2(1),
  "TotalContrAmt" decimal(16, 2) default 0 not null,
  "MainFinCode" varchar2(8),
  "PrincipalBal" decimal(16, 2) default 0 not null,
  "AccuTempAmt" decimal(16, 2) default 0 not null,
  "AccuOverAmt" decimal(16, 2) default 0 not null,
  "AccuDueAmt" decimal(16, 2) default 0 not null,
  "AccuSklShareAmt" decimal(16, 2) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "TwoStepCode" varchar2(1),
  "ChgCondDate" decimal(8, 0) default 0 not null,
  "NextPayDate" decimal(8, 0) default 0 not null,
  "PayIntDate" decimal(8, 0) default 0 not null,
  "RepayPrincipal" decimal(14, 0) default 0 not null,
  "RepayInterest" decimal(14, 0) default 0 not null,
  "StatusDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "ThisAcDate" decimal(8, 0) default 0 not null,
  "ThisTitaTlrNo" varchar2(6),
  "ThisTitaTxtNo" decimal(8, 0) default 0 not null,
  "LastAcDate" decimal(8, 0) default 0 not null,
  "LastTitaTlrNo" varchar2(6),
  "LastTitaTxtNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegMain" add constraint "NegMain_PK" primary key("CustNo", "CaseSeq");

comment on table "NegMain" is '債務協商案件主檔';
comment on column "NegMain"."CustNo" is '戶號';
comment on column "NegMain"."CaseSeq" is '案件序號';
comment on column "NegMain"."CaseKindCode" is '案件種類';
comment on column "NegMain"."Status" is '債權戶況';
comment on column "NegMain"."CustLoanKind" is '債權戶別';
comment on column "NegMain"."PayerCustNo" is '付款人戶號';
comment on column "NegMain"."DeferYMStart" is '延期繳款年月(起)';
comment on column "NegMain"."DeferYMEnd" is '延期繳款年月(訖)';
comment on column "NegMain"."ApplDate" is '協商申請日';
comment on column "NegMain"."DueAmt" is '月付金(期款)';
comment on column "NegMain"."TotalPeriod" is '期數';
comment on column "NegMain"."IntRate" is '計息條件(利率)';
comment on column "NegMain"."FirstDueDate" is '首次應繳日';
comment on column "NegMain"."LastDueDate" is '還款結束日';
comment on column "NegMain"."IsMainFin" is '是否最大債權';
comment on column "NegMain"."TotalContrAmt" is '簽約總金額';
comment on column "NegMain"."MainFinCode" is '最大債權機構';
comment on column "NegMain"."PrincipalBal" is '總本金餘額';
comment on column "NegMain"."AccuTempAmt" is '累繳金額';
comment on column "NegMain"."AccuOverAmt" is '累溢繳金額';
comment on column "NegMain"."AccuDueAmt" is '累應還金額';
comment on column "NegMain"."AccuSklShareAmt" is '累新壽分攤金額';
comment on column "NegMain"."RepaidPeriod" is '已繳期數';
comment on column "NegMain"."TwoStepCode" is '二階段註記';
comment on column "NegMain"."ChgCondDate" is '申請變更還款條件日';
comment on column "NegMain"."NextPayDate" is '下次應繳日';
comment on column "NegMain"."PayIntDate" is '繳息迄日';
comment on column "NegMain"."RepayPrincipal" is '償還本金';
comment on column "NegMain"."RepayInterest" is '償還利息';
comment on column "NegMain"."StatusDate" is '戶況日期';
comment on column "NegMain"."CourtCode" is '受理調解機構代號';
comment on column "NegMain"."ThisAcDate" is '本次會計日期';
comment on column "NegMain"."ThisTitaTlrNo" is '本次經辦';
comment on column "NegMain"."ThisTitaTxtNo" is '本次交易序號';
comment on column "NegMain"."LastAcDate" is '上次會計日期';
comment on column "NegMain"."LastTitaTlrNo" is '上次經辦';
comment on column "NegMain"."LastTitaTxtNo" is '上次交易序號';
comment on column "NegMain"."CreateDate" is '建檔日期時間';
comment on column "NegMain"."CreateEmpNo" is '建檔人員';
comment on column "NegMain"."LastUpdate" is '最後更新日期時間';
comment on column "NegMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegQueryCust" purge;

create table "NegQueryCust" (
  "AcDate" decimal(8, 0) default 0 not null,
  "CustId" varchar2(10),
  "FileYN" varchar2(1),
  "SeqNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegQueryCust" add constraint "NegQueryCust_PK" primary key("AcDate", "CustId");

create index "NegQueryCust_Index1" on "NegQueryCust"("AcDate" asc, "CustId" asc);

comment on table "NegQueryCust" is '債協客戶請求資料';
comment on column "NegQueryCust"."AcDate" is '會計日期';
comment on column "NegQueryCust"."CustId" is '身份證字號/統一編號';
comment on column "NegQueryCust"."FileYN" is '是否已製檔';
comment on column "NegQueryCust"."SeqNo" is '批號';
comment on column "NegQueryCust"."CreateDate" is '建檔日期時間';
comment on column "NegQueryCust"."CreateEmpNo" is '建檔人員';
comment on column "NegQueryCust"."LastUpdate" is '最後更新日期時間';
comment on column "NegQueryCust"."LastUpdateEmpNo" is '最後更新人員';
drop table "NegTrans" purge;

create table "NegTrans" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "TxStatus" decimal(1, 0) default 0 not null,
  "TxKind" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "PrincipalBal" decimal(16, 2) default 0 not null,
  "ReturnAmt" decimal(16, 2) default 0 not null,
  "SklShareAmt" decimal(16, 2) default 0 not null,
  "ApprAmt" decimal(16, 2) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ExportAcDate" decimal(8, 0) default 0 not null,
  "TempRepayAmt" decimal(16, 2) default 0 not null,
  "OverRepayAmt" decimal(16, 2) default 0 not null,
  "PrincipalAmt" decimal(16, 2) default 0 not null,
  "InterestAmt" decimal(16, 2) default 0 not null,
  "OverAmt" decimal(16, 2) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "RepayPeriod" decimal(3, 0) default 0 not null,
  "RepayDate" decimal(8, 0) default 0 not null,
  "OrgAccuOverAmt" decimal(16, 2) default 0 not null,
  "AccuOverAmt" decimal(16, 2) default 0 not null,
  "ShouldPayPeriod" decimal(3, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "ThisEntdy" decimal(8, 0) default 0 not null,
  "ThisKinbr" varchar2(4),
  "ThisTlrNo" varchar2(6),
  "ThisTxtNo" varchar2(8),
  "ThisSeqNo" varchar2(30),
  "LastEntdy" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "LastSeqNo" varchar2(30),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegTrans" add constraint "NegTrans_PK" primary key("AcDate", "TitaTlrNo", "TitaTxtNo");

create index "NegTrans_Index1" on "NegTrans"("CustNo" asc, "CaseSeq" asc, "AcDate" asc, "TitaTlrNo" asc, "TitaTxtNo" asc);

comment on table "NegTrans" is '債務協商交易檔';
comment on column "NegTrans"."AcDate" is '會計日期';
comment on column "NegTrans"."TitaTlrNo" is '經辦';
comment on column "NegTrans"."TitaTxtNo" is '交易序號';
comment on column "NegTrans"."CustNo" is '戶號';
comment on column "NegTrans"."CaseSeq" is '案件序號';
comment on column "NegTrans"."EntryDate" is '入帳日期';
comment on column "NegTrans"."TxStatus" is '交易狀態';
comment on column "NegTrans"."TxKind" is '交易別';
comment on column "NegTrans"."TxAmt" is '交易金額';
comment on column "NegTrans"."PrincipalBal" is '本金餘額';
comment on column "NegTrans"."ReturnAmt" is '退還金額';
comment on column "NegTrans"."SklShareAmt" is '新壽攤分';
comment on column "NegTrans"."ApprAmt" is '撥付金額';
comment on column "NegTrans"."ExportDate" is '撥付製檔日';
comment on column "NegTrans"."ExportAcDate" is '撥付出帳日';
comment on column "NegTrans"."TempRepayAmt" is '暫收抵繳金額';
comment on column "NegTrans"."OverRepayAmt" is '溢收抵繳金額';
comment on column "NegTrans"."PrincipalAmt" is '本金金額';
comment on column "NegTrans"."InterestAmt" is '利息金額';
comment on column "NegTrans"."OverAmt" is '轉入溢收金額';
comment on column "NegTrans"."IntStartDate" is '繳息起日';
comment on column "NegTrans"."IntEndDate" is '繳息迄日';
comment on column "NegTrans"."RepayPeriod" is '還款期數';
comment on column "NegTrans"."RepayDate" is '入帳還款日期';
comment on column "NegTrans"."OrgAccuOverAmt" is '累溢繳款(交易前)';
comment on column "NegTrans"."AccuOverAmt" is '累溢繳款(交易後)';
comment on column "NegTrans"."ShouldPayPeriod" is '本次應還期數';
comment on column "NegTrans"."DueAmt" is '期金';
comment on column "NegTrans"."ThisEntdy" is '本次交易日';
comment on column "NegTrans"."ThisKinbr" is '本次分行別';
comment on column "NegTrans"."ThisTlrNo" is '本次交易員代號';
comment on column "NegTrans"."ThisTxtNo" is '本次交易序號';
comment on column "NegTrans"."ThisSeqNo" is '本次序號';
comment on column "NegTrans"."LastEntdy" is '上次交易日';
comment on column "NegTrans"."LastKinbr" is '上次分行別';
comment on column "NegTrans"."LastTlrNo" is '上次交易員代號';
comment on column "NegTrans"."LastTxtNo" is '上次交易序號';
comment on column "NegTrans"."LastSeqNo" is '上次序號';
comment on column "NegTrans"."CreateDate" is '建檔日期時間';
comment on column "NegTrans"."CreateEmpNo" is '建檔人員';
comment on column "NegTrans"."LastUpdate" is '最後更新日期時間';
comment on column "NegTrans"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfBsDetail" purge;

drop sequence "PfBsDetail_SEQ";

create table "PfBsDetail" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "BsOfficer" varchar2(6),
  "DeptCode" varchar2(6),
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "ProdCode" varchar2(5),
  "PieceCode" varchar2(1),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "PerfCnt" decimal(5, 1) default 0 not null,
  "PerfAmt" decimal(16, 2) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfBsDetail" add constraint "PfBsDetail_PK" primary key("LogNo");

create sequence "PfBsDetail_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

create index "PfBsDetail_Index1" on "PfBsDetail"("WorkMonth" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "PerfDate" asc);

create index "PfBsDetail_Index2" on "PfBsDetail"("CustNo" asc, "FacmNo" asc, "BormNo" asc, "PerfDate" asc);

comment on table "PfBsDetail" is '房貸專員業績明細檔';
comment on column "PfBsDetail"."LogNo" is '序號';
comment on column "PfBsDetail"."PerfDate" is '業績日期';
comment on column "PfBsDetail"."CustNo" is '戶號';
comment on column "PfBsDetail"."FacmNo" is '額度編號';
comment on column "PfBsDetail"."BormNo" is '撥款序號';
comment on column "PfBsDetail"."RepayType" is '還款類別';
comment on column "PfBsDetail"."BsOfficer" is '房貸專員';
comment on column "PfBsDetail"."DeptCode" is '部室代號';
comment on column "PfBsDetail"."DrawdownDate" is '撥款日';
comment on column "PfBsDetail"."ProdCode" is '商品代碼';
comment on column "PfBsDetail"."PieceCode" is '計件代碼';
comment on column "PfBsDetail"."DrawdownAmt" is '撥款金額/追回金額';
comment on column "PfBsDetail"."PerfCnt" is '件數';
comment on column "PfBsDetail"."PerfAmt" is '業績金額';
comment on column "PfBsDetail"."WorkMonth" is '工作月';
comment on column "PfBsDetail"."WorkSeason" is '工作季';
comment on column "PfBsDetail"."CreateDate" is '建檔日期時間';
comment on column "PfBsDetail"."CreateEmpNo" is '建檔人員';
comment on column "PfBsDetail"."LastUpdate" is '最後更新日期時間';
comment on column "PfBsDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfBsOfficer" purge;

create table "PfBsOfficer" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "EmpNo" varchar2(6),
  "Fullname" varchar2(40),
  "AreaCode" varchar2(6),
  "AreaItem" nvarchar2(12),
  "DeptCode" varchar2(6),
  "DepItem" nvarchar2(12),
  "DistCode" varchar2(6),
  "DistItem" nvarchar2(30),
  "StationName" nvarchar2(30),
  "GoalAmt" decimal(16, 2) default 0 not null,
  "SmryGoalAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfBsOfficer" add constraint "PfBsOfficer_PK" primary key("WorkMonth", "EmpNo");

comment on table "PfBsOfficer" is '房貸專員業績目標檔';
comment on column "PfBsOfficer"."WorkMonth" is '年月份';
comment on column "PfBsOfficer"."EmpNo" is '員工代號';
comment on column "PfBsOfficer"."Fullname" is '員工姓名';
comment on column "PfBsOfficer"."AreaCode" is '區域中心';
comment on column "PfBsOfficer"."AreaItem" is '中心中文';
comment on column "PfBsOfficer"."DeptCode" is '部室代號';
comment on column "PfBsOfficer"."DepItem" is '部室中文';
comment on column "PfBsOfficer"."DistCode" is '區部代號';
comment on column "PfBsOfficer"."DistItem" is '區部中文';
comment on column "PfBsOfficer"."StationName" is '駐在地';
comment on column "PfBsOfficer"."GoalAmt" is '目標金額';
comment on column "PfBsOfficer"."SmryGoalAmt" is '累計目標金額';
comment on column "PfBsOfficer"."CreateDate" is '建檔日期時間';
comment on column "PfBsOfficer"."CreateEmpNo" is '建檔人員';
comment on column "PfBsOfficer"."LastUpdate" is '最後更新日期時間';
comment on column "PfBsOfficer"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfCoOfficer" purge;

create table "PfCoOfficer" (
  "EmpNo" varchar2(6),
  "EffectiveDate" decimal(8, 0) default 0 not null,
  "IneffectiveDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "AreaItem" nvarchar2(20),
  "DistItem" nvarchar2(20),
  "DeptItem" nvarchar2(20),
  "EmpClass" varchar2(1),
  "ClassPass" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfCoOfficer" add constraint "PfCoOfficer_PK" primary key("EmpNo", "EffectiveDate");

comment on table "PfCoOfficer" is '協辦人員等級檔';
comment on column "PfCoOfficer"."EmpNo" is '員工代號';
comment on column "PfCoOfficer"."EffectiveDate" is '生效日期';
comment on column "PfCoOfficer"."IneffectiveDate" is '停效日期';
comment on column "PfCoOfficer"."AreaCode" is '單位代號';
comment on column "PfCoOfficer"."DistCode" is '區部代號';
comment on column "PfCoOfficer"."DeptCode" is '部室代號';
comment on column "PfCoOfficer"."AreaItem" is '單位中文';
comment on column "PfCoOfficer"."DistItem" is '區部中文';
comment on column "PfCoOfficer"."DeptItem" is '部室中文';
comment on column "PfCoOfficer"."EmpClass" is '協辦等級';
comment on column "PfCoOfficer"."ClassPass" is '初階授信通過';
comment on column "PfCoOfficer"."CreateDate" is '建檔日期時間';
comment on column "PfCoOfficer"."CreateEmpNo" is '建檔人員';
comment on column "PfCoOfficer"."LastUpdate" is '最後更新日期時間';
comment on column "PfCoOfficer"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfCoOfficerLog" purge;

create table "PfCoOfficerLog" (
  "EmpNo" varchar2(6),
  "EffectiveDate" decimal(8, 0) default 0 not null,
  "IneffectiveDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "AreaItem" varchar2(20),
  "DistItem" varchar2(20),
  "DeptItem" varchar2(20),
  "EmpClass" varchar2(1),
  "ClassPass" varchar2(1),
  "SerialNo" decimal(2, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfCoOfficerLog" add constraint "PfCoOfficerLog_PK" primary key("EmpNo", "EffectiveDate", "SerialNo");

comment on table "PfCoOfficerLog" is '協辦人員等級歷程檔';
comment on column "PfCoOfficerLog"."EmpNo" is '員工代號';
comment on column "PfCoOfficerLog"."EffectiveDate" is '生效日期';
comment on column "PfCoOfficerLog"."IneffectiveDate" is '停效日期';
comment on column "PfCoOfficerLog"."AreaCode" is '單位代號';
comment on column "PfCoOfficerLog"."DistCode" is '區部代號';
comment on column "PfCoOfficerLog"."DeptCode" is '部室代號';
comment on column "PfCoOfficerLog"."AreaItem" is '單位中文';
comment on column "PfCoOfficerLog"."DistItem" is '區部中文';
comment on column "PfCoOfficerLog"."DeptItem" is '部室中文';
comment on column "PfCoOfficerLog"."EmpClass" is '協辦等級';
comment on column "PfCoOfficerLog"."ClassPass" is '初階授信通過';
comment on column "PfCoOfficerLog"."SerialNo" is '序號';
comment on column "PfCoOfficerLog"."CreateDate" is '建檔日期時間';
comment on column "PfCoOfficerLog"."CreateEmpNo" is '建檔人員';
comment on column "PfCoOfficerLog"."LastUpdate" is '最後更新日期時間';
comment on column "PfCoOfficerLog"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfDeparment" purge;

create table "PfDeparment" (
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "EmpNo" varchar2(6),
  "UnitItem" nvarchar2(20),
  "DistItem" nvarchar2(20),
  "DeptItem" nvarchar2(20),
  "DirectorCode" varchar2(1),
  "EmpName" nvarchar2(8),
  "DepartOfficer" nvarchar2(8),
  "GoalCnt" decimal(4, 0) default 0 not null,
  "SumGoalCnt" decimal(16, 0) default 0 not null,
  "GoalAmt" decimal(16, 2) default 0 not null,
  "SumGoalAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfDeparment" add constraint "PfDeparment_PK" primary key("DistCode", "DeptCode", "UnitCode");

comment on table "PfDeparment" is '單位、區部、部室業績目標檔';
comment on column "PfDeparment"."UnitCode" is '單位代號';
comment on column "PfDeparment"."DistCode" is '區部代號';
comment on column "PfDeparment"."DeptCode" is '部室代號';
comment on column "PfDeparment"."EmpNo" is '員工代號';
comment on column "PfDeparment"."UnitItem" is '單位中文';
comment on column "PfDeparment"."DistItem" is '區部中文';
comment on column "PfDeparment"."DeptItem" is '部室中文';
comment on column "PfDeparment"."DirectorCode" is '處長主任別';
comment on column "PfDeparment"."EmpName" is '員工姓名';
comment on column "PfDeparment"."DepartOfficer" is '專員姓名';
comment on column "PfDeparment"."GoalCnt" is '目標件數';
comment on column "PfDeparment"."SumGoalCnt" is '累計目標件數';
comment on column "PfDeparment"."GoalAmt" is '目標金額';
comment on column "PfDeparment"."SumGoalAmt" is '累計目標金額';
comment on column "PfDeparment"."CreateDate" is '建檔日期時間';
comment on column "PfDeparment"."CreateEmpNo" is '建檔人員';
comment on column "PfDeparment"."LastUpdate" is '最後更新日期時間';
comment on column "PfDeparment"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfDetail" purge;

drop sequence "PfDetail_SEQ";

create table "PfDetail" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BorxNo" decimal(4, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "PieceCode" varchar2(1),
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "ProdCode" varchar2(5),
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "Introducer" nvarchar2(8),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "IsReNewEmpUnit" varchar2(1),
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "UnitManager" nvarchar2(8),
  "DistManager" nvarchar2(8),
  "DeptManager" nvarchar2(8),
  "ComputeItAmtFac" decimal(16, 2) default 0 not null,
  "ItPerfCnt" decimal(5, 1) default 0 not null,
  "ComputeItAmt" decimal(16, 2) default 0 not null,
  "ItPerfAmt" decimal(16, 2) default 0 not null,
  "ItPerfEqAmt" decimal(16, 2) default 0 not null,
  "ItPerfReward" decimal(16, 2) default 0 not null,
  "ComputeItBonusAmt" decimal(16, 2) default 0 not null,
  "ItBonus" decimal(16, 2) default 0 not null,
  "ComputeAddBonusAmt" decimal(16, 2) default 0 not null,
  "ItAddBonus" decimal(16, 2) default 0 not null,
  "ComputeCoBonusAmt" decimal(16, 2) default 0 not null,
  "CoorgnizerBonus" decimal(16, 2) default 0 not null,
  "BsOfficer" varchar2(6),
  "BsDeptCode" varchar2(6),
  "ComputeBsAmtFac" decimal(16, 2) default 0 not null,
  "BsPerfCnt" decimal(5, 1) default 0 not null,
  "ComputeBsAmt" decimal(16, 2) default 0 not null,
  "BsPerfAmt" decimal(16, 2) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "PieceCodeCombine" varchar2(1),
  "IsProdFinancial" varchar2(1),
  "IsIntroducerDay15" varchar2(1),
  "IsCoorgnizerDay15" varchar2(1),
  "IsProdExclude1" varchar2(1),
  "IsProdExclude2" varchar2(1),
  "IsProdExclude3" varchar2(1),
  "IsProdExclude4" varchar2(1),
  "IsProdExclude5" varchar2(1),
  "IsDeptExclude1" varchar2(1),
  "IsDeptExclude2" varchar2(1),
  "IsDeptExclude3" varchar2(1),
  "IsDeptExclude4" varchar2(1),
  "IsDeptExclude5" varchar2(1),
  "IsDay15Exclude1" varchar2(1),
  "IsDay15Exclude2" varchar2(1),
  "IsDay15Exclude3" varchar2(1),
  "IsDay15Exclude4" varchar2(1),
  "IsDay15Exclude5" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfDetail" add constraint "PfDetail_PK" primary key("LogNo");

create sequence "PfDetail_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

comment on table "PfDetail" is '業績計算明細檔';
comment on column "PfDetail"."LogNo" is '序號';
comment on column "PfDetail"."PerfDate" is '業績日期';
comment on column "PfDetail"."CustNo" is '戶號';
comment on column "PfDetail"."FacmNo" is '額度編號';
comment on column "PfDetail"."BormNo" is '撥款序號';
comment on column "PfDetail"."BorxNo" is '交易內容檔序號';
comment on column "PfDetail"."RepayType" is '還款類別';
comment on column "PfDetail"."DrawdownDate" is '撥款日';
comment on column "PfDetail"."DrawdownAmt" is '撥款金額/追回金額';
comment on column "PfDetail"."PieceCode" is '計件代碼';
comment on column "PfDetail"."RepaidPeriod" is '已攤還期數';
comment on column "PfDetail"."ProdCode" is '商品代碼';
comment on column "PfDetail"."CreditSysNo" is '案件編號';
comment on column "PfDetail"."Introducer" is '介紹人';
comment on column "PfDetail"."Coorgnizer" is '協辦人員編';
comment on column "PfDetail"."InterviewerA" is '晤談一員編';
comment on column "PfDetail"."InterviewerB" is '晤談二員編';
comment on column "PfDetail"."IsReNewEmpUnit" is '業績重算時是否以新員工資料更新介紹人所屬單位Y/N/null';
comment on column "PfDetail"."UnitCode" is '單位代號';
comment on column "PfDetail"."DistCode" is '區部代號';
comment on column "PfDetail"."DeptCode" is '部室代號';
comment on column "PfDetail"."UnitManager" is '處經理代號';
comment on column "PfDetail"."DistManager" is '區經理代號';
comment on column "PfDetail"."DeptManager" is '部經理代號';
comment on column "PfDetail"."ComputeItAmtFac" is '介紹單位件數累計計算金額';
comment on column "PfDetail"."ItPerfCnt" is '介紹單位件數';
comment on column "PfDetail"."ComputeItAmt" is '介紹人業績金額計算金額';
comment on column "PfDetail"."ItPerfAmt" is '介紹人業績金額';
comment on column "PfDetail"."ItPerfEqAmt" is '介紹人換算業績';
comment on column "PfDetail"."ItPerfReward" is '介紹人業務報酬';
comment on column "PfDetail"."ComputeItBonusAmt" is '介紹人介紹獎金計算金額';
comment on column "PfDetail"."ItBonus" is '介紹人介紹獎金';
comment on column "PfDetail"."ComputeAddBonusAmt" is '介紹人加碼獎勵津貼計算金額';
comment on column "PfDetail"."ItAddBonus" is '介紹人加碼獎勵津貼';
comment on column "PfDetail"."ComputeCoBonusAmt" is '協辦人員協辦獎金計算金額';
comment on column "PfDetail"."CoorgnizerBonus" is '協辦人員協辦獎金';
comment on column "PfDetail"."BsOfficer" is '房貸專員';
comment on column "PfDetail"."BsDeptCode" is '部室代號';
comment on column "PfDetail"."ComputeBsAmtFac" is '房貸專員件數累計計算金額';
comment on column "PfDetail"."BsPerfCnt" is '房貸專員件數';
comment on column "PfDetail"."ComputeBsAmt" is '房貸專員計算金額';
comment on column "PfDetail"."BsPerfAmt" is '房貸專員業績金額';
comment on column "PfDetail"."WorkMonth" is '工作月';
comment on column "PfDetail"."WorkSeason" is '工作季';
comment on column "PfDetail"."PieceCodeCombine" is '連同計件代碼';
comment on column "PfDetail"."IsProdFinancial" is '理財型房貸(Y/N)';
comment on column "PfDetail"."IsIntroducerDay15" is '介紹人是否為15日薪(Y/Null)';
comment on column "PfDetail"."IsCoorgnizerDay15" is '協辦人員是否為15日薪(Y/Null)';
comment on column "PfDetail"."IsProdExclude1" is '計算業績排除商品別(Y/Null)';
comment on column "PfDetail"."IsProdExclude2" is '計算業績排除商品別(Y/Null)';
comment on column "PfDetail"."IsProdExclude3" is '計算業績排除商品別(Y/Null)';
comment on column "PfDetail"."IsProdExclude4" is '計算業績排除商品別(Y/Nnull)';
comment on column "PfDetail"."IsProdExclude5" is '計算業績排除商品別(Y/Null)';
comment on column "PfDetail"."IsDeptExclude1" is '是否屬排徐部門別(Y/Null)';
comment on column "PfDetail"."IsDeptExclude2" is '是否屬排徐部門別(Y/Null)';
comment on column "PfDetail"."IsDeptExclude3" is '是否屬排徐部門別(Y/Null)';
comment on column "PfDetail"."IsDeptExclude4" is '是否屬排徐部門別(Y/Null)';
comment on column "PfDetail"."IsDeptExclude5" is '是否屬排徐部門別(Y/Null)';
comment on column "PfDetail"."IsDay15Exclude1" is '是否屬15日薪被排除(Y/Null/E-屬15日薪未設排除條件)';
comment on column "PfDetail"."IsDay15Exclude2" is '是否屬15日薪被排除(Y/Null/E-屬15日薪未設排除條件)';
comment on column "PfDetail"."IsDay15Exclude3" is '是否屬15日薪被排除(Y/Null/E-屬15日薪未設排除條件)';
comment on column "PfDetail"."IsDay15Exclude4" is '是否屬15日薪被排除(Y/Null/E-屬15日薪未設排除條件)';
comment on column "PfDetail"."IsDay15Exclude5" is '是否屬15日薪被排除(Y/Null/E-屬15日薪未設排除條件)';
comment on column "PfDetail"."CreateDate" is '建檔日期時間';
comment on column "PfDetail"."CreateEmpNo" is '建檔人員';
comment on column "PfDetail"."LastUpdate" is '最後更新日期時間';
comment on column "PfDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfInsCheck" purge;

create table "PfInsCheck" (
  "Kind" decimal(1, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "ApplDate" decimal(8, 0) default 0 not null,
  "InsDate" decimal(8, 0) default 0 not null,
  "InsNo" varchar2(15),
  "CheckResult" varchar2(1),
  "CheckWorkMonth" decimal(6, 0) default 0 not null,
  "ReturnMsg" nvarchar2(2000),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfInsCheck" add constraint "PfInsCheck_PK" primary key("Kind", "CustNo", "FacmNo");

comment on table "PfInsCheck" is '房貸獎勵保費檢核檔';
comment on column "PfInsCheck"."Kind" is '類別';
comment on column "PfInsCheck"."CustNo" is '戶號';
comment on column "PfInsCheck"."FacmNo" is '額度編號';
comment on column "PfInsCheck"."CreditSysNo" is '徵審系統案號(eLoan案件編號)';
comment on column "PfInsCheck"."CustId" is '借款人身份證字號';
comment on column "PfInsCheck"."ApplDate" is '借款書申請日';
comment on column "PfInsCheck"."InsDate" is '承保日';
comment on column "PfInsCheck"."InsNo" is '保單號碼';
comment on column "PfInsCheck"."CheckResult" is '檢核結果(Y/N)';
comment on column "PfInsCheck"."CheckWorkMonth" is '檢核工作月';
comment on column "PfInsCheck"."ReturnMsg" is '回應訊息';
comment on column "PfInsCheck"."CreateDate" is '建檔日期時間';
comment on column "PfInsCheck"."CreateEmpNo" is '建檔人員';
comment on column "PfInsCheck"."LastUpdate" is '最後更新日期時間';
comment on column "PfInsCheck"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfIntranetAdjust" purge;

drop sequence "PfIntranetAdjust_SEQ";

create table "PfIntranetAdjust" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "Introducer" varchar2(6),
  "BsOfficer" varchar2(6),
  "PerfAmt" decimal(16, 2) default 0 not null,
  "PerfCnt" decimal(5, 1) default 0 not null,
  "UnitType" varchar2(1),
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "SumAmtSign" varchar2(1),
  "SumAmt" decimal(16, 2) default 0 not null,
  "SumCntSign" varchar2(1),
  "SumCnt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfIntranetAdjust" add constraint "PfIntranetAdjust_PK" primary key("LogNo");

create sequence "PfIntranetAdjust_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

comment on table "PfIntranetAdjust" is '內網報表業績調整檔';
comment on column "PfIntranetAdjust"."LogNo" is '序號';
comment on column "PfIntranetAdjust"."CustNo" is '戶號';
comment on column "PfIntranetAdjust"."FacmNo" is '額度編號';
comment on column "PfIntranetAdjust"."BormNo" is '撥款序號';
comment on column "PfIntranetAdjust"."PerfDate" is '業績日期';
comment on column "PfIntranetAdjust"."WorkMonth" is '工作月';
comment on column "PfIntranetAdjust"."WorkSeason" is '工作季';
comment on column "PfIntranetAdjust"."Introducer" is '介紹人';
comment on column "PfIntranetAdjust"."BsOfficer" is '房貸專員';
comment on column "PfIntranetAdjust"."PerfAmt" is '業績金額';
comment on column "PfIntranetAdjust"."PerfCnt" is '業績件數';
comment on column "PfIntranetAdjust"."UnitType" is '單位類別';
comment on column "PfIntranetAdjust"."UnitCode" is '單位代號';
comment on column "PfIntranetAdjust"."DistCode" is '區部代號';
comment on column "PfIntranetAdjust"."DeptCode" is '部室代號';
comment on column "PfIntranetAdjust"."SumAmtSign" is '累計達成金額加減號';
comment on column "PfIntranetAdjust"."SumAmt" is '累計達成金額';
comment on column "PfIntranetAdjust"."SumCntSign" is '累計達成件數加減號';
comment on column "PfIntranetAdjust"."SumCnt" is '累計達成件數';
comment on column "PfIntranetAdjust"."CreateDate" is '建檔日期時間';
comment on column "PfIntranetAdjust"."CreateEmpNo" is '建檔人員';
comment on column "PfIntranetAdjust"."LastUpdate" is '最後更新日期時間';
comment on column "PfIntranetAdjust"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfItDetail" purge;

drop sequence "PfItDetail_SEQ";

create table "PfItDetail" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "ProdCode" varchar2(5),
  "PieceCode" varchar2(1),
  "CntingCode" varchar2(1),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "Introducer" nvarchar2(8),
  "UnitManager" nvarchar2(8),
  "DistManager" nvarchar2(8),
  "DeptManager" nvarchar2(8),
  "PerfCnt" decimal(5, 1) default 0 not null,
  "PerfEqAmt" decimal(16, 2) default 0 not null,
  "PerfReward" decimal(16, 2) default 0 not null,
  "PerfAmt" decimal(16, 2) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "RewardDate" decimal(8, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfItDetail" add constraint "PfItDetail_PK" primary key("LogNo");

create sequence "PfItDetail_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

create index "PfItDetail_Index1" on "PfItDetail"("WorkMonth" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "PerfDate" asc);

create index "PfItDetail_Index2" on "PfItDetail"("CustNo" asc, "FacmNo" asc, "BormNo" asc, "PerfDate" asc);

create index "PfItDetail_Index3" on "PfItDetail"("RewardDate" asc);

comment on table "PfItDetail" is '介紹人業績明細檔';
comment on column "PfItDetail"."LogNo" is '序號';
comment on column "PfItDetail"."PerfDate" is '業績日期';
comment on column "PfItDetail"."CustNo" is '戶號';
comment on column "PfItDetail"."FacmNo" is '額度編號';
comment on column "PfItDetail"."BormNo" is '撥款序號';
comment on column "PfItDetail"."RepayType" is '還款類別';
comment on column "PfItDetail"."DrawdownDate" is '撥款日';
comment on column "PfItDetail"."ProdCode" is '商品代碼';
comment on column "PfItDetail"."PieceCode" is '計件代碼';
comment on column "PfItDetail"."CntingCode" is '是否計件';
comment on column "PfItDetail"."DrawdownAmt" is '撥款金額/追回金額';
comment on column "PfItDetail"."UnitCode" is '單位代號';
comment on column "PfItDetail"."DistCode" is '區部代號';
comment on column "PfItDetail"."DeptCode" is '部室代號';
comment on column "PfItDetail"."Introducer" is '介紹人';
comment on column "PfItDetail"."UnitManager" is '處經理代號';
comment on column "PfItDetail"."DistManager" is '區經理代號';
comment on column "PfItDetail"."DeptManager" is '部經理代號';
comment on column "PfItDetail"."PerfCnt" is '件數';
comment on column "PfItDetail"."PerfEqAmt" is '換算業績';
comment on column "PfItDetail"."PerfReward" is '業務報酬';
comment on column "PfItDetail"."PerfAmt" is '業績金額';
comment on column "PfItDetail"."WorkMonth" is '工作月';
comment on column "PfItDetail"."WorkSeason" is '工作季';
comment on column "PfItDetail"."RewardDate" is '保費檢核日';
comment on column "PfItDetail"."MediaDate" is '產出媒體檔日期';
comment on column "PfItDetail"."MediaFg" is '產出媒體檔記號';
comment on column "PfItDetail"."CreateDate" is '建檔日期時間';
comment on column "PfItDetail"."CreateEmpNo" is '建檔人員';
comment on column "PfItDetail"."LastUpdate" is '最後更新日期時間';
comment on column "PfItDetail"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfReward" purge;

drop sequence "PfReward_SEQ";

create table "PfReward" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "PieceCode" varchar2(1),
  "ProdCode" varchar2(5),
  "Introducer" varchar2(6),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "IntroducerBonus" decimal(16, 2) default 0 not null,
  "IntroducerBonusDate" decimal(8, 0) default 0 not null,
  "IntroducerAddBonus" decimal(16, 2) default 0 not null,
  "IntroducerAddBonusDate" decimal(8, 0) default 0 not null,
  "CoorgnizerBonus" decimal(16, 2) default 0 not null,
  "CoorgnizerBonusDate" decimal(8, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfReward" add constraint "PfReward_PK" primary key("LogNo");

create sequence "PfReward_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

create index "PfReward_Index1" on "PfReward"("WorkMonth" asc, "CustNo" asc, "FacmNo" asc, "BormNo" asc, "PerfDate" asc);

create index "PfReward_Index2" on "PfReward"("CustNo" asc, "FacmNo" asc, "BormNo" asc, "PerfDate" asc);

comment on table "PfReward" is '介紹、協辦獎金明細檔';
comment on column "PfReward"."LogNo" is '序號';
comment on column "PfReward"."PerfDate" is '業績日期';
comment on column "PfReward"."CustNo" is '戶號';
comment on column "PfReward"."FacmNo" is '額度編號';
comment on column "PfReward"."BormNo" is '撥款序號';
comment on column "PfReward"."RepayType" is '還款類別';
comment on column "PfReward"."PieceCode" is '計件代碼';
comment on column "PfReward"."ProdCode" is '商品代碼';
comment on column "PfReward"."Introducer" is '介紹人員編';
comment on column "PfReward"."Coorgnizer" is '協辦人員編';
comment on column "PfReward"."InterviewerA" is '晤談一員編';
comment on column "PfReward"."InterviewerB" is '晤談二員編';
comment on column "PfReward"."IntroducerBonus" is '介紹人介紹獎金';
comment on column "PfReward"."IntroducerBonusDate" is '介紹獎金轉檔日';
comment on column "PfReward"."IntroducerAddBonus" is '介紹人加碼獎勵津貼';
comment on column "PfReward"."IntroducerAddBonusDate" is '獎勵津貼轉檔日';
comment on column "PfReward"."CoorgnizerBonus" is '協辦人員協辦獎金';
comment on column "PfReward"."CoorgnizerBonusDate" is '協辦獎金轉檔日';
comment on column "PfReward"."WorkMonth" is '工作月';
comment on column "PfReward"."WorkSeason" is '工作季';
comment on column "PfReward"."CreateDate" is '建檔日期時間';
comment on column "PfReward"."CreateEmpNo" is '建檔人員';
comment on column "PfReward"."LastUpdate" is '最後更新日期時間';
comment on column "PfReward"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfRewardMedia" purge;

drop sequence "PfRewardMedia_SEQ";

create table "PfRewardMedia" (
  "BonusNo" decimal(11,0) not null,
  "BonusDate" decimal(8, 0) default 0 not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BonusType" decimal(1, 0) default 0 not null,
  "EmployeeNo" varchar2(6),
  "ProdCode" varchar2(5),
  "PieceCode" varchar2(1),
  "Bonus" decimal(14, 2) default 0 not null,
  "AdjustBonus" decimal(14, 2) default 0 not null,
  "AdjustBonusDate" decimal(8, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "Remark" nvarchar2(50),
  "MediaFg" decimal(1, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "ManualFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfRewardMedia" add constraint "PfRewardMedia_PK" primary key("BonusNo");

create sequence "PfRewardMedia_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

create index "PfRewardMedia_Index1" on "PfRewardMedia"("WorkMonth" asc, "BonusNo" asc);

comment on table "PfRewardMedia" is '獎金媒體發放檔';
comment on column "PfRewardMedia"."BonusNo" is '系統序號';
comment on column "PfRewardMedia"."BonusDate" is '獎金發放日';
comment on column "PfRewardMedia"."PerfDate" is '業績日期';
comment on column "PfRewardMedia"."CustNo" is '戶號';
comment on column "PfRewardMedia"."FacmNo" is '額度編號';
comment on column "PfRewardMedia"."BormNo" is '撥款序號';
comment on column "PfRewardMedia"."BonusType" is '獎金類別';
comment on column "PfRewardMedia"."EmployeeNo" is '獎金發放員工編號';
comment on column "PfRewardMedia"."ProdCode" is '商品代碼';
comment on column "PfRewardMedia"."PieceCode" is '計件代碼';
comment on column "PfRewardMedia"."Bonus" is '原始獎金';
comment on column "PfRewardMedia"."AdjustBonus" is '發放獎金';
comment on column "PfRewardMedia"."AdjustBonusDate" is '調整獎金日期';
comment on column "PfRewardMedia"."WorkMonth" is '工作月';
comment on column "PfRewardMedia"."WorkSeason" is '工作季';
comment on column "PfRewardMedia"."Remark" is '備註';
comment on column "PfRewardMedia"."MediaFg" is '產出媒體檔記號';
comment on column "PfRewardMedia"."MediaDate" is '產出媒體檔日期';
comment on column "PfRewardMedia"."ManualFg" is '人工新增記號';
comment on column "PfRewardMedia"."CreateDate" is '建檔日期時間';
comment on column "PfRewardMedia"."CreateEmpNo" is '建檔人員';
comment on column "PfRewardMedia"."LastUpdate" is '最後更新日期時間';
comment on column "PfRewardMedia"."LastUpdateEmpNo" is '最後更新人員';
drop table "PfSpecParms" purge;

create table "PfSpecParms" (
  "ConditionCode" varchar2(1),
  "Condition" varchar2(6),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PfSpecParms" add constraint "PfSpecParms_PK" primary key("ConditionCode", "Condition");

comment on table "PfSpecParms" is '業績計算特殊參數設定檔';
comment on column "PfSpecParms"."ConditionCode" is '條件記號';
comment on column "PfSpecParms"."Condition" is '標準條件';
comment on column "PfSpecParms"."CreateDate" is '建檔日期時間';
comment on column "PfSpecParms"."CreateEmpNo" is '建檔人員';
comment on column "PfSpecParms"."LastUpdate" is '最後更新日期時間';
comment on column "PfSpecParms"."LastUpdateEmpNo" is '最後更新人員';
drop table "PostAuthLog" purge;

create table "PostAuthLog" (
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "AuthApplCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "AuthCode" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "RepayAcctSeq" varchar2(2),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "StampCancelDate" decimal(8, 0) default 0 not null,
  "StampCode" varchar2(1),
  "PostMediaCode" varchar2(1),
  "AuthErrorCode" varchar2(2),
  "FileSeq" decimal(6, 0) default 0 not null,
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "TitaTxCd" varchar2(5),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "PostAuthLog" add constraint "PostAuthLog_PK" primary key("AuthCreateDate", "AuthApplCode", "CustNo", "PostDepCode", "RepayAcct", "AuthCode");

create index "PostAuthLog_Index1" on "PostAuthLog"("AuthCreateDate" asc);

create index "PostAuthLog_Index2" on "PostAuthLog"("PostMediaCode" asc, "AuthErrorCode" asc);

create index "PostAuthLog_Index3" on "PostAuthLog"("PropDate" asc);

create index "PostAuthLog_Index4" on "PostAuthLog"("RetrDate" asc);

comment on table "PostAuthLog" is '郵局授權記錄檔';
comment on column "PostAuthLog"."AuthCreateDate" is '建檔日期';
comment on column "PostAuthLog"."AuthApplCode" is '申請代號，狀態碼';
comment on column "PostAuthLog"."CustNo" is '戶號';
comment on column "PostAuthLog"."PostDepCode" is '帳戶別';
comment on column "PostAuthLog"."RepayAcct" is '儲金帳號';
comment on column "PostAuthLog"."AuthCode" is '授權方式';
comment on column "PostAuthLog"."FacmNo" is '額度';
comment on column "PostAuthLog"."CustId" is '統一編號';
comment on column "PostAuthLog"."RepayAcctSeq" is '帳號碼';
comment on column "PostAuthLog"."ProcessDate" is '處理日期';
comment on column "PostAuthLog"."StampFinishDate" is '核印完成日期';
comment on column "PostAuthLog"."StampCancelDate" is '核印取消日期';
comment on column "PostAuthLog"."StampCode" is '核印註記';
comment on column "PostAuthLog"."PostMediaCode" is '媒體碼';
comment on column "PostAuthLog"."AuthErrorCode" is '狀況代號，授權狀態';
comment on column "PostAuthLog"."FileSeq" is '媒體檔流水編號';
comment on column "PostAuthLog"."PropDate" is '提出日期';
comment on column "PostAuthLog"."RetrDate" is '提回日期';
comment on column "PostAuthLog"."DeleteDate" is '暫停授權日期';
comment on column "PostAuthLog"."RelationCode" is '與借款人關係';
comment on column "PostAuthLog"."RelAcctName" is '第三人帳戶戶名';
comment on column "PostAuthLog"."RelationId" is '第三人身分證字號';
comment on column "PostAuthLog"."RelAcctBirthday" is '第三人出生日期';
comment on column "PostAuthLog"."RelAcctGender" is '第三人性別';
comment on column "PostAuthLog"."AmlRsp" is 'AML回應碼';
comment on column "PostAuthLog"."TitaTxCd" is '交易代號';
comment on column "PostAuthLog"."CreateEmpNo" is '建立者櫃員編號';
comment on column "PostAuthLog"."CreateDate" is '建檔日期';
comment on column "PostAuthLog"."LastUpdateEmpNo" is '修改者櫃員編號';
comment on column "PostAuthLog"."LastUpdate" is '異動日期';
drop table "PostAuthLogHistory" purge;

drop sequence "PostAuthLogHistory_SEQ";

create table "PostAuthLogHistory" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthCode" varchar2(1),
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "AuthApplCode" varchar2(1),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "CustId" varchar2(10),
  "RepayAcctSeq" varchar2(2),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "StampCancelDate" decimal(8, 0) default 0 not null,
  "StampCode" varchar2(1),
  "PostMediaCode" varchar2(1),
  "AuthErrorCode" varchar2(2),
  "FileSeq" decimal(6, 0) default 0 not null,
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);

alter table "PostAuthLogHistory" add constraint "PostAuthLogHistory_PK" primary key("LogNo");

create sequence "PostAuthLogHistory_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

create index "PostAuthLogHistory_Index1" on "PostAuthLogHistory"("AuthCreateDate" asc);

create index "PostAuthLogHistory_Index2" on "PostAuthLogHistory"("PostMediaCode" asc, "AuthErrorCode" asc);

create index "PostAuthLogHistory_Index3" on "PostAuthLogHistory"("PropDate" asc);

create index "PostAuthLogHistory_Index4" on "PostAuthLogHistory"("RetrDate" asc);

comment on table "PostAuthLogHistory" is '郵局授權記錄歷史檔';
comment on column "PostAuthLogHistory"."LogNo" is '序號';
comment on column "PostAuthLogHistory"."CustNo" is '戶號';
comment on column "PostAuthLogHistory"."FacmNo" is '額度';
comment on column "PostAuthLogHistory"."AuthCode" is '授權方式';
comment on column "PostAuthLogHistory"."AuthCreateDate" is '建檔日期';
comment on column "PostAuthLogHistory"."AuthApplCode" is '申請代號，狀態碼';
comment on column "PostAuthLogHistory"."PostDepCode" is '帳戶別';
comment on column "PostAuthLogHistory"."RepayAcct" is '儲金帳號';
comment on column "PostAuthLogHistory"."CustId" is '統一編號';
comment on column "PostAuthLogHistory"."RepayAcctSeq" is '帳號碼';
comment on column "PostAuthLogHistory"."ProcessDate" is '處理日期';
comment on column "PostAuthLogHistory"."StampFinishDate" is '核印完成日期';
comment on column "PostAuthLogHistory"."StampCancelDate" is '核印取消日期';
comment on column "PostAuthLogHistory"."StampCode" is '核印註記';
comment on column "PostAuthLogHistory"."PostMediaCode" is '媒體碼';
comment on column "PostAuthLogHistory"."AuthErrorCode" is '狀況代號，授權狀態';
comment on column "PostAuthLogHistory"."FileSeq" is '媒體檔流水編號';
comment on column "PostAuthLogHistory"."PropDate" is '提出日期(媒體產出日)';
comment on column "PostAuthLogHistory"."RetrDate" is '提回日期';
comment on column "PostAuthLogHistory"."DeleteDate" is '刪除日期/暫停授權日期';
comment on column "PostAuthLogHistory"."RelationCode" is '與借款人關係';
comment on column "PostAuthLogHistory"."RelAcctName" is '第三人帳戶戶名';
comment on column "PostAuthLogHistory"."RelationId" is '第三人身分證字號';
comment on column "PostAuthLogHistory"."RelAcctBirthday" is '第三人出生日期';
comment on column "PostAuthLogHistory"."RelAcctGender" is '第三人性別';
comment on column "PostAuthLogHistory"."AmlRsp" is 'AML回應碼';
comment on column "PostAuthLogHistory"."CreateEmpNo" is '建立者櫃員編號';
comment on column "PostAuthLogHistory"."CreateDate" is '建檔日期';
comment on column "PostAuthLogHistory"."LastUpdateEmpNo" is '修改者櫃員編號';
comment on column "PostAuthLogHistory"."LastUpdate" is '異動日期';
drop table "PostDeductMedia" purge;

create table "PostDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ProcNoteCode" varchar2(2),
  "PostDepCode" varchar2(1),
  "OutsrcCode" varchar2(3),
  "DistCode" varchar2(4),
  "TransDate" decimal(8, 0) default 0 not null,
  "RepayAcctNo" varchar2(14),
  "PostUserNo" varchar2(20),
  "OutsrcRemark" nvarchar2(20),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PostDeductMedia" add constraint "PostDeductMedia_PK" primary key("MediaDate", "MediaSeq");

create index "PostDeductMedia_Index1" on "PostDeductMedia"("AcDate" asc, "BatchNo" asc, "DetailSeq" asc);

comment on table "PostDeductMedia" is '郵局扣款媒體檔';
comment on column "PostDeductMedia"."MediaDate" is '媒體日期';
comment on column "PostDeductMedia"."MediaSeq" is '媒體序號';
comment on column "PostDeductMedia"."CustNo" is '戶號';
comment on column "PostDeductMedia"."FacmNo" is '額度號碼';
comment on column "PostDeductMedia"."RepayType" is '還款類別';
comment on column "PostDeductMedia"."RepayAmt" is '還款金額';
comment on column "PostDeductMedia"."ProcNoteCode" is '處理說明';
comment on column "PostDeductMedia"."PostDepCode" is '帳戶別';
comment on column "PostDeductMedia"."OutsrcCode" is '委託機構代號';
comment on column "PostDeductMedia"."DistCode" is '區處代號';
comment on column "PostDeductMedia"."TransDate" is '轉帳日期';
comment on column "PostDeductMedia"."RepayAcctNo" is '儲金帳號';
comment on column "PostDeductMedia"."PostUserNo" is '用戶編號';
comment on column "PostDeductMedia"."OutsrcRemark" is '委託機構使用欄';
comment on column "PostDeductMedia"."AcDate" is '會計日期';
comment on column "PostDeductMedia"."BatchNo" is '批號';
comment on column "PostDeductMedia"."DetailSeq" is '明細序號';
comment on column "PostDeductMedia"."CreateDate" is '建檔日期時間';
comment on column "PostDeductMedia"."CreateEmpNo" is '建檔人員';
comment on column "PostDeductMedia"."LastUpdate" is '最後更新日期時間';
comment on column "PostDeductMedia"."LastUpdateEmpNo" is '最後更新人員';
drop table "ReltMain" purge;

create table "ReltMain" (
  "CaseNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "ReltUKey" varchar2(32),
  "ReltCode" varchar2(2),
  "RemarkType" nvarchar2(1),
  "Reltmark" nvarchar2(100),
  "FinalFg" varchar2(1),
  "ApplDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ReltMain" add constraint "ReltMain_PK" primary key("CaseNo", "CustNo", "ReltUKey");

create index "ReltMain_Index1" on "ReltMain"("CaseNo" asc);

create index "ReltMain_Index2" on "ReltMain"("CustNo" asc);

create index "ReltMain_Index3" on "ReltMain"("ReltUKey" asc);

comment on table "ReltMain" is '借款戶關係人/關係企業主檔';
comment on column "ReltMain"."CaseNo" is 'eLoan案件編號';
comment on column "ReltMain"."CustNo" is '借戶人戶號';
comment on column "ReltMain"."ReltUKey" is '關係人客戶識別碼';
comment on column "ReltMain"."ReltCode" is '關係';
comment on column "ReltMain"."RemarkType" is '備註類型';
comment on column "ReltMain"."Reltmark" is '備註';
comment on column "ReltMain"."FinalFg" is '最新案件記號';
comment on column "ReltMain"."ApplDate" is '申請日期';
comment on column "ReltMain"."CreateDate" is '建檔日期時間';
comment on column "ReltMain"."CreateEmpNo" is '建檔人員';
comment on column "ReltMain"."LastUpdate" is '最後更新日期時間';
comment on column "ReltMain"."LastUpdateEmpNo" is '最後更新人員';
drop table "RepayActChangeLog" purge;

drop sequence "RepayActChangeLog_SEQ";

create table "RepayActChangeLog" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "Status" varchar2(1),
  "RelDy" decimal(8, 0) default 0 not null,
  "RelTxseq" varchar2(18),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RepayActChangeLog" add constraint "RepayActChangeLog_PK" primary key("LogNo");

create sequence "RepayActChangeLog_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;

create index "RepayActChangeLog_Index1" on "RepayActChangeLog"("CustNo" asc, "FacmNo" asc);

comment on table "RepayActChangeLog" is '還款帳號變更(含還款方式)紀錄檔';
comment on column "RepayActChangeLog"."LogNo" is '序號';
comment on column "RepayActChangeLog"."CustNo" is '戶號';
comment on column "RepayActChangeLog"."FacmNo" is '額度';
comment on column "RepayActChangeLog"."RepayCode" is '繳款方式';
comment on column "RepayActChangeLog"."RepayBank" is '扣款銀行';
comment on column "RepayActChangeLog"."PostDepCode" is '郵局存款別';
comment on column "RepayActChangeLog"."RepayAcct" is '扣款帳號';
comment on column "RepayActChangeLog"."Status" is '狀態碼';
comment on column "RepayActChangeLog"."RelDy" is '登放日期';
comment on column "RepayActChangeLog"."RelTxseq" is '登放序號';
comment on column "RepayActChangeLog"."CreateDate" is '建檔日期時間';
comment on column "RepayActChangeLog"."CreateEmpNo" is '建檔人員';
comment on column "RepayActChangeLog"."LastUpdate" is '最後更新日期時間';
comment on column "RepayActChangeLog"."LastUpdateEmpNo" is '最後更新人員';
drop table "RptJcic" purge;

create table "RptJcic" (
  "BranchNo" varchar2(4),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "JcicName" nvarchar2(100),
  "JcicStatus" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptJcic" add constraint "RptJcic_PK" primary key("BranchNo", "CustNo", "FacmNo");

comment on table "RptJcic" is '呆帳不報送檔';
comment on column "RptJcic"."BranchNo" is '單位別';
comment on column "RptJcic"."CustNo" is '戶號';
comment on column "RptJcic"."FacmNo" is '額度號碼';
comment on column "RptJcic"."JcicName" is 'Jcic名稱';
comment on column "RptJcic"."JcicStatus" is 'Jcic戶況';
comment on column "RptJcic"."CreateDate" is '建檔日期時間';
comment on column "RptJcic"."CreateEmpNo" is '建檔人員';
comment on column "RptJcic"."LastUpdate" is '最後更新日期時間';
comment on column "RptJcic"."LastUpdateEmpNo" is '最後更新人員';
drop table "RptRelationCompany" purge;

create table "RptRelationCompany" (
  "CusId" nvarchar2(20),
  "CusSCD" nvarchar2(2),
  "ComNo" nvarchar2(10),
  "ComName" nvarchar2(50),
  "ComCRA" nvarchar2(18),
  "STSCD" nvarchar2(2),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptRelationCompany" add constraint "RptRelationCompany_PK" primary key("CusId", "CusSCD", "ComNo", "STSCD");

comment on table "RptRelationCompany" is '報表用_金控利害關係人_關係人公司資料';
comment on column "RptRelationCompany"."CusId" is 'CusId';
comment on column "RptRelationCompany"."CusSCD" is 'CusSCD';
comment on column "RptRelationCompany"."ComNo" is 'ComNo';
comment on column "RptRelationCompany"."ComName" is 'ComName';
comment on column "RptRelationCompany"."ComCRA" is 'ComCRA';
comment on column "RptRelationCompany"."STSCD" is 'STSCD';
comment on column "RptRelationCompany"."LAW001" is 'LAW001';
comment on column "RptRelationCompany"."LAW002" is 'LAW002';
comment on column "RptRelationCompany"."LAW003" is 'LAW003';
comment on column "RptRelationCompany"."LAW004" is 'LAW004';
comment on column "RptRelationCompany"."LAW005" is 'LAW005';
comment on column "RptRelationCompany"."LAW006" is 'LAW006';
comment on column "RptRelationCompany"."LAW007" is 'LAW007';
comment on column "RptRelationCompany"."LAW008" is 'LAW008';
comment on column "RptRelationCompany"."LAW009" is 'LAW009';
comment on column "RptRelationCompany"."LAW010" is 'LAW010';
comment on column "RptRelationCompany"."CreateDate" is '建檔日期時間';
comment on column "RptRelationCompany"."CreateEmpNo" is '建檔人員';
comment on column "RptRelationCompany"."LastUpdate" is '最後更新日期時間';
comment on column "RptRelationCompany"."LastUpdateEmpNo" is '最後更新人員';
drop table "RptRelationFamily" purge;

create table "RptRelationFamily" (
  "CusId" nvarchar2(20),
  "CusSCD" nvarchar2(2),
  "RlbID" nvarchar2(20),
  "RlbName" nvarchar2(40),
  "FamilyCD" nvarchar2(3),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "RlbCusCCD" nvarchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptRelationFamily" add constraint "RptRelationFamily_PK" primary key("CusId", "CusSCD", "RlbID");

comment on table "RptRelationFamily" is '報表用_金控利害關係人_關係人親屬資料';
comment on column "RptRelationFamily"."CusId" is 'CusId';
comment on column "RptRelationFamily"."CusSCD" is 'CusSCD';
comment on column "RptRelationFamily"."RlbID" is 'RlbID';
comment on column "RptRelationFamily"."RlbName" is 'RlbName';
comment on column "RptRelationFamily"."FamilyCD" is 'FamilyCD';
comment on column "RptRelationFamily"."LAW001" is 'LAW001';
comment on column "RptRelationFamily"."LAW002" is 'LAW002';
comment on column "RptRelationFamily"."LAW003" is 'LAW003';
comment on column "RptRelationFamily"."LAW004" is 'LAW004';
comment on column "RptRelationFamily"."LAW005" is 'LAW005';
comment on column "RptRelationFamily"."LAW006" is 'LAW006';
comment on column "RptRelationFamily"."LAW007" is 'LAW007';
comment on column "RptRelationFamily"."LAW008" is 'LAW008';
comment on column "RptRelationFamily"."LAW009" is 'LAW009';
comment on column "RptRelationFamily"."LAW010" is 'LAW010';
comment on column "RptRelationFamily"."RlbCusCCD" is 'RlbCusCCD';
comment on column "RptRelationFamily"."CreateDate" is '建檔日期時間';
comment on column "RptRelationFamily"."CreateEmpNo" is '建檔人員';
comment on column "RptRelationFamily"."LastUpdate" is '最後更新日期時間';
comment on column "RptRelationFamily"."LastUpdateEmpNo" is '最後更新人員';
drop table "RptRelationSelf" purge;

create table "RptRelationSelf" (
  "CusId" nvarchar2(20),
  "CusName" nvarchar2(30),
  "STSCD" nvarchar2(2),
  "CusCCD" nvarchar2(1),
  "CusSCD" nvarchar2(2),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "Mark" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "RptRelationSelf" add constraint "RptRelationSelf_PK" primary key("CusId", "STSCD", "CusSCD");

comment on table "RptRelationSelf" is '報表用_金控利害關係人_關係人資料';
comment on column "RptRelationSelf"."CusId" is 'CusId';
comment on column "RptRelationSelf"."CusName" is 'CusName';
comment on column "RptRelationSelf"."STSCD" is 'STSCD';
comment on column "RptRelationSelf"."CusCCD" is 'CusCCD';
comment on column "RptRelationSelf"."CusSCD" is 'CusSCD';
comment on column "RptRelationSelf"."LAW001" is 'LAW001';
comment on column "RptRelationSelf"."LAW002" is 'LAW002';
comment on column "RptRelationSelf"."LAW003" is 'LAW003';
comment on column "RptRelationSelf"."LAW004" is 'LAW004';
comment on column "RptRelationSelf"."LAW005" is 'LAW005';
comment on column "RptRelationSelf"."LAW006" is 'LAW006';
comment on column "RptRelationSelf"."LAW007" is 'LAW007';
comment on column "RptRelationSelf"."LAW008" is 'LAW008';
comment on column "RptRelationSelf"."LAW009" is 'LAW009';
comment on column "RptRelationSelf"."LAW010" is 'LAW010';
comment on column "RptRelationSelf"."Mark" is 'Mark';
comment on column "RptRelationSelf"."CreateDate" is '建檔日期時間';
comment on column "RptRelationSelf"."CreateEmpNo" is '建檔人員';
comment on column "RptRelationSelf"."LastUpdate" is '最後更新日期時間';
comment on column "RptRelationSelf"."LastUpdateEmpNo" is '最後更新人員';
drop table "SlipMedia" purge;

create table "SlipMedia" (
  "BranchNo" varchar2(4),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" decimal(2, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "MediaSeq" decimal(3, 0) default 0 not null,
  "MediaSlipNo" varchar2(10),
  "Seq" decimal(3, 0) default 0 not null,
  "AcBookItem" nvarchar2(50),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcNoItem" nvarchar2(40),
  "CurrencyCode" varchar2(3),
  "DbCr" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "ReceiveCode" varchar2(15),
  "DeptCode" varchar2(6),
  "SlipRmk" nvarchar2(40),
  "CostMonth" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "SlipMedia" add constraint "SlipMedia_PK" primary key("BranchNo", "AcDate", "BatchNo", "AcBookCode", "MediaSeq", "MediaSlipNo", "Seq");

comment on table "SlipMedia" is '傳票媒體檔';
comment on column "SlipMedia"."BranchNo" is '單位別';
comment on column "SlipMedia"."AcDate" is '會計日期';
comment on column "SlipMedia"."BatchNo" is '傳票批號';
comment on column "SlipMedia"."AcBookCode" is '帳冊別代碼';
comment on column "SlipMedia"."MediaSeq" is '媒體檔上傳序號';
comment on column "SlipMedia"."MediaSlipNo" is '媒體檔傳票號碼';
comment on column "SlipMedia"."Seq" is '傳票序號';
comment on column "SlipMedia"."AcBookItem" is '帳冊別名稱';
comment on column "SlipMedia"."AcNoCode" is '會計科目代號';
comment on column "SlipMedia"."AcSubCode" is '子目代號';
comment on column "SlipMedia"."AcNoItem" is '會計科目名稱';
comment on column "SlipMedia"."CurrencyCode" is '幣別';
comment on column "SlipMedia"."DbCr" is '借貸別';
comment on column "SlipMedia"."TxAmt" is '記帳金額';
comment on column "SlipMedia"."ReceiveCode" is '會計科目銷帳碼';
comment on column "SlipMedia"."DeptCode" is '部門代號';
comment on column "SlipMedia"."SlipRmk" is '傳票摘要';
comment on column "SlipMedia"."CostMonth" is '成本月份';
comment on column "SlipMedia"."CreateDate" is '建檔日期時間';
comment on column "SlipMedia"."CreateEmpNo" is '建檔人員';
comment on column "SlipMedia"."LastUpdate" is '最後更新日期時間';
comment on column "SlipMedia"."LastUpdateEmpNo" is '最後更新人員';
drop table "SlipMedia2022" purge;

create table "SlipMedia2022" (
  "AcBookCode" varchar2(3),
  "MediaSlipNo" varchar2(12),
  "Seq" decimal(5, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" decimal(2, 0) default 0 not null,
  "MediaSeq" decimal(3, 0) default 0 not null,
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "DeptCode" varchar2(6),
  "DbCr" varchar2(1),
  "TxAmt" decimal(14, 2) default 0 not null,
  "SlipRmk" varchar2(80),
  "ReceiveCode" varchar2(15),
  "CostMonth" varchar2(2),
  "InsuNo" varchar2(10),
  "SalesmanCode" varchar2(12),
  "SalaryCode" varchar2(2),
  "CurrencyCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CostUnit" varchar2(6),
  "SalesChannelType" varchar2(2),
  "IfrsType" varchar2(1),
  "RelationId" varchar2(10),
  "RelateCode" varchar2(3),
  "Ifrs17Group" varchar2(9),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "SlipMedia2022" add constraint "SlipMedia2022_PK" primary key("MediaSlipNo", "Seq");

comment on table "SlipMedia2022" is '傳票媒體檔2022年格式';
comment on column "SlipMedia2022"."AcBookCode" is '帳冊別';
comment on column "SlipMedia2022"."MediaSlipNo" is '傳票號碼';
comment on column "SlipMedia2022"."Seq" is '傳票明細序號';
comment on column "SlipMedia2022"."AcDate" is '傳票日期';
comment on column "SlipMedia2022"."BatchNo" is '傳票批號';
comment on column "SlipMedia2022"."MediaSeq" is '媒體檔上傳序號';
comment on column "SlipMedia2022"."AcNoCode" is '科目代號';
comment on column "SlipMedia2022"."AcSubCode" is '子目代號';
comment on column "SlipMedia2022"."DeptCode" is '部門代號';
comment on column "SlipMedia2022"."DbCr" is '借貸別';
comment on column "SlipMedia2022"."TxAmt" is '金額';
comment on column "SlipMedia2022"."SlipRmk" is '傳票摘要';
comment on column "SlipMedia2022"."ReceiveCode" is '會計科目銷帳碼';
comment on column "SlipMedia2022"."CostMonth" is '成本月份';
comment on column "SlipMedia2022"."InsuNo" is '保單號碼';
comment on column "SlipMedia2022"."SalesmanCode" is '業務員代號';
comment on column "SlipMedia2022"."SalaryCode" is '薪碼';
comment on column "SlipMedia2022"."CurrencyCode" is '幣別';
comment on column "SlipMedia2022"."AcSubBookCode" is '區隔帳冊';
comment on column "SlipMedia2022"."CostUnit" is '成本單位';
comment on column "SlipMedia2022"."SalesChannelType" is '通路別';
comment on column "SlipMedia2022"."IfrsType" is '會計準則類型';
comment on column "SlipMedia2022"."RelationId" is '關係人ID';
comment on column "SlipMedia2022"."RelateCode" is '關聯方代號';
comment on column "SlipMedia2022"."Ifrs17Group" is 'IFRS17群組';
comment on column "SlipMedia2022"."CreateDate" is '建檔日期時間';
comment on column "SlipMedia2022"."CreateEmpNo" is '建檔人員';
comment on column "SlipMedia2022"."LastUpdate" is '最後更新日期時間';
comment on column "SlipMedia2022"."LastUpdateEmpNo" is '最後更新人員';
drop table "StgCdEmp" purge;

create table "StgCdEmp" (
  "AGENT_CODE" varchar2(12),
  "COMM_LINE_CODE" varchar2(2),
  "COMM_LINE_TYPE" varchar2(1),
  "ORIG_INTRODUCER_ID" varchar2(12),
  "INTRODUCER_IND" varchar2(1),
  "REGISTER_LEVEL" varchar2(2),
  "REGISTER_DATE" varchar2(30),
  "CENTER_CODE" varchar2(6),
  "ADMINISTRAT_ID" varchar2(12),
  "INPUT_DATE" varchar2(30),
  "INPUT_USER" varchar2(8),
  "AG_STATUS_CODE" varchar2(1),
  "AG_STATUS_DATE" varchar2(30),
  "TRAN_DATE" varchar2(30),
  "TRAN_USER" varchar2(8),
  "RE_REGISTER_DATE" varchar2(30),
  "DIRECTOR_ID" varchar2(12),
  "DIRECTOR_ID_F" varchar2(12),
  "INTRODUCER_ID" varchar2(12),
  "INTRODUCER_ID_F" varchar2(12),
  "AG_LEVEL" varchar2(2),
  "LAST_LEVEL" varchar2(2),
  "LEVEL_DATE" varchar2(30),
  "TOP_LEVEL" varchar2(2),
  "OCCP_IND" varchar2(1),
  "QUOTA_AMT" varchar2(10),
  "APPL_TYPE" varchar2(1),
  "TAX_RATE" varchar2(9),
  "SOCIAL_INSU_CLASS" varchar2(5),
  "PROMOT_LEVEL_YM" varchar2(7),
  "DIRECTOR_YM" varchar2(7),
  "RECORD_DATE" varchar2(30),
  "EX_RECORD_DATE" varchar2(30),
  "EX_TR_DATE" varchar2(30),
  "EX_TR_IDENT" varchar2(16),
  "EX_TR_IDENT2" varchar2(9),
  "EX_TR_IDENT3" varchar2(12),
  "EX_TR_DATE3" varchar2(30),
  "REGISTER_BEFORE" varchar2(5),
  "DIRECTOR_AFTER" varchar2(5),
  "MEDICAL_CODE" varchar2(2),
  "EX_CHG_DATE" varchar2(30),
  "EX_DEL_DATE" varchar2(30),
  "APPL_CODE" varchar2(10),
  "FIRST_REG_DATE" varchar2(30),
  "AGIN_SOURCE" varchar2(3),
  "AGUI_CENTER" varchar2(9),
  "AGENT_ID" varchar2(10),
  "TOP_ID" varchar2(12),
  "AG_DEGREE" varchar2(2),
  "COLLECT_IND" varchar2(1),
  "AG_TYPE_1" varchar2(1),
  "EMPLOYEE_NO" varchar2(10),
  "CONTRACT_IND" varchar2(1),
  "CONTRACT_IND_YM" varchar2(7),
  "AG_TYPE_2" varchar2(1),
  "AG_TYPE_3" varchar2(1),
  "AG_TYPE_4" varchar2(1),
  "AGIN_IND1" varchar2(1),
  "AG_PO_IND" varchar2(1),
  "AG_DOC_IND" varchar2(1),
  "NEW_HIRE_TYPE" varchar2(1),
  "AG_CUR_IND" varchar2(1),
  "AG_SEND_TYPE" varchar2(3),
  "AG_SEND_NO" varchar2(100),
  "REGISTER_DATE_2" varchar2(30),
  "AG_RETURN_DATE" varchar2(30),
  "AG_TRANSFER_DATE_F" varchar2(30),
  "AG_TRANSFER_DATE" varchar2(30),
  "PROMOT_YM" varchar2(7),
  "PROMOT_YM_F" varchar2(7),
  "AG_POST_CHG_DATE" varchar2(30),
  "FAMILIES_TAX" varchar2(5),
  "AGENT_CODE_I" varchar2(12),
  "AG_LEVEL_SYS" varchar2(2),
  "AG_POST_IN" varchar2(6),
  "CENTER_CODE_ACC" varchar2(6),
  "EVALUE_IND" varchar2(1),
  "EVALUE_IND_1" varchar2(1),
  "BATCH_NO" varchar2(10),
  "EVALUE_YM" varchar2(7),
  "AG_TRANSFER_CODE" varchar2(2),
  "FULLNAME" nvarchar2(100),
  "BIRTH" varchar2(30),
  "EDUCATION" varchar2(1),
  "LR_IND" varchar2(1),
  "PROCESS_DATE" varchar2(30),
  "QUIT_DATE" varchar2(30),
  "CENTER_SHORT_NAME" nvarchar2(100),
  "CENTER_CODE_NAME" nvarchar2(100),
  "CENTER_CODE_1" varchar2(6),
  "CENTER_CODE_1_SHORT" nvarchar2(10),
  "CENTER_CODE_1_NAME" nvarchar2(100),
  "CENTER_CODE_2" varchar2(6),
  "CENTER_CODE_2_SHORT" nvarchar2(10),
  "CENTER_CODE_2_NAME" nvarchar2(100),
  "CENTER_CODE_ACC_1" varchar2(6),
  "CENTER_CODE_ACC_1_NAME" nvarchar2(100),
  "CENTER_CODE_ACC_2" varchar2(6),
  "CENTER_CODE_ACC_2_NAME" nvarchar2(100),
  "AG_POST" varchar2(2),
  "LEVEL_NAME_CHS" nvarchar2(10),
  "LR_SYSTEM_TYPE" varchar2(1),
  "SENIORITY_YY" varchar2(5),
  "SENIORITY_MM" varchar2(5),
  "SENIORITY_DD" varchar2(5),
  "AGLA_PROCESS_IND" varchar2(2),
  "STATUS_CODE" varchar2(1),
  "AGLA_CANCEL_REASON" varchar2(1),
  "IS_ANN_APPL_DATE" varchar2(30),
  "RECORD_DATE_C" varchar2(30),
  "STOP_REASON" varchar2(15),
  "STOP_STR_DATE" varchar2(30),
  "STOP_END_DATE" varchar2(30),
  "IFP_DATE" varchar2(30),
  "EFFECT_STR_DATE" varchar2(30),
  "EFFECT_END_DATE" varchar2(30),
  "ANN_APPL_DATE" varchar2(30),
  "CENTER_CODE_ACC_NAME" nvarchar2(20),
  "RE_HIRE_CODE" varchar2(1),
  "RSVD_ADMIN_CODE" varchar2(1),
  "ACCOUNT" varchar2(16),
  "PRP_DATE" varchar2(15),
  "ZIP" varchar2(10),
  "ADDRESS" nvarchar2(100),
  "PHONE_H" varchar2(30),
  "PHONE_C" varchar2(30),
  "SALES_QUAL_IND" varchar2(1),
  "AGSQ_START_DATE" varchar2(30),
  "PINYIN_NAME_INDI" nvarchar2(100)
);

alter table "StgCdEmp" add constraint "StgCdEmp_PK" primary key("AGENT_CODE");

comment on table "StgCdEmp" is '員工資料中介檔';
comment on column "StgCdEmp"."AGENT_CODE" is '業務員代號';
comment on column "StgCdEmp"."COMM_LINE_CODE" is '業務線代號';
comment on column "StgCdEmp"."COMM_LINE_TYPE" is '業務線別';
comment on column "StgCdEmp"."ORIG_INTRODUCER_ID" is '介紹人';
comment on column "StgCdEmp"."INTRODUCER_IND" is '介紹關係碼';
comment on column "StgCdEmp"."REGISTER_LEVEL" is '報聘職等';
comment on column "StgCdEmp"."REGISTER_DATE" is '在職/締約日期';
comment on column "StgCdEmp"."CENTER_CODE" is '單位代號';
comment on column "StgCdEmp"."ADMINISTRAT_ID" is '單位主管';
comment on column "StgCdEmp"."INPUT_DATE" is '建檔日期';
comment on column "StgCdEmp"."INPUT_USER" is '建檔人';
comment on column "StgCdEmp"."AG_STATUS_CODE" is '業務人員任用狀況碼';
comment on column "StgCdEmp"."AG_STATUS_DATE" is '業務人員任用狀況異動日';
comment on column "StgCdEmp"."TRAN_DATE" is '作業日期(交易日期)';
comment on column "StgCdEmp"."TRAN_USER" is '作業者';
comment on column "StgCdEmp"."RE_REGISTER_DATE" is '再聘日';
comment on column "StgCdEmp"."DIRECTOR_ID" is '上層主管';
comment on column "StgCdEmp"."DIRECTOR_ID_F" is '主管_財務';
comment on column "StgCdEmp"."INTRODUCER_ID" is '區主任/上一代主管';
comment on column "StgCdEmp"."INTRODUCER_ID_F" is '推介人_財務';
comment on column "StgCdEmp"."AG_LEVEL" is '業務人員職等';
comment on column "StgCdEmp"."LAST_LEVEL" is '前次業務人員職等';
comment on column "StgCdEmp"."LEVEL_DATE" is '職等異動日';
comment on column "StgCdEmp"."TOP_LEVEL" is '最高職等';
comment on column "StgCdEmp"."OCCP_IND" is '任職型態';
comment on column "StgCdEmp"."QUOTA_AMT" is '責任額';
comment on column "StgCdEmp"."APPL_TYPE" is '申請登錄類別';
comment on column "StgCdEmp"."TAX_RATE" is '所得稅率';
comment on column "StgCdEmp"."SOCIAL_INSU_CLASS" is '勞保等級';
comment on column "StgCdEmp"."PROMOT_LEVEL_YM" is '職等平階起始年月';
comment on column "StgCdEmp"."DIRECTOR_YM" is '晉陞主管年月';
comment on column "StgCdEmp"."RECORD_DATE" is '登錄日期';
comment on column "StgCdEmp"."EX_RECORD_DATE" is '發證日期';
comment on column "StgCdEmp"."EX_TR_DATE" is '證書日期/測驗日期';
comment on column "StgCdEmp"."EX_TR_IDENT" is '證書字號';
comment on column "StgCdEmp"."EX_TR_IDENT2" is '中專證號';
comment on column "StgCdEmp"."EX_TR_IDENT3" is '投資型證號';
comment on column "StgCdEmp"."EX_TR_DATE3" is '投資登錄日期';
comment on column "StgCdEmp"."REGISTER_BEFORE" is '報聘前年資(月表示)';
comment on column "StgCdEmp"."DIRECTOR_AFTER" is '主管年資';
comment on column "StgCdEmp"."MEDICAL_CODE" is '免體檢授權碼';
comment on column "StgCdEmp"."EX_CHG_DATE" is '換證日期';
comment on column "StgCdEmp"."EX_DEL_DATE" is '註銷日期';
comment on column "StgCdEmp"."APPL_CODE" is '申請業務類別';
comment on column "StgCdEmp"."FIRST_REG_DATE" is '初次登錄日';
comment on column "StgCdEmp"."AGIN_SOURCE" is '業務來源之專案';
comment on column "StgCdEmp"."AGUI_CENTER" is '單位代號';
comment on column "StgCdEmp"."AGENT_ID" is '業務人員身份證字號';
comment on column "StgCdEmp"."TOP_ID" is '業務人員主管';
comment on column "StgCdEmp"."AG_DEGREE" is '業務人員職級';
comment on column "StgCdEmp"."COLLECT_IND" is '收費員指示碼';
comment on column "StgCdEmp"."AG_TYPE_1" is '制度別';
comment on column "StgCdEmp"."EMPLOYEE_NO" is '電腦編號';
comment on column "StgCdEmp"."CONTRACT_IND" is '單雙合約碼';
comment on column "StgCdEmp"."CONTRACT_IND_YM" is '單雙合約異動工作月';
comment on column "StgCdEmp"."AG_TYPE_2" is '身份別';
comment on column "StgCdEmp"."AG_TYPE_3" is '特殊人員碼';
comment on column "StgCdEmp"."AG_TYPE_4" is '新舊制別';
comment on column "StgCdEmp"."AGIN_IND1" is '辦事員碼';
comment on column "StgCdEmp"."AG_PO_IND" is '可招攬指示碼';
comment on column "StgCdEmp"."AG_DOC_IND" is '齊件否';
comment on column "StgCdEmp"."NEW_HIRE_TYPE" is '新舊人指示碼';
comment on column "StgCdEmp"."AG_CUR_IND" is '現職指示碼';
comment on column "StgCdEmp"."AG_SEND_TYPE" is '發文類別';
comment on column "StgCdEmp"."AG_SEND_NO" is '發文文號';
comment on column "StgCdEmp"."REGISTER_DATE_2" is '任職日期';
comment on column "StgCdEmp"."AG_RETURN_DATE" is '回任日期';
comment on column "StgCdEmp"."AG_TRANSFER_DATE_F" is '初次轉制日期';
comment on column "StgCdEmp"."AG_TRANSFER_DATE" is '轉制日期';
comment on column "StgCdEmp"."PROMOT_YM" is '初次晉升年月';
comment on column "StgCdEmp"."PROMOT_YM_F" is '生效業績年月';
comment on column "StgCdEmp"."AG_POST_CHG_DATE" is '職務異動日';
comment on column "StgCdEmp"."FAMILIES_TAX" is '扶養人數';
comment on column "StgCdEmp"."AGENT_CODE_I" is '原區主任代號';
comment on column "StgCdEmp"."AG_LEVEL_SYS" is '職等_系統';
comment on column "StgCdEmp"."AG_POST_IN" is '內階職務';
comment on column "StgCdEmp"."CENTER_CODE_ACC" is '駐在單位';
comment on column "StgCdEmp"."EVALUE_IND" is '考核特殊碼';
comment on column "StgCdEmp"."EVALUE_IND_1" is '辦法優待碼';
comment on column "StgCdEmp"."BATCH_NO" is '批次號碼';
comment on column "StgCdEmp"."EVALUE_YM" is '考核年月';
comment on column "StgCdEmp"."AG_TRANSFER_CODE" is '轉檔碼';
comment on column "StgCdEmp"."FULLNAME" is '姓名';
comment on column "StgCdEmp"."BIRTH" is '出生年月日';
comment on column "StgCdEmp"."EDUCATION" is '學歷';
comment on column "StgCdEmp"."LR_IND" is '勞退狀況';
comment on column "StgCdEmp"."PROCESS_DATE" is '資料處理時間';
comment on column "StgCdEmp"."QUIT_DATE" is '離職/停約日';
comment on column "StgCdEmp"."CENTER_SHORT_NAME" is '單位簡稱';
comment on column "StgCdEmp"."CENTER_CODE_NAME" is '單位名稱';
comment on column "StgCdEmp"."CENTER_CODE_1" is '區部代號';
comment on column "StgCdEmp"."CENTER_CODE_1_SHORT" is '區部簡稱';
comment on column "StgCdEmp"."CENTER_CODE_1_NAME" is '區部名稱';
comment on column "StgCdEmp"."CENTER_CODE_2" is '部室代號';
comment on column "StgCdEmp"."CENTER_CODE_2_SHORT" is '部室簡稱';
comment on column "StgCdEmp"."CENTER_CODE_2_NAME" is '部室名稱';
comment on column "StgCdEmp"."CENTER_CODE_ACC_1" is '區部代號(駐在單位)';
comment on column "StgCdEmp"."CENTER_CODE_ACC_1_NAME" is '區部名稱(駐在單位)';
comment on column "StgCdEmp"."CENTER_CODE_ACC_2" is '部室代號(駐在單位)';
comment on column "StgCdEmp"."CENTER_CODE_ACC_2_NAME" is '部室名稱(駐在單位)';
comment on column "StgCdEmp"."AG_POST" is '職務';
comment on column "StgCdEmp"."LEVEL_NAME_CHS" is '職等中文';
comment on column "StgCdEmp"."LR_SYSTEM_TYPE" is '勞退碼';
comment on column "StgCdEmp"."SENIORITY_YY" is '年資_年';
comment on column "StgCdEmp"."SENIORITY_MM" is '年資_月';
comment on column "StgCdEmp"."SENIORITY_DD" is '年資_日';
comment on column "StgCdEmp"."AGLA_PROCESS_IND" is '登錄處理事項';
comment on column "StgCdEmp"."STATUS_CODE" is '登錄狀態';
comment on column "StgCdEmp"."AGLA_CANCEL_REASON" is '註銷原因';
comment on column "StgCdEmp"."IS_ANN_APPL_DATE" is '利變年金通報日';
comment on column "StgCdEmp"."RECORD_DATE_C" is '外幣保單登入日';
comment on column "StgCdEmp"."STOP_REASON" is '停招/撤銷原因';
comment on column "StgCdEmp"."STOP_STR_DATE" is '停止招攬起日';
comment on column "StgCdEmp"."STOP_END_DATE" is '停止招攬迄日';
comment on column "StgCdEmp"."IFP_DATE" is 'IFP登錄日';
comment on column "StgCdEmp"."EFFECT_STR_DATE" is '撤銷起日';
comment on column "StgCdEmp"."EFFECT_END_DATE" is '撤銷迄日';
comment on column "StgCdEmp"."ANN_APPL_DATE" is '一般年金通報日';
comment on column "StgCdEmp"."CENTER_CODE_ACC_NAME" is '單位名稱(駐在單位)';
comment on column "StgCdEmp"."RE_HIRE_CODE" is '重僱碼';
comment on column "StgCdEmp"."RSVD_ADMIN_CODE" is '特別碼';
comment on column "StgCdEmp"."ACCOUNT" is '帳號';
comment on column "StgCdEmp"."PRP_DATE" is '優體測驗通過日';
comment on column "StgCdEmp"."ZIP" is '戶籍地址郵遞區號';
comment on column "StgCdEmp"."ADDRESS" is '戶籍地址';
comment on column "StgCdEmp"."PHONE_H" is '住家電話';
comment on column "StgCdEmp"."PHONE_C" is '手機電話';
comment on column "StgCdEmp"."SALES_QUAL_IND" is '基金銷售資格碼';
comment on column "StgCdEmp"."AGSQ_START_DATE" is '基金銷售資格日';
comment on column "StgCdEmp"."PINYIN_NAME_INDI" is '原住民羅馬拼音姓名';
drop table "SystemParas" purge;

create table "SystemParas" (
  "BusinessType" varchar2(2),
  "GraceDays" decimal(2, 0) default 0 not null,
  "AchAuthOneTime" varchar2(1),
  "AchDeductFlag" decimal(1, 0) default 0 not null,
  "AchDeductDD1" decimal(2, 0) default 0 not null,
  "AchDeductDD2" decimal(2, 0) default 0 not null,
  "AchDeductDD3" decimal(2, 0) default 0 not null,
  "AchDeductDD4" decimal(2, 0) default 0 not null,
  "AchDeductDD5" decimal(2, 0) default 0 not null,
  "AchSecondDeductDays" decimal(2, 0) default 0 not null,
  "AchDeductMethod" decimal(1, 0) default 0 not null,
  "PostDeductFlag" decimal(1, 0) default 0 not null,
  "PostDeductDD1" decimal(2, 0) default 0 not null,
  "PostDeductDD2" decimal(2, 0) default 0 not null,
  "PostDeductDD3" decimal(2, 0) default 0 not null,
  "PostDeductDD4" decimal(2, 0) default 0 not null,
  "PostDeductDD5" decimal(2, 0) default 0 not null,
  "PostSecondDeductDays" decimal(2, 0) default 0 not null,
  "PostDeductMethod" decimal(1, 0) default 0 not null,
  "LoanDeptCustNo" decimal(7, 0) default 0 not null,
  "NegDeptCustNo" decimal(7, 0) default 0 not null,
  "PerfBackRepayAmt" decimal(16, 2) default 0 not null,
  "PerfBackPeriodS" decimal(3, 0) default 0 not null,
  "PerfBackPeriodE" decimal(3, 0) default 0 not null,
  "AcctCode310A" decimal(3, 0) default 0 not null,
  "AcctCode310B" decimal(3, 0) default 0 not null,
  "AcctCode320A" decimal(3, 0) default 0 not null,
  "AcctCode320B" decimal(3, 0) default 0 not null,
  "AcctCode330A" decimal(3, 0) default 0 not null,
  "AcctCode330B" decimal(3, 0) default 0 not null,
  "ReduceAmtLimit" decimal(5, 0) default 0 not null,
  "PreRepayTerms" decimal(3, 0) default 0 not null,
  "PreRepayTermsBatch" decimal(3, 0) default 0 not null,
  "ShortPrinPercent" decimal(3, 0) default 0 not null,
  "ShortIntPercent" decimal(3, 0) default 0 not null,
  "AmlFg" decimal(1, 0) default 0 not null,
  "AmlUrl" nvarchar2(50),
  "PerfDate" decimal(8, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcBookAdjDate" decimal(8, 0) default 0 not null,
  "EbsFg" varchar2(1),
  "EbsUrl" varchar2(100),
  "EbsAuth" varchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "SystemParas" add constraint "SystemParas_PK" primary key("BusinessType");

comment on table "SystemParas" is '系統參數設定檔';
comment on column "SystemParas"."BusinessType" is '業務類型';
comment on column "SystemParas"."GraceDays" is '違約寬限天數(營業日)';
comment on column "SystemParas"."AchAuthOneTime" is 'ACH授權提出一日一批';
comment on column "SystemParas"."AchDeductFlag" is 'ACH扣款方式';
comment on column "SystemParas"."AchDeductDD1" is 'ACH扣款特定日1';
comment on column "SystemParas"."AchDeductDD2" is 'ACH扣款特定日2';
comment on column "SystemParas"."AchDeductDD3" is 'ACH扣款特定日3';
comment on column "SystemParas"."AchDeductDD4" is 'ACH扣款特定日4';
comment on column "SystemParas"."AchDeductDD5" is 'ACH扣款特定日5';
comment on column "SystemParas"."AchSecondDeductDays" is 'ACH特定日二扣營業日差';
comment on column "SystemParas"."AchDeductMethod" is 'ACH連續日扣款方式';
comment on column "SystemParas"."PostDeductFlag" is 'POST扣款方式';
comment on column "SystemParas"."PostDeductDD1" is 'ACH扣款特定日1';
comment on column "SystemParas"."PostDeductDD2" is 'ACH扣款特定日2';
comment on column "SystemParas"."PostDeductDD3" is 'ACH扣款特定日3';
comment on column "SystemParas"."PostDeductDD4" is 'ACH扣款特定日4';
comment on column "SystemParas"."PostDeductDD5" is 'ACH扣款特定日5';
comment on column "SystemParas"."PostSecondDeductDays" is 'ACH特定日二扣營業日差';
comment on column "SystemParas"."PostDeductMethod" is 'ACH連續日扣款方式';
comment on column "SystemParas"."LoanDeptCustNo" is '放款部收款專戶戶號';
comment on column "SystemParas"."NegDeptCustNo" is '前置協商收款專戶戶號';
comment on column "SystemParas"."PerfBackRepayAmt" is '業績追回之部分還款金額條件';
comment on column "SystemParas"."PerfBackPeriodS" is '業績追回之起期數';
comment on column "SystemParas"."PerfBackPeriodE" is '業績追回之止期數';
comment on column "SystemParas"."AcctCode310A" is '短期擔保放款年限之起';
comment on column "SystemParas"."AcctCode310B" is '短期擔保放款年限之止';
comment on column "SystemParas"."AcctCode320A" is '中期擔保放款年限之起';
comment on column "SystemParas"."AcctCode320B" is '中期擔保放款年限之止';
comment on column "SystemParas"."AcctCode330A" is '長期擔保放款年限之起';
comment on column "SystemParas"."AcctCode330B" is '長期擔保放款年限之止';
comment on column "SystemParas"."ReduceAmtLimit" is '減免金額限額';
comment on column "SystemParas"."PreRepayTerms" is '單筆預收期數';
comment on column "SystemParas"."PreRepayTermsBatch" is '批次預收期數';
comment on column "SystemParas"."ShortPrinPercent" is '回收時可短繳本金金額之百分比';
comment on column "SystemParas"."ShortIntPercent" is '回收時可短繳利息金額之百分比';
comment on column "SystemParas"."AmlFg" is 'AML檢查記號';
comment on column "SystemParas"."AmlUrl" is 'AML網址';
comment on column "SystemParas"."PerfDate" is '業績日期';
comment on column "SystemParas"."AcBookCode" is '帳冊別';
comment on column "SystemParas"."AcSubBookCode" is '區隔帳冊';
comment on column "SystemParas"."AcBookAdjDate" is '帳冊別帳務調整日期';
comment on column "SystemParas"."EbsFg" is 'EBS啟用記號';
comment on column "SystemParas"."EbsUrl" is 'EBS網址';
comment on column "SystemParas"."EbsAuth" is 'EBS認證';
comment on column "SystemParas"."CreateDate" is '建檔日期時間';
comment on column "SystemParas"."CreateEmpNo" is '建檔人員';
comment on column "SystemParas"."LastUpdate" is '最後更新日期時間';
comment on column "SystemParas"."LastUpdateEmpNo" is '最後更新人員';
drop table "TbJcicMu01" purge;

create table "TbJcicMu01" (
  "HeadOfficeCode" varchar2(3),
  "BranchCode" varchar2(4),
  "DataDate" decimal(8, 0) default 0 not null,
  "EmpId" varchar2(6),
  "Title" varchar2(50),
  "AuthQryType" varchar2(1),
  "QryUserId" varchar2(8),
  "AuthItemQuery" varchar2(1),
  "AuthItemReview" varchar2(1),
  "AuthItemOther" varchar2(1),
  "AuthStartDay" decimal(8, 0) default 0 not null,
  "AuthMgrIdS" varchar2(6),
  "AuthEndDay" decimal(8, 0) default 0 not null,
  "AuthMgrIdE" varchar2(6),
  "EmailAccount" varchar2(50),
  "ModifyUserId" varchar2(10),
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "TbJcicMu01" add constraint "TbJcicMu01_PK" primary key("HeadOfficeCode", "BranchCode", "DataDate", "EmpId");

create index "TbJcicMu01_Index1" on "TbJcicMu01"("HeadOfficeCode" asc);

create index "TbJcicMu01_Index2" on "TbJcicMu01"("BranchCode" asc);

create index "TbJcicMu01_Index3" on "TbJcicMu01"("DataDate" asc);

create index "TbJcicMu01_Index4" on "TbJcicMu01"("EmpId" asc);

comment on table "TbJcicMu01" is '聯徵人員名冊';
comment on column "TbJcicMu01"."HeadOfficeCode" is '總行代號';
comment on column "TbJcicMu01"."BranchCode" is '分行代號';
comment on column "TbJcicMu01"."DataDate" is '資料日期';
comment on column "TbJcicMu01"."EmpId" is '員工代號';
comment on column "TbJcicMu01"."Title" is '職稱';
comment on column "TbJcicMu01"."AuthQryType" is '授權查詢方式';
comment on column "TbJcicMu01"."QryUserId" is '使用者代碼';
comment on column "TbJcicMu01"."AuthItemQuery" is '授權辦理事項-查詢';
comment on column "TbJcicMu01"."AuthItemReview" is '授權辦理事項-覆核';
comment on column "TbJcicMu01"."AuthItemOther" is '授權辦理事項-其他';
comment on column "TbJcicMu01"."AuthStartDay" is '授權起日';
comment on column "TbJcicMu01"."AuthMgrIdS" is '起日授權主管員工代號';
comment on column "TbJcicMu01"."AuthEndDay" is '授權迄日';
comment on column "TbJcicMu01"."AuthMgrIdE" is '迄日授權主管員工代號';
comment on column "TbJcicMu01"."EmailAccount" is 'E-mail信箱';
comment on column "TbJcicMu01"."ModifyUserId" is '異動人員ID';
comment on column "TbJcicMu01"."OutJcictxtDate" is '轉出JCIC文字檔日期';
comment on column "TbJcicMu01"."CreateDate" is '建檔日期時間';
comment on column "TbJcicMu01"."CreateEmpNo" is '建檔人員';
comment on column "TbJcicMu01"."LastUpdate" is '最後更新日期時間';
comment on column "TbJcicMu01"."LastUpdateEmpNo" is '最後更新人員';
drop table "TbJcicW020" purge;

create table "TbJcicW020" (
  "QueryYm" varchar2(5),
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "TbJcicW020" add constraint "TbJcicW020_PK" primary key("QueryYm");

create index "TbJcicW020_Index1" on "TbJcicW020"("QueryYm" asc);

comment on table "TbJcicW020" is '聯徵稽查產品';
comment on column "TbJcicW020"."QueryYm" is '查詢年月';
comment on column "TbJcicW020"."OutJcictxtDate" is '轉出JCIC文字檔日期';
comment on column "TbJcicW020"."CreateDate" is '建檔日期時間';
comment on column "TbJcicW020"."CreateEmpNo" is '建檔人員';
comment on column "TbJcicW020"."LastUpdate" is '最後更新日期時間';
comment on column "TbJcicW020"."LastUpdateEmpNo" is '最後更新人員';
drop table "TbJcicZZ50" purge;

create table "TbJcicZZ50" (
  "QryStartDate" decimal(8, 0) default 0 not null,
  "QryEndDate" decimal(8, 0) default 0 not null,
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "TbJcicZZ50" add constraint "TbJcicZZ50_PK" primary key("QryStartDate", "QryEndDate");

create index "TbJcicZZ50_Index1" on "TbJcicZZ50"("QryStartDate" asc);

create index "TbJcicZZ50_Index2" on "TbJcicZZ50"("QryEndDate" asc);

comment on table "TbJcicZZ50" is '會員查詢紀錄查詢';
comment on column "TbJcicZZ50"."QryStartDate" is '查詢開始日';
comment on column "TbJcicZZ50"."QryEndDate" is '查詢結束日';
comment on column "TbJcicZZ50"."OutJcictxtDate" is '轉出JCIC文字檔日期';
comment on column "TbJcicZZ50"."CreateDate" is '建檔日期時間';
comment on column "TbJcicZZ50"."CreateEmpNo" is '建檔人員';
comment on column "TbJcicZZ50"."LastUpdate" is '最後更新日期時間';
comment on column "TbJcicZZ50"."LastUpdateEmpNo" is '最後更新人員';
drop table "YearlyHouseLoanInt" purge;

create table "YearlyHouseLoanInt" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "UsageCode" varchar2(2),
  "AcctCode" varchar2(3),
  "RepayCode" varchar2(2),
  "LoanAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "YearlyInt" decimal(16, 2) default 0 not null,
  "HouseBuyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "YearlyHouseLoanInt" add constraint "YearlyHouseLoanInt_PK" primary key("YearMonth", "CustNo", "FacmNo", "UsageCode");

comment on table "YearlyHouseLoanInt" is '每年房屋擔保借款繳息工作檔';
comment on column "YearlyHouseLoanInt"."YearMonth" is '資料年月';
comment on column "YearlyHouseLoanInt"."CustNo" is '戶號';
comment on column "YearlyHouseLoanInt"."FacmNo" is '額度編號';
comment on column "YearlyHouseLoanInt"."UsageCode" is '資金用途別';
comment on column "YearlyHouseLoanInt"."AcctCode" is '業務科目代號';
comment on column "YearlyHouseLoanInt"."RepayCode" is '繳款方式';
comment on column "YearlyHouseLoanInt"."LoanAmt" is '撥款金額';
comment on column "YearlyHouseLoanInt"."LoanBal" is '放款餘額';
comment on column "YearlyHouseLoanInt"."FirstDrawdownDate" is '初貸日';
comment on column "YearlyHouseLoanInt"."MaturityDate" is '到期日';
comment on column "YearlyHouseLoanInt"."YearlyInt" is '年度繳息金額';
comment on column "YearlyHouseLoanInt"."HouseBuyDate" is '房屋取得日期';
comment on column "YearlyHouseLoanInt"."CreateDate" is '建檔日期時間';
comment on column "YearlyHouseLoanInt"."CreateEmpNo" is '建檔人員';
comment on column "YearlyHouseLoanInt"."LastUpdate" is '最後更新日期時間';
comment on column "YearlyHouseLoanInt"."LastUpdateEmpNo" is '最後更新人員';
