drop table "JcicZ444Log" purge;

create table "JcicZ444Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CustRegAddr" nvarchar2(76),
  "CustComAddr" nvarchar2(76),
  "CustRegTelNo" nvarchar2(16),
  "CustComTelNo" nvarchar2(16),
  "CustMobilNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ444Log" add constraint "JcicZ444Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ444Log" is '前置調解債務人基本資料';
comment on column "JcicZ444Log"."Ukey" is '流水號';
comment on column "JcicZ444Log"."TxSeq" is '交易序號';
comment on column "JcicZ444Log"."TranKey" is '交易代碼';
comment on column "JcicZ444Log"."CustRegAddr" is '債務人戶籍之郵遞區號及地址';
comment on column "JcicZ444Log"."CustComAddr" is '債務人通訊地之郵遞區號及地址';
comment on column "JcicZ444Log"."CustRegTelNo" is '債務人戶籍電話';
comment on column "JcicZ444Log"."CustComTelNo" is '債務人通訊電話';
comment on column "JcicZ444Log"."CustMobilNo" is '債務人行動電話';
comment on column "JcicZ444Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ444Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ444Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ444Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ444Log"."LastUpdateEmpNo" is '最後更新人員';
