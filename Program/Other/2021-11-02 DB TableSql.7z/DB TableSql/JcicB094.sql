drop table "JcicB094" purge;

create table "JcicB094" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(7, 0) default 0 not null,
  "LoanLimitAmt" decimal(10, 0) default 0 not null,
  "SettingDate" decimal(7, 0) default 0 not null,
  "CompanyId" varchar2(8),
  "CompanyCountry" varchar2(2),
  "StockCode" varchar2(10),
  "StockType" decimal(1, 0) default 0 not null,
  "Currency" varchar2(3),
  "SettingBalance" decimal(14, 0) default 0 not null,
  "LoanBal" decimal(10, 0) default 0 not null,
  "InsiderJobTitle" varchar2(1),
  "InsiderPosition" varchar2(1),
  "LegalPersonId" varchar2(10),
  "DispPrice" decimal(8, 0) default 0 not null,
  "Filler19" varchar2(14),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB094" add constraint "JcicB094_PK" primary key("DataYM", "ClActNo", "OwnerId", "CompanyId", "StockCode", "StockType");

comment on table "JcicB094" is '聯徵股票擔保品明細檔';
comment on column "JcicB094"."DataYM" is '資料日期';
comment on column "JcicB094"."DataType" is '資料別';
comment on column "JcicB094"."BankItem" is '總行代號';
comment on column "JcicB094"."BranchItem" is '分行代號';
comment on column "JcicB094"."Filler4" is '空白';
comment on column "JcicB094"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB094"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB094"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB094"."EvaAmt" is '鑑估值';
comment on column "JcicB094"."EvaDate" is '鑑估日期';
comment on column "JcicB094"."LoanLimitAmt" is '可放款值';
comment on column "JcicB094"."SettingDate" is '設質日期';
comment on column "JcicB094"."CompanyId" is '發行機構 BAN';
comment on column "JcicB094"."CompanyCountry" is '發行機構所在國別';
comment on column "JcicB094"."StockCode" is '股票代號';
comment on column "JcicB094"."StockType" is '股票種類';
comment on column "JcicB094"."Currency" is '幣別';
comment on column "JcicB094"."SettingBalance" is '設定股數餘額';
comment on column "JcicB094"."LoanBal" is '股票質押授信餘額';
comment on column "JcicB094"."InsiderJobTitle" is '公司內部人職稱';
comment on column "JcicB094"."InsiderPosition" is '公司內部人身分註記';
comment on column "JcicB094"."LegalPersonId" is '公司內部人法定關係人';
comment on column "JcicB094"."DispPrice" is '處分價格';
comment on column "JcicB094"."Filler19" is '空白';
comment on column "JcicB094"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB094"."CreateDate" is '建檔日期時間';
comment on column "JcicB094"."CreateEmpNo" is '建檔人員';
comment on column "JcicB094"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB094"."LastUpdateEmpNo" is '最後更新人員';
