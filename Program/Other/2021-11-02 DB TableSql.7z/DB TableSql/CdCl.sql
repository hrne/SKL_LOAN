drop table "CdCl" purge;

create table "CdCl" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClItem" nvarchar2(20),
  "ClTypeJCIC" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCl" add constraint "CdCl_PK" primary key("ClCode1", "ClCode2");

create index "CdCl_Index1" on "CdCl"("ClCode1" asc);

create index "CdCl_Index2" on "CdCl"("ClTypeJCIC" asc);

comment on table "CdCl" is '擔保品代號檔';
comment on column "CdCl"."ClCode1" is '擔保品代號1';
comment on column "CdCl"."ClCode2" is '擔保品代號2';
comment on column "CdCl"."ClItem" is '擔保品名稱';
comment on column "CdCl"."ClTypeJCIC" is 'JCIC類別';
comment on column "CdCl"."CreateDate" is '建檔日期時間';
comment on column "CdCl"."CreateEmpNo" is '建檔人員';
comment on column "CdCl"."LastUpdate" is '最後更新日期時間';
comment on column "CdCl"."LastUpdateEmpNo" is '最後更新人員';
