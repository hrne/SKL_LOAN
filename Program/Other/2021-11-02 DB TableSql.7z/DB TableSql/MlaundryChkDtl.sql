drop table "MlaundryChkDtl" purge;

create table "MlaundryChkDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "Factor" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "DtlSeq" decimal(4, 0) default 0 not null,
  "DtlEntryDate" decimal(8, 0) default 0 not null,
  "RepayItem" nvarchar2(10),
  "DscptCode" varchar2(4),
  "TxAmt" decimal(16, 2) default 0 not null,
  "TotalCnt" decimal(3, 0) default 0 not null,
  "TotalAmt" decimal(16, 2) default 0 not null,
  "StartEntryDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryChkDtl" add constraint "MlaundryChkDtl_PK" primary key("EntryDate", "Factor", "CustNo", "DtlSeq");

comment on table "MlaundryChkDtl" is '疑似洗錢樣態檢核明細檔';
comment on column "MlaundryChkDtl"."EntryDate" is '入帳日期(統計期間迄日)';
comment on column "MlaundryChkDtl"."Factor" is '交易樣態';
comment on column "MlaundryChkDtl"."CustNo" is '戶號';
comment on column "MlaundryChkDtl"."DtlSeq" is '明細序號';
comment on column "MlaundryChkDtl"."DtlEntryDate" is '明細入帳日期';
comment on column "MlaundryChkDtl"."RepayItem" is '來源';
comment on column "MlaundryChkDtl"."DscptCode" is '摘要代碼';
comment on column "MlaundryChkDtl"."TxAmt" is '交易金額';
comment on column "MlaundryChkDtl"."TotalCnt" is '累積筆數';
comment on column "MlaundryChkDtl"."TotalAmt" is '累積金額';
comment on column "MlaundryChkDtl"."StartEntryDate" is '統計期間起日';
comment on column "MlaundryChkDtl"."CreateDate" is '建檔日期時間';
comment on column "MlaundryChkDtl"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryChkDtl"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryChkDtl"."LastUpdateEmpNo" is '最後更新人員';
