drop table "DataInputMapping" purge;

create table "DataInputMapping" (
  "InputTableName" varchar2(30),
  "TargerTableName" varchar2(30),
  "EnableFlag" varchar2(1),
  "SourceSystem" nvarchar2(50),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "DataInputMapping" add constraint "DataInputMapping_PK" primary key("InputTableName");

comment on table "DataInputMapping" is '資料傳入對照檔';
comment on column "DataInputMapping"."InputTableName" is '傳入資料表名稱';
comment on column "DataInputMapping"."TargerTableName" is '目標資料表名稱';
comment on column "DataInputMapping"."EnableFlag" is '啟用記號';
comment on column "DataInputMapping"."SourceSystem" is '來源系統';
comment on column "DataInputMapping"."Remark" is '備註';
comment on column "DataInputMapping"."CreateDate" is '建檔日期時間';
comment on column "DataInputMapping"."CreateEmpNo" is '建檔人員';
comment on column "DataInputMapping"."LastUpdate" is '最後更新日期時間';
comment on column "DataInputMapping"."LastUpdateEmpNo" is '最後更新人員';
