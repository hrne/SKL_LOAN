drop table "CdCashFlow" purge;

create table "CdCashFlow" (
  "DataYearMonth" decimal(6, 0) default 0 not null,
  "InterestIncome" decimal(16, 2) default 0 not null,
  "PrincipalAmortizeAmt" decimal(16, 2) default 0 not null,
  "PrepaymentAmt" decimal(16, 2) default 0 not null,
  "DuePaymentAmt" decimal(16, 2) default 0 not null,
  "ExtendAmt" decimal(16, 2) default 0 not null,
  "LoanAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdCashFlow" add constraint "CdCashFlow_PK" primary key("DataYearMonth");

comment on table "CdCashFlow" is '現金流量預估資料檔';
comment on column "CdCashFlow"."DataYearMonth" is '年月份';
comment on column "CdCashFlow"."InterestIncome" is '利息收入';
comment on column "CdCashFlow"."PrincipalAmortizeAmt" is '本金攤還金額';
comment on column "CdCashFlow"."PrepaymentAmt" is '提前還款金額';
comment on column "CdCashFlow"."DuePaymentAmt" is '到期清償金額';
comment on column "CdCashFlow"."ExtendAmt" is '展期金額';
comment on column "CdCashFlow"."LoanAmt" is '貸放金額';
comment on column "CdCashFlow"."CreateDate" is '建檔日期時間';
comment on column "CdCashFlow"."CreateEmpNo" is '建檔人員';
comment on column "CdCashFlow"."LastUpdate" is '最後更新日期時間';
comment on column "CdCashFlow"."LastUpdateEmpNo" is '最後更新人員';
