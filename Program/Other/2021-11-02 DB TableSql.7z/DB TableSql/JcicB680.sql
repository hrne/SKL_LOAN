drop table "JcicB680" purge;

create table "JcicB680" (
  "DataYM" decimal(6, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "CustId" varchar2(10),
  "CustIdErr" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "Filler6" varchar2(40),
  "Amt" decimal(10, 0) default 0 not null,
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "Filler9" varchar2(54),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB680" add constraint "JcicB680_PK" primary key("DataYM", "TranCode", "CustId", "CustNo", "FacmNo", "BormNo");

comment on table "JcicB680" is '貸款餘額扣除擔保品鑑估值之金額資料檔';
comment on column "JcicB680"."DataYM" is '資料日期';
comment on column "JcicB680"."BankItem" is '總行代號';
comment on column "JcicB680"."BranchItem" is '分行代號';
comment on column "JcicB680"."TranCode" is '交易代碼';
comment on column "JcicB680"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB680"."CustIdErr" is '上欄IDN或BAN錯誤註記';
comment on column "JcicB680"."CustNo" is '借款人戶號';
comment on column "JcicB680"."FacmNo" is '額度編號';
comment on column "JcicB680"."BormNo" is '撥款序號';
comment on column "JcicB680"."Filler6" is '空白';
comment on column "JcicB680"."Amt" is '貸款餘額扣除擔保品鑑估值之金額';
comment on column "JcicB680"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB680"."Filler9" is '空白';
comment on column "JcicB680"."CreateDate" is '建檔日期時間';
comment on column "JcicB680"."CreateEmpNo" is '建檔人員';
comment on column "JcicB680"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB680"."LastUpdateEmpNo" is '最後更新人員';
