drop table "JcicZ574Log" purge;

create table "JcicZ574Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseMark" varchar2(2),
  "PhoneNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ574Log" add constraint "JcicZ574Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ574Log" is '更生款項統一收付結案通知資料';
comment on column "JcicZ574Log"."Ukey" is '流水號';
comment on column "JcicZ574Log"."TxSeq" is '交易序號';
comment on column "JcicZ574Log"."TranKey" is '交易代碼';
comment on column "JcicZ574Log"."CloseDate" is '結案日期';
comment on column "JcicZ574Log"."CloseMark" is '結案原因';
comment on column "JcicZ574Log"."PhoneNo" is '通訊電話';
comment on column "JcicZ574Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ574Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ574Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ574Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ574Log"."LastUpdateEmpNo" is '最後更新人員';
