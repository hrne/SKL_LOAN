drop table "SlipMedia" purge;

create table "SlipMedia" (
  "BranchNo" varchar2(4),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" decimal(2, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "MediaSeq" decimal(3, 0) default 0 not null,
  "MediaSlipNo" varchar2(10),
  "Seq" decimal(3, 0) default 0 not null,
  "AcBookItem" nvarchar2(50),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcNoItem" nvarchar2(40),
  "CurrencyCode" varchar2(3),
  "DbCr" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "ReceiveCode" varchar2(15),
  "DeptCode" varchar2(6),
  "SlipRmk" nvarchar2(40),
  "CostMonth" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "SlipMedia" add constraint "SlipMedia_PK" primary key("BranchNo", "AcDate", "BatchNo", "AcBookCode", "MediaSeq", "MediaSlipNo", "Seq");

comment on table "SlipMedia" is '傳票媒體檔';
comment on column "SlipMedia"."BranchNo" is '單位別';
comment on column "SlipMedia"."AcDate" is '會計日期';
comment on column "SlipMedia"."BatchNo" is '傳票批號';
comment on column "SlipMedia"."AcBookCode" is '帳冊別代碼';
comment on column "SlipMedia"."MediaSeq" is '媒體檔上傳序號';
comment on column "SlipMedia"."MediaSlipNo" is '媒體檔傳票號碼';
comment on column "SlipMedia"."Seq" is '傳票序號';
comment on column "SlipMedia"."AcBookItem" is '帳冊別名稱';
comment on column "SlipMedia"."AcNoCode" is '會計科目代號';
comment on column "SlipMedia"."AcSubCode" is '子目代號';
comment on column "SlipMedia"."AcNoItem" is '會計科目名稱';
comment on column "SlipMedia"."CurrencyCode" is '幣別';
comment on column "SlipMedia"."DbCr" is '借貸別';
comment on column "SlipMedia"."TxAmt" is '記帳金額';
comment on column "SlipMedia"."ReceiveCode" is '會計科目銷帳碼';
comment on column "SlipMedia"."DeptCode" is '部門代號';
comment on column "SlipMedia"."SlipRmk" is '傳票摘要';
comment on column "SlipMedia"."CostMonth" is '成本月份';
comment on column "SlipMedia"."CreateDate" is '建檔日期時間';
comment on column "SlipMedia"."CreateEmpNo" is '建檔人員';
comment on column "SlipMedia"."LastUpdate" is '最後更新日期時間';
comment on column "SlipMedia"."LastUpdateEmpNo" is '最後更新人員';
