drop table "JcicZ450Log" purge;

create table "JcicZ450Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "PayStatus" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ450Log" add constraint "JcicZ450Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ450Log" is '前置調解債務人繳款資料';
comment on column "JcicZ450Log"."Ukey" is '流水號';
comment on column "JcicZ450Log"."TxSeq" is '交易序號';
comment on column "JcicZ450Log"."TranKey" is '交易代碼';
comment on column "JcicZ450Log"."PayAmt" is '本次繳款金額';
comment on column "JcicZ450Log"."SumRepayActualAmt" is '累計實際還款金額';
comment on column "JcicZ450Log"."SumRepayShouldAmt" is '截至目前累計應還款金額';
comment on column "JcicZ450Log"."PayStatus" is '債權結案註記';
comment on column "JcicZ450Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ450Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ450Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ450Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ450Log"."LastUpdateEmpNo" is '最後更新人員';
