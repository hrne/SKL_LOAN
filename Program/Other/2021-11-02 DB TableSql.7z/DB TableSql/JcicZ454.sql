drop table "JcicZ454" purge;

create table "JcicZ454" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ454" add constraint "JcicZ454_PK" primary key("SubmitKey", "CustId", "ApplyDate", "CourtCode", "MaxMainCode");

create index "JcicZ454_Index1" on "JcicZ454"("SubmitKey" asc);

create index "JcicZ454_Index2" on "JcicZ454"("CustId" asc);

create index "JcicZ454_Index3" on "JcicZ454"("ApplyDate" asc);

create index "JcicZ454_Index4" on "JcicZ454"("CourtCode" asc);

create index "JcicZ454_Index5" on "JcicZ454"("MaxMainCode" asc);

comment on table "JcicZ454" is '前置調解單獨全數受清償資料';
comment on column "JcicZ454"."TranKey" is '交易代碼';
comment on column "JcicZ454"."CustId" is '債務人IDN';
comment on column "JcicZ454"."SubmitKey" is '報送單位代號';
comment on column "JcicZ454"."ApplyDate" is '調解申請日';
comment on column "JcicZ454"."CourtCode" is '受理調解機構代號';
comment on column "JcicZ454"."MaxMainCode" is '最大債權金融機構代號';
comment on column "JcicZ454"."PayOffResult" is '單獨全數受清償原因';
comment on column "JcicZ454"."PayOffDate" is '單獨全數受清償日期';
comment on column "JcicZ454"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ454"."Ukey" is '流水號';
comment on column "JcicZ454"."CreateDate" is '建檔日期時間';
comment on column "JcicZ454"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ454"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ454"."LastUpdateEmpNo" is '最後更新人員';
