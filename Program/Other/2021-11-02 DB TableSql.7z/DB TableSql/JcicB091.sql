drop table "JcicB091" purge;

create table "JcicB091" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(7, 0) default 0 not null,
  "LoanLimitAmt" decimal(10, 0) default 0 not null,
  "SettingDate" decimal(7, 0) default 0 not null,
  "CompanyId" varchar2(8),
  "CompanyCountry" varchar2(2),
  "StockCode" varchar2(10),
  "Currency" varchar2(3),
  "PledgeEndYM" decimal(5, 0) default 0 not null,
  "DispPrice" decimal(8, 0) default 0 not null,
  "Filler19" varchar2(14),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB091" add constraint "JcicB091_PK" primary key("DataYM", "ClActNo", "OwnerId", "CompanyId");

comment on table "JcicB091" is '聯徵有價證券(股票除外)擔保品明細檔';
comment on column "JcicB091"."DataYM" is '資料日期';
comment on column "JcicB091"."DataType" is '資料別';
comment on column "JcicB091"."BankItem" is '總行代號';
comment on column "JcicB091"."BranchItem" is '分行代號';
comment on column "JcicB091"."Filler4" is '空白';
comment on column "JcicB091"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB091"."ClTypeJCIC" is '擔保品類別';
comment on column "JcicB091"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB091"."EvaAmt" is '鑑估值';
comment on column "JcicB091"."EvaDate" is '鑑估日期';
comment on column "JcicB091"."LoanLimitAmt" is '可放款值';
comment on column "JcicB091"."SettingDate" is '設質日期';
comment on column "JcicB091"."CompanyId" is '發行機構 BAN';
comment on column "JcicB091"."CompanyCountry" is '發行機構所在國別';
comment on column "JcicB091"."StockCode" is '證券代號';
comment on column "JcicB091"."Currency" is '幣別';
comment on column "JcicB091"."PledgeEndYM" is '到期年月';
comment on column "JcicB091"."DispPrice" is '處分價格';
comment on column "JcicB091"."Filler19" is '空白';
comment on column "JcicB091"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB091"."CreateDate" is '建檔日期時間';
comment on column "JcicB091"."CreateEmpNo" is '建檔人員';
comment on column "JcicB091"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB091"."LastUpdateEmpNo" is '最後更新人員';
