drop table "JcicZ451Log" purge;

create table "JcicZ451Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DelayCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ451Log" add constraint "JcicZ451Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ451Log" is '前置調解延期繳款資料';
comment on column "JcicZ451Log"."Ukey" is '流水號';
comment on column "JcicZ451Log"."TxSeq" is '交易序號';
comment on column "JcicZ451Log"."TranKey" is '交易代碼';
comment on column "JcicZ451Log"."DelayCode" is '延期繳款原因';
comment on column "JcicZ451Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ451Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ451Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ451Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ451Log"."LastUpdateEmpNo" is '最後更新人員';
