drop table "MlaundryRecord" purge;

create table "MlaundryRecord" (
  "RecordDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayDate" decimal(8, 0) default 0 not null,
  "ActualRepayDate" decimal(8, 0) default 0 not null,
  "RepayAmt" decimal(16, 2) default 0 not null,
  "ActualRepayAmt" decimal(16, 2) default 0 not null,
  "Career" nvarchar2(20),
  "Income" nvarchar2(30),
  "RepaySource" decimal(2, 0) default 0 not null,
  "RepayBank" nvarchar2(10),
  "Description" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MlaundryRecord" add constraint "MlaundryRecord_PK" primary key("RecordDate", "CustNo", "FacmNo", "BormNo");

comment on table "MlaundryRecord" is '疑似洗錢交易訪談記錄檔';
comment on column "MlaundryRecord"."RecordDate" is '訪談日期';
comment on column "MlaundryRecord"."CustNo" is '戶號';
comment on column "MlaundryRecord"."FacmNo" is '額度編號';
comment on column "MlaundryRecord"."BormNo" is '撥款序號';
comment on column "MlaundryRecord"."RepayDate" is '預定還款日期';
comment on column "MlaundryRecord"."ActualRepayDate" is '實際還款日期';
comment on column "MlaundryRecord"."RepayAmt" is '預定還款金額';
comment on column "MlaundryRecord"."ActualRepayAmt" is '實際還款金額';
comment on column "MlaundryRecord"."Career" is '職業別';
comment on column "MlaundryRecord"."Income" is '年收入(萬)';
comment on column "MlaundryRecord"."RepaySource" is '還款來源';
comment on column "MlaundryRecord"."RepayBank" is '代償銀行';
comment on column "MlaundryRecord"."Description" is '其他說明';
comment on column "MlaundryRecord"."CreateDate" is '建檔日期時間';
comment on column "MlaundryRecord"."CreateEmpNo" is '建檔人員';
comment on column "MlaundryRecord"."LastUpdate" is '最後更新日期時間';
comment on column "MlaundryRecord"."LastUpdateEmpNo" is '最後更新人員';
