drop table "BankRelationSelf" purge;

create table "BankRelationSelf" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BankRelationSelf" add constraint "BankRelationSelf_PK" primary key("CustName", "CustId");

comment on table "BankRelationSelf" is '金控利害關係人_關係人員工資料';
comment on column "BankRelationSelf"."CustName" is '借款戶所屬公司名稱';
comment on column "BankRelationSelf"."CustId" is '借款戶統編';
comment on column "BankRelationSelf"."LAW001" is '金控法第44條';
comment on column "BankRelationSelf"."LAW002" is '金控法第44條(列項)';
comment on column "BankRelationSelf"."LAW003" is '金控法第45條';
comment on column "BankRelationSelf"."LAW005" is '保險法(放款)';
comment on column "BankRelationSelf"."LAW008" is '準利害關係人';
comment on column "BankRelationSelf"."CreateDate" is '建檔日期時間';
comment on column "BankRelationSelf"."CreateEmpNo" is '建檔人員';
comment on column "BankRelationSelf"."LastUpdate" is '最後更新日期時間';
comment on column "BankRelationSelf"."LastUpdateEmpNo" is '最後更新人員';
