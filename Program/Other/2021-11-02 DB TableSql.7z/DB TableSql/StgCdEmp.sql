drop table "StgCdEmp" purge;

create table "StgCdEmp" (
  "AGENT_CODE" varchar2(12),
  "COMM_LINE_CODE" varchar2(2),
  "COMM_LINE_TYPE" varchar2(1),
  "ORIG_INTRODUCER_ID" varchar2(12),
  "INTRODUCER_IND" varchar2(1),
  "REGISTER_LEVEL" varchar2(2),
  "REGISTER_DATE" varchar2(30),
  "CENTER_CODE" varchar2(6),
  "ADMINISTRAT_ID" varchar2(12),
  "INPUT_DATE" varchar2(30),
  "INPUT_USER" varchar2(8),
  "AG_STATUS_CODE" varchar2(1),
  "AG_STATUS_DATE" varchar2(30),
  "TRAN_DATE" varchar2(30),
  "TRAN_USER" varchar2(8),
  "RE_REGISTER_DATE" varchar2(30),
  "DIRECTOR_ID" varchar2(12),
  "DIRECTOR_ID_F" varchar2(12),
  "INTRODUCER_ID" varchar2(12),
  "INTRODUCER_ID_F" varchar2(12),
  "AG_LEVEL" varchar2(2),
  "LAST_LEVEL" varchar2(2),
  "LEVEL_DATE" varchar2(30),
  "TOP_LEVEL" varchar2(2),
  "OCCP_IND" varchar2(1),
  "QUOTA_AMT" varchar2(10),
  "APPL_TYPE" varchar2(1),
  "TAX_RATE" varchar2(9),
  "SOCIAL_INSU_CLASS" varchar2(5),
  "PROMOT_LEVEL_YM" varchar2(7),
  "DIRECTOR_YM" varchar2(7),
  "RECORD_DATE" varchar2(30),
  "EX_RECORD_DATE" varchar2(30),
  "EX_TR_DATE" varchar2(30),
  "EX_TR_IDENT" varchar2(16),
  "EX_TR_IDENT2" varchar2(9),
  "EX_TR_IDENT3" varchar2(12),
  "EX_TR_DATE3" varchar2(30),
  "REGISTER_BEFORE" varchar2(5),
  "DIRECTOR_AFTER" varchar2(5),
  "MEDICAL_CODE" varchar2(2),
  "EX_CHG_DATE" varchar2(30),
  "EX_DEL_DATE" varchar2(30),
  "APPL_CODE" varchar2(10),
  "FIRST_REG_DATE" varchar2(30),
  "AGIN_SOURCE" varchar2(3),
  "AGUI_CENTER" varchar2(9),
  "AGENT_ID" varchar2(10),
  "TOP_ID" varchar2(12),
  "AG_DEGREE" varchar2(2),
  "COLLECT_IND" varchar2(1),
  "AG_TYPE_1" varchar2(1),
  "EMPLOYEE_NO" varchar2(10),
  "CONTRACT_IND" varchar2(1),
  "CONTRACT_IND_YM" varchar2(7),
  "AG_TYPE_2" varchar2(1),
  "AG_TYPE_3" varchar2(1),
  "AG_TYPE_4" varchar2(1),
  "AGIN_IND1" varchar2(1),
  "AG_PO_IND" varchar2(1),
  "AG_DOC_IND" varchar2(1),
  "NEW_HIRE_TYPE" varchar2(1),
  "AG_CUR_IND" varchar2(1),
  "AG_SEND_TYPE" varchar2(3),
  "AG_SEND_NO" varchar2(100),
  "REGISTER_DATE_2" varchar2(30),
  "AG_RETURN_DATE" varchar2(30),
  "AG_TRANSFER_DATE_F" varchar2(30),
  "AG_TRANSFER_DATE" varchar2(30),
  "PROMOT_YM" varchar2(7),
  "PROMOT_YM_F" varchar2(7),
  "AG_POST_CHG_DATE" varchar2(30),
  "FAMILIES_TAX" varchar2(5),
  "AGENT_CODE_I" varchar2(12),
  "AG_LEVEL_SYS" varchar2(2),
  "AG_POST_IN" varchar2(6),
  "CENTER_CODE_ACC" varchar2(6),
  "EVALUE_IND" varchar2(1),
  "EVALUE_IND_1" varchar2(1),
  "BATCH_NO" varchar2(10),
  "EVALUE_YM" varchar2(7),
  "AG_TRANSFER_CODE" varchar2(2),
  "FULLNAME" nvarchar2(100),
  "BIRTH" varchar2(30),
  "EDUCATION" varchar2(1),
  "LR_IND" varchar2(1),
  "PROCESS_DATE" varchar2(30),
  "QUIT_DATE" varchar2(30),
  "CENTER_SHORT_NAME" nvarchar2(100),
  "CENTER_CODE_NAME" nvarchar2(100),
  "CENTER_CODE_1" varchar2(6),
  "CENTER_CODE_1_SHORT" nvarchar2(10),
  "CENTER_CODE_1_NAME" nvarchar2(100),
  "CENTER_CODE_2" varchar2(6),
  "CENTER_CODE_2_SHORT" nvarchar2(10),
  "CENTER_CODE_2_NAME" nvarchar2(100),
  "CENTER_CODE_ACC_1" varchar2(6),
  "CENTER_CODE_ACC_1_NAME" nvarchar2(100),
  "CENTER_CODE_ACC_2" varchar2(6),
  "CENTER_CODE_ACC_2_NAME" nvarchar2(100),
  "AG_POST" varchar2(2),
  "LEVEL_NAME_CHS" nvarchar2(10),
  "LR_SYSTEM_TYPE" varchar2(1),
  "SENIORITY_YY" varchar2(5),
  "SENIORITY_MM" varchar2(5),
  "SENIORITY_DD" varchar2(5),
  "AGLA_PROCESS_IND" varchar2(2),
  "STATUS_CODE" varchar2(1),
  "AGLA_CANCEL_REASON" varchar2(1),
  "IS_ANN_APPL_DATE" varchar2(30),
  "RECORD_DATE_C" varchar2(30),
  "STOP_REASON" varchar2(15),
  "STOP_STR_DATE" varchar2(30),
  "STOP_END_DATE" varchar2(30),
  "IFP_DATE" varchar2(30),
  "EFFECT_STR_DATE" varchar2(30),
  "EFFECT_END_DATE" varchar2(30),
  "ANN_APPL_DATE" varchar2(30),
  "CENTER_CODE_ACC_NAME" nvarchar2(20),
  "RE_HIRE_CODE" varchar2(1),
  "RSVD_ADMIN_CODE" varchar2(1),
  "ACCOUNT" varchar2(16),
  "PRP_DATE" varchar2(15),
  "ZIP" varchar2(10),
  "ADDRESS" nvarchar2(100),
  "PHONE_H" varchar2(30),
  "PHONE_C" varchar2(30),
  "SALES_QUAL_IND" varchar2(1),
  "AGSQ_START_DATE" varchar2(30),
  "PINYIN_NAME_INDI" nvarchar2(100)
);

alter table "StgCdEmp" add constraint "StgCdEmp_PK" primary key("AGENT_CODE");

comment on table "StgCdEmp" is '員工資料中介檔';
comment on column "StgCdEmp"."AGENT_CODE" is '業務員代號';
comment on column "StgCdEmp"."COMM_LINE_CODE" is '業務線代號';
comment on column "StgCdEmp"."COMM_LINE_TYPE" is '業務線別';
comment on column "StgCdEmp"."ORIG_INTRODUCER_ID" is '介紹人';
comment on column "StgCdEmp"."INTRODUCER_IND" is '介紹關係碼';
comment on column "StgCdEmp"."REGISTER_LEVEL" is '報聘職等';
comment on column "StgCdEmp"."REGISTER_DATE" is '在職/締約日期';
comment on column "StgCdEmp"."CENTER_CODE" is '單位代號';
comment on column "StgCdEmp"."ADMINISTRAT_ID" is '單位主管';
comment on column "StgCdEmp"."INPUT_DATE" is '建檔日期';
comment on column "StgCdEmp"."INPUT_USER" is '建檔人';
comment on column "StgCdEmp"."AG_STATUS_CODE" is '業務人員任用狀況碼';
comment on column "StgCdEmp"."AG_STATUS_DATE" is '業務人員任用狀況異動日';
comment on column "StgCdEmp"."TRAN_DATE" is '作業日期(交易日期)';
comment on column "StgCdEmp"."TRAN_USER" is '作業者';
comment on column "StgCdEmp"."RE_REGISTER_DATE" is '再聘日';
comment on column "StgCdEmp"."DIRECTOR_ID" is '上層主管';
comment on column "StgCdEmp"."DIRECTOR_ID_F" is '主管_財務';
comment on column "StgCdEmp"."INTRODUCER_ID" is '區主任/上一代主管';
comment on column "StgCdEmp"."INTRODUCER_ID_F" is '推介人_財務';
comment on column "StgCdEmp"."AG_LEVEL" is '業務人員職等';
comment on column "StgCdEmp"."LAST_LEVEL" is '前次業務人員職等';
comment on column "StgCdEmp"."LEVEL_DATE" is '職等異動日';
comment on column "StgCdEmp"."TOP_LEVEL" is '最高職等';
comment on column "StgCdEmp"."OCCP_IND" is '任職型態';
comment on column "StgCdEmp"."QUOTA_AMT" is '責任額';
comment on column "StgCdEmp"."APPL_TYPE" is '申請登錄類別';
comment on column "StgCdEmp"."TAX_RATE" is '所得稅率';
comment on column "StgCdEmp"."SOCIAL_INSU_CLASS" is '勞保等級';
comment on column "StgCdEmp"."PROMOT_LEVEL_YM" is '職等平階起始年月';
comment on column "StgCdEmp"."DIRECTOR_YM" is '晉陞主管年月';
comment on column "StgCdEmp"."RECORD_DATE" is '登錄日期';
comment on column "StgCdEmp"."EX_RECORD_DATE" is '發證日期';
comment on column "StgCdEmp"."EX_TR_DATE" is '證書日期/測驗日期';
comment on column "StgCdEmp"."EX_TR_IDENT" is '證書字號';
comment on column "StgCdEmp"."EX_TR_IDENT2" is '中專證號';
comment on column "StgCdEmp"."EX_TR_IDENT3" is '投資型證號';
comment on column "StgCdEmp"."EX_TR_DATE3" is '投資登錄日期';
comment on column "StgCdEmp"."REGISTER_BEFORE" is '報聘前年資(月表示)';
comment on column "StgCdEmp"."DIRECTOR_AFTER" is '主管年資';
comment on column "StgCdEmp"."MEDICAL_CODE" is '免體檢授權碼';
comment on column "StgCdEmp"."EX_CHG_DATE" is '換證日期';
comment on column "StgCdEmp"."EX_DEL_DATE" is '註銷日期';
comment on column "StgCdEmp"."APPL_CODE" is '申請業務類別';
comment on column "StgCdEmp"."FIRST_REG_DATE" is '初次登錄日';
comment on column "StgCdEmp"."AGIN_SOURCE" is '業務來源之專案';
comment on column "StgCdEmp"."AGUI_CENTER" is '單位代號';
comment on column "StgCdEmp"."AGENT_ID" is '業務人員身份證字號';
comment on column "StgCdEmp"."TOP_ID" is '業務人員主管';
comment on column "StgCdEmp"."AG_DEGREE" is '業務人員職級';
comment on column "StgCdEmp"."COLLECT_IND" is '收費員指示碼';
comment on column "StgCdEmp"."AG_TYPE_1" is '制度別';
comment on column "StgCdEmp"."EMPLOYEE_NO" is '電腦編號';
comment on column "StgCdEmp"."CONTRACT_IND" is '單雙合約碼';
comment on column "StgCdEmp"."CONTRACT_IND_YM" is '單雙合約異動工作月';
comment on column "StgCdEmp"."AG_TYPE_2" is '身份別';
comment on column "StgCdEmp"."AG_TYPE_3" is '特殊人員碼';
comment on column "StgCdEmp"."AG_TYPE_4" is '新舊制別';
comment on column "StgCdEmp"."AGIN_IND1" is '辦事員碼';
comment on column "StgCdEmp"."AG_PO_IND" is '可招攬指示碼';
comment on column "StgCdEmp"."AG_DOC_IND" is '齊件否';
comment on column "StgCdEmp"."NEW_HIRE_TYPE" is '新舊人指示碼';
comment on column "StgCdEmp"."AG_CUR_IND" is '現職指示碼';
comment on column "StgCdEmp"."AG_SEND_TYPE" is '發文類別';
comment on column "StgCdEmp"."AG_SEND_NO" is '發文文號';
comment on column "StgCdEmp"."REGISTER_DATE_2" is '任職日期';
comment on column "StgCdEmp"."AG_RETURN_DATE" is '回任日期';
comment on column "StgCdEmp"."AG_TRANSFER_DATE_F" is '初次轉制日期';
comment on column "StgCdEmp"."AG_TRANSFER_DATE" is '轉制日期';
comment on column "StgCdEmp"."PROMOT_YM" is '初次晉升年月';
comment on column "StgCdEmp"."PROMOT_YM_F" is '生效業績年月';
comment on column "StgCdEmp"."AG_POST_CHG_DATE" is '職務異動日';
comment on column "StgCdEmp"."FAMILIES_TAX" is '扶養人數';
comment on column "StgCdEmp"."AGENT_CODE_I" is '原區主任代號';
comment on column "StgCdEmp"."AG_LEVEL_SYS" is '職等_系統';
comment on column "StgCdEmp"."AG_POST_IN" is '內階職務';
comment on column "StgCdEmp"."CENTER_CODE_ACC" is '駐在單位';
comment on column "StgCdEmp"."EVALUE_IND" is '考核特殊碼';
comment on column "StgCdEmp"."EVALUE_IND_1" is '辦法優待碼';
comment on column "StgCdEmp"."BATCH_NO" is '批次號碼';
comment on column "StgCdEmp"."EVALUE_YM" is '考核年月';
comment on column "StgCdEmp"."AG_TRANSFER_CODE" is '轉檔碼';
comment on column "StgCdEmp"."FULLNAME" is '姓名';
comment on column "StgCdEmp"."BIRTH" is '出生年月日';
comment on column "StgCdEmp"."EDUCATION" is '學歷';
comment on column "StgCdEmp"."LR_IND" is '勞退狀況';
comment on column "StgCdEmp"."PROCESS_DATE" is '資料處理時間';
comment on column "StgCdEmp"."QUIT_DATE" is '離職/停約日';
comment on column "StgCdEmp"."CENTER_SHORT_NAME" is '單位簡稱';
comment on column "StgCdEmp"."CENTER_CODE_NAME" is '單位名稱';
comment on column "StgCdEmp"."CENTER_CODE_1" is '區部代號';
comment on column "StgCdEmp"."CENTER_CODE_1_SHORT" is '區部簡稱';
comment on column "StgCdEmp"."CENTER_CODE_1_NAME" is '區部名稱';
comment on column "StgCdEmp"."CENTER_CODE_2" is '部室代號';
comment on column "StgCdEmp"."CENTER_CODE_2_SHORT" is '部室簡稱';
comment on column "StgCdEmp"."CENTER_CODE_2_NAME" is '部室名稱';
comment on column "StgCdEmp"."CENTER_CODE_ACC_1" is '區部代號(駐在單位)';
comment on column "StgCdEmp"."CENTER_CODE_ACC_1_NAME" is '區部名稱(駐在單位)';
comment on column "StgCdEmp"."CENTER_CODE_ACC_2" is '部室代號(駐在單位)';
comment on column "StgCdEmp"."CENTER_CODE_ACC_2_NAME" is '部室名稱(駐在單位)';
comment on column "StgCdEmp"."AG_POST" is '職務';
comment on column "StgCdEmp"."LEVEL_NAME_CHS" is '職等中文';
comment on column "StgCdEmp"."LR_SYSTEM_TYPE" is '勞退碼';
comment on column "StgCdEmp"."SENIORITY_YY" is '年資_年';
comment on column "StgCdEmp"."SENIORITY_MM" is '年資_月';
comment on column "StgCdEmp"."SENIORITY_DD" is '年資_日';
comment on column "StgCdEmp"."AGLA_PROCESS_IND" is '登錄處理事項';
comment on column "StgCdEmp"."STATUS_CODE" is '登錄狀態';
comment on column "StgCdEmp"."AGLA_CANCEL_REASON" is '註銷原因';
comment on column "StgCdEmp"."IS_ANN_APPL_DATE" is '利變年金通報日';
comment on column "StgCdEmp"."RECORD_DATE_C" is '外幣保單登入日';
comment on column "StgCdEmp"."STOP_REASON" is '停招/撤銷原因';
comment on column "StgCdEmp"."STOP_STR_DATE" is '停止招攬起日';
comment on column "StgCdEmp"."STOP_END_DATE" is '停止招攬迄日';
comment on column "StgCdEmp"."IFP_DATE" is 'IFP登錄日';
comment on column "StgCdEmp"."EFFECT_STR_DATE" is '撤銷起日';
comment on column "StgCdEmp"."EFFECT_END_DATE" is '撤銷迄日';
comment on column "StgCdEmp"."ANN_APPL_DATE" is '一般年金通報日';
comment on column "StgCdEmp"."CENTER_CODE_ACC_NAME" is '單位名稱(駐在單位)';
comment on column "StgCdEmp"."RE_HIRE_CODE" is '重僱碼';
comment on column "StgCdEmp"."RSVD_ADMIN_CODE" is '特別碼';
comment on column "StgCdEmp"."ACCOUNT" is '帳號';
comment on column "StgCdEmp"."PRP_DATE" is '優體測驗通過日';
comment on column "StgCdEmp"."ZIP" is '戶籍地址郵遞區號';
comment on column "StgCdEmp"."ADDRESS" is '戶籍地址';
comment on column "StgCdEmp"."PHONE_H" is '住家電話';
comment on column "StgCdEmp"."PHONE_C" is '手機電話';
comment on column "StgCdEmp"."SALES_QUAL_IND" is '基金銷售資格碼';
comment on column "StgCdEmp"."AGSQ_START_DATE" is '基金銷售資格日';
comment on column "StgCdEmp"."PINYIN_NAME_INDI" is '原住民羅馬拼音姓名';
