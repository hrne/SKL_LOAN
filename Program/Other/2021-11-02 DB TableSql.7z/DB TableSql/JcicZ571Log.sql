drop table "JcicZ571Log" purge;

create table "JcicZ571Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "OwnerYn" varchar2(1),
  "PayYn" varchar2(1),
  "OwnerAmt" decimal(9, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "UnallotAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ571Log" add constraint "JcicZ571Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ571Log" is '更生款項統一收付回報債權資料';
comment on column "JcicZ571Log"."Ukey" is '流水號';
comment on column "JcicZ571Log"."TxSeq" is '交易序號';
comment on column "JcicZ571Log"."TranKey" is '交易代碼';
comment on column "JcicZ571Log"."OwnerYn" is '是否為更生債權人';
comment on column "JcicZ571Log"."PayYn" is '債務人是否仍依更生方案正常還款予本金融機構';
comment on column "JcicZ571Log"."OwnerAmt" is '本金融機構更生債權總金額';
comment on column "JcicZ571Log"."AllotAmt" is '參與分配債權金額';
comment on column "JcicZ571Log"."UnallotAmt" is '未參與分配債權金額';
comment on column "JcicZ571Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ571Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ571Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ571Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ571Log"."LastUpdateEmpNo" is '最後更新人員';
