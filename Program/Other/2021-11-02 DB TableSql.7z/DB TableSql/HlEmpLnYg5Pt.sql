drop table "HlEmpLnYg5Pt" purge;

create table "HlEmpLnYg5Pt" (
  "WorkYM" varchar2(10),
  "AreaUnitNo" varchar2(6),
  "HlEmpNo" varchar2(6),
  "HlEmpName" nvarchar2(15),
  "DeptNo" varchar2(6),
  "DeptName" varchar2(20),
  "Area" varchar2(20),
  "BranchName" varchar2(20),
  "GoalAmt" decimal(14, 2) default 0 not null,
  "HlAppNum" decimal(14, 2) default 0 not null,
  "HlAppAmt" decimal(14, 2) default 0 not null,
  "ClAppNum" decimal(14, 2) default 0 not null,
  "ClAppAmt" decimal(14, 2) default 0 not null,
  "ServiceAppNum" decimal(14, 2) default 0 not null,
  "ServiceAppAmt" decimal(14, 2) default 0 not null,
  "CalDate" varchar2(10),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "HlEmpLnYg5Pt" add constraint "HlEmpLnYg5Pt_PK" primary key("WorkYM", "AreaUnitNo", "HlEmpNo");

comment on table "HlEmpLnYg5Pt" is '員工目標檔案';
comment on column "HlEmpLnYg5Pt"."WorkYM" is '年月份';
comment on column "HlEmpLnYg5Pt"."AreaUnitNo" is '單位代號';
comment on column "HlEmpLnYg5Pt"."HlEmpNo" is '員工代號';
comment on column "HlEmpLnYg5Pt"."HlEmpName" is '員工姓名';
comment on column "HlEmpLnYg5Pt"."DeptNo" is '部室代號';
comment on column "HlEmpLnYg5Pt"."DeptName" is '部室中文';
comment on column "HlEmpLnYg5Pt"."Area" is '駐在地';
comment on column "HlEmpLnYg5Pt"."BranchName" is '區部中文';
comment on column "HlEmpLnYg5Pt"."GoalAmt" is '目標金額';
comment on column "HlEmpLnYg5Pt"."HlAppNum" is '房貸撥款件數';
comment on column "HlEmpLnYg5Pt"."HlAppAmt" is '房貸撥款金額';
comment on column "HlEmpLnYg5Pt"."ClAppNum" is '車貸撥款件數';
comment on column "HlEmpLnYg5Pt"."ClAppAmt" is '車貸撥款金額';
comment on column "HlEmpLnYg5Pt"."ServiceAppNum" is '信義撥款件數';
comment on column "HlEmpLnYg5Pt"."ServiceAppAmt" is '信義撥款金額';
comment on column "HlEmpLnYg5Pt"."CalDate" is '年月日';
comment on column "HlEmpLnYg5Pt"."UpNo" is 'UpdateIdentifier';
comment on column "HlEmpLnYg5Pt"."ProcessDate" is '更新日期';
comment on column "HlEmpLnYg5Pt"."CreateDate" is '建檔日期時間';
comment on column "HlEmpLnYg5Pt"."CreateEmpNo" is '建檔人員';
comment on column "HlEmpLnYg5Pt"."LastUpdate" is '最後更新日期時間';
comment on column "HlEmpLnYg5Pt"."LastUpdateEmpNo" is '最後更新人員';
