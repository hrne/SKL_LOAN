drop table "JcicZ440Log" purge;

create table "JcicZ440Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "RemindDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "ReportYn" varchar2(1),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ440Log" add constraint "JcicZ440Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ440Log" is '前置調解受理申請暨請求回報債權通知資料';
comment on column "JcicZ440Log"."Ukey" is '流水號';
comment on column "JcicZ440Log"."TxSeq" is '交易序號';
comment on column "JcicZ440Log"."TranKey" is '交易代碼';
comment on column "JcicZ440Log"."AgreeDate" is '同意書取得日期';
comment on column "JcicZ440Log"."StartDate" is '首次調解日';
comment on column "JcicZ440Log"."RemindDate" is '債權計算基準日';
comment on column "JcicZ440Log"."ApplyType" is '受理方式';
comment on column "JcicZ440Log"."ReportYn" is '協辦行是否需自行回報債權';
comment on column "JcicZ440Log"."NotBankId1" is '未揭露債權機構代號1';
comment on column "JcicZ440Log"."NotBankId2" is '未揭露債權機構代號2';
comment on column "JcicZ440Log"."NotBankId3" is '未揭露債權機構代號3';
comment on column "JcicZ440Log"."NotBankId4" is '未揭露債權機構代號4';
comment on column "JcicZ440Log"."NotBankId5" is '未揭露債權機構代號5';
comment on column "JcicZ440Log"."NotBankId6" is '未揭露債權機構代號6';
comment on column "JcicZ440Log"."OutJcicTxtDate" is '轉JCIC文字檔日期';
comment on column "JcicZ440Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ440Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ440Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ440Log"."LastUpdateEmpNo" is '最後更新人員';
