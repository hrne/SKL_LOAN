drop table "Ias34Dp" purge;

create table "Ias34Dp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerDate" decimal(8, 0) default 0 not null,
  "DerRate" decimal(8, 6) default 0 not null,
  "DerLoanBal" decimal(16, 2) default 0 not null,
  "DerIntAmt" decimal(16, 2) default 0 not null,
  "DerFee" decimal(16, 2) default 0 not null,
  "DerY1Amt" decimal(16, 2) default 0 not null,
  "DerY2Amt" decimal(16, 2) default 0 not null,
  "DerY3Amt" decimal(16, 2) default 0 not null,
  "DerY4Amt" decimal(16, 2) default 0 not null,
  "DerY5Amt" decimal(16, 2) default 0 not null,
  "DerY1Int" decimal(16, 2) default 0 not null,
  "DerY2Int" decimal(16, 2) default 0 not null,
  "DerY3Int" decimal(16, 2) default 0 not null,
  "DerY4Int" decimal(16, 2) default 0 not null,
  "DerY5Int" decimal(16, 2) default 0 not null,
  "DerY1Fee" decimal(16, 2) default 0 not null,
  "DerY2Fee" decimal(16, 2) default 0 not null,
  "DerY3Fee" decimal(16, 2) default 0 not null,
  "DerY4Fee" decimal(16, 2) default 0 not null,
  "DerY5Fee" decimal(16, 2) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdCode" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "Ias34Dp" add constraint "Ias34Dp_PK" primary key("DataYM", "CustNo", "FacmNo", "BormNo");

comment on table "Ias34Dp" is 'IAS34欄位清單D檔';
comment on column "Ias34Dp"."DataYM" is '年月份';
comment on column "Ias34Dp"."CustNo" is '戶號';
comment on column "Ias34Dp"."CustId" is '借款人ID / 統編';
comment on column "Ias34Dp"."FacmNo" is '額度編號';
comment on column "Ias34Dp"."BormNo" is '撥款序號';
comment on column "Ias34Dp"."AcCode" is '會計科目';
comment on column "Ias34Dp"."Status" is '案件狀態';
comment on column "Ias34Dp"."FirstDrawdownDate" is '初貸日期';
comment on column "Ias34Dp"."DrawdownDate" is '貸放日期';
comment on column "Ias34Dp"."MaturityDate" is '到期日';
comment on column "Ias34Dp"."LineAmt" is '核准金額';
comment on column "Ias34Dp"."DrawdownAmt" is '撥款金額';
comment on column "Ias34Dp"."LoanBal" is '本金餘額(撥款)';
comment on column "Ias34Dp"."IntAmt" is '應收利息';
comment on column "Ias34Dp"."Fee" is '法拍及火險費用';
comment on column "Ias34Dp"."OvduDays" is '逾期繳款天數';
comment on column "Ias34Dp"."OvduDate" is '轉催收款日期';
comment on column "Ias34Dp"."BadDebtDate" is '轉銷呆帳日期';
comment on column "Ias34Dp"."BadDebtAmt" is '轉銷呆帳金額';
comment on column "Ias34Dp"."DerDate" is '個案減損客觀證據發生日期';
comment on column "Ias34Dp"."DerRate" is '上述發生日期前之最近一次利率';
comment on column "Ias34Dp"."DerLoanBal" is '上述發生日期時之本金餘額';
comment on column "Ias34Dp"."DerIntAmt" is '上述發生日期時之應收利息';
comment on column "Ias34Dp"."DerFee" is '上述發生日期時之法拍及火險費用';
comment on column "Ias34Dp"."DerY1Amt" is '個案減損客觀證據發生後第一年本金回收金額';
comment on column "Ias34Dp"."DerY2Amt" is '個案減損客觀證據發生後第二年本金回收金額';
comment on column "Ias34Dp"."DerY3Amt" is '個案減損客觀證據發生後第三年本金回收金額';
comment on column "Ias34Dp"."DerY4Amt" is '個案減損客觀證據發生後第四年本金回收金額';
comment on column "Ias34Dp"."DerY5Amt" is '個案減損客觀證據發生後第五年本金回收金額';
comment on column "Ias34Dp"."DerY1Int" is '個案減損客觀證據發生後第一年應收利息回收金額';
comment on column "Ias34Dp"."DerY2Int" is '個案減損客觀證據發生後第二年應收利息回收金額';
comment on column "Ias34Dp"."DerY3Int" is '個案減損客觀證據發生後第三年應收利息回收金額';
comment on column "Ias34Dp"."DerY4Int" is '個案減損客觀證據發生後第四年應收利息回收金額';
comment on column "Ias34Dp"."DerY5Int" is '個案減損客觀證據發生後第五年應收利息回收金額';
comment on column "Ias34Dp"."DerY1Fee" is '個案減損客觀證據發生後第一年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY2Fee" is '個案減損客觀證據發生後第二年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY3Fee" is '個案減損客觀證據發生後第三年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY4Fee" is '個案減損客觀證據發生後第四年法拍及火險費用回收金額';
comment on column "Ias34Dp"."DerY5Fee" is '個案減損客觀證據發生後第五年法拍及火險費用回收金額';
comment on column "Ias34Dp"."IndustryCode" is '授信行業別';
comment on column "Ias34Dp"."ClTypeJCIC" is '擔保品類別';
comment on column "Ias34Dp"."Zip3" is '擔保品地區別';
comment on column "Ias34Dp"."ProdCode" is '商品利率代碼';
comment on column "Ias34Dp"."CustKind" is '企業戶/個人戶';
comment on column "Ias34Dp"."IfrsProdCode" is '產品別';
comment on column "Ias34Dp"."CreateDate" is '建檔日期時間';
comment on column "Ias34Dp"."CreateEmpNo" is '建檔人員';
comment on column "Ias34Dp"."LastUpdate" is '最後更新日期時間';
comment on column "Ias34Dp"."LastUpdateEmpNo" is '最後更新人員';
