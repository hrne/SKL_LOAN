drop table "MonthlyLM003" purge;

create table "MonthlyLM003" (
  "EntType" decimal(1, 0) default 0 not null,
  "DataYear" decimal(4, 0) default 0 not null,
  "DataMonth" decimal(2, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "CloseLoan" decimal(16, 2) default 0 not null,
  "CloseSale" decimal(16, 2) default 0 not null,
  "CloseSelfRepay" decimal(16, 2) default 0 not null,
  "ExtraRepay" decimal(16, 2) default 0 not null,
  "PrincipalAmortize" decimal(16, 2) default 0 not null,
  "Collection" decimal(16, 2) default 0 not null,
  "LoanBalance" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM003" add constraint "MonthlyLM003_PK" primary key("EntType", "DataYear", "DataMonth");

comment on table "MonthlyLM003" is '撥款還款金額比較月報工作檔';
comment on column "MonthlyLM003"."EntType" is '企金別';
comment on column "MonthlyLM003"."DataYear" is '資料年份';
comment on column "MonthlyLM003"."DataMonth" is '資料月份';
comment on column "MonthlyLM003"."DrawdownAmt" is '撥款金額';
comment on column "MonthlyLM003"."CloseLoan" is '結清-利率高轉貸';
comment on column "MonthlyLM003"."CloseSale" is '結清-買賣';
comment on column "MonthlyLM003"."CloseSelfRepay" is '結清-自行還款';
comment on column "MonthlyLM003"."ExtraRepay" is '非結清-部份還款';
comment on column "MonthlyLM003"."PrincipalAmortize" is '非結清-本金攤提';
comment on column "MonthlyLM003"."Collection" is '非結清-轉催收';
comment on column "MonthlyLM003"."LoanBalance" is '月底餘額';
comment on column "MonthlyLM003"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM003"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM003"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM003"."LastUpdateEmpNo" is '最後更新人員';
