drop table "MonthlyLM028" purge;

create table "MonthlyLM028" (
  "LMSSTS" decimal(2, 0) default 0 not null,
  "CUSENT" decimal(1, 0) default 0 not null,
  "CUSBRH" varchar2(4),
  "LMSACN" decimal(7, 0) default 0 not null,
  "LMSAPN" decimal(3, 0) default 0 not null,
  "LMSASQ" decimal(3, 0) default 0 not null,
  "IRTRAT" decimal(6, 4) default 0 not null,
  "LMSISC" decimal(2, 0) default 0 not null,
  "LMSPBK" varchar2(3),
  "APLMON" decimal(2, 0) default 0 not null,
  "APLDAY" decimal(3, 0) default 0 not null,
  "LMSLBL" decimal(16, 2) default 0 not null,
  "AILIRT" varchar2(1),
  "POSCDE" varchar2(1),
  "LMSPDY" decimal(2, 0) default 0 not null,
  "IRTFSC" decimal(2, 0) default 0 not null,
  "IRTBCD" varchar2(2),
  "IRTRATYR1" decimal(6, 4) default 0 not null,
  "IRTRATYR2" decimal(6, 4) default 0 not null,
  "IRTRATYR3" decimal(6, 4) default 0 not null,
  "IRTRATYR4" decimal(6, 4) default 0 not null,
  "IRTRATYR5" decimal(6, 4) default 0 not null,
  "GDRID1" decimal(1, 0) default 0 not null,
  "GDRID2" decimal(2, 0) default 0 not null,
  "YYYY" decimal(4, 0) default 0 not null,
  "MONTH" decimal(2, 0) default 0 not null,
  "DAY" decimal(2, 0) default 0 not null,
  "W08CDE" decimal(1, 0) default 0 not null,
  "RELATION" varchar2(1),
  "DPTLVL" varchar2(1),
  "ACTFSC" varchar2(1),
  "LIRTRATYR" decimal(6, 4) default 0 not null,
  "LIRTDAY" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "MonthlyLM028" add constraint "MonthlyLM028_PK" primary key("LMSACN", "LMSAPN", "LMSASQ");

comment on table "MonthlyLM028" is 'LM028預估現金流量月報工作檔';
comment on column "MonthlyLM028"."LMSSTS" is '戶況';
comment on column "MonthlyLM028"."CUSENT" is '企金別';
comment on column "MonthlyLM028"."CUSBRH" is '營業單位別';
comment on column "MonthlyLM028"."LMSACN" is '借款人戶號';
comment on column "MonthlyLM028"."LMSAPN" is '額度編號';
comment on column "MonthlyLM028"."LMSASQ" is '撥款序號';
comment on column "MonthlyLM028"."IRTRAT" is '利率';
comment on column "MonthlyLM028"."LMSISC" is '繳息週期';
comment on column "MonthlyLM028"."LMSPBK" is '扣款銀行';
comment on column "MonthlyLM028"."APLMON" is '貸款期間－月';
comment on column "MonthlyLM028"."APLDAY" is '貸款期間－日';
comment on column "MonthlyLM028"."LMSLBL" is '放款餘額';
comment on column "MonthlyLM028"."AILIRT" is '利率區分';
comment on column "MonthlyLM028"."POSCDE" is '郵局存款別';
comment on column "MonthlyLM028"."LMSPDY" is '應繳日';
comment on column "MonthlyLM028"."IRTFSC" is '首次調整週期';
comment on column "MonthlyLM028"."IRTBCD" is '基本利率代碼';
comment on column "MonthlyLM028"."IRTRATYR1" is '利率1';
comment on column "MonthlyLM028"."IRTRATYR2" is '利率2';
comment on column "MonthlyLM028"."IRTRATYR3" is '利率3';
comment on column "MonthlyLM028"."IRTRATYR4" is '利率4';
comment on column "MonthlyLM028"."IRTRATYR5" is '利率5';
comment on column "MonthlyLM028"."GDRID1" is '押品別１';
comment on column "MonthlyLM028"."GDRID2" is '押品別２';
comment on column "MonthlyLM028"."YYYY" is '撥款日-年';
comment on column "MonthlyLM028"."MONTH" is '撥款日-月';
comment on column "MonthlyLM028"."DAY" is '撥款日-日';
comment on column "MonthlyLM028"."W08CDE" is '到期日碼';
comment on column "MonthlyLM028"."RELATION" is '是否為關係人';
comment on column "MonthlyLM028"."DPTLVL" is '制度別';
comment on column "MonthlyLM028"."ACTFSC" is '資金來源';
comment on column "MonthlyLM028"."LIRTRATYR" is '最新利率';
comment on column "MonthlyLM028"."LIRTDAY" is '最新利率生效起日';
comment on column "MonthlyLM028"."CreateDate" is '建檔日期時間';
comment on column "MonthlyLM028"."CreateEmpNo" is '建檔人員';
comment on column "MonthlyLM028"."LastUpdate" is '最後更新日期時間';
comment on column "MonthlyLM028"."LastUpdateEmpNo" is '最後更新人員';
