CREATE OR REPLACE PROCEDURE "Usp_Cp_TxAgent_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMIN' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxAgent" DROP STORAGE';

  INSERT INTO "TxAgent" (
    "TlrNo",
    "AgentTlrNo",
    "BeginDate",
    "BeginTime",
    "EndDate",
    "EndTime",
    "Status",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "TlrNo",
    "AgentTlrNo",
    "BeginDate",
    "BeginTime",
    "EndDate",
    "EndTime",
    "Status",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMIN."TxAgent";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxAgent_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;