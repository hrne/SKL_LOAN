CREATE OR REPLACE PROCEDURE "Usp_Cp_TxArchiveTableLog_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMIN' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxArchiveTableLog" DROP STORAGE';

  INSERT INTO "TxArchiveTableLog" (
    "Type",
    "DataFrom",
    "DataTo",
    "ExecuteDate",
    "TableName",
    "BatchNo",
    "Result",
    "CustNo",
    "FacmNo",
    "BormNo",
    "Description",
    "Records",
    "IsDeleted",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "Type",
    "DataFrom",
    "DataTo",
    "ExecuteDate",
    "TableName",
    "BatchNo",
    "Result",
    "CustNo",
    "FacmNo",
    "BormNo",
    "Description",
    "Records",
    "IsDeleted",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMIN."TxArchiveTableLog";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxArchiveTableLog_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;