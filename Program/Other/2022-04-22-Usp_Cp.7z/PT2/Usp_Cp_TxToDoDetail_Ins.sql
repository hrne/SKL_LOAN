CREATE OR REPLACE PROCEDURE "Usp_Cp_TxToDoDetail_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxToDoDetail" DROP STORAGE';

  INSERT INTO "TxToDoDetail" (
    "ItemCode",
    "CustNo",
    "FacmNo",
    "BormNo",
    "DtlValue",
    "Status",
    "ProcessNote",
    "ExcuteTxcd",
    "DataDate",
    "TitaEntdy",
    "TitaKinbr",
    "TitaTlrNo",
    "TitaTxtNo",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "ItemCode",
    "CustNo",
    "FacmNo",
    "BormNo",
    "DtlValue",
    "Status",
    "ProcessNote",
    "ExcuteTxcd",
    "DataDate",
    "TitaEntdy",
    "TitaKinbr",
    "TitaTlrNo",
    "TitaTxtNo",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxToDoDetail";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxToDoDetail_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;