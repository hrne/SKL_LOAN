CREATE OR REPLACE PROCEDURE "Usp_Cp_TxAmlCredit_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxAmlCredit" DROP STORAGE';

  INSERT INTO "TxAmlCredit" (
    "DataDt",
    "CustKey",
    "RRSeq",
    "ReviewType",
    "Unit",
    "IsStatus",
    "WlfConfirmStatus",
    "ProcessType",
    "ProcessCount",
    "ProcessBrNo",
    "ProcessGroupNo",
    "ProcessTlrNo",
    "ProcessDate",
    "ProcessMobile",
    "ProcessAddress",
    "ProcessName",
    "ProcessNote",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "DataDt",
    "CustKey",
    "RRSeq",
    "ReviewType",
    "Unit",
    "IsStatus",
    "WlfConfirmStatus",
    "ProcessType",
    "ProcessCount",
    "ProcessBrNo",
    "ProcessGroupNo",
    "ProcessTlrNo",
    "ProcessDate",
    "ProcessMobile",
    "ProcessAddress",
    "ProcessName",
    "ProcessNote",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxAmlCredit";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxAmlCredit_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;