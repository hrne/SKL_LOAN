CREATE OR REPLACE PROCEDURE "Usp_Cp_TxAttachment_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxAttachment" DROP STORAGE';

  INSERT INTO "TxAttachment" (
    "FileNo",
    "TranNo",
    "CustNo",
    "FacmNo",
    "BormNo",
    "MrKey",
    "TypeItem",
    "FileItem",
    "FileData",
    "Desc",
    "Status",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "FileNo",
    "TranNo",
    "CustNo",
    "FacmNo",
    "BormNo",
    "MrKey",
    "TypeItem",
    "FileItem",
    "FileData",
    "Desc",
    "Status",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxAttachment";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxAttachment_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;