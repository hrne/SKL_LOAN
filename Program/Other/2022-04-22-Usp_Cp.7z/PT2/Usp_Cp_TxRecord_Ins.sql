CREATE OR REPLACE PROCEDURE "Usp_Cp_TxRecord_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxRecord" DROP STORAGE';

  INSERT INTO "TxRecord" (
    "Entdy",
    "TxNo",
    "BrNo",
    "TlrNo",
    "TxSeq",
    "TranNo",
    "GroupNo",
    "TrmType",
    "MrKey",
    "SecNo",
    "DeCr",
    "BookAc",
    "AcCnt",
    "CurCode",
    "CurName",
    "TxAmt",
    "SupNo",
    "Hcode",
    "CalDate",
    "CalTime",
    "TxResult",
    "MsgId",
    "ErrMsg",
    "FlowNo",
    "FlowType",
    "FlowStep",
    "LockCustNo",
    "LockNo",
    "CanCancel",
    "CanModify",
    "ActionFg",
    "OrgEntdy",
    "OrgTxNo",
    "TranData",
    "ImportFg",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "Entdy",
    "TxNo",
    "BrNo",
    "TlrNo",
    "TxSeq",
    "TranNo",
    "GroupNo",
    "TrmType",
    "MrKey",
    "SecNo",
    "DeCr",
    "BookAc",
    "AcCnt",
    "CurCode",
    "CurName",
    "TxAmt",
    "SupNo",
    "Hcode",
    "CalDate",
    "CalTime",
    "TxResult",
    "MsgId",
    "ErrMsg",
    "FlowNo",
    "FlowType",
    "FlowStep",
    "LockCustNo",
    "LockNo",
    "CanCancel",
    "CanModify",
    "ActionFg",
    "OrgEntdy",
    "OrgTxNo",
    "TranData",
    "ImportFg",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxRecord";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxRecord_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;