CREATE OR REPLACE PROCEDURE "Usp_Cp_TxBizDate_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxBizDate" DROP STORAGE';

  INSERT INTO "TxBizDate" (
    "DateCode",
    "DayOfWeek",
    "TbsDy",
    "NbsDy",
    "NnbsDy",
    "LbsDy",
    "LmnDy",
    "TmnDy",
    "MfbsDy",
    "TbsDyf",
    "NbsDyf",
    "NnbsDyf",
    "LbsDyf",
    "LmnDyf",
    "TmnDyf",
    "MfbsDyf",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "DateCode",
    "DayOfWeek",
    "TbsDy",
    "NbsDy",
    "NnbsDy",
    "LbsDy",
    "LmnDy",
    "TmnDy",
    "MfbsDy",
    "TbsDyf",
    "NbsDyf",
    "NnbsDyf",
    "LbsDyf",
    "LmnDyf",
    "TmnDyf",
    "MfbsDyf",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxBizDate";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxBizDate_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;