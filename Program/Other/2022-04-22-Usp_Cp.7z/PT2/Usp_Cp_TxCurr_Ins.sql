CREATE OR REPLACE PROCEDURE "Usp_Cp_TxCurr_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxCurr" DROP STORAGE';

  INSERT INTO "TxCurr" (
    "CurCd",
    "CurNm",
    "CurEm",
    "CurCm",
    "ActFg",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "CurCd",
    "CurNm",
    "CurEm",
    "CurCm",
    "ActFg",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxCurr";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxCurr_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;