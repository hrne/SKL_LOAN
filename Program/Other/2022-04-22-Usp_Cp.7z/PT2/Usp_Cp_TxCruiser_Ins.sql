CREATE OR REPLACE PROCEDURE "Usp_Cp_TxCruiser_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxCruiser" DROP STORAGE';

  INSERT INTO "TxCruiser" (
    "TxSeq",
    "TlrNo",
    "TxCode",
    "JobList",
    "Parameter",
    "Status",
    "SendMSgChainOff",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "TxSeq",
    "TlrNo",
    "TxCode",
    "JobList",
    "Parameter",
    "Status",
    "SendMSgChainOff",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxCruiser";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxCruiser_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;