CREATE OR REPLACE PROCEDURE "Usp_Cp_TxTranCode_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxTranCode" DROP STORAGE';

  INSERT INTO "TxTranCode" (
    "TranNo",
    "TranItem",
    "Desc",
    "TypeFg",
    "CancelFg",
    "ModifyFg",
    "MenuNo",
    "SubMenuNo",
    "MenuFg",
    "SubmitFg",
    "Status",
    "CustDataCtrlFg",
    "CustRmkFg",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "TranNo",
    "TranItem",
    "Desc",
    "TypeFg",
    "CancelFg",
    "ModifyFg",
    "MenuNo",
    "SubMenuNo",
    "MenuFg",
    "SubmitFg",
    "Status",
    "CustDataCtrlFg",
    "CustRmkFg",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxTranCode";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxTranCode_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;