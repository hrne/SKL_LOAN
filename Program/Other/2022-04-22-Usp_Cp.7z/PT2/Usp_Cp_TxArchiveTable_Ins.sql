CREATE OR REPLACE PROCEDURE "Usp_Cp_TxArchiveTable_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxArchiveTable" DROP STORAGE';

  INSERT INTO "TxArchiveTable" (
    "Type",
    "TableName",
    "Enabled",
    "Conditions",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "Type",
    "TableName",
    "Enabled",
    "Conditions",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxArchiveTable";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxArchiveTable_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;