CREATE OR REPLACE PROCEDURE "Usp_Cp_TxAmlLog_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxAmlLog" DROP STORAGE';

  INSERT INTO "TxAmlLog" (
    "LogNo",
    "Entdy",
    "BrNo",
    "RefNo",
    "CaseNo",
    "AcctNo",
    "TransactionId",
    "MsgRg",
    "MsgRs",
    "Status",
    "StatusCode",
    "StatusDesc",
    "IsSimilar",
    "IsSan",
    "IsBanNation",
    "ConfirmStatus",
    "ConfirmCode",
    "ConfirmEmpNo",
    "ConfirmTranCode",
    "CustId",
    "CustNo",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "LogNo",
    "Entdy",
    "BrNo",
    "RefNo",
    "CaseNo",
    "AcctNo",
    "TransactionId",
    "MsgRg",
    "MsgRs",
    "Status",
    "StatusCode",
    "StatusDesc",
    "IsSimilar",
    "IsSan",
    "IsBanNation",
    "ConfirmStatus",
    "ConfirmCode",
    "ConfirmEmpNo",
    "ConfirmTranCode",
    "CustId",
    "CustNo",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxAmlLog";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxAmlLog_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;