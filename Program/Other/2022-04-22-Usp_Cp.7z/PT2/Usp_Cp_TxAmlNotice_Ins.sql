CREATE OR REPLACE PROCEDURE "Usp_Cp_TxAmlNotice_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxAmlNotice" DROP STORAGE';

  INSERT INTO "TxAmlNotice" (
    "DataDt",
    "CustKey",
    "ProcessSno",
    "ReviewType",
    "ProcessType",
    "ProcessBrNo",
    "ProcessGroupNo",
    "ProcessTlrNo",
    "ProcessDate",
    "ProcessMobile",
    "ProcessAddress",
    "ProcessName",
    "ProcessNote",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "DataDt",
    "CustKey",
    "ProcessSno",
    "ReviewType",
    "ProcessType",
    "ProcessBrNo",
    "ProcessGroupNo",
    "ProcessTlrNo",
    "ProcessDate",
    "ProcessMobile",
    "ProcessAddress",
    "ProcessName",
    "ProcessNote",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxAmlNotice";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxAmlNotice_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;