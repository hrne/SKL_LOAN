CREATE OR REPLACE PROCEDURE "Usp_Cp_TxTeller_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxTeller" DROP STORAGE';

  INSERT INTO "TxTeller" (
    "TlrNo",
    "BrNo",
    "AdFg",
    "TlrItem",
    "LevelFg",
    "AllowFg",
    "Status",
    "GroupNo",
    "AuthNo",
    "Entdy",
    "ReportDb",
    "LogonFg",
    "LoggerFg",
    "TxtNo",
    "LtxDate",
    "LtxTime",
    "Desc",
    "LastDate",
    "LastTime",
    "AmlHighFg",
    "AuthNo1",
    "AuthNo2",
    "AuthNo3",
    "AuthNo4",
    "AuthNo5",
    "AuthNo6",
    "AuthNo7",
    "AuthNo8",
    "AuthNo9",
    "AuthNo10",
    "Station",
    "AdminFg",
    "MntDate",
    "MntEmpNo",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "TlrNo",
    "BrNo",
    "AdFg",
    "TlrItem",
    "LevelFg",
    "AllowFg",
    "Status",
    "GroupNo",
    "AuthNo",
    "Entdy",
    "ReportDb",
    "LogonFg",
    "LoggerFg",
    "TxtNo",
    "LtxDate",
    "LtxTime",
    "Desc",
    "LastDate",
    "LastTime",
    "AmlHighFg",
    "AuthNo1",
    "AuthNo2",
    "AuthNo3",
    "AuthNo4",
    "AuthNo5",
    "AuthNo6",
    "AuthNo7",
    "AuthNo8",
    "AuthNo9",
    "AuthNo10",
    "Station",
    "AdminFg",
    "MntDate",
    "MntEmpNo",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxTeller";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxTeller_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;