CREATE OR REPLACE PROCEDURE "Usp_Cp_TxUnLock_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "TxUnLock" DROP STORAGE';

  INSERT INTO "TxUnLock" (
    "LockNo",
    "Entdy",
    "CustNo",
    "TranNo",
    "BrNo",
    "TlrNo",
    "BrNo2",
    "TlrNo2",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "LockNo",
    "Entdy",
    "CustNo",
    "TranNo",
    "BrNo",
    "TlrNo",
    "BrNo2",
    "TlrNo2",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."TxUnLock";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_TxUnLock_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;