CREATE OR REPLACE PROCEDURE "Usp_Cp_LoanBorTx_Ins"
(
"EmpNo" IN VARCHAR2
)
AS
BEGIN
  IF USER = 'ITXADMINTE' THEN
    RETURN;
  END IF;

  EXECUTE IMMEDIATE 'TRUNCATE TABLE "LoanBorTx" DROP STORAGE';

  INSERT INTO "LoanBorTx" (
    "CustNo",
    "FacmNo",
    "BormNo",
    "BorxNo",
    "TitaCalDy",
    "TitaCalTm",
    "TitaKinBr",
    "TitaTlrNo",
    "TitaTxtNo",
    "TitaTxCd",
    "TitaCrDb",
    "TitaHCode",
    "TitaCurCd",
    "TitaEmpNoS",
    "RepayCode",
    "Desc",
    "AcDate",
    "CorrectSeq",
    "Displayflag",
    "EntryDate",
    "DueDate",
    "TxAmt",
    "LoanBal",
    "IntStartDate",
    "IntEndDate",
    "RepaidPeriod",
    "Rate",
    "Principal",
    "Interest",
    "DelayInt",
    "BreachAmt",
    "CloseBreachAmt",
    "TempAmt",
    "ExtraRepay",
    "UnpaidInterest",
    "UnpaidPrincipal",
    "UnpaidCloseBreach",
    "Shortfall",
    "Overflow",
    "OtherFields",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
)
  SELECT
    "CustNo",
    "FacmNo",
    "BormNo",
    "BorxNo",
    "TitaCalDy",
    "TitaCalTm",
    "TitaKinBr",
    "TitaTlrNo",
    "TitaTxtNo",
    "TitaTxCd",
    "TitaCrDb",
    "TitaHCode",
    "TitaCurCd",
    "TitaEmpNoS",
    "RepayCode",
    "Desc",
    "AcDate",
    "CorrectSeq",
    "Displayflag",
    "EntryDate",
    "DueDate",
    "TxAmt",
    "LoanBal",
    "IntStartDate",
    "IntEndDate",
    "RepaidPeriod",
    "Rate",
    "Principal",
    "Interest",
    "DelayInt",
    "BreachAmt",
    "CloseBreachAmt",
    "TempAmt",
    "ExtraRepay",
    "UnpaidInterest",
    "UnpaidPrincipal",
    "UnpaidCloseBreach",
    "Shortfall",
    "Overflow",
    "OtherFields",
    "CreateDate",
    "CreateEmpNo",
    "LastUpdate",
    "LastUpdateEmpNo"
  FROM ITXADMINTE."LoanBorTx";

  Exception 
  WHEN OTHERS THEN
  "Usp_L9_UspErrorLog_Ins"(
    'Usp_Cp_LoanBorTx_Ins',
    SQLCODE,
    SQLERRM,
    dbms_utility.format_error_backtrace,
    "EmpNo"
  );
END;