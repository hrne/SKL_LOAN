drop table "CdPfParms" purge;

create table "CdPfParms" (
  "ConditionCode1" varchar2(1),
  "ConditionCode2" varchar2(1),
  "Condition" varchar2(6),
  "WorkMonthStart" decimal(6, 0) default 0 not null,
  "WorkMonthEnd" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "CdPfParms" add constraint "CdPfParms_PK" primary key("ConditionCode1", "ConditionCode2", "Condition");

comment on table "CdPfParms" is '業績特殊參數設定檔';
comment on column "CdPfParms"."ConditionCode1" is '條件記號1';
comment on column "CdPfParms"."ConditionCode2" is '條件記號2';
comment on column "CdPfParms"."Condition" is '標準條件';
comment on column "CdPfParms"."WorkMonthStart" is '有效工作月(起)';
comment on column "CdPfParms"."WorkMonthEnd" is '有效工作月(止)';
comment on column "CdPfParms"."CreateDate" is '建檔日期時間';
comment on column "CdPfParms"."CreateEmpNo" is '建檔人員';
comment on column "CdPfParms"."LastUpdate" is '最後更新日期時間';
comment on column "CdPfParms"."LastUpdateEmpNo" is '最後更新人員';
