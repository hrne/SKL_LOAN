drop table "JcicB090" purge;

create table "JcicB090" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "CustId" varchar2(10),
  "ClActNo" varchar2(50),
  "FacmNo" varchar2(50),
  "GlOverseas" varchar2(2),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB090" add constraint "JcicB090_PK" primary key("DataYM", "CustId", "ClActNo", "FacmNo");

comment on table "JcicB090" is '擔保品關聯檔資料檔';
comment on column "JcicB090"."DataYM" is '資料日期';
comment on column "JcicB090"."DataType" is '資料別';
comment on column "JcicB090"."BankItem" is '總行代號';
comment on column "JcicB090"."BranchItem" is '分行代號';
comment on column "JcicB090"."Filler4" is '空白';
comment on column "JcicB090"."CustId" is '授信戶IDN/BAN';
comment on column "JcicB090"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB090"."FacmNo" is '額度控制編碼';
comment on column "JcicB090"."GlOverseas" is '海外不動產擔保品資料註記';
comment on column "JcicB090"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB090"."CreateDate" is '建檔日期時間';
comment on column "JcicB090"."CreateEmpNo" is '建檔人員';
comment on column "JcicB090"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB090"."LastUpdateEmpNo" is '最後更新人員';
