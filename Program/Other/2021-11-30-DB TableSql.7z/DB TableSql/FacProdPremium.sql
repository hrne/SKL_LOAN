drop table "FacProdPremium" purge;

create table "FacProdPremium" (
  "ProdNo" varchar2(5),
  "PremiumLow" decimal(16, 2) default 0 not null,
  "PremiumHigh" decimal(16, 2) default 0 not null,
  "PremiumIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "FacProdPremium" add constraint "FacProdPremium_PK" primary key("ProdNo", "PremiumLow");

alter table "FacProdPremium" add constraint "FacProdPremium_FacProd_FK1" foreign key ("ProdNo") references "FacProd" ("ProdNo") on delete cascade;

comment on table "FacProdPremium" is '商品參數副檔年繳保費優惠減碼';
comment on column "FacProdPremium"."ProdNo" is '商品代碼';
comment on column "FacProdPremium"."PremiumLow" is '保戶壽險年繳化保費(含)以上';
comment on column "FacProdPremium"."PremiumHigh" is '保戶壽險年繳化保費(含)以下';
comment on column "FacProdPremium"."PremiumIncr" is '優惠減碼';
comment on column "FacProdPremium"."CreateDate" is '建檔日期時間';
comment on column "FacProdPremium"."CreateEmpNo" is '建檔人員';
comment on column "FacProdPremium"."LastUpdate" is '最後更新日期時間';
comment on column "FacProdPremium"."LastUpdateEmpNo" is '最後更新人員';
