drop table "JcicB096" purge;

create table "JcicB096" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "LandSeq" decimal(3, 0) default 0 not null,
  "OwnerId" varchar2(10),
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "LandNo1" decimal(4, 0) default 0 not null,
  "LandNo2" decimal(4, 0) default 0 not null,
  "LandCode" varchar2(1),
  "Area" decimal(10, 2) default 0 not null,
  "LandZoningCode" varchar2(1),
  "LandUsageType" varchar2(2),
  "PostedLandValue" decimal(10, 0) default 0 not null,
  "PostedLandValueYearMonth" decimal(5, 0) default 0 not null,
  "Filler18" varchar2(30),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicB096" add constraint "JcicB096_PK" primary key("DataYM", "ClActNo", "LandSeq", "OwnerId", "CityJCICCode", "AreaJCICCode", "IrCode", "LandNo1", "LandNo2");

comment on table "JcicB096" is '聯徵不動產擔保品明細-地號附加檔';
comment on column "JcicB096"."DataYM" is '資料日期';
comment on column "JcicB096"."DataType" is '資料別';
comment on column "JcicB096"."BankItem" is '總行代號';
comment on column "JcicB096"."BranchItem" is '分行代號';
comment on column "JcicB096"."Filler4" is '空白';
comment on column "JcicB096"."ClActNo" is '擔保品控制編碼';
comment on column "JcicB096"."LandSeq" is '土地序號';
comment on column "JcicB096"."OwnerId" is '擔保品所有權人或代表人IDN/BAN';
comment on column "JcicB096"."CityJCICCode" is '縣市別';
comment on column "JcicB096"."AreaJCICCode" is '鄉鎮市區別';
comment on column "JcicB096"."IrCode" is '段、小段號';
comment on column "JcicB096"."LandNo1" is '地號-前四碼';
comment on column "JcicB096"."LandNo2" is '地號-後四碼';
comment on column "JcicB096"."LandCode" is '地目';
comment on column "JcicB096"."Area" is '面積';
comment on column "JcicB096"."LandZoningCode" is '使用分區';
comment on column "JcicB096"."LandUsageType" is '使用地類別';
comment on column "JcicB096"."PostedLandValue" is '公告土地現值';
comment on column "JcicB096"."PostedLandValueYearMonth" is '公告土地現值年月';
comment on column "JcicB096"."Filler18" is '空白';
comment on column "JcicB096"."JcicDataYM" is '資料所屬年月';
comment on column "JcicB096"."CreateDate" is '建檔日期時間';
comment on column "JcicB096"."CreateEmpNo" is '建檔人員';
comment on column "JcicB096"."LastUpdate" is '最後更新日期時間';
comment on column "JcicB096"."LastUpdateEmpNo" is '最後更新人員';
