drop table "PostDeductMedia" purge;

create table "PostDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ProcNoteCode" varchar2(2),
  "PostDepCode" varchar2(1),
  "OutsrcCode" varchar2(3),
  "DistCode" varchar2(4),
  "TransDate" decimal(8, 0) default 0 not null,
  "RepayAcctNo" varchar2(14),
  "PostUserNo" varchar2(20),
  "OutsrcRemark" nvarchar2(20),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "PostDeductMedia" add constraint "PostDeductMedia_PK" primary key("MediaDate", "MediaSeq");

create index "PostDeductMedia_Index1" on "PostDeductMedia"("AcDate" asc, "BatchNo" asc, "DetailSeq" asc);

comment on table "PostDeductMedia" is '郵局扣款媒體檔';
comment on column "PostDeductMedia"."MediaDate" is '媒體日期';
comment on column "PostDeductMedia"."MediaSeq" is '媒體序號';
comment on column "PostDeductMedia"."CustNo" is '戶號';
comment on column "PostDeductMedia"."FacmNo" is '額度號碼';
comment on column "PostDeductMedia"."RepayType" is '還款類別';
comment on column "PostDeductMedia"."RepayAmt" is '還款金額';
comment on column "PostDeductMedia"."ProcNoteCode" is '處理說明';
comment on column "PostDeductMedia"."PostDepCode" is '帳戶別';
comment on column "PostDeductMedia"."OutsrcCode" is '委託機構代號';
comment on column "PostDeductMedia"."DistCode" is '區處代號';
comment on column "PostDeductMedia"."TransDate" is '轉帳日期';
comment on column "PostDeductMedia"."RepayAcctNo" is '儲金帳號';
comment on column "PostDeductMedia"."PostUserNo" is '用戶編號';
comment on column "PostDeductMedia"."OutsrcRemark" is '委託機構使用欄';
comment on column "PostDeductMedia"."AcDate" is '會計日期';
comment on column "PostDeductMedia"."BatchNo" is '批號';
comment on column "PostDeductMedia"."DetailSeq" is '明細序號';
comment on column "PostDeductMedia"."CreateDate" is '建檔日期時間';
comment on column "PostDeductMedia"."CreateEmpNo" is '建檔人員';
comment on column "PostDeductMedia"."LastUpdate" is '最後更新日期時間';
comment on column "PostDeductMedia"."LastUpdateEmpNo" is '最後更新人員';
