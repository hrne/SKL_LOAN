drop table "NegAppr02" purge;

create table "NegAppr02" (
  "BringUpDate" decimal(8, 0) default 0 not null,
  "FinCode" varchar2(8),
  "TxSeq" varchar2(10),
  "SendUnit" varchar2(8),
  "RecvUnit" varchar2(8),
  "EntryDate" decimal(8, 0) default 0 not null,
  "TransCode" varchar2(5),
  "TxAmt" decimal(16, 2) default 0 not null,
  "Consign" varchar2(8),
  "FinIns" varchar2(7),
  "RemitAcct" varchar2(16),
  "CustId" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(4),
  "AcDate" decimal(8, 0) default 0 not null,
  "TxKind" varchar2(1),
  "TxStatus" decimal(1, 0) default 0 not null,
  "NegTransAcDate" decimal(8, 0) default 0 not null,
  "NegTransTlrNo" varchar2(6),
  "NegTransTxtNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "NegAppr02" add constraint "NegAppr02_PK" primary key("BringUpDate", "FinCode", "TxSeq");

comment on table "NegAppr02" is '一般債權撥付資料檔';
comment on column "NegAppr02"."BringUpDate" is '提兌日';
comment on column "NegAppr02"."FinCode" is '債權機構代號';
comment on column "NegAppr02"."TxSeq" is '資料檔交易序號';
comment on column "NegAppr02"."SendUnit" is '發件單位';
comment on column "NegAppr02"."RecvUnit" is '收件單位';
comment on column "NegAppr02"."EntryDate" is '指定入/扣帳日';
comment on column "NegAppr02"."TransCode" is '轉帳類別';
comment on column "NegAppr02"."TxAmt" is '交易金額';
comment on column "NegAppr02"."Consign" is '委託單位';
comment on column "NegAppr02"."FinIns" is '金融機構';
comment on column "NegAppr02"."RemitAcct" is '轉帳帳號';
comment on column "NegAppr02"."CustId" is '帳戶ID';
comment on column "NegAppr02"."CustNo" is '戶號';
comment on column "NegAppr02"."StatusCode" is '還款狀況';
comment on column "NegAppr02"."AcDate" is '會計日期';
comment on column "NegAppr02"."TxKind" is '銷帳編號';
comment on column "NegAppr02"."TxStatus" is '交易狀態';
comment on column "NegAppr02"."NegTransAcDate" is '交易檔會計日';
comment on column "NegAppr02"."NegTransTlrNo" is '交易檔經辦';
comment on column "NegAppr02"."NegTransTxtNo" is '交易檔序號';
comment on column "NegAppr02"."CreateDate" is '建檔日期時間';
comment on column "NegAppr02"."CreateEmpNo" is '建檔人員';
comment on column "NegAppr02"."LastUpdate" is '最後更新日期時間';
comment on column "NegAppr02"."LastUpdateEmpNo" is '最後更新人員';
