drop table "JcicZ041" purge;

create table "JcicZ041" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ScDate" decimal(8, 0) default 0 not null,
  "NegoStartDate" decimal(8, 0) default 0 not null,
  "NonFinClaimAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ041" add constraint "JcicZ041_PK" primary key("SubmitKey", "CustId", "RcDate");

create index "JcicZ041_Index1" on "JcicZ041"("SubmitKey" asc);

create index "JcicZ041_Index2" on "JcicZ041"("CustId" asc);

create index "JcicZ041_Index3" on "JcicZ041"("RcDate" asc);

comment on table "JcicZ041" is '協商開始暨停催通知資料';
comment on column "JcicZ041"."TranKey" is '交易代碼';
comment on column "JcicZ041"."SubmitKey" is '報送單位代號';
comment on column "JcicZ041"."CustId" is '債務人IDN';
comment on column "JcicZ041"."RcDate" is '協商申請日';
comment on column "JcicZ041"."ScDate" is '停催日期';
comment on column "JcicZ041"."NegoStartDate" is '協商開始日';
comment on column "JcicZ041"."NonFinClaimAmt" is '非金融機構債權金額';
comment on column "JcicZ041"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ041"."Ukey" is '流水號';
comment on column "JcicZ041"."CreateDate" is '建檔日期時間';
comment on column "JcicZ041"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ041"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ041"."LastUpdateEmpNo" is '最後更新人員';
