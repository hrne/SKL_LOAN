drop table "BatxCheque" purge;

create table "BatxCheque" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "ChequeAcct" varchar2(9),
  "ChequeNo" varchar2(7),
  "ChequeAmt" decimal(14, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "AdjDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "ChequeDate" decimal(8, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "ProcessCode" varchar2(1),
  "OutsideCode" varchar2(1),
  "MediaCode" varchar2(1),
  "BankCode" varchar2(7),
  "MediaBatchNo" varchar2(2),
  "OfficeCode" varchar2(1),
  "ExchangeAreaCode" varchar2(2),
  "ChequeId" varchar2(10),
  "ChequeName" nvarchar2(100),
  "AmlRsp" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "BatxCheque" add constraint "BatxCheque_PK" primary key("AcDate", "BatchNo", "ChequeAcct", "ChequeNo");

comment on table "BatxCheque" is '支票兌現檔';
comment on column "BatxCheque"."AcDate" is '會計日期';
comment on column "BatxCheque"."BatchNo" is '批號';
comment on column "BatxCheque"."ChequeAcct" is '支票帳號';
comment on column "BatxCheque"."ChequeNo" is '支票號碼';
comment on column "BatxCheque"."ChequeAmt" is '支票金額';
comment on column "BatxCheque"."CustNo" is '戶號';
comment on column "BatxCheque"."StatusCode" is '票據狀況碼';
comment on column "BatxCheque"."AdjDate" is '異動日';
comment on column "BatxCheque"."TitaTlrNo" is '經辦';
comment on column "BatxCheque"."TitaTxtNo" is '交易序號';
comment on column "BatxCheque"."ChequeDate" is '到期日';
comment on column "BatxCheque"."EntryDate" is '收票日';
comment on column "BatxCheque"."ProcessCode" is '處理代碼';
comment on column "BatxCheque"."OutsideCode" is '本埠外埠';
comment on column "BatxCheque"."MediaCode" is '入媒體';
comment on column "BatxCheque"."BankCode" is '行庫代號';
comment on column "BatxCheque"."MediaBatchNo" is '媒體批號';
comment on column "BatxCheque"."OfficeCode" is '服務中心別';
comment on column "BatxCheque"."ExchangeAreaCode" is '交換區號';
comment on column "BatxCheque"."ChequeId" is '發票人ID';
comment on column "BatxCheque"."ChequeName" is '發票人姓名';
comment on column "BatxCheque"."AmlRsp" is 'AML回應碼';
comment on column "BatxCheque"."CreateDate" is '建檔日期時間';
comment on column "BatxCheque"."CreateEmpNo" is '建檔人員';
comment on column "BatxCheque"."LastUpdate" is '最後更新日期時間';
comment on column "BatxCheque"."LastUpdateEmpNo" is '最後更新人員';
