drop table "ForeclosureFinished" purge;

create table "ForeclosureFinished" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FinishedDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "ForeclosureFinished" add constraint "ForeclosureFinished_PK" primary key("CustNo", "FacmNo");

comment on table "ForeclosureFinished" is '法拍完成資料檔';
comment on column "ForeclosureFinished"."CustNo" is '借款人戶號';
comment on column "ForeclosureFinished"."FacmNo" is '額度編號';
comment on column "ForeclosureFinished"."FinishedDate" is '完成日期';
comment on column "ForeclosureFinished"."CreateDate" is '建檔日期時間';
comment on column "ForeclosureFinished"."CreateEmpNo" is '建檔人員';
comment on column "ForeclosureFinished"."LastUpdate" is '最後更新日期時間';
comment on column "ForeclosureFinished"."LastUpdateEmpNo" is '最後更新人員';
