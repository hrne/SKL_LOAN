drop table "JcicZ061Log" purge;

create table "JcicZ061Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "MaxMainNote" varchar2(1),
  "IsGuarantor" varchar2(1),
  "IsChangePayment" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);

alter table "JcicZ061Log" add constraint "JcicZ061Log_PK" primary key("Ukey", "TxSeq");

comment on table "JcicZ061Log" is '回報協商剩餘債權金額資料';
comment on column "JcicZ061Log"."Ukey" is '流水號';
comment on column "JcicZ061Log"."TxSeq" is '交易序號';
comment on column "JcicZ061Log"."TranKey" is '交易代碼';
comment on column "JcicZ061Log"."ExpBalanceAmt" is '信用貸款協商剩餘債權餘額';
comment on column "JcicZ061Log"."CashBalanceAmt" is '現金卡協商剩餘債權餘額';
comment on column "JcicZ061Log"."CreditBalanceAmt" is '信用卡協商剩餘債權餘額';
comment on column "JcicZ061Log"."MaxMainNote" is '最大債權金融機構報送註記';
comment on column "JcicZ061Log"."IsGuarantor" is '是否有保證人';
comment on column "JcicZ061Log"."IsChangePayment" is '是否同意債務人申請變更還款條件方案';
comment on column "JcicZ061Log"."OutJcicTxtDate" is '轉出JCIC文字檔日期';
comment on column "JcicZ061Log"."CreateDate" is '建檔日期時間';
comment on column "JcicZ061Log"."CreateEmpNo" is '建檔人員';
comment on column "JcicZ061Log"."LastUpdate" is '最後更新日期時間';
comment on column "JcicZ061Log"."LastUpdateEmpNo" is '最後更新人員';
