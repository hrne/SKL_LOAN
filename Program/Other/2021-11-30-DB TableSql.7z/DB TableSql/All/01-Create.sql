
create table "AcAcctCheck" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "TdBal" decimal(18, 2) default 0 not null,
  "TdCnt" decimal(8, 0) default 0 not null,
  "TdNewCnt" decimal(8, 0) default 0 not null,
  "TdClsCnt" decimal(8, 0) default 0 not null,
  "TdExtCnt" decimal(8, 0) default 0 not null,
  "TdExtAmt" decimal(18, 2) default 0 not null,
  "ReceivableBal" decimal(18, 2) default 0 not null,
  "AcctMasterBal" decimal(18, 2) default 0 not null,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);



create table "AcAcctCheckDetail" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcBal" decimal(16, 2) default 0 not null,
  "AcctMasterBal" decimal(16, 2) default 0 not null,
  "DiffBal" decimal(16, 2) default 0 not null,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);



create table "AcCheque" (
  "DataDate" decimal(8, 0) default 0 not null,
  "UnitCode" varchar2(6),
  "ChequeSeq" decimal(8, 0) default 0 not null,
  "BankNo" decimal(8, 0) default 0 not null,
  "ChequeAccount" decimal(8, 0) default 0 not null,
  "Amt" decimal(16, 2) default 0 not null,
  "ChequeDate" decimal(8, 0) default 0 not null,
  "KeyInDate" decimal(8, 0) default 0 not null,
  "ExpectedExchangeDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "AcClose" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "SecNo" varchar2(2),
  "ClsFg" decimal(1, 0) default 0 not null,
  "BatNo" decimal(2, 0) default 0 not null,
  "ClsNo" decimal(2, 0) default 0 not null,
  "SlipNo" decimal(6, 0) default 0 not null,
  "CoreSeqNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "AcDetail" (
  "RelDy" decimal(8, 0) default 0 not null,
  "RelTxseq" varchar2(18),
  "AcSeq" decimal(4, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcctCode" varchar2(3),
  "DbCr" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "EntAc" decimal(1, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RvNo" varchar2(30),
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "AcBookFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "SumNo" varchar2(3),
  "DscptCode" varchar2(4),
  "SlipNote" nvarchar2(80),
  "SlipBatNo" decimal(2, 0) default 0 not null,
  "SlipNo" decimal(6, 0) default 0 not null,
  "TitaKinbr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "TitaTxCd" varchar2(5),
  "TitaSecNo" varchar2(2),
  "TitaBatchNo" varchar2(6),
  "TitaBatchSeq" varchar2(6),
  "TitaSupNo" varchar2(6),
  "TitaRelCd" decimal(1, 0) default 0 not null,
  "JsonFields" varchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "AchAuthLog" (
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcct" varchar2(14),
  "CreateFlag" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "AuthStatus" varchar2(1),
  "AuthMeth" varchar2(1),
  "LimitAmt" decimal(8, 2) default 0 not null,
  "MediaCode" varchar2(1),
  "BatchNo" varchar2(6),
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "TitaTxCd" varchar2(5),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);








create table "AchAuthLogHistory" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcct" varchar2(14),
  "CreateFlag" varchar2(1),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "AuthStatus" varchar2(1),
  "AuthMeth" varchar2(1),
  "LimitAmt" decimal(8, 2) default 0 not null,
  "MediaCode" varchar2(1),
  "BatchNo" varchar2(6),
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);


create sequence "AchAuthLogHistory_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;


create table "AchDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ReturnCode" varchar2(2),
  "EntryDate" decimal(8, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "RepayAcctNo" varchar2(14),
  "AchRepayCode" varchar2(1),
  "AcctCode" varchar2(3),
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "DepCode" varchar2(2),
  "RelationCode" varchar2(2),
  "RelCustName" nvarchar2(100),
  "RelCustId" varchar2(10),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "AcLoanInt" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "TermNo" decimal(3, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "Amount" decimal(16, 2) default 0 not null,
  "IntRate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "AcctCode" varchar2(3),
  "PayIntDate" decimal(8, 0) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "Aging" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "BranchNo" varchar2(4),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "AcLoanRenew" (
  "CustNo" decimal(7, 0) default 0 not null,
  "NewFacmNo" decimal(3, 0) default 0 not null,
  "NewBormNo" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "OldBormNo" decimal(3, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "MainFlag" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);




create table "AcMain" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcDate" decimal(8, 0) default 0 not null,
  "YdBal" decimal(16, 2) default 0 not null,
  "TdBal" decimal(16, 2) default 0 not null,
  "DbCnt" decimal(8, 0) default 0 not null,
  "DbAmt" decimal(16, 2) default 0 not null,
  "CrCnt" decimal(8, 0) default 0 not null,
  "CrAmt" decimal(16, 2) default 0 not null,
  "CoreDbCnt" decimal(8, 0) default 0 not null,
  "CoreDbAmt" decimal(16, 2) default 0 not null,
  "CoreCrCnt" decimal(8, 0) default 0 not null,
  "CoreCrAmt" decimal(16, 2) default 0 not null,
  "AcctCode" varchar2(3),
  "MonthEndYm" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "AcReceivable" (
  "AcctCode" varchar2(3),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RvNo" varchar2(30),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "BranchNo" varchar2(4),
  "CurrencyCode" varchar2(3),
  "ClsFlag" decimal(1, 0) default 0 not null,
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "RvAmt" decimal(16, 2) default 0 not null,
  "RvBal" decimal(16, 2) default 0 not null,
  "AcBal" decimal(16, 2) default 0 not null,
  "SlipNote" nvarchar2(80),
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "OpenAcDate" decimal(8, 0) default 0 not null,
  "LastAcDate" decimal(8, 0) default 0 not null,
  "LastTxDate" decimal(8, 0) default 0 not null,
  "TitaTxCd" varchar2(5),
  "TitaKinBr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "JsonFields" varchar2(300),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);






create table "AmlCustList" (
  "CustNo" decimal(7, 0) default 0 not null,
  "Note1" varchar2(1),
  "Note2" varchar2(1),
  "Note3" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BankAuthAct" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthType" varchar2(2),
  "RepayBank" varchar2(3),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "Status" varchar2(1),
  "LimitAmt" decimal(14, 0) default 0 not null,
  "AcctSeq" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "BankDeductDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "PayIntDate" decimal(8, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "RepayBank" varchar2(3),
  "RepayAcctNo" varchar2(14),
  "RepayAcctSeq" varchar2(2),
  "UnpaidAmt" decimal(14, 0) default 0 not null,
  "TempAmt" decimal(14, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "PostCode" varchar2(1),
  "MediaCode" varchar2(1),
  "RelationCode" varchar2(2),
  "RelCustName" nvarchar2(100),
  "RelCustId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "AmlRsp" varchar2(1),
  "ReturnCode" varchar2(2),
  "JsonFields" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "BankRelationCompany" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "CompanyId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BankRelationFamily" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "RelationId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BankRelationSelf" (
  "CustName" nvarchar2(70),
  "CustId" varchar2(11),
  "LAW001" varchar2(1),
  "LAW002" varchar2(1),
  "LAW003" varchar2(1),
  "LAW005" varchar2(1),
  "LAW008" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BankRelationSuspected" (
  "RepCusName" nvarchar2(100),
  "CustId" varchar2(11),
  "CustName" nvarchar2(100),
  "SubCom" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BankRemit" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "BatchNo" varchar2(6),
  "DrawdownCode" decimal(2, 0) default 0 not null,
  "StatusCode" decimal(1, 0) default 0 not null,
  "RemitBank" varchar2(3),
  "RemitBranch" varchar2(4),
  "RemitAcctNo" varchar2(14),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustName" nvarchar2(100),
  "Remark" nvarchar2(100),
  "CurrencyCode" varchar2(3),
  "RemitAmt" decimal(16, 2) default 0 not null,
  "AmlRsp" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "ModifyContent" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "BankRmtf" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayType" varchar2(2),
  "RepayAmt" decimal(14, 0) default 0 not null,
  "DepAcctNo" varchar2(14),
  "EntryDate" decimal(8, 0) default 0 not null,
  "DscptCode" varchar2(4),
  "VirtualAcctNo" nvarchar2(14),
  "WithdrawAmt" decimal(14, 0) default 0 not null,
  "DepositAmt" decimal(14, 0) default 0 not null,
  "Balance" decimal(14, 0) default 0 not null,
  "RemintBank" varchar2(7),
  "TraderInfo" nvarchar2(20),
  "AmlRsp" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BatxCheque" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "ChequeAcct" varchar2(9),
  "ChequeNo" varchar2(7),
  "ChequeAmt" decimal(14, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "AdjDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "ChequeDate" decimal(8, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "ProcessCode" varchar2(1),
  "OutsideCode" varchar2(1),
  "MediaCode" varchar2(1),
  "BankCode" varchar2(7),
  "MediaBatchNo" varchar2(2),
  "OfficeCode" varchar2(1),
  "ExchangeAreaCode" varchar2(2),
  "ChequeId" varchar2(10),
  "ChequeName" nvarchar2(100),
  "AmlRsp" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BatxDetail" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "FileName" varchar2(50),
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RvNo" nvarchar2(30),
  "RepayType" decimal(2, 0) default 0 not null,
  "ReconCode" varchar2(3),
  "RepayAcCode" varchar2(18),
  "AcquiredAmt" decimal(14, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "AcctAmt" decimal(14, 0) default 0 not null,
  "DisacctAmt" decimal(14, 0) default 0 not null,
  "ProcStsCode" varchar2(1),
  "ProcCode" varchar2(5),
  "ProcNote" nvarchar2(600),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "BatxHead" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "BatxTotAmt" decimal(14, 0) default 0 not null,
  "BatxTotCnt" decimal(6, 0) default 0 not null,
  "UnfinishCnt" decimal(6, 0) default 0 not null,
  "BatxExeCode" varchar2(1),
  "BatxStsCode" varchar2(1),
  "TitaTlrNo" varchar2(6),
  "TitaTxCd" varchar2(5),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "BatxOthers" (
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAcCode" varchar2(18),
  "EntryDate" decimal(8, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "RepayId" varchar2(10),
  "RepayName" nvarchar2(100),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CustNm" nvarchar2(100),
  "RvNo" varchar2(12),
  "Note" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "BatxRateChange" (
  "AdjDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "TxKind" decimal(1, 0) default 0 not null,
  "DrawdownAmt" decimal(14, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IncrFlag" varchar2(1),
  "AdjCode" decimal(1, 0) default 0 not null,
  "RateKeyInCode" decimal(1, 0) default 0 not null,
  "ConfirmFlag" decimal(1, 0) default 0 not null,
  "TotBalance" decimal(14, 0) default 0 not null,
  "LoanBalance" decimal(14, 0) default 0 not null,
  "PresEffDate" decimal(8, 0) default 0 not null,
  "CurtEffDate" decimal(8, 0) default 0 not null,
  "PreNextAdjDate" decimal(8, 0) default 0 not null,
  "PreNextAdjFreq" decimal(2, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "CustCode" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "RateIncr" decimal(6, 4) default 0 not null,
  "ContractRate" decimal(6, 4) default 0 not null,
  "PresentRate" decimal(6, 4) default 0 not null,
  "ProposalRate" decimal(6, 4) default 0 not null,
  "AdjustedRate" decimal(6, 4) default 0 not null,
  "ContrBaseRate" decimal(6, 4) default 0 not null,
  "ContrRateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "BaseRateCode" varchar2(2),
  "RateCode" varchar2(1),
  "CurrBaseRate" decimal(6, 4) default 0 not null,
  "TxEffectDate" decimal(8, 0) default 0 not null,
  "TxRateAdjFreq" decimal(2, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "OvduTerm" decimal(3, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdAcBook" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "TargetAmt" decimal(16, 2) default 0 not null,
  "ActualAmt" decimal(16, 2) default 0 not null,
  "AssignSeq" decimal(2, 0) default 0 not null,
  "AcctSource" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdAcCode" (
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDtlCode" varchar2(2),
  "AcNoItem" nvarchar2(40),
  "AcctCode" varchar2(3),
  "AcctItem" nvarchar2(20),
  "ClassCode" decimal(1, 0) default 0 not null,
  "AcBookFlag" decimal(1, 0) default 0 not null,
  "DbCr" varchar2(1),
  "AcctFlag" decimal(1, 0) default 0 not null,
  "ReceivableFlag" decimal(1, 0) default 0 not null,
  "ClsChkFlag" decimal(1, 0) default 0 not null,
  "InuseFlag" decimal(1, 0) default 0 not null,
  "AcNoCodeOld" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CdAoDept" (
  "EmployeeNo" varchar2(6),
  "DeptCode" varchar2(6),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdAppraisalCompany" (
  "AppraisalCompany" varchar2(30),
  "Company" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdAppraiser" (
  "AppraiserCode" varchar2(6),
  "AppraiserItem" nvarchar2(100),
  "Company" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdArea" (
  "CityCode" varchar2(2),
  "AreaCode" varchar2(2),
  "AreaItem" nvarchar2(12),
  "CityShort" nvarchar2(6),
  "AreaShort" nvarchar2(8),
  "JcicCityCode" varchar2(1),
  "JcicAreaCode" varchar2(2),
  "CityType" varchar2(2),
  "Zip3" varchar2(3),
  "DepartCode" varchar2(6),
  "CityGroup" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "CdBank" (
  "BankCode" varchar2(3),
  "BranchCode" varchar2(4),
  "BankItem" nvarchar2(50),
  "BranchItem" nvarchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdBaseRate" (
  "CurrencyCode" varchar2(3),
  "BaseRateCode" varchar2(2),
  "EffectDate" decimal(8, 0) default 0 not null,
  "BaseRate" decimal(6, 4) default 0 not null,
  "Remark" nvarchar2(40),
  "EffectFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdBcm" (
  "UnitCode" varchar2(6),
  "UnitItem" nvarchar2(20),
  "DeptCode" varchar2(6),
  "DeptItem" nvarchar2(20),
  "DistCode" varchar2(6),
  "DistItem" nvarchar2(20),
  "UnitManager" varchar2(6),
  "DeptManager" varchar2(6),
  "DistManager" varchar2(6),
  "ShortDeptItem" varchar2(6),
  "ShortDistItem" varchar2(6),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "CdBonus" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(1, 0) default 0 not null,
  "Condition" varchar2(5),
  "AmtStartRange" decimal(16, 2) default 0 not null,
  "AmtEndRange" decimal(16, 2) default 0 not null,
  "Bonus" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CdBonusCo" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(1, 0) default 0 not null,
  "Condition" varchar2(5),
  "ConditionAmt" decimal(16, 2) default 0 not null,
  "Bonus" decimal(16, 2) default 0 not null,
  "ClassPassBonus" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdBranch" (
  "BranchNo" varchar2(4),
  "AcBranchNo" varchar2(4),
  "CRH" varchar2(2),
  "BranchStatusCode" varchar2(1),
  "BranchShort" nvarchar2(14),
  "BranchItem" nvarchar2(40),
  "BranchAddress1" nvarchar2(30),
  "BranchAddress2" nvarchar2(30),
  "Zip3" varchar2(3),
  "Zip2" varchar2(2),
  "Owner" nvarchar2(14),
  "BusinessID" varchar2(10),
  "RSOCode" varchar2(3),
  "MediaUnitCode" varchar2(4),
  "CIFKey" varchar2(6),
  "LastestCustNo" varchar2(7),
  "Group1" nvarchar2(10),
  "Group2" nvarchar2(10),
  "Group3" nvarchar2(10),
  "Group4" nvarchar2(10),
  "Group5" nvarchar2(10),
  "Group6" nvarchar2(10),
  "Group7" nvarchar2(10),
  "Group8" nvarchar2(10),
  "Group9" nvarchar2(10),
  "Group10" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdBranchGroup" (
  "BranchNo" varchar2(4),
  "GroupNo" varchar2(1),
  "GroupItem" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdBudget" (
  "Year" decimal(4, 0) default 0 not null,
  "Month" decimal(2, 0) default 0 not null,
  "Budget" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdBuildingCost" (
  "CityCode" varchar2(2),
  "FloorLowerLimit" decimal(3, 0) default 0 not null,
  "Cost" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdCashFlow" (
  "DataYearMonth" decimal(6, 0) default 0 not null,
  "InterestIncome" decimal(16, 2) default 0 not null,
  "PrincipalAmortizeAmt" decimal(16, 2) default 0 not null,
  "PrepaymentAmt" decimal(16, 2) default 0 not null,
  "DuePaymentAmt" decimal(16, 2) default 0 not null,
  "ExtendAmt" decimal(16, 2) default 0 not null,
  "LoanAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdCity" (
  "CityCode" varchar2(2),
  "CityItem" nvarchar2(10),
  "UnitCode" varchar2(6),
  "AccCollPsn" varchar2(6),
  "AccTelArea" varchar2(5),
  "AccTelNo" varchar2(10),
  "AccTelExt" varchar2(5),
  "LegalPsn" varchar2(6),
  "LegalArea" varchar2(5),
  "LegalNo" varchar2(10),
  "LegalExt" varchar2(5),
  "IntRateIncr" decimal(6, 4) default 0 not null,
  "IntRateCeiling" decimal(6, 4) default 0 not null,
  "IntRateFloor" decimal(6, 4) default 0 not null,
  "JcicCityCode" varchar2(0),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "CdCl" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClItem" nvarchar2(20),
  "ClTypeJCIC" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "CdCode" (
  "DefCode" varchar2(20),
  "DefType" decimal(2, 0) default 0 not null,
  "Code" varchar2(20),
  "Item" nvarchar2(50),
  "Enable" varchar2(1),
  "EffectFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdEmp" (
  "AgentCode" varchar2(12),
  "EmployeeNo" varchar2(10),
  "Fullname" nvarchar2(40),
  "CenterShortName" nvarchar2(10),
  "CenterCodeName" nvarchar2(20),
  "CenterCode1" varchar2(6),
  "CenterCode1Short" nvarchar2(10),
  "CenterCode1Name" nvarchar2(20),
  "CenterCode2" varchar2(6),
  "CenterCode2Short" nvarchar2(10),
  "CenterCode2Name" nvarchar2(20),
  "CenterCodeAcc1" varchar2(6),
  "CenterCodeAcc1Name" nvarchar2(20),
  "CenterCodeAcc2" varchar2(6),
  "CenterCodeAcc2Name" nvarchar2(20),
  "CommLineCode" varchar2(2),
  "CommLineType" varchar2(1),
  "OrigIntroducerId" varchar2(12),
  "IntroducerInd" varchar2(1),
  "RegisterLevel" varchar2(2),
  "RegisterDate" decimal(8, 0) default 0 not null,
  "CenterCode" varchar2(6),
  "AdministratId" varchar2(12),
  "InputDate" decimal(8, 0) default 0 not null,
  "InputUser" varchar2(8),
  "AgStatusCode" varchar2(1),
  "AgStatusDate" decimal(8, 0) default 0 not null,
  "TranDate" decimal(8, 0) default 0 not null,
  "TranUser" varchar2(8),
  "ReRegisterDate" decimal(8, 0) default 0 not null,
  "DirectorId" varchar2(12),
  "DirectorIdF" varchar2(12),
  "IntroducerId" varchar2(12),
  "IntroducerIdF" varchar2(12),
  "AgLevel" varchar2(2),
  "LastLevel" varchar2(2),
  "LevelDate" decimal(8, 0) default 0 not null,
  "TopLevel" varchar2(2),
  "OccpInd" varchar2(1),
  "QuotaAmt" decimal(10, 0) default 0 not null,
  "ApplType" varchar2(1),
  "TaxRate" decimal(5, 3) default 0 not null,
  "SocialInsuClass" decimal(5, 0) default 0 not null,
  "PromotLevelYM" varchar2(7),
  "DirectorYM" varchar2(7),
  "RecordDate" decimal(8, 0) default 0 not null,
  "ExRecordDate" decimal(8, 0) default 0 not null,
  "RxTrDate" decimal(8, 0) default 0 not null,
  "ExTrIdent" varchar2(16),
  "ExTrIdent2" varchar2(9),
  "ExTrIdent3" varchar2(12),
  "ExTrDate" decimal(8, 0) default 0 not null,
  "RegisterBefore" decimal(5, 0) default 0 not null,
  "DirectorAfter" decimal(5, 0) default 0 not null,
  "MedicalCode" varchar2(2),
  "ExChgDate" decimal(8, 0) default 0 not null,
  "ExDelDate" decimal(8, 0) default 0 not null,
  "ApplCode" varchar2(10),
  "FirstRegDate" decimal(8, 0) default 0 not null,
  "AginSource" varchar2(3),
  "AguiCenter" varchar2(9),
  "AgentId" varchar2(10),
  "TopId" varchar2(12),
  "AgDegree" varchar2(2),
  "CollectInd" varchar2(1),
  "AgType1" varchar2(1),
  "ContractInd" varchar2(1),
  "ContractIndYM" varchar2(7),
  "AgType2" varchar2(1),
  "AgType3" varchar2(1),
  "AgType4" varchar2(1),
  "AginInd1" varchar2(1),
  "AgPoInd" varchar2(1),
  "AgDocInd" varchar2(1),
  "NewHireType" varchar2(1),
  "AgCurInd" varchar2(1),
  "AgSendType" varchar2(3),
  "AgSendNo" nvarchar2(100),
  "RegisterDate2" decimal(8, 0) default 0 not null,
  "AgReturnDate" decimal(8, 0) default 0 not null,
  "AgTransferDateF" decimal(8, 0) default 0 not null,
  "AgTransferDate" decimal(8, 0) default 0 not null,
  "PromotYM" varchar2(7),
  "PromotYMF" varchar2(7),
  "AgPostChgDate" decimal(8, 0) default 0 not null,
  "FamiliesTax" decimal(5, 0) default 0 not null,
  "AgentCodeI" varchar2(12),
  "AgLevelSys" varchar2(2),
  "AgPostIn" varchar2(6),
  "CenterCodeAcc" varchar2(6),
  "EvalueInd" varchar2(1),
  "EvalueInd1" varchar2(1),
  "BatchNo" decimal(10, 0) default 0 not null,
  "EvalueYM" varchar2(7),
  "AgTransferCode" varchar2(2),
  "Birth" decimal(8, 0) default 0 not null,
  "Education" varchar2(1),
  "LrInd" varchar2(1),
  "ProceccDate" decimal(8, 0) default 0 not null,
  "QuitDate" decimal(8, 0) default 0 not null,
  "AgPost" varchar2(2),
  "LevelNameChs" nvarchar2(10),
  "LrSystemType" varchar2(1),
  "SeniorityYY" decimal(5, 0) default 0 not null,
  "SeniorityMM" decimal(5, 0) default 0 not null,
  "SeniorityDD" decimal(5, 0) default 0 not null,
  "AglaProcessInd" varchar2(2),
  "StatusCode" varchar2(1),
  "AglaCancelReason" varchar2(1),
  "ISAnnApplDate" decimal(8, 0) default 0 not null,
  "RecordDateC" decimal(8, 0) default 0 not null,
  "StopReason" nvarchar2(20),
  "StopStrDate" decimal(8, 0) default 0 not null,
  "StopEndDate" decimal(8, 0) default 0 not null,
  "IFPDate" decimal(8, 0) default 0 not null,
  "EffectStrDate" decimal(8, 0) default 0 not null,
  "EffectEndDate" decimal(8, 0) default 0 not null,
  "AnnApplDate" decimal(8, 0) default 0 not null,
  "CenterCodeAccName" nvarchar2(20),
  "ReHireCode" varchar2(1),
  "RSVDAdminCode" varchar2(1),
  "Account" varchar2(16),
  "PRPDate" varchar2(15),
  "Zip" varchar2(5),
  "Address" nvarchar2(80),
  "PhoneH" varchar2(30),
  "PhoneC" varchar2(30),
  "SalesQualInd" varchar2(1),
  "AgsqStartDate" decimal(8, 0) default 0 not null,
  "PinYinNameIndi" nvarchar2(50),
  "Email" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CdGseq" (
  "GseqDate" decimal(8, 0) default 0 not null,
  "GseqCode" decimal(1, 0) default 0 not null,
  "GseqType" varchar2(2),
  "GseqKind" varchar2(4),
  "Offset" decimal(8, 0) default 0 not null,
  "SeqNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdGuarantor" (
  "GuaRelCode" varchar2(2),
  "GuaRelItem" nvarchar2(30),
  "GuaRelJcic" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CdIndustry" (
  "IndustryCode" varchar2(6),
  "IndustryItem" nvarchar2(50),
  "MainType" varchar2(1),
  "IndustryRating" varchar2(1),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CdInsurer" (
  "InsurerType" varchar2(1),
  "InsurerCode" varchar2(2),
  "InsurerId" varchar2(8),
  "InsurerItem" nvarchar2(40),
  "InsurerShort" nvarchar2(20),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdLandOffice" (
  "LandOfficeCode" varchar2(2),
  "RecWord" varchar2(3),
  "RecWordItem" nvarchar2(30),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdLandSection" (
  "CityCode" varchar2(2),
  "AreaCode" varchar2(2),
  "IrCode" varchar2(5),
  "IrItem" nvarchar2(30),
  "LandOfficeCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "CdLoanNotYet" (
  "NotYetCode" varchar2(2),
  "NotYetItem" nvarchar2(40),
  "YetDays" decimal(3, 0) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdOverdue" (
  "OverdueSign" varchar2(1),
  "OverdueCode" varchar2(4),
  "OverdueItem" nvarchar2(50),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "CdPerformance" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "PieceCode" varchar2(1),
  "UnitCnt" decimal(4, 2) default 0 not null,
  "UnitAmtCond" decimal(16, 2) default 0 not null,
  "UnitPercent" decimal(9, 6) default 0 not null,
  "IntrodPerccent" decimal(9, 6) default 0 not null,
  "IntrodAmtCond" decimal(16, 2) default 0 not null,
  "IntrodPfEqBase" decimal(16, 2) default 0 not null,
  "IntrodPfEqAmt" decimal(16, 2) default 0 not null,
  "IntrodRewardBase" decimal(16, 2) default 0 not null,
  "IntrodReward" decimal(16, 2) default 0 not null,
  "BsOffrCnt" decimal(4, 2) default 0 not null,
  "BsOffrCntLimit" decimal(4, 2) default 0 not null,
  "BsOffrAmtCond" decimal(16, 2) default 0 not null,
  "BsOffrPerccent" decimal(9, 6) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdPfParms" (
  "ConditionCode1" varchar2(1),
  "ConditionCode2" varchar2(1),
  "Condition" varchar2(6),
  "WorkMonthStart" decimal(6, 0) default 0 not null,
  "WorkMonthEnd" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdReport" (
  "FormNo" varchar2(10),
  "FormName" nvarchar2(40),
  "Cycle" decimal(2, 0) default 0 not null,
  "SendCode" decimal(1, 0) default 0 not null,
  "Letter" decimal(1, 0) default 0 not null,
  "Message" decimal(1, 0) default 0 not null,
  "Email" decimal(1, 0) default 0 not null,
  "UsageDesc" nvarchar2(40),
  "SignCode" decimal(1, 0) default 0 not null,
  "WatermarkFlag" decimal(1, 0) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "CdStock" (
  "StockCode" varchar2(10),
  "StockItem" nvarchar2(20),
  "StockCompanyName" nvarchar2(50),
  "Currency" varchar2(3),
  "YdClosePrice" decimal(16, 2) default 0 not null,
  "MonthlyAvg" decimal(16, 2) default 0 not null,
  "ThreeMonthAvg" decimal(16, 2) default 0 not null,
  "StockType" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdSupv" (
  "SupvReasonCode" varchar2(4),
  "SupvReasonItem" nvarchar2(40),
  "SupvReasonLevel" varchar2(1),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdSyndFee" (
  "SyndFeeCode" varchar2(2),
  "SyndFeeItem" nvarchar2(30),
  "AcctCode" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CdVarValue" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "AvailableFunds" decimal(16, 2) default 0 not null,
  "LoanTotalLmt" decimal(16, 2) default 0 not null,
  "NoGurTotalLmt" decimal(16, 2) default 0 not null,
  "Totalequity" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CdWorkMonth" (
  "Year" decimal(4, 0) default 0 not null,
  "Month" decimal(2, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "BonusDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "ClBuilding" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "Road" nvarchar2(40),
  "Section" varchar2(5),
  "Alley" varchar2(5),
  "Lane" varchar2(5),
  "Num" varchar2(5),
  "NumDash" varchar2(5),
  "Floor" varchar2(5),
  "FloorDash" varchar2(5),
  "BdNo1" varchar2(5),
  "BdNo2" varchar2(3),
  "BdLocation" nvarchar2(150),
  "BdMainUseCode" varchar2(2),
  "BdUsageCode" varchar2(1),
  "BdMtrlCode" varchar2(2),
  "BdTypeCode" varchar2(2),
  "TotalFloor" decimal(3, 0) default 0 not null,
  "FloorNo" varchar2(7),
  "FloorArea" decimal(16, 2) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "RoofStructureCode" varchar2(2),
  "BdDate" decimal(8, 0) default 0 not null,
  "BdSubUsageCode" varchar2(2),
  "BdSubArea" decimal(16, 2) default 0 not null,
  "SellerId" varchar2(10),
  "SellerName" nvarchar2(100),
  "ContractPrice" decimal(16, 2) default 0 not null,
  "ContractDate" decimal(8, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "ParkingArea" decimal(16, 2) default 0 not null,
  "ParkingProperty" varchar2(1),
  "HouseTaxNo" varchar2(12),
  "HouseBuyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "ClBuildingOwner" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "OwnerRelCode" varchar2(2),
  "OwnerPart" decimal(10, 0) default 0 not null,
  "OwnerTotal" decimal(10, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "ClBuildingPublic" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PublicSeq" decimal(5, 0) default 0 not null,
  "PublicBdNo1" decimal(5, 0) default 0 not null,
  "PublicBdNo2" decimal(3, 0) default 0 not null,
  "Area" decimal(16, 2) default 0 not null,
  "OwnerId" varchar2(10),
  "OwnerName" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "ClBuildingReason" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ReasonSeq" decimal(3, 0) default 0 not null,
  "Reason" decimal(1, 0) default 0 not null,
  "OtherReason" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create unique index "ClBuildingReason_Index1" on "ClBuildingReason"("ClCode1" asc, "ClCode2" asc, "ClNo" asc, "ReasonSeq" asc);


create table "ClEva" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "EvaNo" decimal(2, 0) default 0 not null,
  "EvaDate" decimal(8, 0) default 0 not null,
  "EvaAmt" decimal(16, 2) default 0 not null,
  "EvaNetWorth" decimal(16, 2) default 0 not null,
  "RentEvaValue" decimal(16, 2) default 0 not null,
  "EvaCompanyId" varchar2(2),
  "EvaCompanyName" nvarchar2(100),
  "EvaEmpno" varchar2(6),
  "EvaReason" decimal(2, 0) default 0 not null,
  "OtherReason" nvarchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "ClFac" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ApproveNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "MainFlag" varchar2(1),
  "FacShareFlag" decimal(1, 0) default 0 not null,
  "ShareAmt" decimal(16, 2) default 0 not null,
  "OriSettingAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);










create table "ClImm" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "EvaNetWorth" decimal(16, 2) default 0 not null,
  "LVITax" decimal(16, 2) default 0 not null,
  "RentEvaValue" decimal(16, 2) default 0 not null,
  "RentPrice" decimal(16, 2) default 0 not null,
  "OwnershipCode" varchar2(1),
  "MtgCode" varchar2(1),
  "MtgCheck" varchar2(1),
  "MtgLoan" varchar2(1),
  "MtgPledge" varchar2(1),
  "Agreement" varchar2(1),
  "EvaCompanyCode" varchar2(2),
  "LimitCancelDate" decimal(8, 0) default 0 not null,
  "ClCode" varchar2(1),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "OtherOwnerTotal" decimal(16, 2) default 0 not null,
  "CompensationCopy" varchar2(1),
  "BdRmk" nvarchar2(60),
  "MtgReasonCode" varchar2(1),
  "ReceivedDate" decimal(8, 0) default 0 not null,
  "ReceivedNo" nvarchar2(20),
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelNo" nvarchar2(20),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "ClaimDate" decimal(8, 0) default 0 not null,
  "SettingSeq" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "ClImmRankDetail" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "SettingSeq" varchar2(1),
  "FirstCreditor" nvarchar2(40),
  "FirstAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "ClLand" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "LandSeq" decimal(3, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "LandNo1" varchar2(4),
  "LandNo2" varchar2(4),
  "LandLocation" nvarchar2(150),
  "LandCode" varchar2(2),
  "Area" decimal(9, 2) default 0 not null,
  "LandZoningCode" varchar2(2),
  "LandUsageType" varchar2(2),
  "LandUsageCode" varchar2(2),
  "PostedLandValue" decimal(16, 2) default 0 not null,
  "PostedLandValueYearMonth" decimal(6, 0) default 0 not null,
  "TransferedYear" decimal(4, 0) default 0 not null,
  "LastTransferedAmt" decimal(16, 2) default 0 not null,
  "LVITax" decimal(16, 2) default 0 not null,
  "LVITaxYearMonth" decimal(6, 0) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "LandRentStartDate" decimal(8, 0) default 0 not null,
  "LandRentEndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "ClLandOwner" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "LandSeq" decimal(3, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "OwnerRelCode" varchar2(2),
  "OwnerPart" decimal(10, 0) default 0 not null,
  "OwnerTotal" decimal(10, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "ClLandReason" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ReasonSeq" decimal(3, 0) default 0 not null,
  "Reason" decimal(1, 0) default 0 not null,
  "OtherReason" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create unique index "ClLandReason_Index1" on "ClLandReason"("ClCode1" asc, "ClCode2" asc, "ClNo" asc, "ReasonSeq" asc);


create table "ClMain" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ClTypeCode" varchar2(3),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "ClStatus" varchar2(1),
  "EvaDate" decimal(8, 0) default 0 not null,
  "EvaAmt" decimal(16, 2) default 0 not null,
  "ShareTotal" decimal(16, 2) default 0 not null,
  "Synd" varchar2(1),
  "SyndCode" varchar2(1),
  "DispPrice" decimal(16, 2) default 0 not null,
  "DispDate" decimal(8, 0) default 0 not null,
  "NewNote" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "ClMovables" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "ServiceLife" decimal(2, 0) default 0 not null,
  "ProductSpec" varchar2(20),
  "ProductType" varchar2(10),
  "ProductBrand" varchar2(20),
  "ProductCC" varchar2(10),
  "ProductColor" varchar2(10),
  "EngineSN" varchar2(50),
  "LicenseNo" varchar2(10),
  "LicenseTypeCode" varchar2(1),
  "LicenseUsageCode" varchar2(1),
  "LiceneIssueDate" decimal(8, 0) default 0 not null,
  "MfgYearMonth" decimal(6, 0) default 0 not null,
  "VehicleTypeCode" varchar2(2),
  "VehicleStyleCode" varchar2(2),
  "VehicleOfficeCode" varchar2(3),
  "Currency" varchar2(3),
  "ExchangeRate" decimal(8, 5) default 0 not null,
  "Insurance" varchar2(1),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "ScrapValue" decimal(16, 2) default 0 not null,
  "MtgCode" varchar2(1),
  "MtgCheck" varchar2(1),
  "MtgLoan" varchar2(1),
  "MtgPledge" varchar2(1),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "ReceiptNo" nvarchar2(20),
  "MtgNo" nvarchar2(20),
  "ReceivedDate" decimal(8, 0) default 0 not null,
  "MortgageIssueStartDate" decimal(8, 0) default 0 not null,
  "MortgageIssueEndDate" decimal(8, 0) default 0 not null,
  "Remark" nvarchar2(120),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "ClNoMap" (
  "GdrId1" decimal(1, 0) default 0 not null,
  "GdrId2" decimal(2, 0) default 0 not null,
  "GdrNum" decimal(7, 0) default 0 not null,
  "LgtSeq" decimal(2, 0) default 0 not null,
  "MainGdrId1" decimal(1, 0) default 0 not null,
  "MainGdrId2" decimal(2, 0) default 0 not null,
  "MainGdrNum" decimal(7, 0) default 0 not null,
  "MainLgtSeq" decimal(2, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "TfStatus" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "ClOther" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PledgeStartDate" decimal(8, 0) default 0 not null,
  "PledgeEndDate" decimal(8, 0) default 0 not null,
  "PledgeBankCode" varchar2(2),
  "PledgeNO" varchar2(30),
  "OwnerCustUKey" varchar2(32),
  "IssuingId" varchar2(10),
  "IssuingCounty" varchar2(3),
  "DocNo" nvarchar2(30),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "SecuritiesType" varchar2(2),
  "Listed" varchar2(2),
  "OfferingDate" decimal(8, 0) default 0 not null,
  "ExpirationDate" decimal(8, 0) default 0 not null,
  "TargetIssuer" varchar2(2),
  "SubTargetIssuer" varchar2(2),
  "CreditDate" decimal(8, 0) default 0 not null,
  "Credit" varchar2(2),
  "ExternalCredit" varchar2(3),
  "Index" varchar2(2),
  "TradingMethod" varchar2(1),
  "Compensation" varchar2(3),
  "Investment" nvarchar2(300),
  "PublicValue" nvarchar2(300),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "ClOtherRights" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "Seq" varchar2(8),
  "City" varchar2(2),
  "OtherCity" varchar2(40),
  "LandAdm" varchar2(2),
  "OtherLandAdm" varchar2(40),
  "RecYear" decimal(3, 0) default 0 not null,
  "RecWord" varchar2(3),
  "OtherRecWord" varchar2(40),
  "RecNumber" varchar2(6),
  "RightsNote" varchar2(2),
  "SecuredTotal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "ClOwnerRelation" (
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "OwnerRelCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "ClParking" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ParkingSeqNo" decimal(5, 0) default 0 not null,
  "ParkingNo" nvarchar2(20),
  "ParkingQty" decimal(5, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "OwnerPart" decimal(10, 0) default 0 not null,
  "OwnerTotal" decimal(10, 0) default 0 not null,
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "IrCode" varchar2(5),
  "BdNo1" varchar2(5),
  "BdNo2" varchar2(3),
  "LandNo1" varchar2(4),
  "LandNo2" varchar2(4),
  "ParkingArea" decimal(16, 2) default 0 not null,
  "Amount" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "ClParkingType" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ParkingTypeCode" varchar2(1),
  "ParkingQty" decimal(5, 0) default 0 not null,
  "ParkingArea" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "ClStock" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "StockCode" varchar2(10),
  "ListingType" varchar2(2),
  "StockType" varchar2(1),
  "CompanyId" varchar2(10),
  "DataYear" decimal(4, 0) default 0 not null,
  "IssuedShares" decimal(16, 2) default 0 not null,
  "NetWorth" decimal(16, 2) default 0 not null,
  "EvaStandard" varchar2(2),
  "ParValue" decimal(16, 2) default 0 not null,
  "MonthlyAvg" decimal(16, 2) default 0 not null,
  "YdClosingPrice" decimal(16, 2) default 0 not null,
  "ThreeMonthAvg" decimal(16, 2) default 0 not null,
  "EvaUnitPrice" decimal(16, 2) default 0 not null,
  "OwnerCustUKey" varchar2(32),
  "InsiderJobTitle" varchar2(2),
  "InsiderPosition" varchar2(2),
  "LegalPersonId" varchar2(10),
  "LoanToValue" decimal(5, 2) default 0 not null,
  "ClMtr" decimal(5, 2) default 0 not null,
  "NoticeMtr" decimal(5, 2) default 0 not null,
  "ImplementMtr" decimal(5, 2) default 0 not null,
  "AcMtr" decimal(5, 2) default 0 not null,
  "PledgeNo" nvarchar2(14),
  "ComputeMTR" varchar2(1),
  "SettingStat" varchar2(1),
  "ClStat" varchar2(1),
  "SettingDate" decimal(8, 0) default 0 not null,
  "SettingBalance" decimal(16, 2) default 0 not null,
  "MtgDate" decimal(8, 0) default 0 not null,
  "CustodyNo" nvarchar2(5),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "CollLaw" (
  "CaseCode" varchar2(1),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "RecordDate" decimal(8, 0) default 0 not null,
  "LegalProg" varchar2(3),
  "Amount" decimal(16, 2) default 0 not null,
  "Remark" varchar2(1),
  "Memo" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CollLetter" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MailTypeCode" varchar2(1),
  "MailDate" decimal(8, 0) default 0 not null,
  "MailObj" varchar2(1),
  "CustName" nvarchar2(100),
  "DelvrYet" varchar2(1),
  "DelvrCode" varchar2(1),
  "AddressCode" decimal(1, 0) default 0 not null,
  "Address" nvarchar2(60),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CollList" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CaseCode" varchar2(1),
  "TxDate" decimal(8, 0) default 0 not null,
  "TxCode" varchar2(1),
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "OvduTerm" decimal(3, 0) default 0 not null,
  "OvduDays" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "AccCollPsn" varchar2(6),
  "LegalPsn" varchar2(6),
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "IsSpecify" varchar2(1),
  "CityCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CollListTmp" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "CaseCode" varchar2(1),
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "RenewCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CollMeet" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "MeetDate" decimal(8, 0) default 0 not null,
  "MeetTime" varchar2(4),
  "ContactCode" varchar2(1),
  "MeetPsnCode" varchar2(1),
  "CollPsnCode" varchar2(1),
  "CollPsnName" nvarchar2(8),
  "MeetPlaceCode" decimal(1, 0) default 0 not null,
  "MeetPlace" nvarchar2(60),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CollRemind" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "CondCode" varchar2(1),
  "RemindDate" decimal(8, 0) default 0 not null,
  "EditDate" decimal(8, 0) default 0 not null,
  "EditTime" varchar2(4),
  "RemindCode" varchar2(2),
  "Remark" varchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CollTel" (
  "CaseCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "TelDate" decimal(8, 0) default 0 not null,
  "TelTime" varchar2(4),
  "ContactCode" varchar2(1),
  "RecvrCode" varchar2(1),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "ResultCode" varchar2(1),
  "Remark" nvarchar2(500),
  "CallDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CoreAcMain" (
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcDate" decimal(8, 0) default 0 not null,
  "YdBal" decimal(16, 2) default 0 not null,
  "TdBal" decimal(16, 2) default 0 not null,
  "DbAmt" decimal(16, 2) default 0 not null,
  "CrAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CreditRating" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreditRatingCode" varchar2(1),
  "OriModel" varchar2(1),
  "OriRatingDate" decimal(8, 0) default 0 not null,
  "OriRating" varchar2(1),
  "Model" varchar2(1),
  "RatingDate" decimal(8, 0) default 0 not null,
  "Rating" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CustCross" (
  "CustUKey" varchar2(32),
  "SubCompanyCode" varchar2(2),
  "CrossUse" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CustDataCtrl" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ApplMark" decimal(1, 0) default 0 not null,
  "Reason" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "CustFin" (
  "CustUKey" varchar2(32),
  "DataYear" decimal(4, 0) default 0 not null,
  "AssetTotal" decimal(16, 2) default 0 not null,
  "Cash" decimal(16, 2) default 0 not null,
  "ShortInv" decimal(16, 2) default 0 not null,
  "AR" decimal(16, 2) default 0 not null,
  "Inventory" decimal(16, 2) default 0 not null,
  "LongInv" decimal(16, 2) default 0 not null,
  "FixedAsset" decimal(16, 2) default 0 not null,
  "OtherAsset" decimal(16, 2) default 0 not null,
  "LiabTotal" decimal(16, 2) default 0 not null,
  "BankLoan" decimal(16, 2) default 0 not null,
  "OtherCurrLiab" decimal(16, 2) default 0 not null,
  "LongLiab" decimal(16, 2) default 0 not null,
  "OtherLiab" decimal(16, 2) default 0 not null,
  "NetWorthTotal" decimal(16, 2) default 0 not null,
  "Capital" decimal(16, 2) default 0 not null,
  "RetainEarning" decimal(16, 2) default 0 not null,
  "OpIncome" decimal(16, 2) default 0 not null,
  "OpCost" decimal(16, 2) default 0 not null,
  "OpProfit" decimal(16, 2) default 0 not null,
  "OpExpense" decimal(16, 2) default 0 not null,
  "OpRevenue" decimal(16, 2) default 0 not null,
  "NopIncome" decimal(16, 2) default 0 not null,
  "FinExpense" decimal(16, 2) default 0 not null,
  "NopExpense" decimal(16, 2) default 0 not null,
  "NetIncome" decimal(16, 2) default 0 not null,
  "Accountant" nvarchar2(14),
  "AccountDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "CustMain" (
  "CustUKey" varchar2(32),
  "CustId" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CustName" nvarchar2(100),
  "Birthday" decimal(8, 0) default 0 not null,
  "Sex" varchar2(1),
  "CustTypeCode" varchar2(2),
  "IndustryCode" varchar2(6),
  "NationalityCode" varchar2(2),
  "BussNationalityCode" varchar2(2),
  "SpouseId" varchar2(10),
  "SpouseName" nvarchar2(100),
  "RegZip3" varchar2(3),
  "RegZip2" varchar2(3),
  "RegCityCode" varchar2(2),
  "RegAreaCode" varchar2(3),
  "RegRoad" nvarchar2(40),
  "RegSection" varchar2(5),
  "RegAlley" varchar2(5),
  "RegLane" varchar2(5),
  "RegNum" varchar2(5),
  "RegNumDash" varchar2(5),
  "RegFloor" varchar2(5),
  "RegFloorDash" varchar2(5),
  "CurrZip3" varchar2(3),
  "CurrZip2" varchar2(3),
  "CurrCityCode" varchar2(2),
  "CurrAreaCode" varchar2(3),
  "CurrRoad" nvarchar2(40),
  "CurrSection" varchar2(5),
  "CurrAlley" varchar2(5),
  "CurrLane" varchar2(5),
  "CurrNum" varchar2(5),
  "CurrNumDash" varchar2(5),
  "CurrFloor" varchar2(5),
  "CurrFloorDash" varchar2(5),
  "CuscCd" varchar2(1),
  "EntCode" varchar2(1),
  "EmpNo" varchar2(6),
  "EName" varchar2(50),
  "EduCode" varchar2(1),
  "OwnedHome" varchar2(1),
  "CurrCompName" nvarchar2(60),
  "CurrCompId" varchar2(8),
  "CurrCompTel" varchar2(16),
  "JobTitle" nvarchar2(20),
  "JobTenure" varchar2(2),
  "IncomeOfYearly" decimal(9, 0) default 0 not null,
  "IncomeDataDate" varchar2(6),
  "PassportNo" varchar2(20),
  "AMLJobCode" varchar2(3),
  "AMLGroup" varchar2(3),
  "IndigenousName" nvarchar2(100),
  "LastFacmNo" decimal(3, 0) default 0 not null,
  "LastSyndNo" decimal(3, 0) default 0 not null,
  "AllowInquire" varchar2(1),
  "Email" varchar2(50),
  "ActFg" decimal(1, 0) default 0 not null,
  "Introducer" varchar2(6),
  "IsSuspected" varchar2(1),
  "IsSuspectedCheck" varchar2(1),
  "IsSuspectedCheckType" varchar2(1),
  "DataStatus" decimal(1, 0) default 0 not null,
  "TypeCode" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create unique index "CustMain_Index1" on "CustMain"("CustId" asc);




create table "CustNotice" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FormNo" varchar2(10),
  "PaperNotice" varchar2(1),
  "MsgNotice" varchar2(1),
  "EmailNotice" varchar2(1),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "CustomerAmlRating" (
  "CustId" varchar2(10),
  "AmlRating" varchar2(1),
  "IsRelated" varchar2(1),
  "IsLnrelNear" varchar2(1),
  "IsLimit" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "CustRmk" (
  "CustNo" decimal(7, 0) default 0 not null,
  "RmkNo" decimal(3, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "RmkCode" varchar2(3),
  "RmkDesc" nvarchar2(120),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "CustTelNo" (
  "TelNoUKey" varchar2(32),
  "CustUKey" varchar2(32),
  "TelTypeCode" varchar2(2),
  "TelArea" varchar2(5),
  "TelNo" varchar2(10),
  "TelExt" varchar2(5),
  "TelChgRsnCode" varchar2(2),
  "RelationCode" varchar2(2),
  "LiaisonName" nvarchar2(100),
  "Rmk" nvarchar2(40),
  "StopReason" nvarchar2(40),
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "DailyLoanBal" (
  "DataDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LatestFlag" decimal(1, 0) default 0 not null,
  "MonthEndYm" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ProdNo" varchar2(5),
  "LoanBalance" decimal(16, 2) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtAcc" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "DataInputMapping" (
  "InputTableName" varchar2(30),
  "TargerTableName" varchar2(30),
  "EnableFlag" varchar2(1),
  "SourceSystem" nvarchar2(50),
  "Remark" nvarchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "DataInputRecord" (
  "DataDate" decimal(8, 0) default 0 not null,
  "TableName" varchar2(30),
  "TargetTable" varchar2(30),
  "Seq" decimal(8, 0) default 0 not null,
  "InputCounts" decimal(14, 0) default 0 not null,
  "MovedFlag" varchar2(1),
  "MovedCount" decimal(14, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "EmpDeductDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "AchRepayCode" decimal(2, 0) default 0 not null,
  "PerfMonth" decimal(6, 0) default 0 not null,
  "ProcCode" varchar2(1),
  "RepayCode" varchar2(1),
  "AcctCode" varchar2(12),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "EmpNo" varchar2(6),
  "CustId" varchar2(10),
  "TxAmt" decimal(14, 0) default 0 not null,
  "ErrMsg" nvarchar2(20),
  "Acdate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "BatchNo" varchar2(6),
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ResignCode" varchar2(2),
  "DeptCode" varchar2(6),
  "UnitCode" varchar2(6),
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "PositCode" varchar2(2),
  "Principal" decimal(14, 0) default 0 not null,
  "Interest" decimal(14, 0) default 0 not null,
  "SumOvpayAmt" decimal(14, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "CurrIntAmt" decimal(14, 0) default 0 not null,
  "CurrPrinAmt" decimal(14, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "EmpDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaKind" varchar2(1),
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "PerfRepayCode" decimal(1, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "PerfMonth" decimal(6, 0) default 0 not null,
  "FlowCode" varchar2(1),
  "UnitCode" varchar2(6),
  "CustId" varchar2(10),
  "EntryDate" decimal(8, 0) default 0 not null,
  "TxAmt" decimal(14, 0) default 0 not null,
  "ErrorCode" varchar2(2),
  "AcctCode" varchar2(3),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "EmpDeductSchedule" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "AgType1" varchar2(1),
  "EntryDate" decimal(8, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "FacCaseAppl" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "ApplDate" decimal(8, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "SyndNo" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ApplAmt" decimal(16, 2) default 0 not null,
  "ProdNo" varchar2(5),
  "Estimate" varchar2(6),
  "DepartmentCode" varchar2(1),
  "PieceCode" varchar2(1),
  "CreditOfficer" varchar2(6),
  "LoanOfficer" varchar2(6),
  "Introducer" varchar2(6),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "Supervisor" varchar2(6),
  "ProcessCode" varchar2(1),
  "ApproveDate" decimal(8, 0) default 0 not null,
  "GroupUKey" varchar2(32),
  "BranchNo" varchar2(4),
  "IsLimit" varchar2(1),
  "IsRelated" varchar2(1),
  "IsLnrelNear" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "FacClose" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CloseNo" decimal(3, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ActFlag" decimal(1, 0) default 0 not null,
  "FunCode" varchar2(1),
  "CarLoan" decimal(1, 0) default 0 not null,
  "ApplDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseInd" varchar2(1),
  "CloseReasonCode" varchar2(2),
  "CloseAmt" decimal(16, 2) default 0 not null,
  "CollectFlag" varchar2(1),
  "CollectWayCode" varchar2(2),
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "TelNo1" varchar2(15),
  "TelNo2" varchar2(15),
  "TelNo3" varchar2(15),
  "EntryDate" decimal(8, 0) default 0 not null,
  "AgreeNo" varchar2(10),
  "DocNo" decimal(7, 0) default 0 not null,
  "ClsNo" nvarchar2(18),
  "Rmk" nvarchar2(100),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ReceiveFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "FacMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "LastBormNo" decimal(3, 0) default 0 not null,
  "LastBormRvNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AnnualIncr" decimal(6, 4) default 0 not null,
  "EmailIncr" decimal(6, 4) default 0 not null,
  "GraceIncr" decimal(6, 4) default 0 not null,
  "RateCode" varchar2(1),
  "FirstRateAdjFreq" decimal(2, 0) default 0 not null,
  "RateAdjFreq" decimal(2, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "LineAmt" decimal(16, 2) default 0 not null,
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "AcctCode" varchar2(3),
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "IntCalcCode" varchar2(1),
  "AmortizedCode" varchar2(1),
  "FreqBase" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "HandlingFee" decimal(16, 2) default 0 not null,
  "RuleCode" varchar2(2),
  "ExtraRepayCode" varchar2(1),
  "CustTypeCode" varchar2(2),
  "RecycleCode" varchar2(1),
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "UsageCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "IncomeTaxFlag" varchar2(1),
  "CompensateFlag" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "RateAdjNoticeCode" varchar2(1),
  "PieceCode" varchar2(1),
  "RepayCode" decimal(2, 0) default 0 not null,
  "Introducer" varchar2(6),
  "District" varchar2(6),
  "FireOfficer" varchar2(6),
  "Estimate" varchar2(6),
  "CreditOfficer" varchar2(6),
  "LoanOfficer" varchar2(6),
  "BusinessOfficer" varchar2(6),
  "Supervisor" varchar2(6),
  "InvestigateOfficer" varchar2(6),
  "EstimateReview" varchar2(6),
  "Coorgnizer" varchar2(6),
  "AdvanceCloseCode" decimal(2, 0) default 0 not null,
  "ProdBreachFlag" varchar2(1),
  "BreachDescription" nvarchar2(200),
  "CreditScore" decimal(3, 0) default 0 not null,
  "GuaranteeDate" decimal(8, 0) default 0 not null,
  "ContractNo" varchar2(10),
  "ColSetFlag" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "LastAcctDate" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "AcDate" decimal(8, 0) default 0 not null,
  "L9110Flag" varchar2(1),
  "BranchNo" varchar2(4),
  "ApprovedLevel" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "FacProd" (
  "ProdNo" varchar2(5),
  "ProdName" nvarchar2(60),
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "AgreementFg" varchar2(1),
  "EnterpriseFg" varchar2(1),
  "CurrencyCode" varchar2(3),
  "BaseRateCode" varchar2(2),
  "ProdIncr" decimal(6, 4) default 0 not null,
  "LowLimitRate" decimal(6, 4) default 0 not null,
  "IncrFlag" varchar2(1),
  "RateCode" varchar2(1),
  "GovOfferFlag" varchar2(1),
  "FinancialFlag" varchar2(1),
  "EmpFlag" varchar2(1),
  "BreachFlag" varchar2(1),
  "BreachCode" varchar2(3),
  "BreachGetCode" varchar2(1),
  "ProhibitMonth" decimal(3, 0) default 0 not null,
  "BreachPercent" decimal(5, 2) default 0 not null,
  "BreachDecreaseMonth" decimal(3, 0) default 0 not null,
  "BreachDecrease" decimal(5, 2) default 0 not null,
  "BreachStartPercent" decimal(3, 0) default 0 not null,
  "IfrsStepProdCode" varchar2(1),
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FacProdAcctFee" (
  "ProdNo" varchar2(9),
  "FeeType" varchar2(1),
  "LoanLow" decimal(16, 2) default 0 not null,
  "LoanHigh" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "FacProdPremium" (
  "ProdNo" varchar2(5),
  "PremiumLow" decimal(16, 2) default 0 not null,
  "PremiumHigh" decimal(16, 2) default 0 not null,
  "PremiumIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "FacProdStepRate" (
  "ProdNo" varchar2(10),
  "MonthStart" decimal(3, 0) default 0 not null,
  "MonthEnd" decimal(3, 0) default 0 not null,
  "RateType" varchar2(1),
  "RateIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FacRelation" (
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustUKey" varchar2(32),
  "FacRelationCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FacShareAppl" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "MainApplNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(3, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "KeyinSeq" decimal(2, 0) default 0 not null,
  "JcicMergeFlag" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FacShareLimit" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "MainApplNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(3, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "KeyinSeq" decimal(2, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "LineAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FacShareRelation" (
  "ApplNo" decimal(7, 0) default 0 not null,
  "RelApplNo" decimal(7, 0) default 0 not null,
  "RelCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FinReportCashFlow" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "BusCash" decimal(18, 0) default 0 not null,
  "InvestCash" decimal(18, 0) default 0 not null,
  "FinCash" decimal(18, 0) default 0 not null,
  "AccountItem01" nvarchar2(20),
  "AccountItem02" nvarchar2(20),
  "AccountValue01" decimal(18, 0) default 0 not null,
  "AccountValue02" decimal(18, 0) default 0 not null,
  "EndCash" decimal(18, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FinReportDebt" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "StartYY" decimal(4, 0) default 0 not null,
  "StartMM" decimal(2, 0) default 0 not null,
  "EndYY" decimal(4, 0) default 0 not null,
  "EndMM" decimal(2, 0) default 0 not null,
  "AssetTotal" decimal(18, 0) default 0 not null,
  "FlowAsset" decimal(18, 0) default 0 not null,
  "Cash" decimal(18, 0) default 0 not null,
  "FinAsset" decimal(18, 0) default 0 not null,
  "ReceiveTicket" decimal(18, 0) default 0 not null,
  "ReceiveAccount" decimal(18, 0) default 0 not null,
  "ReceiveRelation" decimal(18, 0) default 0 not null,
  "OtherReceive" decimal(18, 0) default 0 not null,
  "Stock" decimal(18, 0) default 0 not null,
  "PrepayItem" decimal(18, 0) default 0 not null,
  "OtherFlowAsset" decimal(18, 0) default 0 not null,
  "AccountItem01" nvarchar2(20),
  "AccountItem02" nvarchar2(20),
  "AccountItem03" nvarchar2(20),
  "AccountValue01" decimal(18, 0) default 0 not null,
  "AccountValue02" decimal(18, 0) default 0 not null,
  "AccountValue03" decimal(18, 0) default 0 not null,
  "LongInvest" decimal(18, 0) default 0 not null,
  "FixedAsset" decimal(18, 0) default 0 not null,
  "Land" decimal(18, 0) default 0 not null,
  "HouseBuild" decimal(18, 0) default 0 not null,
  "MachineEquip" decimal(18, 0) default 0 not null,
  "OtherEquip" decimal(18, 0) default 0 not null,
  "PrepayEquip" decimal(18, 0) default 0 not null,
  "UnFinish" decimal(18, 0) default 0 not null,
  "Depreciation" decimal(18, 0) default 0 not null,
  "InvisibleAsset" decimal(18, 0) default 0 not null,
  "OtherAsset" decimal(18, 0) default 0 not null,
  "AccountItem04" nvarchar2(20),
  "AccountItem05" nvarchar2(20),
  "AccountItem06" nvarchar2(20),
  "AccountValue04" decimal(18, 0) default 0 not null,
  "AccountValue05" decimal(18, 0) default 0 not null,
  "AccountValue06" decimal(18, 0) default 0 not null,
  "DebtNetTotal" decimal(18, 0) default 0 not null,
  "FlowDebt" decimal(18, 0) default 0 not null,
  "ShortLoan" decimal(18, 0) default 0 not null,
  "PayShortTicket" decimal(18, 0) default 0 not null,
  "PayTicket" decimal(18, 0) default 0 not null,
  "PayAccount" decimal(18, 0) default 0 not null,
  "PayRelation" decimal(18, 0) default 0 not null,
  "OtherPay" decimal(18, 0) default 0 not null,
  "PreReceiveItem" decimal(18, 0) default 0 not null,
  "LongDebtOneYear" decimal(18, 0) default 0 not null,
  "Shareholder" decimal(18, 0) default 0 not null,
  "OtherFlowDebt" decimal(18, 0) default 0 not null,
  "AccountItem07" nvarchar2(20),
  "AccountItem08" nvarchar2(20),
  "AccountItem09" nvarchar2(20),
  "AccountValue07" decimal(18, 0) default 0 not null,
  "AccountValue08" decimal(18, 0) default 0 not null,
  "AccountValue09" decimal(18, 0) default 0 not null,
  "LongDebt" decimal(18, 0) default 0 not null,
  "OtherDebt" decimal(18, 0) default 0 not null,
  "DebtTotal" decimal(18, 0) default 0 not null,
  "NetValue" decimal(18, 0) default 0 not null,
  "Capital" decimal(18, 0) default 0 not null,
  "CapitalSurplus" decimal(18, 0) default 0 not null,
  "RetainProfit" decimal(18, 0) default 0 not null,
  "OtherRight" decimal(18, 0) default 0 not null,
  "TreasuryStock" decimal(18, 0) default 0 not null,
  "UnControlRight" decimal(18, 0) default 0 not null,
  "AccountItem10" nvarchar2(20),
  "AccountItem11" nvarchar2(20),
  "AccountValue10" decimal(18, 0) default 0 not null,
  "AccountValue11" decimal(18, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FinReportProfit" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "BusIncome" decimal(18, 0) default 0 not null,
  "GrowRate" decimal(18, 2) default 0 not null,
  "BusCost" decimal(18, 0) default 0 not null,
  "BusGrossProfit" decimal(18, 0) default 0 not null,
  "ManageFee" decimal(18, 0) default 0 not null,
  "BusLossProfit" decimal(18, 0) default 0 not null,
  "BusOtherIncome" decimal(18, 0) default 0 not null,
  "Interest" decimal(18, 0) default 0 not null,
  "BusOtherFee" decimal(18, 0) default 0 not null,
  "BeforeTaxNet" decimal(18, 0) default 0 not null,
  "BusTax" decimal(18, 0) default 0 not null,
  "HomeLossProfit" decimal(18, 0) default 0 not null,
  "OtherComLossProfit" decimal(18, 0) default 0 not null,
  "HomeComLossProfit" decimal(18, 0) default 0 not null,
  "UncontrolRight" decimal(18, 0) default 0 not null,
  "ParentCompanyRight" decimal(18, 0) default 0 not null,
  "EPS" decimal(18, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FinReportQuality" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "ReportType" varchar2(1),
  "Opinion" varchar2(1),
  "IsCheck" varchar2(1),
  "IsChange" varchar2(1),
  "OfficeType" varchar2(1),
  "PunishRecord" varchar2(1),
  "ChangeReason" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FinReportRate" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "IsSameTrade" varchar2(1),
  "TradeType" varchar2(20),
  "Flow" decimal(18, 4) default 0 not null,
  "Speed" decimal(18, 4) default 0 not null,
  "RateGuar" decimal(18, 4) default 0 not null,
  "Debt" decimal(18, 4) default 0 not null,
  "Net" decimal(18, 4) default 0 not null,
  "CashFlow" decimal(18, 4) default 0 not null,
  "FixLong" decimal(18, 4) default 0 not null,
  "FinSpend" decimal(18, 4) default 0 not null,
  "GrossProfit" decimal(18, 4) default 0 not null,
  "AfterTaxNet" decimal(18, 4) default 0 not null,
  "NetReward" decimal(18, 4) default 0 not null,
  "TotalAssetReward" decimal(18, 4) default 0 not null,
  "Stock" decimal(18, 4) default 0 not null,
  "ReceiveAccount" decimal(18, 4) default 0 not null,
  "TotalAsset" decimal(18, 4) default 0 not null,
  "PayAccount" decimal(18, 4) default 0 not null,
  "AveTotalAsset" decimal(18, 4) default 0 not null,
  "AveNetBusCycle" decimal(18, 4) default 0 not null,
  "FinLever" decimal(18, 4) default 0 not null,
  "LoanDebtNet" decimal(18, 4) default 0 not null,
  "BusRate" decimal(18, 4) default 0 not null,
  "PayFinLever" decimal(18, 4) default 0 not null,
  "ADE" decimal(18, 4) default 0 not null,
  "CashGuar" decimal(18, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "FinReportReview" (
  "CustUKey" varchar2(32),
  "UKey" varchar2(32),
  "CurrentAsset" decimal(18, 0) default 0 not null,
  "TotalAsset" decimal(18, 0) default 0 not null,
  "PropertyAsset" decimal(18, 0) default 0 not null,
  "Investment" decimal(18, 0) default 0 not null,
  "InvestmentProperty" decimal(18, 0) default 0 not null,
  "Depreciation" decimal(18, 0) default 0 not null,
  "CurrentDebt" decimal(18, 0) default 0 not null,
  "TotalDebt" decimal(18, 0) default 0 not null,
  "TotalEquity" decimal(18, 0) default 0 not null,
  "BondsPayable" decimal(18, 0) default 0 not null,
  "LongTermBorrowings" decimal(18, 0) default 0 not null,
  "NonCurrentLease" decimal(18, 0) default 0 not null,
  "LongTermPayable" decimal(18, 0) default 0 not null,
  "Preference" decimal(18, 0) default 0 not null,
  "OperatingRevenue" decimal(18, 0) default 0 not null,
  "InterestExpense" decimal(18, 0) default 0 not null,
  "ProfitBeforeTax" decimal(18, 0) default 0 not null,
  "ProfitAfterTax" decimal(18, 0) default 0 not null,
  "WorkingCapitalRatio" decimal(18, 4) default 0 not null,
  "InterestCoverageRatio1" decimal(18, 4) default 0 not null,
  "InterestCoverageRatio2" decimal(18, 4) default 0 not null,
  "LeverageRatio" decimal(18, 4) default 0 not null,
  "EquityRatio" decimal(18, 4) default 0 not null,
  "LongFitRatio" decimal(18, 4) default 0 not null,
  "NetProfitRatio" decimal(18, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "ForeclosureFee" (
  "RecordNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "DocDate" decimal(8, 0) default 0 not null,
  "OpenAcDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "FeeCode" varchar2(2),
  "LegalStaff" varchar2(6),
  "CloseNo" decimal(7, 0) default 0 not null,
  "Rmk" nvarchar2(60),
  "CaseCode" decimal(1, 0) default 0 not null,
  "RemitBranch" varchar2(3),
  "Remitter" varchar2(10),
  "CaseNo" varchar2(3),
  "OverdueDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "ForeclosureFinished" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FinishedDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "GraceCondition" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ActUse" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Guarantor" (
  "ApproveNo" decimal(7, 0) default 0 not null,
  "GuaUKey" varchar2(32),
  "GuaRelCode" varchar2(2),
  "GuaAmt" decimal(16, 2) default 0 not null,
  "GuaTypeCode" varchar2(2),
  "GuaDate" decimal(8, 0) default 0 not null,
  "GuaStatCode" varchar2(1),
  "CancelDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "GuildBuilders" (
  "CustNo" decimal(7, 0) default 0 not null,
  "BuilderStatus" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "HlAreaData" (
  "AreaUnitNo" varchar2(6),
  "AreaName" nvarchar2(20),
  "AreaChiefEmpNo" varchar2(6),
  "AreaChiefName" nvarchar2(15),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "HlAreaLnYg6Pt" (
  "WorkYM" varchar2(10),
  "AreaUnitNo" varchar2(6),
  "LstAppNum" decimal(14, 2) default 0 not null,
  "LstAppAmt" decimal(14, 2) default 0 not null,
  "TisAppNum" decimal(14, 2) default 0 not null,
  "TisAppAmt" decimal(14, 2) default 0 not null,
  "CalDate" varchar2(10),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "HlCusData" (
  "HlCusNo" decimal(10, 0) default 0 not null,
  "HlCusName" nvarchar2(50),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "HlEmpLnYg5Pt" (
  "WorkYM" varchar2(10),
  "AreaUnitNo" varchar2(6),
  "HlEmpNo" varchar2(6),
  "HlEmpName" nvarchar2(15),
  "DeptNo" varchar2(6),
  "DeptName" varchar2(20),
  "Area" varchar2(20),
  "BranchName" varchar2(20),
  "GoalAmt" decimal(14, 2) default 0 not null,
  "HlAppNum" decimal(14, 2) default 0 not null,
  "HlAppAmt" decimal(14, 2) default 0 not null,
  "ClAppNum" decimal(14, 2) default 0 not null,
  "ClAppAmt" decimal(14, 2) default 0 not null,
  "ServiceAppNum" decimal(14, 2) default 0 not null,
  "ServiceAppAmt" decimal(14, 2) default 0 not null,
  "CalDate" varchar2(10),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "HlThreeDetail" (
  "CusBNo" varchar2(2),
  "HlCusNo" decimal(14, 0) default 0 not null,
  "AmountNo" varchar2(3),
  "AplAmount" decimal(14, 2) default 0 not null,
  "CaseNo" varchar2(1),
  "IfCal" varchar2(1),
  "TActAmt" varchar2(30),
  "EmpNo" varchar2(10),
  "EmpId" varchar2(10),
  "HlEmpName" nvarchar2(15),
  "DeptNo" varchar2(6),
  "BranchNo" varchar2(50),
  "UnitNo" varchar2(6),
  "DeptName" varchar2(20),
  "BranchName" varchar2(20),
  "UnitName" varchar2(20),
  "FirAppDate" varchar2(8),
  "BiReteNo" varchar2(2),
  "TwoYag" decimal(14, 2) default 0 not null,
  "ThreeYag" decimal(14, 2) default 0 not null,
  "TwoPay" decimal(14, 2) default 0 not null,
  "ThreePay" decimal(14, 2) default 0 not null,
  "UnitChiefNo" varchar2(10),
  "UnitChiefName" nvarchar2(15),
  "AreaChiefNo" varchar2(10),
  "AreaChiefName" nvarchar2(15),
  "Id3" varchar2(10),
  "Id3Name" nvarchar2(15),
  "TeamChiefNo" varchar2(10),
  "TeamChiefName" nvarchar2(15),
  "Id0" varchar2(10),
  "Id0Name" nvarchar2(15),
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "HlThreeLaqhcp" (
  "CalDate" varchar2(10),
  "EmpNo" varchar2(6),
  "UnitNo" varchar2(6),
  "BranchNo" varchar2(6),
  "DeptNo" varchar2(6),
  "UnitName" varchar2(20),
  "BranchName" varchar2(20),
  "DeptName" varchar2(20),
  "ChiefName" nvarchar2(15),
  "HlEmpName" nvarchar2(15),
  "MType" varchar2(1),
  "GoalNum" decimal(14, 2) default 0 not null,
  "GoalAmt" decimal(14, 2) default 0 not null,
  "ActNum" decimal(14, 2) default 0 not null,
  "ActAmt" decimal(14, 2) default 0 not null,
  "ActRate" decimal(14, 2) default 0 not null,
  "TGoalNum" decimal(14, 2) default 0 not null,
  "TGoalAmt" decimal(14, 2) default 0 not null,
  "TActNum" decimal(14, 2) default 0 not null,
  "TActAmt" decimal(14, 2) default 0 not null,
  "TActRate" decimal(14, 2) default 0 not null,
  "UpNo" decimal(7, 0) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias34Ap" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "Rate" decimal(8, 6) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerCode" decimal(2, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "AmortizedCode" decimal(1, 0) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetClass" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias34Bp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LoanRate" decimal(8, 6) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias34Cp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias34Dp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerDate" decimal(8, 0) default 0 not null,
  "DerRate" decimal(8, 6) default 0 not null,
  "DerLoanBal" decimal(16, 2) default 0 not null,
  "DerIntAmt" decimal(16, 2) default 0 not null,
  "DerFee" decimal(16, 2) default 0 not null,
  "DerY1Amt" decimal(16, 2) default 0 not null,
  "DerY2Amt" decimal(16, 2) default 0 not null,
  "DerY3Amt" decimal(16, 2) default 0 not null,
  "DerY4Amt" decimal(16, 2) default 0 not null,
  "DerY5Amt" decimal(16, 2) default 0 not null,
  "DerY1Int" decimal(16, 2) default 0 not null,
  "DerY2Int" decimal(16, 2) default 0 not null,
  "DerY3Int" decimal(16, 2) default 0 not null,
  "DerY4Int" decimal(16, 2) default 0 not null,
  "DerY5Int" decimal(16, 2) default 0 not null,
  "DerY1Fee" decimal(16, 2) default 0 not null,
  "DerY2Fee" decimal(16, 2) default 0 not null,
  "DerY3Fee" decimal(16, 2) default 0 not null,
  "DerY4Fee" decimal(16, 2) default 0 not null,
  "DerY5Fee" decimal(16, 2) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdCode" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias34Ep" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "DerFg" varchar2(1),
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias34Gp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "AgreeNo" decimal(3, 0) default 0 not null,
  "AgreeFg" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias39IntMethod" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "Principal" decimal(16, 4) default 0 not null,
  "BookValue" decimal(16, 4) default 0 not null,
  "AccumDPAmortized" decimal(16, 4) default 0 not null,
  "AccumDPunAmortized" decimal(16, 4) default 0 not null,
  "DPAmortized" decimal(16, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias39LGD" (
  "Date" decimal(8, 0) default 0 not null,
  "Type" varchar2(2),
  "TypeDesc" nvarchar2(10),
  "LGDPercent" decimal(7, 5) default 0 not null,
  "Enable" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias39Loan34Data" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "Status" decimal(2, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(13, 2) default 0 not null,
  "DrawdownAmt" decimal(13, 2) default 0 not null,
  "AcctFee" decimal(13, 2) default 0 not null,
  "LoanBal" decimal(13, 2) default 0 not null,
  "IntAmt" decimal(13, 2) default 0 not null,
  "Fee" decimal(13, 2) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(13, 2) default 0 not null,
  "DerCode" decimal(2, 0) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AmortizedCode" decimal(1, 0) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "Zip3" varchar2(3),
  "BaseRateCode" varchar2(2),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetKind" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(2),
  "EvaAmt" decimal(13, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "UtilAmt" decimal(13, 2) default 0 not null,
  "UtilBal" decimal(13, 2) default 0 not null,
  "TempAmt" decimal(13, 2) default 0 not null,
  "AvblBal" decimal(13, 2) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ExchangeRate" decimal(8, 5) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "LoanTerm" decimal(6, 0) default 0 not null,
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcNoCode" varchar2(11),
  "FacAmortizedCode" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias39LoanCommit" (
  "DataYm" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(13, 2) default 0 not null,
  "UtilBal" decimal(13, 2) default 0 not null,
  "AvblBal" decimal(13, 2) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "Ccf" decimal(5, 2) default 0 not null,
  "ExpLimitAmt" decimal(13, 2) default 0 not null,
  "DbAcNoCode" varchar2(11),
  "CrAcNoCode" varchar2(11),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ias39Loss" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "MarkDate" decimal(8, 0) default 0 not null,
  "MarkCode" decimal(2, 0) default 0 not null,
  "MarkCodeDesc" nvarchar2(20),
  "StartDate" decimal(8, 0) default 0 not null,
  "EndDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ifrs9FacData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "UtilDeadline" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LawFee" decimal(16, 2) default 0 not null,
  "FireFee" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IfrsStepProdCode" varchar2(1),
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(2),
  "AreaCode" varchar2(3),
  "Zip3" varchar2(3),
  "ProdNo" varchar2(5),
  "AgreementFg" varchar2(1),
  "EntCode" varchar2(1),
  "AssetClass" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "TotalLoanBal" decimal(16, 2) default 0 not null,
  "RecycleCode" decimal(1, 0) default 0 not null,
  "IrrevocableFlag" decimal(1, 0) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "Ifrs9LoanData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "AcctCode" varchar2(3),
  "AcCode" varchar2(11),
  "AcCodeOld" varchar2(8),
  "Status" decimal(2, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AgreeBefFacmNo" decimal(3, 0) default 0 not null,
  "AgreeBefBormNo" decimal(3, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "InnDocRecord" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplSeq" varchar2(3),
  "TitaActFg" varchar2(1),
  "ApplCode" varchar2(1),
  "ApplEmpNo" varchar2(6),
  "KeeperEmpNo" varchar2(6),
  "UsageCode" varchar2(2),
  "CopyCode" varchar2(1),
  "ApplDate" decimal(8, 0) default 0 not null,
  "ReturnDate" decimal(8, 0) default 0 not null,
  "ReturnEmpNo" varchar2(6),
  "Remark" nvarchar2(60),
  "ApplObj" varchar2(1),
  "TitaEntDy" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "JsonFields" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "InnFundApl" (
  "AcDate" decimal(8, 0) default 0 not null,
  "ResrvStndrd" decimal(14, 0) default 0 not null,
  "PosbleBorPsn" decimal(7, 4) default 0 not null,
  "PosbleBorAmt" decimal(16, 2) default 0 not null,
  "AlrdyBorAmt" decimal(16, 2) default 0 not null,
  "StockHoldersEqt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "InnLoanMeeting" (
  "MeetNo" decimal(6, 0) default 0 not null,
  "MeetingDate" decimal(8, 0) default 0 not null,
  "CustCode" varchar2(1),
  "Amount" decimal(14, 0) default 0 not null,
  "Issue" varchar2(50),
  "Remark" varchar2(500),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "InnReCheck" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "ConditionCode" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "ReCheckCode" varchar2(1),
  "FollowMark" varchar2(1),
  "ReChkYearMonth" decimal(6, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "Evaluation" decimal(2, 0) default 0 not null,
  "CustTypeItem" nvarchar2(10),
  "UsageItem" nvarchar2(10),
  "CityItem" nvarchar2(10),
  "ReChkUnit" nvarchar2(10),
  "SpecifyFg" varchar2(2),
  "Remark" nvarchar2(300),
  "TraceMonth" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "InsuComm" (
  "InsuYearMonth" decimal(6, 0) default 0 not null,
  "InsuCommSeq" decimal(6, 0) default 0 not null,
  "ManagerCode" varchar2(3),
  "NowInsuNo" varchar2(20),
  "BatchNo" varchar2(20),
  "InsuType" decimal(2, 0) default 0 not null,
  "InsuSignDate" decimal(8, 0) default 0 not null,
  "InsuredName" nvarchar2(60),
  "InsuredAddr" nvarchar2(60),
  "InsuredTeleph" varchar2(20),
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "InsuCate" decimal(2, 0) default 0 not null,
  "InsuPrem" decimal(14, 0) default 0 not null,
  "CommRate" decimal(5, 3) default 0 not null,
  "Commision" decimal(14, 0) default 0 not null,
  "TotInsuPrem" decimal(14, 0) default 0 not null,
  "TotComm" decimal(14, 0) default 0 not null,
  "RecvSeq" varchar2(14),
  "ChargeDate" decimal(8, 0) default 0 not null,
  "CommDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "FireOfficer" varchar2(6),
  "EmpId" varchar2(10),
  "EmpName" nvarchar2(20),
  "DueAmt" decimal(14, 0) default 0 not null,
  "MediaCode" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "InsuOrignal" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "OrigInsuNo" varchar2(17),
  "EndoInsuNo" varchar2(17),
  "InsuCompany" varchar2(2),
  "InsuTypeCode" varchar2(2),
  "FireInsuCovrg" decimal(16, 2) default 0 not null,
  "EthqInsuCovrg" decimal(16, 2) default 0 not null,
  "FireInsuPrem" decimal(16, 2) default 0 not null,
  "EthqInsuPrem" decimal(16, 2) default 0 not null,
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "CommericalFlag" varchar2(2),
  "Remark" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "InsuRenew" (
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "PrevInsuNo" varchar2(17),
  "EndoInsuNo" varchar2(17),
  "InsuYearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "NowInsuNo" varchar2(17),
  "OrigInsuNo" varchar2(17),
  "RenewCode" decimal(1, 0) default 0 not null,
  "InsuCompany" varchar2(2),
  "InsuTypeCode" varchar2(2),
  "RepayCode" decimal(1, 0) default 0 not null,
  "FireInsuCovrg" decimal(14, 0) default 0 not null,
  "EthqInsuCovrg" decimal(14, 0) default 0 not null,
  "FireInsuPrem" decimal(14, 0) default 0 not null,
  "EthqInsuPrem" decimal(14, 0) default 0 not null,
  "InsuStartDate" decimal(8, 0) default 0 not null,
  "InsuEndDate" decimal(8, 0) default 0 not null,
  "TotInsuPrem" decimal(14, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "NotiTempFg" varchar2(1),
  "StatusCode" decimal(1, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "OvduNo" decimal(10, 0) default 0 not null,
  "CommericalFlag" varchar2(2),
  "Remark" varchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);









create table "InsuRenewMediaTemp" (
  "LogNo" decimal(11,0) not null,
  "FireInsuMonth" nvarchar2(6),
  "ReturnCode" nvarchar2(2),
  "InsuCampCode" nvarchar2(2),
  "InsuCustId" nvarchar2(10),
  "InsuCustName" nvarchar2(12),
  "LoanCustId" nvarchar2(10),
  "LoanCustName" nvarchar2(12),
  "PostalCode" nvarchar2(5),
  "Address" nvarchar2(58),
  "BuildingSquare" nvarchar2(9),
  "BuildingCode" nvarchar2(2),
  "BuildingYears" nvarchar2(3),
  "BuildingFloors" nvarchar2(2),
  "RoofCode" nvarchar2(2),
  "BusinessUnit" nvarchar2(4),
  "ClCode1" nvarchar2(1),
  "ClCode2" nvarchar2(2),
  "ClNo" nvarchar2(7),
  "Seq" nvarchar2(2),
  "InsuNo" nvarchar2(16),
  "InsuStartDate" nvarchar2(10),
  "InsuEndDate" nvarchar2(10),
  "FireInsuAmt" nvarchar2(11),
  "FireInsuFee" nvarchar2(7),
  "EqInsuAmt" nvarchar2(7),
  "EqInsuFee" nvarchar2(6),
  "CustNo" nvarchar2(7),
  "FacmNo" nvarchar2(3),
  "Space" nvarchar2(4),
  "SendDate" nvarchar2(14),
  "NewInusNo" nvarchar2(16),
  "NewInsuStartDate" nvarchar2(10),
  "NewInsuEndDate" nvarchar2(10),
  "NewFireInsuAmt" nvarchar2(11),
  "NewFireInsuFee" nvarchar2(7),
  "NewEqInsuAmt" nvarchar2(8),
  "NewEqInsuFee" nvarchar2(6),
  "NewTotalFee" nvarchar2(7),
  "Remark1" nvarchar2(16),
  "MailingAddress" nvarchar2(60),
  "Remark2" nvarchar2(39),
  "SklSalesName" nvarchar2(20),
  "SklUnitCode" nvarchar2(6),
  "SklUnitName" nvarchar2(20),
  "SklSalesCode" nvarchar2(6),
  "RenewTrlCode" nvarchar2(8),
  "RenewUnit" nvarchar2(7),
  "CheckResultA" nvarchar2(30),
  "CheckResultB" nvarchar2(30),
  "CheckResultC" nvarchar2(30),
  "RepayCode" decimal(1, 0) default 0 not null,
  "NoticeFlag" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "InsuRenewMediaTemp_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;


create table "JcicAtomDetail" (
  "FunctionCode" varchar2(6),
  "DataOrder" decimal(3, 0) default 0 not null,
  "FiledName" nvarchar2(50),
  "FiledType" nvarchar2(20),
  "Remark" nvarchar2(300),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicAtomMain" (
  "FunctionCode" varchar2(6),
  "DataType" nvarchar2(45),
  "Remark" nvarchar2(300),
  "SearchPoint" varchar2(3),
  "FunctionKey" nvarchar2(200),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB080" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "Filler4" varchar2(4),
  "CustId" varchar2(10),
  "FacmNo" varchar2(50),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmtFx" decimal(10, 0) default 0 not null,
  "DrawdownDate" decimal(5, 0) default 0 not null,
  "MaturityDate" decimal(5, 0) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "UpFacmNo" varchar2(50),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "ClTypeCode" varchar2(2),
  "Filler18" varchar2(24),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB085" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "RenewYM" decimal(5, 0) default 0 not null,
  "CustId" varchar2(10),
  "BefBankItem" varchar2(3),
  "BefBranchItem" varchar2(4),
  "Filler6" varchar2(2),
  "BefAcctNo" varchar2(50),
  "AftBankItem" varchar2(3),
  "AftBranchItem" varchar2(4),
  "Filler10" varchar2(2),
  "AftAcctNo" varchar2(50),
  "Filler12" varchar2(25),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB090" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "CustId" varchar2(10),
  "ClActNo" varchar2(50),
  "FacmNo" varchar2(50),
  "GlOverseas" varchar2(2),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB091" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(7, 0) default 0 not null,
  "LoanLimitAmt" decimal(10, 0) default 0 not null,
  "SettingDate" decimal(7, 0) default 0 not null,
  "CompanyId" varchar2(8),
  "CompanyCountry" varchar2(2),
  "StockCode" varchar2(10),
  "Currency" varchar2(3),
  "PledgeEndYM" decimal(5, 0) default 0 not null,
  "DispPrice" decimal(8, 0) default 0 not null,
  "Filler19" varchar2(14),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB092" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" varchar2(9),
  "EvaDate" decimal(5, 0) default 0 not null,
  "LoanLimitAmt" varchar2(9),
  "SettingDate" decimal(5, 0) default 0 not null,
  "MonthSettingAmt" varchar2(9),
  "SettingSeq" decimal(1, 0) default 0 not null,
  "SettingAmt" varchar2(9),
  "PreSettingAmt" varchar2(9),
  "DispPrice" varchar2(9),
  "IssueEndDate" decimal(5, 0) default 0 not null,
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "LandNo1" decimal(4, 0) default 0 not null,
  "LandNo2" decimal(4, 0) default 0 not null,
  "BdNo1" decimal(5, 0) default 0 not null,
  "BdNo2" decimal(3, 0) default 0 not null,
  "Zip" varchar2(5),
  "InsuFg" varchar2(1),
  "LVITax" varchar2(9),
  "LVITaxYearMonth" varchar2(5),
  "ContractPrice" varchar2(9),
  "ContractDate" varchar2(7),
  "ParkingTypeCode" varchar2(1),
  "Area" varchar2(9),
  "LandOwnedArea" varchar2(10),
  "BdTypeCode" varchar2(2),
  "Filler33" varchar2(29),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB093" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(5, 0) default 0 not null,
  "LoanLimitAmt" decimal(8, 0) default 0 not null,
  "SettingDate" decimal(5, 0) default 0 not null,
  "MonthSettingAmt" decimal(8, 0) default 0 not null,
  "SettingSeq" decimal(1, 0) default 0 not null,
  "SettingAmt" decimal(8, 0) default 0 not null,
  "PreSettingAmt" decimal(8, 0) default 0 not null,
  "DispPrice" decimal(8, 0) default 0 not null,
  "IssueEndDate" decimal(5, 0) default 0 not null,
  "InsuFg" varchar2(1),
  "Filler19" varchar2(17),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB094" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "ClTypeJCIC" varchar2(2),
  "OwnerId" varchar2(10),
  "EvaAmt" decimal(8, 0) default 0 not null,
  "EvaDate" decimal(7, 0) default 0 not null,
  "LoanLimitAmt" decimal(10, 0) default 0 not null,
  "SettingDate" decimal(7, 0) default 0 not null,
  "CompanyId" varchar2(8),
  "CompanyCountry" varchar2(2),
  "StockCode" varchar2(10),
  "StockType" decimal(1, 0) default 0 not null,
  "Currency" varchar2(3),
  "SettingBalance" decimal(14, 0) default 0 not null,
  "LoanBal" decimal(10, 0) default 0 not null,
  "InsiderJobTitle" varchar2(1),
  "InsiderPosition" varchar2(1),
  "LegalPersonId" varchar2(10),
  "DispPrice" decimal(8, 0) default 0 not null,
  "Filler19" varchar2(14),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB095" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "OwnerId" varchar2(10),
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "BdNo1" decimal(5, 0) default 0 not null,
  "BdNo2" decimal(3, 0) default 0 not null,
  "CityName" varchar2(36),
  "AreaName" varchar2(36),
  "Addr" varchar2(228),
  "BdMainUseCode" varchar2(1),
  "BdMtrlCode" varchar2(1),
  "BdSubUsageCode" varchar2(6),
  "TotalFloor" decimal(3, 0) default 0 not null,
  "FloorNo" varchar2(7),
  "BdDate" varchar2(7),
  "TotalArea" decimal(10, 2) default 0 not null,
  "FloorArea" decimal(10, 2) default 0 not null,
  "BdSubArea" decimal(10, 2) default 0 not null,
  "PublicArea" decimal(10, 2) default 0 not null,
  "Filler33" varchar2(44),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB096" (
  "DataYM" decimal(6, 0) default 0 not null,
  "DataType" varchar2(2),
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "Filler4" varchar2(2),
  "ClActNo" varchar2(50),
  "LandSeq" decimal(3, 0) default 0 not null,
  "OwnerId" varchar2(10),
  "CityJCICCode" varchar2(1),
  "AreaJCICCode" decimal(2, 0) default 0 not null,
  "IrCode" varchar2(4),
  "LandNo1" decimal(4, 0) default 0 not null,
  "LandNo2" decimal(4, 0) default 0 not null,
  "LandCode" varchar2(1),
  "Area" decimal(10, 2) default 0 not null,
  "LandZoningCode" varchar2(1),
  "LandUsageType" varchar2(2),
  "PostedLandValue" decimal(10, 0) default 0 not null,
  "PostedLandValueYearMonth" decimal(5, 0) default 0 not null,
  "Filler18" varchar2(30),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB201" (
  "DataYM" decimal(6, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "SubTranCode" varchar2(1),
  "AcctNo" varchar2(50),
  "SeqNo" decimal(2, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "CustId" varchar2(10),
  "CustIdErr" varchar2(1),
  "SuvId" varchar2(10),
  "SuvIdErr" varchar2(1),
  "OverseasId" varchar2(10),
  "IndustryCode" varchar2(6),
  "Filler12" varchar2(3),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "OrigAcctCode" varchar2(1),
  "ConsumeFg" varchar2(1),
  "FinCode" varchar2(1),
  "ProjCode" varchar2(2),
  "NonCreditCode" varchar2(1),
  "UsageCode" varchar2(1),
  "ApproveRate" decimal(7, 5) default 0 not null,
  "DrawdownDate" decimal(5, 0) default 0 not null,
  "MaturityDate" decimal(5, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmtFx" decimal(10, 0) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "FacmNo" varchar2(50),
  "UnDelayBal" decimal(10, 0) default 0 not null,
  "UnDelayBalFx" decimal(10, 0) default 0 not null,
  "DelayBal" decimal(10, 0) default 0 not null,
  "DelayBalFx" decimal(10, 0) default 0 not null,
  "DelayPeriodCode" varchar2(1),
  "RepayCode" varchar2(1),
  "PayAmt" decimal(16, 3) default 0 not null,
  "Principal" decimal(16, 3) default 0 not null,
  "Interest" decimal(16, 3) default 0 not null,
  "Fee" decimal(16, 3) default 0 not null,
  "FirstDelayCode" varchar2(3),
  "SecondDelayCode" varchar2(1),
  "BadDebtCode" varchar2(3),
  "NegStatus" varchar2(3),
  "NegCreditor" varchar2(10),
  "NegNo" varchar2(14),
  "NegTransYM" varchar2(5),
  "Filler443" varchar2(6),
  "ClType" varchar2(1),
  "ClEvaAmt" decimal(10, 0) default 0 not null,
  "ClTypeCode" varchar2(2),
  "SyndKind" varchar2(1),
  "SyndContractDate" varchar2(8),
  "SyndRatio" decimal(5, 2) default 0 not null,
  "Filler51" varchar2(2),
  "Filler52" varchar2(6),
  "PayablesFg" varchar2(1),
  "NegFg" varchar2(1),
  "Filler533" varchar2(1),
  "GuaTypeCode1" varchar2(1),
  "GuaId1" varchar2(10),
  "GuaIdErr1" varchar2(1),
  "GuaRelCode1" varchar2(2),
  "GuaTypeCode2" varchar2(1),
  "GuaId2" varchar2(10),
  "GuaIdErr2" varchar2(1),
  "GuaRelCode2" varchar2(2),
  "GuaTypeCode3" varchar2(1),
  "GuaId3" varchar2(10),
  "GuaIdErr3" varchar2(1),
  "GuaRelCode3" varchar2(2),
  "GuaTypeCode4" varchar2(1),
  "GuaId4" varchar2(10),
  "GuaIdErr4" varchar2(1),
  "GuaRelCode4" varchar2(2),
  "GuaTypeCode5" varchar2(1),
  "GuaId5" varchar2(10),
  "GuaIdErr5" varchar2(1),
  "GuaRelCode5" varchar2(2),
  "Filler741" varchar2(10),
  "Filler742" varchar2(10),
  "BadDebtDate" decimal(5, 0) default 0 not null,
  "SyndCode" varchar2(5),
  "BankruptDate" decimal(7, 0) default 0 not null,
  "BdLoanFg" varchar2(1),
  "SmallAmt" decimal(4, 0) default 0 not null,
  "ExtraAttrCode" varchar2(1),
  "ExtraStatusCode" varchar2(2),
  "Filler74A" varchar2(9),
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "DataEnd" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB204" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "DataDate" decimal(7, 0) default 0 not null,
  "AcctNo" varchar2(50),
  "CustId" varchar2(10),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "SubTranCode" varchar2(1),
  "LineAmt" decimal(10, 0) default 0 not null,
  "DrawdownAmt" decimal(10, 0) default 0 not null,
  "DBR22Amt" decimal(10, 0) default 0 not null,
  "SeqNo" varchar2(1),
  "Filler13" varchar2(20),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB207" (
  "DataYM" decimal(6, 0) default 0 not null,
  "TranCode" varchar2(1),
  "BankItem" varchar2(3),
  "Filler3" varchar2(4),
  "DataDate" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "CustName" varchar2(30),
  "EName" varchar2(20),
  "Birthday" decimal(7, 0) default 0 not null,
  "RegAddr" varchar2(99),
  "CurrZip" varchar2(5),
  "CurrAddr" varchar2(99),
  "Tel" varchar2(30),
  "Mobile" varchar2(16),
  "Filler14" varchar2(5),
  "EduCode" varchar2(1),
  "OwnedHome" varchar2(1),
  "CurrCompName" varchar2(45),
  "CurrCompId" varchar2(8),
  "JobCode" varchar2(6),
  "CurrCompTel" varchar2(16),
  "JobTitle" varchar2(15),
  "JobTenure" varchar2(2),
  "IncomeOfYearly" decimal(6, 0) default 0 not null,
  "IncomeDataDate" decimal(5, 0) default 0 not null,
  "Sex" varchar2(1),
  "NationalityCode" varchar2(2),
  "PassportNo" varchar2(20),
  "PreTaxNo" varchar2(10),
  "FullCustName" varchar2(300),
  "Filler30" varchar2(36),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB211" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "CustId" varchar2(10),
  "SubTranCode" varchar2(1),
  "AcDate" decimal(7, 0) default 0 not null,
  "AcctNo" varchar2(50),
  "BorxNo" decimal(4, 0) default 0 not null,
  "TxAmt" decimal(10, 0) default 0 not null,
  "LoanBal" decimal(10, 0) default 0 not null,
  "RepayCode" varchar2(1),
  "NegStatus" varchar2(3),
  "AcctCode" varchar2(1),
  "SubAcctCode" varchar2(1),
  "BadDebtDate" decimal(5, 0) default 0 not null,
  "ConsumeFg" varchar2(1),
  "FinCode" varchar2(1),
  "UsageCode" varchar2(1),
  "Filler18" varchar2(130),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicB680" (
  "DataYM" decimal(6, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "TranCode" varchar2(1),
  "CustId" varchar2(10),
  "CustIdErr" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "Filler6" varchar2(40),
  "Amt" decimal(10, 0) default 0 not null,
  "JcicDataYM" decimal(5, 0) default 0 not null,
  "Filler9" varchar2(54),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicMonthlyLoanData" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "Status" decimal(2, 0) default 0 not null,
  "EntCode" varchar2(1),
  "SuvId" varchar2(10),
  "OverseasId" varchar2(10),
  "IndustryCode" varchar2(6),
  "AcctCode" varchar2(3),
  "SubAcctCode" varchar2(1),
  "OrigAcctCode" varchar2(3),
  "UtilAmt" decimal(16, 2) default 0 not null,
  "UtilBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "RecycleDeadline" decimal(8, 0) default 0 not null,
  "IrrevocableFlag" varchar2(1),
  "FinCode" varchar2(1),
  "ProjCode" varchar2(2),
  "NonCreditCode" varchar2(1),
  "UsageCode" varchar2(2),
  "ApproveRate" decimal(6, 4) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "PrevAmt" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "PrevAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "FeeAmtRcv" decimal(16, 2) default 0 not null,
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "PrevRepaidDate" decimal(8, 0) default 0 not null,
  "NextPayIntDate" decimal(8, 0) default 0 not null,
  "NextRepayDate" decimal(8, 0) default 0 not null,
  "IntDelayMon" decimal(3, 0) default 0 not null,
  "RepayDelayMon" decimal(3, 0) default 0 not null,
  "RepaidEndMon" decimal(3, 0) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "ClTypeCode" varchar2(3),
  "ClType" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "DispDate" decimal(8, 0) default 0 not null,
  "SyndNo" decimal(3, 0) default 0 not null,
  "SyndCode" varchar2(1),
  "SigningDate" decimal(8, 0) default 0 not null,
  "SyndAmt" decimal(16, 2) default 0 not null,
  "PartAmt" decimal(16, 2) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtSkipFg" varchar2(1),
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicRel" (
  "DataYMD" decimal(8, 0) default 0 not null,
  "BankItem" varchar2(3),
  "BranchItem" varchar2(4),
  "RelYM" decimal(5, 0) default 0 not null,
  "TranCode" varchar2(1),
  "CustId" varchar2(8),
  "Filler6" varchar2(1),
  "RelId" varchar2(8),
  "Filler8" varchar2(1),
  "RelationCode" varchar2(3),
  "Filler10" varchar2(5),
  "EndCode" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ040" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "RbDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "RefBankId" nvarchar2(3),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ040Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "RbDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "RefBankId" nvarchar2(3),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ041" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ScDate" decimal(8, 0) default 0 not null,
  "NegoStartDate" decimal(8, 0) default 0 not null,
  "NonFinClaimAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ041Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ScDate" decimal(8, 0) default 0 not null,
  "NegoStartDate" decimal(8, 0) default 0 not null,
  "NonFinClaimAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ042" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ReceExpAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "ReceCashAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "ReceCreditAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ042Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ReceExpAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "ReceCashAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "ReceCreditAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ043" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" varchar2(3),
  "Account" varchar2(50),
  "CollateralType" varchar2(2),
  "OriginLoanAmt" decimal(12, 0) default 0 not null,
  "CreditBalance" decimal(12, 0) default 0 not null,
  "PerPeriordAmt" decimal(10, 0) default 0 not null,
  "LastPayAmt" decimal(10, 0) default 0 not null,
  "LastPayDate" decimal(8, 0) default 0 not null,
  "OutstandAmt" decimal(10, 0) default 0 not null,
  "RepayPerMonDay" decimal(2, 0) default 0 not null,
  "ContractStartYM" decimal(6, 0) default 0 not null,
  "ContractEndYM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ043Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CollateralType" varchar2(2),
  "OriginLoanAmt" decimal(12, 0) default 0 not null,
  "CreditBalance" decimal(12, 0) default 0 not null,
  "PerPeriordAmt" decimal(10, 0) default 0 not null,
  "LastPayAmt" decimal(10, 0) default 0 not null,
  "LastPayDate" decimal(8, 0) default 0 not null,
  "OutstandAmt" decimal(10, 0) default 0 not null,
  "RepayPerMonDay" decimal(2, 0) default 0 not null,
  "ContractStartYM" decimal(6, 0) default 0 not null,
  "ContractEndYM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ044" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "DebtCode" varchar2(2),
  "NonGageAmt" decimal(9, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "ReceYearIncome" decimal(9, 0) default 0 not null,
  "ReceYear" decimal(4, 0) default 0 not null,
  "ReceYear2Income" decimal(9, 0) default 0 not null,
  "ReceYear2" decimal(4, 0) default 0 not null,
  "CurrentMonthIncome" decimal(9, 0) default 0 not null,
  "LivingCost" decimal(9, 0) default 0 not null,
  "CompName" nvarchar2(40),
  "CompId" varchar2(8),
  "CarCnt" decimal(2, 0) default 0 not null,
  "HouseCnt" decimal(2, 0) default 0 not null,
  "LandCnt" decimal(2, 0) default 0 not null,
  "ChildCnt" decimal(2, 0) default 0 not null,
  "ChildRate" decimal(5, 1) default 0 not null,
  "ParentCnt" decimal(2, 0) default 0 not null,
  "ParentRate" decimal(5, 1) default 0 not null,
  "MouthCnt" decimal(2, 0) default 0 not null,
  "MouthRate" decimal(5, 1) default 0 not null,
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ044Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DebtCode" varchar2(2),
  "NonGageAmt" decimal(9, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "ReceYearIncome" decimal(9, 0) default 0 not null,
  "ReceYear" decimal(4, 0) default 0 not null,
  "ReceYear2Income" decimal(9, 0) default 0 not null,
  "ReceYear2" decimal(4, 0) default 0 not null,
  "CurrentMonthIncome" decimal(9, 0) default 0 not null,
  "LivingCost" decimal(9, 0) default 0 not null,
  "CompName" nvarchar2(40),
  "CompId" varchar2(8),
  "CarCnt" decimal(2, 0) default 0 not null,
  "HouseCnt" decimal(2, 0) default 0 not null,
  "LandCnt" decimal(2, 0) default 0 not null,
  "ChildCnt" decimal(2, 0) default 0 not null,
  "ChildRate" decimal(5, 1) default 0 not null,
  "ParentCnt" decimal(2, 0) default 0 not null,
  "ParentRate" decimal(5, 1) default 0 not null,
  "MouthCnt" decimal(2, 0) default 0 not null,
  "MouthRate" decimal(5, 1) default 0 not null,
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ045" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "AgreeCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ045Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ046" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "CloseCode" varchar2(2),
  "BreakCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ046Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "BreakCode" varchar2(2),
  "CloseCode" varchar2(2),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ047" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "PassDate" decimal(8, 0) default 0 not null,
  "InterviewDate" decimal(8, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "LimitDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(38),
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ047Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "ExpLoanAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "CashCardAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "CreditCardAmt" decimal(9, 0) default 0 not null,
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "PassDate" decimal(8, 0) default 0 not null,
  "InterviewDate" decimal(8, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "LimitDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(38),
  "GradeType" varchar2(1),
  "PayLastAmt" decimal(9, 0) default 0 not null,
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "PayLastAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ048" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "CustRegAddr" nvarchar2(114),
  "CustComAddr" nvarchar2(114),
  "CustRegTelNo" varchar2(16),
  "CustComTelNo" varchar2(16),
  "CustMobilNo" varchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ048Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CustRegAddr" nvarchar2(114),
  "CustComAddr" nvarchar2(114),
  "CustRegTelNo" varchar2(16),
  "CustComTelNo" varchar2(16),
  "CustMobilNo" varchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ049" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ClaimStatus" decimal(1, 0) default 0 not null,
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(6),
  "CourtCaseNo" nvarchar2(20),
  "Approve" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ049Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ClaimStatus" decimal(1, 0) default 0 not null,
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(6),
  "CourtCaseNo" nvarchar2(20),
  "Approve" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ050" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "Status" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "SecondRepayYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ050Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "Status" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "SecondRepayYM" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ051" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "DelayCode" nvarchar2(1),
  "DelayYM" decimal(6, 0) default 0 not null,
  "DelayDesc" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ051Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DelayCode" nvarchar2(1),
  "DelayDesc" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ052" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "BankCode1" nvarchar2(3),
  "DataCode1" nvarchar2(2),
  "BankCode2" nvarchar2(3),
  "DataCode2" nvarchar2(2),
  "BankCode3" nvarchar2(3),
  "DataCode3" nvarchar2(2),
  "BankCode4" nvarchar2(3),
  "DataCode4" nvarchar2(2),
  "BankCode5" nvarchar2(3),
  "DataCode5" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ052Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "BankCode1" nvarchar2(3),
  "DataCode1" nvarchar2(2),
  "BankCode2" nvarchar2(3),
  "DataCode2" nvarchar2(2),
  "BankCode3" nvarchar2(3),
  "DataCode3" nvarchar2(2),
  "BankCode4" nvarchar2(3),
  "DataCode4" nvarchar2(2),
  "BankCode5" nvarchar2(3),
  "DataCode5" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ053" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "AgreeSend" varchar2(1),
  "AgreeSendData1" nvarchar2(2),
  "AgreeSendData2" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ053Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeSend" varchar2(1),
  "AgreeSendData1" nvarchar2(2),
  "AgreeSendData2" nvarchar2(2),
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ054" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ054Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayOffResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ055" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "CaseStatus" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayEndDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "IsImplement" varchar2(1),
  "InspectName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ055Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayEndDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "IsImplement" varchar2(1),
  "InspectName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ056" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "CaseStatus" varchar2(1),
  "ClaimDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "Approve" varchar2(1),
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "AdminName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ056Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Year" decimal(4, 0) default 0 not null,
  "CourtDiv" nvarchar2(4),
  "CourtCaseNo" nvarchar2(40),
  "Approve" varchar2(1),
  "OutstandAmt" decimal(9, 0) default 0 not null,
  "SubAmt" decimal(9, 0) default 0 not null,
  "ClaimStatus1" varchar2(1),
  "SaveDate" decimal(8, 0) default 0 not null,
  "ClaimStatus2" varchar2(1),
  "SaveEndDate" decimal(8, 0) default 0 not null,
  "AdminName" nvarchar2(10),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ060" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "YM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ060Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "YM" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ061" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "MaxMainCode" nvarchar2(3),
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "MaxMainNote" varchar2(1),
  "IsGuarantor" varchar2(1),
  "IsChangePayment" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ061Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "MaxMainNote" varchar2(1),
  "IsGuarantor" varchar2(1),
  "IsChangePayment" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ062" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "CompletePeriod" decimal(3, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "ChaRepayAmt" decimal(10, 0) default 0 not null,
  "ChaRepayAgreeDate" decimal(8, 0) default 0 not null,
  "ChaRepayViewDate" decimal(8, 0) default 0 not null,
  "ChaRepayEndDate" decimal(8, 0) default 0 not null,
  "ChaRepayFirstDate" decimal(8, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(76),
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "GradeType" varchar2(1),
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ062Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CompletePeriod" decimal(3, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "ExpBalanceAmt" decimal(9, 0) default 0 not null,
  "CashBalanceAmt" decimal(9, 0) default 0 not null,
  "CreditBalanceAmt" decimal(9, 0) default 0 not null,
  "ChaRepayAmt" decimal(10, 0) default 0 not null,
  "ChaRepayAgreeDate" decimal(8, 0) default 0 not null,
  "ChaRepayViewDate" decimal(8, 0) default 0 not null,
  "ChaRepayEndDate" decimal(8, 0) default 0 not null,
  "ChaRepayFirstDate" decimal(8, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "PostAddr" nvarchar2(76),
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "GradeType" varchar2(1),
  "Period2" decimal(3, 0) default 0 not null,
  "Rate2" decimal(5, 2) default 0 not null,
  "MonthPayAmt2" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ063" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "RcDate" decimal(8, 0) default 0 not null,
  "ChangePayDate" decimal(8, 0) default 0 not null,
  "ClosedDate" decimal(8, 0) default 0 not null,
  "ClosedResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ063Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ClosedDate" decimal(8, 0) default 0 not null,
  "ClosedResult" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ440" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "AgreeDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "RemindDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "ReportYn" varchar2(1),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ440Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AgreeDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "RemindDate" decimal(8, 0) default 0 not null,
  "ApplyType" varchar2(1),
  "ReportYn" varchar2(1),
  "NotBankId1" nvarchar2(3),
  "NotBankId2" nvarchar2(3),
  "NotBankId3" nvarchar2(3),
  "NotBankId4" nvarchar2(3),
  "NotBankId5" nvarchar2(3),
  "NotBankId6" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ442" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "IsMaxMain" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "Civil323GuarAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "GuarObliPrin" decimal(9, 0) default 0 not null,
  "GuarObliInte" decimal(9, 0) default 0 not null,
  "GuarObliPena" decimal(9, 0) default 0 not null,
  "GuarObliOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ442Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsMaxMain" varchar2(1),
  "IsClaims" varchar2(1),
  "GuarLoanCnt" decimal(2, 0) default 0 not null,
  "Civil323ExpAmt" decimal(9, 0) default 0 not null,
  "Civil323CashAmt" decimal(9, 0) default 0 not null,
  "Civil323CreditAmt" decimal(9, 0) default 0 not null,
  "Civil323GuarAmt" decimal(9, 0) default 0 not null,
  "ReceExpPrin" decimal(9, 0) default 0 not null,
  "ReceExpInte" decimal(9, 0) default 0 not null,
  "ReceExpPena" decimal(9, 0) default 0 not null,
  "ReceExpOther" decimal(9, 0) default 0 not null,
  "CashCardPrin" decimal(9, 0) default 0 not null,
  "CashCardInte" decimal(9, 0) default 0 not null,
  "CashCardPena" decimal(9, 0) default 0 not null,
  "CashCardOther" decimal(9, 0) default 0 not null,
  "CreditCardPrin" decimal(9, 0) default 0 not null,
  "CreditCardInte" decimal(9, 0) default 0 not null,
  "CreditCardPena" decimal(9, 0) default 0 not null,
  "CreditCardOther" decimal(9, 0) default 0 not null,
  "GuarObliPrin" decimal(9, 0) default 0 not null,
  "GuarObliInte" decimal(9, 0) default 0 not null,
  "GuarObliPena" decimal(9, 0) default 0 not null,
  "GuarObliOther" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ443" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "IsMaxMain" varchar2(1),
  "Account" nvarchar2(50),
  "GuarantyType" nvarchar2(2),
  "LoanAmt" decimal(12, 0) default 0 not null,
  "CreditAmt" decimal(12, 0) default 0 not null,
  "Principal" decimal(10, 0) default 0 not null,
  "Interest" decimal(10, 0) default 0 not null,
  "Penalty" decimal(10, 0) default 0 not null,
  "Other" decimal(10, 0) default 0 not null,
  "TerminalPayAmt" decimal(10, 0) default 0 not null,
  "LatestPayAmt" decimal(10, 0) default 0 not null,
  "FinalPayDay" decimal(8, 0) default 0 not null,
  "NotyetacQuit" decimal(10, 0) default 0 not null,
  "MothPayDay" decimal(2, 0) default 0 not null,
  "BeginDate" decimal(6, 0) default 0 not null,
  "EndDate" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);









create table "JcicZ443Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "IsMaxMain" varchar2(1),
  "Account" nvarchar2(50),
  "GuarantyType" nvarchar2(2),
  "LoanAmt" decimal(12, 0) default 0 not null,
  "CreditAmt" decimal(12, 0) default 0 not null,
  "Principal" decimal(10, 0) default 0 not null,
  "Interest" decimal(10, 0) default 0 not null,
  "Penalty" decimal(10, 0) default 0 not null,
  "Other" decimal(10, 0) default 0 not null,
  "TerminalPayAmt" decimal(10, 0) default 0 not null,
  "LatestPayAmt" decimal(10, 0) default 0 not null,
  "FinalPayDay" decimal(8, 0) default 0 not null,
  "NotyetacQuit" decimal(10, 0) default 0 not null,
  "MothPayDay" decimal(2, 0) default 0 not null,
  "BeginDate" decimal(6, 0) default 0 not null,
  "EndDate" decimal(6, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ444" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "CustRegAddr" nvarchar2(76),
  "CustComAddr" nvarchar2(76),
  "CustRegTelNo" nvarchar2(16),
  "CustComTelNo" nvarchar2(16),
  "CustMobilNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ444Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CustRegAddr" nvarchar2(76),
  "CustComAddr" nvarchar2(76),
  "CustRegTelNo" nvarchar2(16),
  "CustComTelNo" nvarchar2(16),
  "CustMobilNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ446" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "CloseCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ446Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CloseCode" varchar2(2),
  "CloseDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ447" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ447Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "Civil323Amt" decimal(10, 0) default 0 not null,
  "TotalAmt" decimal(10, 0) default 0 not null,
  "SignDate" decimal(8, 0) default 0 not null,
  "FirstPayDate" decimal(8, 0) default 0 not null,
  "Period" decimal(3, 0) default 0 not null,
  "Rate" decimal(5, 2) default 0 not null,
  "MonthPayAmt" decimal(9, 0) default 0 not null,
  "PayAccount" nvarchar2(20),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ448" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "SignPrin" decimal(9, 0) default 0 not null,
  "SignOther" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "AcQuitAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ448Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "SignPrin" decimal(9, 0) default 0 not null,
  "SignOther" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "AcQuitAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ450" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "PayStatus" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ450Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "SumRepayActualAmt" decimal(9, 0) default 0 not null,
  "SumRepayShouldAmt" decimal(9, 0) default 0 not null,
  "PayStatus" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ451" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "DelayYM" decimal(6, 0) default 0 not null,
  "DelayCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ451Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "DelayCode" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ454" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CourtCode" nvarchar2(3),
  "MaxMainCode" nvarchar2(3),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ454Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayOffResult" varchar2(1),
  "PayOffDate" decimal(8, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ570" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "AdjudicateDate" decimal(8, 0) default 0 not null,
  "BankCount" decimal(2, 0) default 0 not null,
  "Bank1" nvarchar2(3),
  "Bank2" nvarchar2(3),
  "Bank3" nvarchar2(3),
  "Bank4" nvarchar2(3),
  "Bank5" nvarchar2(3),
  "Bank6" nvarchar2(3),
  "Bank7" nvarchar2(3),
  "Bank8" nvarchar2(3),
  "Bank9" nvarchar2(3),
  "Bank10" nvarchar2(3),
  "Bank11" nvarchar2(3),
  "Bank12" nvarchar2(3),
  "Bank13" nvarchar2(3),
  "Bank14" nvarchar2(3),
  "Bank15" nvarchar2(3),
  "Bank16" nvarchar2(3),
  "Bank17" nvarchar2(3),
  "Bank18" nvarchar2(3),
  "Bank19" nvarchar2(3),
  "Bank20" nvarchar2(3),
  "Bank21" nvarchar2(3),
  "Bank22" nvarchar2(3),
  "Bank23" nvarchar2(3),
  "Bank24" nvarchar2(3),
  "Bank25" nvarchar2(3),
  "Bank26" nvarchar2(3),
  "Bank27" nvarchar2(3),
  "Bank28" nvarchar2(3),
  "Bank29" nvarchar2(3),
  "Bank30" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ570Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "AdjudicateDate" decimal(8, 0) default 0 not null,
  "BankCount" decimal(2, 0) default 0 not null,
  "Bank1" nvarchar2(3),
  "Bank2" nvarchar2(3),
  "Bank3" nvarchar2(3),
  "Bank4" nvarchar2(3),
  "Bank5" nvarchar2(3),
  "Bank6" nvarchar2(3),
  "Bank7" nvarchar2(3),
  "Bank8" nvarchar2(3),
  "Bank9" nvarchar2(3),
  "Bank10" nvarchar2(3),
  "Bank11" nvarchar2(3),
  "Bank12" nvarchar2(3),
  "Bank13" nvarchar2(3),
  "Bank14" nvarchar2(3),
  "Bank15" nvarchar2(3),
  "Bank16" nvarchar2(3),
  "Bank17" nvarchar2(3),
  "Bank18" nvarchar2(3),
  "Bank19" nvarchar2(3),
  "Bank20" nvarchar2(3),
  "Bank21" nvarchar2(3),
  "Bank22" nvarchar2(3),
  "Bank23" nvarchar2(3),
  "Bank24" nvarchar2(3),
  "Bank25" nvarchar2(3),
  "Bank26" nvarchar2(3),
  "Bank27" nvarchar2(3),
  "Bank28" nvarchar2(3),
  "Bank29" nvarchar2(3),
  "Bank30" nvarchar2(3),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ571" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "BankId" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "OwnerYn" varchar2(1),
  "PayYn" varchar2(1),
  "OwnerAmt" decimal(9, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "UnallotAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ571Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "OwnerYn" varchar2(1),
  "PayYn" varchar2(1),
  "OwnerAmt" decimal(9, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "UnallotAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ572" (
  "TranKey" varchar2(1),
  "SubmitKey" nvarchar2(3),
  "CustId" varchar2(10),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "StartDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "BankId" nvarchar2(3),
  "AllotAmt" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);








create table "JcicZ572Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "StartDate" decimal(8, 0) default 0 not null,
  "AllotAmt" decimal(9, 0) default 0 not null,
  "OwnPercentage" decimal(6, 2) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ573" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "PayDate" decimal(8, 0) default 0 not null,
  "PayAmt" decimal(9, 0) default 0 not null,
  "TotalPayAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ573Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "PayAmt" decimal(9, 0) default 0 not null,
  "TotalPayAmt" decimal(9, 0) default 0 not null,
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ574" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseMark" varchar2(2),
  "PhoneNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);






create table "JcicZ574Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "CloseDate" decimal(8, 0) default 0 not null,
  "CloseMark" varchar2(2),
  "PhoneNo" nvarchar2(16),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JcicZ575" (
  "TranKey" varchar2(1),
  "CustId" varchar2(10),
  "SubmitKey" nvarchar2(3),
  "ApplyDate" decimal(8, 0) default 0 not null,
  "BankId" nvarchar2(3),
  "ModifyType" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "Ukey" varchar2(32),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "JcicZ575Log" (
  "Ukey" varchar2(32),
  "TxSeq" varchar2(18),
  "TranKey" varchar2(1),
  "ModifyType" varchar2(1),
  "OutJcicTxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "JobDetail" (
  "ExecDate" decimal(8, 0) default 0 not null,
  "JobCode" varchar2(10),
  "StepId" varchar2(30),
  "BatchType" varchar2(1),
  "Status" varchar2(1),
  "ErrCode" varchar2(15),
  "ErrContent" clob,
  "StepStartTime" timestamp,
  "StepEndTime" timestamp,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);




create table "JobMain" (
  "ExecDate" decimal(8, 0) default 0 not null,
  "JobCode" varchar2(10),
  "StartTime" timestamp,
  "EndTime" timestamp,
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);



create table "LoanBook" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BookDate" decimal(8, 0) default 0 not null,
  "ActualDate" decimal(8, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "IncludeIntFlag" varchar2(1),
  "UnpaidIntFlag" varchar2(1),
  "BookAmt" decimal(16, 2) default 0 not null,
  "RepayAmt" decimal(16, 2) default 0 not null,
  "PayMethod" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "LoanBorMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LastBorxNo" decimal(4, 0) default 0 not null,
  "LastOvduNo" decimal(3, 0) default 0 not null,
  "Status" decimal(2, 0) default 0 not null,
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "ApproveRate" decimal(6, 4) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "RateCode" varchar2(1),
  "RateAdjFreq" decimal(2, 0) default 0 not null,
  "DrawdownCode" varchar2(1),
  "CurrencyCode" varchar2(3),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "LoanTermYy" decimal(2, 0) default 0 not null,
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "IntCalcCode" varchar2(1),
  "AmortizedCode" varchar2(1),
  "FreqBase" decimal(1, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "PaidTerms" decimal(3, 0) default 0 not null,
  "PrevPayIntDate" decimal(8, 0) default 0 not null,
  "PrevRepaidDate" decimal(8, 0) default 0 not null,
  "NextPayIntDate" decimal(8, 0) default 0 not null,
  "NextRepayDate" decimal(8, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "GraceDate" decimal(8, 0) default 0 not null,
  "SpecificDd" decimal(2, 0) default 0 not null,
  "SpecificDate" decimal(8, 0) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "FirstAdjRateDate" decimal(8, 0) default 0 not null,
  "NextAdjRateDate" decimal(8, 0) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "HandlingFee" decimal(16, 2) default 0 not null,
  "FinalBal" decimal(16, 2) default 0 not null,
  "NotYetFlag" varchar2(1),
  "RenewFlag" varchar2(1),
  "PieceCode" varchar2(1),
  "PieceCodeSecond" varchar2(1),
  "PieceCodeSecondAmt" decimal(16, 2) default 0 not null,
  "UsageCode" varchar2(2),
  "SyndNo" decimal(3, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelationName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelationBirthday" decimal(8, 0) default 0 not null,
  "RelationGender" varchar2(1),
  "ActFg" decimal(1, 0) default 0 not null,
  "LastEntDy" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "RemitBank" varchar2(3),
  "RemitBranch" varchar2(4),
  "RemitAcctNo" decimal(14, 0) default 0 not null,
  "CompensateAcct" nvarchar2(60),
  "PaymentBank" varchar2(7),
  "Remark" nvarchar2(40),
  "AcDate" decimal(8, 0) default 0 not null,
  "NextAcDate" decimal(8, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "LoanBorTx" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BorxNo" decimal(4, 0) default 0 not null,
  "TitaCalDy" decimal(8, 0) default 0 not null,
  "TitaCalTm" decimal(8, 0) default 0 not null,
  "TitaKinBr" varchar2(4),
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" varchar2(8),
  "TitaTxCd" varchar2(5),
  "TitaCrDb" varchar2(1),
  "TitaHCode" varchar2(1),
  "TitaCurCd" varchar2(3),
  "TitaEmpNoS" varchar2(6),
  "RepayCode" decimal(2, 0) default 0 not null,
  "Desc" nvarchar2(15),
  "AcDate" decimal(8, 0) default 0 not null,
  "CorrectSeq" varchar2(26),
  "Displayflag" varchar2(1),
  "EntryDate" decimal(8, 0) default 0 not null,
  "DueDate" decimal(8, 0) default 0 not null,
  "TxAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "Rate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "CloseBreachAmt" decimal(16, 2) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "ExtraRepay" decimal(16, 2) default 0 not null,
  "UnpaidInterest" decimal(16, 2) default 0 not null,
  "UnpaidPrincipal" decimal(16, 2) default 0 not null,
  "UnpaidCloseBreach" decimal(16, 2) default 0 not null,
  "Shortfall" decimal(16, 2) default 0 not null,
  "Overflow" decimal(16, 2) default 0 not null,
  "OtherFields" varchar2(2000),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanCheque" (
  "CustNo" decimal(7, 0) default 0 not null,
  "ChequeAcct" decimal(9, 0) default 0 not null,
  "ChequeNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(1),
  "ProcessCode" varchar2(1),
  "AcDate" decimal(8, 0) default 0 not null,
  "Kinbr" varchar2(4),
  "TellerNo" varchar2(6),
  "TxtNo" varchar2(8),
  "ReceiveDate" decimal(8, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "ChequeAmt" decimal(16, 2) default 0 not null,
  "ChequeName" varchar2(60),
  "ChequeDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(2),
  "BankCode" varchar2(7),
  "OutsideCode" varchar2(1),
  "BktwFlag" varchar2(1),
  "TsibFlag" varchar2(1),
  "MediaFlag" varchar2(1),
  "UsageCode" varchar2(2),
  "ServiceCenter" varchar2(1),
  "CreditorId" varchar2(10),
  "CreditorBankCode" varchar2(7),
  "OtherAcctCode" varchar2(3),
  "ReceiptNo" varchar2(5),
  "RepaidAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsAp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "FacLineDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "Rate" decimal(8, 6) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "AssetClass" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "AvblBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "TempAmt" decimal(16, 2) default 0 not null,
  "AcCurcd" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "CurrencyCode" varchar2(4),
  "ExchangeRate" decimal(8, 5) default 0 not null,
  "LineAmtCurr" decimal(16, 2) default 0 not null,
  "DrawdownAmtCurr" decimal(16, 2) default 0 not null,
  "AcctFeeCurr" decimal(16, 2) default 0 not null,
  "LoanBalCurr" decimal(16, 2) default 0 not null,
  "IntAmtCurr" decimal(16, 2) default 0 not null,
  "FeeCurr" decimal(16, 2) default 0 not null,
  "AvblBalCurr" decimal(16, 2) default 0 not null,
  "TempAmtCurr" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsBp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "LoanRate" decimal(8, 6) default 0 not null,
  "RateCode" decimal(1, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsCp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayFreq" decimal(2, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsDp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "DataFg" decimal(1, 0) default 0 not null,
  "AcCode" varchar2(11),
  "Status" decimal(1, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "OvduDays" decimal(3, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "DerDate" decimal(8, 0) default 0 not null,
  "DerRate" decimal(6, 4) default 0 not null,
  "DerLoanBal" decimal(16, 2) default 0 not null,
  "DerIntAmt" decimal(16, 2) default 0 not null,
  "DerFee" decimal(16, 2) default 0 not null,
  "DerY1Amt" decimal(16, 2) default 0 not null,
  "DerY2Amt" decimal(16, 2) default 0 not null,
  "DerY3Amt" decimal(16, 2) default 0 not null,
  "DerY4Amt" decimal(16, 2) default 0 not null,
  "DerY5Amt" decimal(16, 2) default 0 not null,
  "DerY1Int" decimal(16, 2) default 0 not null,
  "DerY2Int" decimal(16, 2) default 0 not null,
  "DerY3Int" decimal(16, 2) default 0 not null,
  "DerY4Int" decimal(16, 2) default 0 not null,
  "DerY5Int" decimal(16, 2) default 0 not null,
  "DerY1Fee" decimal(16, 2) default 0 not null,
  "DerY2Fee" decimal(16, 2) default 0 not null,
  "DerY3Fee" decimal(16, 2) default 0 not null,
  "DerY4Fee" decimal(16, 2) default 0 not null,
  "DerY5Fee" decimal(16, 2) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "AreaCode" varchar2(3),
  "ProdCode" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsFp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "AgreeNo" decimal(3, 0) default 0 not null,
  "AgreeFg" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsGp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "CustKind" decimal(1, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "OvduDate" decimal(8, 0) default 0 not null,
  "OriRating" varchar2(1),
  "OriModel" varchar2(1),
  "Rating" varchar2(1),
  "Model" varchar2(1),
  "OvduDays" decimal(4, 0) default 0 not null,
  "Stage1" decimal(1, 0) default 0 not null,
  "Stage2" decimal(1, 0) default 0 not null,
  "Stage3" decimal(1, 0) default 0 not null,
  "Stage4" decimal(1, 0) default 0 not null,
  "Stage5" decimal(1, 0) default 0 not null,
  "PdFlagToD" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsHp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "CustKind" decimal(1, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "IfrsProdCode" varchar2(2),
  "AvblBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "IndustryCode" varchar2(10),
  "OriRating" varchar2(1),
  "OriModel" varchar2(1),
  "Rating" varchar2(1),
  "Model" varchar2(1),
  "LGDModel" decimal(2, 0) default 0 not null,
  "LGD" decimal(10, 8) default 0 not null,
  "LineAmtCurr" decimal(16, 2) default 0 not null,
  "AvblBalCurr" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsIp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "FacmNo" decimal(3, 0) default 0 not null,
  "ApplNo" decimal(7, 0) default 0 not null,
  "DrawdownFg" decimal(1, 0) default 0 not null,
  "ApproveDate" decimal(8, 0) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "LineAmt" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "Fee" decimal(16, 2) default 0 not null,
  "ApproveRate" decimal(8, 6) default 0 not null,
  "GracePeriod" decimal(3, 0) default 0 not null,
  "AmortizedCode" varchar2(1),
  "RateCode" varchar2(1),
  "RepayFreq" decimal(2, 0) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "IndustryCode" varchar2(6),
  "ClTypeJCIC" varchar2(2),
  "CityCode" varchar2(3),
  "ProdNo" varchar2(5),
  "CustKind" decimal(1, 0) default 0 not null,
  "IfrsProdCode" varchar2(1),
  "EvaAmt" decimal(16, 2) default 0 not null,
  "AvblBal" decimal(16, 2) default 0 not null,
  "RecycleCode" varchar2(1),
  "IrrevocableFlag" varchar2(1),
  "LoanTerm" varchar2(8),
  "AcCode" varchar2(11),
  "AcCurcd" decimal(1, 0) default 0 not null,
  "AcBookCode" varchar2(1),
  "CurrencyCode" varchar2(4),
  "ExchangeRate" decimal(10, 8) default 0 not null,
  "LineAmtCurr" decimal(16, 2) default 0 not null,
  "AcctFeeCurr" decimal(16, 2) default 0 not null,
  "FeeCurr" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIfrsJp" (
  "DataYM" decimal(6, 0) default 0 not null,
  "AcDateYM" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "NewFacmNo" decimal(3, 0) default 0 not null,
  "NewBormNo" decimal(3, 0) default 0 not null,
  "OldFacmNo" decimal(3, 0) default 0 not null,
  "OldBormNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanIntDetail" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "TlrNo" varchar2(6),
  "TxtNo" varchar2(8),
  "IntSeq" decimal(3, 0) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "IntDays" decimal(5, 0) default 0 not null,
  "BreachDays" decimal(5, 0) default 0 not null,
  "MonthLimit" decimal(2, 0) default 0 not null,
  "IntFlag" decimal(1, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "Amount" decimal(16, 2) default 0 not null,
  "IntRate" decimal(6, 4) default 0 not null,
  "Principal" decimal(16, 2) default 0 not null,
  "Interest" decimal(16, 2) default 0 not null,
  "DelayInt" decimal(16, 2) default 0 not null,
  "BreachAmt" decimal(16, 2) default 0 not null,
  "CloseBreachAmt" decimal(16, 2) default 0 not null,
  "BreachGetCode" varchar2(1),
  "LoanBal" decimal(16, 2) default 0 not null,
  "ExtraRepayFlag" decimal(1, 0) default 0 not null,
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "LoanNotYet" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "NotYetCode" varchar2(2),
  "NotYetItem" nvarchar2(40),
  "YetDate" decimal(8, 0) default 0 not null,
  "CloseDate" decimal(8, 0) default 0 not null,
  "ReMark" nvarchar2(80),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "LoanOverdue" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "OvduNo" decimal(3, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "OvduDate" decimal(8, 0) default 0 not null,
  "BadDebtDate" decimal(8, 0) default 0 not null,
  "ReplyDate" decimal(8, 0) default 0 not null,
  "OvduPrinAmt" decimal(16, 2) default 0 not null,
  "OvduIntAmt" decimal(16, 2) default 0 not null,
  "OvduBreachAmt" decimal(16, 2) default 0 not null,
  "OvduAmt" decimal(16, 2) default 0 not null,
  "OvduPrinBal" decimal(16, 2) default 0 not null,
  "OvduIntBal" decimal(16, 2) default 0 not null,
  "OvduBreachBal" decimal(16, 2) default 0 not null,
  "OvduBal" decimal(16, 2) default 0 not null,
  "ReduceInt" decimal(16, 2) default 0 not null,
  "ReduceBreach" decimal(16, 2) default 0 not null,
  "BadDebtAmt" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "ReplyReduceAmt" decimal(16, 2) default 0 not null,
  "ProcessDate" decimal(8, 0) default 0 not null,
  "OvduSituaction" nvarchar2(30),
  "Remark" nvarchar2(60),
  "AcDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "LoanRateChange" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "EffectDate" decimal(8, 0) default 0 not null,
  "Status" decimal(1, 0) default 0 not null,
  "RateCode" varchar2(1),
  "ProdNo" varchar2(5),
  "BaseRateCode" varchar2(2),
  "IncrFlag" varchar2(1),
  "RateIncr" decimal(6, 4) default 0 not null,
  "IndividualIncr" decimal(6, 4) default 0 not null,
  "FitRate" decimal(6, 4) default 0 not null,
  "Remark" nvarchar2(60),
  "AcDate" decimal(8, 0) default 0 not null,
  "TellerNo" varchar2(6),
  "TxtNo" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "LoanSynd" (
  "SyndNo" decimal(6, 0) default 0 not null,
  "LeadingBank" varchar2(7),
  "AgentBank" varchar2(7),
  "SigningDate" decimal(8, 0) default 0 not null,
  "SyndTypeCodeFlag" varchar2(1),
  "PartRate" decimal(6, 4) default 0 not null,
  "CurrencyCode" varchar2(3),
  "SyndAmt" decimal(16, 2) default 0 not null,
  "PartAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "LoanSyndItem" (
  "SyndNo" decimal(6, 0) default 0 not null,
  "SyndSeq" decimal(3, 0) default 0 not null,
  "Item" varchar2(10),
  "SyndAmt" decimal(16, 2) default 0 not null,
  "SyndMark" nvarchar2(40),
  "SyndBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MlaundryChkDtl" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "Factor" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "DtlSeq" decimal(4, 0) default 0 not null,
  "DtlEntryDate" decimal(8, 0) default 0 not null,
  "RepayItem" nvarchar2(10),
  "DscptCode" varchar2(4),
  "TxAmt" decimal(16, 2) default 0 not null,
  "TotalCnt" decimal(3, 0) default 0 not null,
  "TotalAmt" decimal(16, 2) default 0 not null,
  "StartEntryDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MlaundryDetail" (
  "EntryDate" decimal(8, 0) default 0 not null,
  "Factor" decimal(2, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "TotalCnt" decimal(4, 0) default 0 not null,
  "TotalAmt" decimal(16, 2) default 0 not null,
  "Rational" varchar2(1),
  "EmpNoDesc" nvarchar2(50),
  "ManagerCheck" varchar2(1),
  "ManagerDate" decimal(8, 0) default 0 not null,
  "ManagerCheckDate" decimal(8, 0) default 0 not null,
  "ManagerDesc" nvarchar2(50),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MlaundryParas" (
  "BusinessType" varchar2(2),
  "Factor1TotLimit" decimal(16, 2) default 0 not null,
  "Factor2Count" decimal(4, 0) default 0 not null,
  "Factor2AmtStart" decimal(16, 2) default 0 not null,
  "Factor2AmtEnd" decimal(16, 2) default 0 not null,
  "Factor3TotLimit" decimal(16, 2) default 0 not null,
  "FactorDays" decimal(3, 0) default 0 not null,
  "FactorDays3" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MlaundryRecord" (
  "RecordDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayDate" decimal(8, 0) default 0 not null,
  "ActualRepayDate" decimal(8, 0) default 0 not null,
  "RepayAmt" decimal(16, 2) default 0 not null,
  "ActualRepayAmt" decimal(16, 2) default 0 not null,
  "Career" nvarchar2(20),
  "Income" nvarchar2(30),
  "RepaySource" decimal(2, 0) default 0 not null,
  "RepayBank" nvarchar2(10),
  "Description" nvarchar2(60),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyFacBal" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "PrevIntDate" decimal(8, 0) default 0 not null,
  "NextIntDate" decimal(8, 0) default 0 not null,
  "DueDate" decimal(8, 0) default 0 not null,
  "OvduTerm" decimal(3, 0) default 0 not null,
  "OvduDays" decimal(6, 0) default 0 not null,
  "CurrencyCode" varchar2(3),
  "PrinBalance" decimal(16, 2) default 0 not null,
  "BadDebtBal" decimal(16, 2) default 0 not null,
  "AccCollPsn" varchar2(6),
  "LegalPsn" varchar2(6),
  "Status" decimal(2, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "ClCustNo" decimal(7, 0) default 0 not null,
  "ClFacmNo" decimal(3, 0) default 0 not null,
  "ClRowNo" decimal(3, 0) default 0 not null,
  "RenewCode" varchar2(1),
  "ProdNo" varchar2(5),
  "AcBookCode" varchar2(3),
  "EntCode" varchar2(1),
  "RelsCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "UnpaidPrincipal" decimal(16, 2) default 0 not null,
  "UnpaidInterest" decimal(16, 2) default 0 not null,
  "UnpaidBreachAmt" decimal(16, 2) default 0 not null,
  "UnpaidDelayInt" decimal(16, 2) default 0 not null,
  "AcdrPrincipal" decimal(16, 2) default 0 not null,
  "AcdrInterest" decimal(16, 2) default 0 not null,
  "AcdrBreachAmt" decimal(16, 2) default 0 not null,
  "AcdrDelayInt" decimal(16, 2) default 0 not null,
  "FireFee" decimal(16, 2) default 0 not null,
  "LawFee" decimal(16, 2) default 0 not null,
  "ModifyFee" decimal(16, 2) default 0 not null,
  "AcctFee" decimal(16, 2) default 0 not null,
  "ShortfallPrin" decimal(16, 2) default 0 not null,
  "ShortfallInt" decimal(16, 2) default 0 not null,
  "TempAmt" decimal(16, 2) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "OvduDate" decimal(8, 0) default 0 not null,
  "OvduPrinBal" decimal(16, 2) default 0 not null,
  "OvduIntBal" decimal(16, 2) default 0 not null,
  "OvduBreachBal" decimal(16, 2) default 0 not null,
  "OvduBal" decimal(16, 2) default 0 not null,
  "LawAmount" decimal(16, 2) default 0 not null,
  "AssetClass" varchar2(2),
  "StoreRate" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "AcSubBookCode" varchar2(3)
);



create table "MonthlyLM003" (
  "EntType" decimal(1, 0) default 0 not null,
  "DataYear" decimal(4, 0) default 0 not null,
  "DataMonth" decimal(2, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "CloseLoan" decimal(16, 2) default 0 not null,
  "CloseSale" decimal(16, 2) default 0 not null,
  "CloseSelfRepay" decimal(16, 2) default 0 not null,
  "ExtraRepay" decimal(16, 2) default 0 not null,
  "PrincipalAmortize" decimal(16, 2) default 0 not null,
  "Collection" decimal(16, 2) default 0 not null,
  "LoanBalance" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLM028" (
  "DataMonth" decimal(6, 0) default 0 not null,
  "Status" decimal(2, 0) default 0 not null,
  "EntCode" decimal(1, 0) default 0 not null,
  "BranchNo" varchar2(4),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "PayIntFreq" decimal(2, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "LoanTermMm" decimal(2, 0) default 0 not null,
  "LoanTermDd" decimal(3, 0) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "RateCode" varchar2(1),
  "PostDepCode" varchar2(1),
  "SpecificDd" decimal(2, 0) default 0 not null,
  "FirstRateAdjFreq" decimal(2, 0) default 0 not null,
  "BaseRateCode" varchar2(2),
  "FitRate1" decimal(6, 4) default 0 not null,
  "FitRate2" decimal(6, 4) default 0 not null,
  "FitRate3" decimal(6, 4) default 0 not null,
  "FitRate4" decimal(6, 4) default 0 not null,
  "FitRate5" decimal(6, 4) default 0 not null,
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "DrawdownYear" decimal(4, 0) default 0 not null,
  "DrawdownMonth" decimal(2, 0) default 0 not null,
  "DrawdownDay" decimal(2, 0) default 0 not null,
  "W08Code" decimal(1, 0) default 0 not null,
  "IsRelation" varchar2(1),
  "AgType1" varchar2(1),
  "AcctSource" varchar2(1),
  "LastestRate" decimal(6, 4) default 0 not null,
  "LastestRateStartDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLM032" (
  "ADTYMT" decimal(6, 0) default 0 not null,
  "GDRID1" decimal(1, 0) default 0 not null,
  "W08PPR" decimal(5, 0) default 0 not null,
  "LMSACN" decimal(7, 0) default 0 not null,
  "LMSAPN" decimal(3, 0) default 0 not null,
  "W08LBL" decimal(16, 2) default 0 not null,
  "W08DLY" decimal(5, 0) default 0 not null,
  "STATUS" nvarchar2(2),
  "ADTYMT01" decimal(6, 0) default 0 not null,
  "GDRID101" decimal(1, 0) default 0 not null,
  "W08PPR01" decimal(5, 0) default 0 not null,
  "LMSACN01" decimal(7, 0) default 0 not null,
  "LMSAPN01" decimal(3, 0) default 0 not null,
  "W08LBL01" decimal(16, 2) default 0 not null,
  "W08DLY01" decimal(5, 0) default 0 not null,
  "ACTACT" varchar2(3),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLM036Portfolio" (
  "DataMonth" decimal(6, 0) default 0 not null,
  "MonthEndDate" decimal(8, 0) default 0 not null,
  "PortfolioTotal" decimal(16, 2) default 0 not null,
  "NaturalPersonLoanBal" decimal(16, 2) default 0 not null,
  "LegalPersonLoanBal" decimal(16, 2) default 0 not null,
  "SyndLoanBal" decimal(16, 2) default 0 not null,
  "StockLoanBal" decimal(16, 2) default 0 not null,
  "OtherLoanbal" decimal(16, 2) default 0 not null,
  "AmortizeTotal" decimal(16, 2) default 0 not null,
  "OvduExpense" decimal(16, 2) default 0 not null,
  "NaturalPersonLargeCounts" decimal(16, 0) default 0 not null,
  "NaturalPersonLargeTotal" decimal(16, 2) default 0 not null,
  "LegalPersonLargeCounts" decimal(16, 0) default 0 not null,
  "LegalPersonLargeTotal" decimal(16, 2) default 0 not null,
  "NaturalPersonPercent" decimal(6, 4) default 0 not null,
  "LegalPersonPercent" decimal(6, 4) default 0 not null,
  "SyndPercent" decimal(6, 4) default 0 not null,
  "StockPercent" decimal(6, 4) default 0 not null,
  "OtherPercent" decimal(6, 4) default 0 not null,
  "EntUsedPercent" decimal(6, 4) default 0 not null,
  "InsuDividendRate" decimal(6, 4) default 0 not null,
  "NaturalPersonRate" decimal(6, 4) default 0 not null,
  "LegalPersonRate" decimal(6, 4) default 0 not null,
  "SyndRate" decimal(6, 4) default 0 not null,
  "StockRate" decimal(6, 4) default 0 not null,
  "OtherRate" decimal(6, 4) default 0 not null,
  "AvgRate" decimal(6, 4) default 0 not null,
  "HouseRateOfReturn" decimal(6, 4) default 0 not null,
  "EntRateOfReturn" decimal(6, 4) default 0 not null,
  "RateOfReturn" decimal(6, 4) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLM052AssetClass" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "AssetClassNo" varchar2(2),
  "AcSubBookCode" varchar2(3),
  "LoanBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLM052LoanAsset" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "LoanAssetCode" varchar2(3),
  "LoanBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLM052Ovdu" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "OvduNo" varchar2(1),
  "AcctCode" varchar2(3),
  "LoanBal" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "MonthlyLoanBal" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "AcctCode" varchar2(3),
  "FacAcctCode" varchar2(3),
  "CurrencyCode" varchar2(3),
  "LoanBalance" decimal(16, 2) default 0 not null,
  "MaxLoanBal" decimal(16, 2) default 0 not null,
  "StoreRate" decimal(6, 4) default 0 not null,
  "IntAmtRcv" decimal(16, 2) default 0 not null,
  "IntAmtAcc" decimal(16, 2) default 0 not null,
  "UnpaidInt" decimal(16, 2) default 0 not null,
  "UnexpiredInt" decimal(16, 2) default 0 not null,
  "SumRcvInt" decimal(16, 2) default 0 not null,
  "IntAmt" decimal(16, 2) default 0 not null,
  "ProdNo" varchar2(5),
  "AcBookCode" varchar2(3),
  "EntCode" varchar2(1),
  "RelsCode" varchar2(2),
  "DepartmentCode" varchar2(1),
  "ClCode1" decimal(1, 0) default 0 not null,
  "ClCode2" decimal(2, 0) default 0 not null,
  "ClNo" decimal(7, 0) default 0 not null,
  "CityCode" varchar2(2),
  "OvduPrinAmt" decimal(16, 2) default 0 not null,
  "OvduIntAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "AcSubBookCode" varchar2(3)
);



create table "MonthlyQ53" (
  "DataYM" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegAppr" (
  "YyyyMm" decimal(6, 0) default 0 not null,
  "KindCode" decimal(1, 0) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ApprAcDate" decimal(8, 0) default 0 not null,
  "BringUpDate" decimal(8, 0) default 0 not null,
  "ExportMark" decimal(1, 0) default 0 not null,
  "ApprAcMark" decimal(1, 0) default 0 not null,
  "BringUpMark" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegAppr01" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "FinCode" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "CaseKindCode" varchar2(1),
  "ApprAmt" decimal(16, 2) default 0 not null,
  "AccuApprAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ApprDate" decimal(8, 0) default 0 not null,
  "BringUpDate" decimal(8, 0) default 0 not null,
  "RemitBank" varchar2(7),
  "RemitAcct" varchar2(16),
  "DataSendUnit" varchar2(8),
  "ApprAcDate" decimal(8, 0) default 0 not null,
  "ReplyCode" varchar2(4),
  "BatchTxtNo" varchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegAppr02" (
  "BringUpDate" decimal(8, 0) default 0 not null,
  "FinCode" varchar2(8),
  "TxSeq" varchar2(10),
  "SendUnit" varchar2(8),
  "RecvUnit" varchar2(8),
  "EntryDate" decimal(8, 0) default 0 not null,
  "TransCode" varchar2(5),
  "TxAmt" decimal(16, 2) default 0 not null,
  "Consign" varchar2(8),
  "FinIns" varchar2(7),
  "RemitAcct" varchar2(16),
  "CustId" varchar2(10),
  "CustNo" decimal(7, 0) default 0 not null,
  "StatusCode" varchar2(4),
  "AcDate" decimal(8, 0) default 0 not null,
  "TxKind" varchar2(1),
  "TxStatus" decimal(1, 0) default 0 not null,
  "NegTransAcDate" decimal(8, 0) default 0 not null,
  "NegTransTlrNo" varchar2(6),
  "NegTransTxtNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegFinAcct" (
  "FinCode" varchar2(8),
  "FinItem" nvarchar2(60),
  "RemitBank" varchar2(7),
  "RemitAcct" varchar2(16),
  "DataSendSection" varchar2(8),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegFinShare" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "FinCode" varchar2(8),
  "ContractAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegFinShareLog" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "Seq" decimal(4, 0) default 0 not null,
  "FinCode" varchar2(8),
  "ContractAmt" decimal(16, 2) default 0 not null,
  "AmtRatio" decimal(5, 2) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "CancelDate" decimal(8, 0) default 0 not null,
  "CancelAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegMain" (
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "CaseKindCode" varchar2(1),
  "Status" varchar2(1),
  "CustLoanKind" varchar2(1),
  "PayerCustNo" decimal(7, 0) default 0 not null,
  "DeferYMStart" decimal(6, 0) default 0 not null,
  "DeferYMEnd" decimal(6, 0) default 0 not null,
  "ApplDate" decimal(8, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "TotalPeriod" decimal(3, 0) default 0 not null,
  "IntRate" decimal(4, 2) default 0 not null,
  "FirstDueDate" decimal(8, 0) default 0 not null,
  "LastDueDate" decimal(8, 0) default 0 not null,
  "IsMainFin" varchar2(1),
  "TotalContrAmt" decimal(16, 2) default 0 not null,
  "MainFinCode" varchar2(8),
  "PrincipalBal" decimal(16, 2) default 0 not null,
  "AccuTempAmt" decimal(16, 2) default 0 not null,
  "AccuOverAmt" decimal(16, 2) default 0 not null,
  "AccuDueAmt" decimal(16, 2) default 0 not null,
  "AccuSklShareAmt" decimal(16, 2) default 0 not null,
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "TwoStepCode" varchar2(1),
  "ChgCondDate" decimal(8, 0) default 0 not null,
  "NextPayDate" decimal(8, 0) default 0 not null,
  "PayIntDate" decimal(8, 0) default 0 not null,
  "RepayPrincipal" decimal(14, 0) default 0 not null,
  "RepayInterest" decimal(14, 0) default 0 not null,
  "StatusDate" decimal(8, 0) default 0 not null,
  "CourtCode" varchar2(3),
  "ThisAcDate" decimal(8, 0) default 0 not null,
  "ThisTitaTlrNo" varchar2(6),
  "ThisTitaTxtNo" decimal(8, 0) default 0 not null,
  "LastAcDate" decimal(8, 0) default 0 not null,
  "LastTitaTlrNo" varchar2(6),
  "LastTitaTxtNo" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "NegQueryCust" (
  "AcDate" decimal(8, 0) default 0 not null,
  "CustId" varchar2(10),
  "FileYN" varchar2(1),
  "SeqNo" decimal(3, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "NegTrans" (
  "AcDate" decimal(8, 0) default 0 not null,
  "TitaTlrNo" varchar2(6),
  "TitaTxtNo" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "CaseSeq" decimal(3, 0) default 0 not null,
  "EntryDate" decimal(8, 0) default 0 not null,
  "TxStatus" decimal(1, 0) default 0 not null,
  "TxKind" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "PrincipalBal" decimal(16, 2) default 0 not null,
  "ReturnAmt" decimal(16, 2) default 0 not null,
  "SklShareAmt" decimal(16, 2) default 0 not null,
  "ApprAmt" decimal(16, 2) default 0 not null,
  "ExportDate" decimal(8, 0) default 0 not null,
  "ExportAcDate" decimal(8, 0) default 0 not null,
  "TempRepayAmt" decimal(16, 2) default 0 not null,
  "OverRepayAmt" decimal(16, 2) default 0 not null,
  "PrincipalAmt" decimal(16, 2) default 0 not null,
  "InterestAmt" decimal(16, 2) default 0 not null,
  "OverAmt" decimal(16, 2) default 0 not null,
  "IntStartDate" decimal(8, 0) default 0 not null,
  "IntEndDate" decimal(8, 0) default 0 not null,
  "RepayPeriod" decimal(3, 0) default 0 not null,
  "RepayDate" decimal(8, 0) default 0 not null,
  "OrgAccuOverAmt" decimal(16, 2) default 0 not null,
  "AccuOverAmt" decimal(16, 2) default 0 not null,
  "ShouldPayPeriod" decimal(3, 0) default 0 not null,
  "DueAmt" decimal(16, 2) default 0 not null,
  "ThisEntdy" decimal(8, 0) default 0 not null,
  "ThisKinbr" varchar2(4),
  "ThisTlrNo" varchar2(6),
  "ThisTxtNo" varchar2(8),
  "ThisSeqNo" varchar2(30),
  "LastEntdy" decimal(8, 0) default 0 not null,
  "LastKinbr" varchar2(4),
  "LastTlrNo" varchar2(6),
  "LastTxtNo" varchar2(8),
  "LastSeqNo" varchar2(30),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "PfBsDetail" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "BsOfficer" varchar2(6),
  "DeptCode" varchar2(6),
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "ProdCode" varchar2(5),
  "PieceCode" varchar2(1),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "PerfCnt" decimal(5, 1) default 0 not null,
  "PerfAmt" decimal(16, 2) default 0 not null,
  "AdjPerfCnt" decimal(5, 1) default 0 not null,
  "AdjPerfAmt" decimal(16, 2) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfBsDetail_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;





create table "PfBsDetailAdjust" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "AdjPerfCnt" decimal(5, 1) default 0 not null,
  "AdjPerfAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfBsDetailAdjust_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;



create table "PfBsOfficer" (
  "WorkMonth" decimal(6, 0) default 0 not null,
  "EmpNo" varchar2(6),
  "Fullname" varchar2(40),
  "AreaCode" varchar2(6),
  "AreaItem" nvarchar2(12),
  "DeptCode" varchar2(6),
  "DepItem" nvarchar2(12),
  "DistCode" varchar2(6),
  "DistItem" nvarchar2(30),
  "StationName" nvarchar2(30),
  "GoalAmt" decimal(16, 2) default 0 not null,
  "SmryGoalAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "PfCoOfficer" (
  "EmpNo" varchar2(6),
  "EffectiveDate" decimal(8, 0) default 0 not null,
  "IneffectiveDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "AreaItem" nvarchar2(20),
  "DistItem" nvarchar2(20),
  "DeptItem" nvarchar2(20),
  "EmpClass" varchar2(1),
  "ClassPass" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "PfCoOfficerLog" (
  "EmpNo" varchar2(6),
  "EffectiveDate" decimal(8, 0) default 0 not null,
  "IneffectiveDate" decimal(8, 0) default 0 not null,
  "AreaCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "AreaItem" varchar2(20),
  "DistItem" varchar2(20),
  "DeptItem" varchar2(20),
  "EmpClass" varchar2(1),
  "ClassPass" varchar2(1),
  "SerialNo" decimal(2, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "PfDeparment" (
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "EmpNo" varchar2(6),
  "UnitItem" nvarchar2(20),
  "DistItem" nvarchar2(20),
  "DeptItem" nvarchar2(20),
  "DirectorCode" varchar2(1),
  "EmpName" nvarchar2(8),
  "DepartOfficer" nvarchar2(8),
  "GoalCnt" decimal(4, 0) default 0 not null,
  "SumGoalCnt" decimal(16, 0) default 0 not null,
  "GoalAmt" decimal(16, 2) default 0 not null,
  "SumGoalAmt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "PfDetail" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BorxNo" decimal(4, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "PieceCode" varchar2(1),
  "RepaidPeriod" decimal(3, 0) default 0 not null,
  "ProdCode" varchar2(5),
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "Introducer" nvarchar2(8),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "IsReNewEmpUnit" varchar2(1),
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "UnitManager" nvarchar2(8),
  "DistManager" nvarchar2(8),
  "DeptManager" nvarchar2(8),
  "ComputeItAmtFac" decimal(16, 2) default 0 not null,
  "ItPerfCnt" decimal(5, 1) default 0 not null,
  "ComputeItAmt" decimal(16, 2) default 0 not null,
  "ItPerfAmt" decimal(16, 2) default 0 not null,
  "ItPerfEqAmt" decimal(16, 2) default 0 not null,
  "ItPerfReward" decimal(16, 2) default 0 not null,
  "ComputeItBonusAmt" decimal(16, 2) default 0 not null,
  "ItBonus" decimal(16, 2) default 0 not null,
  "ComputeAddBonusAmt" decimal(16, 2) default 0 not null,
  "ItAddBonus" decimal(16, 2) default 0 not null,
  "ComputeCoBonusAmt" decimal(16, 2) default 0 not null,
  "CoorgnizerBonus" decimal(16, 2) default 0 not null,
  "BsOfficer" varchar2(6),
  "BsDeptCode" varchar2(6),
  "ComputeBsAmtFac" decimal(16, 2) default 0 not null,
  "BsPerfCnt" decimal(5, 1) default 0 not null,
  "ComputeBsAmt" decimal(16, 2) default 0 not null,
  "BsPerfAmt" decimal(16, 2) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "PieceCodeCombine" varchar2(1),
  "IsProdFinancial" varchar2(1),
  "IsIntroducerDay15" varchar2(1),
  "IsCoorgnizerDay15" varchar2(1),
  "IsProdExclude1" varchar2(1),
  "IsProdExclude2" varchar2(1),
  "IsProdExclude3" varchar2(1),
  "IsProdExclude4" varchar2(1),
  "IsProdExclude5" varchar2(1),
  "IsDeptExclude1" varchar2(1),
  "IsDeptExclude2" varchar2(1),
  "IsDeptExclude3" varchar2(1),
  "IsDeptExclude4" varchar2(1),
  "IsDeptExclude5" varchar2(1),
  "IsDay15Exclude1" varchar2(1),
  "IsDay15Exclude2" varchar2(1),
  "IsDay15Exclude3" varchar2(1),
  "IsDay15Exclude4" varchar2(1),
  "IsDay15Exclude5" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfDetail_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;


create table "PfInsCheck" (
  "Kind" decimal(1, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "CreditSysNo" decimal(7, 0) default 0 not null,
  "CustId" varchar2(10),
  "ApplDate" decimal(8, 0) default 0 not null,
  "InsDate" decimal(8, 0) default 0 not null,
  "InsNo" varchar2(15),
  "CheckResult" varchar2(1),
  "CheckWorkMonth" decimal(6, 0) default 0 not null,
  "ReturnMsg" nvarchar2(2000),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "PfIntranetAdjust" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "Introducer" varchar2(6),
  "BsOfficer" varchar2(6),
  "PerfAmt" decimal(16, 2) default 0 not null,
  "PerfCnt" decimal(5, 1) default 0 not null,
  "UnitType" varchar2(1),
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "SumAmt" decimal(16, 2) default 0 not null,
  "SumCnt" decimal(16, 2) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfIntranetAdjust_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;



create table "PfItDetail" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "DrawdownDate" decimal(8, 0) default 0 not null,
  "ProdCode" varchar2(5),
  "PieceCode" varchar2(1),
  "CntingCode" varchar2(1),
  "DrawdownAmt" decimal(16, 2) default 0 not null,
  "UnitCode" varchar2(6),
  "DistCode" varchar2(6),
  "DeptCode" varchar2(6),
  "Introducer" nvarchar2(8),
  "UnitManager" nvarchar2(8),
  "DistManager" nvarchar2(8),
  "DeptManager" nvarchar2(8),
  "PerfCnt" decimal(5, 1) default 0 not null,
  "PerfEqAmt" decimal(16, 2) default 0 not null,
  "PerfReward" decimal(16, 2) default 0 not null,
  "PerfAmt" decimal(16, 2) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "RewardDate" decimal(8, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaFg" decimal(1, 0) default 0 not null,
  "AdjRange" decimal(1, 0) default 0 not null,
  "AdjPerfEqAmt" decimal(16, 2) default 0 not null,
  "AdjPerfReward" decimal(16, 2) default 0 not null,
  "AdjPerfAmt" decimal(16, 2) default 0 not null,
  "AdjCntingCode" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfItDetail_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;






create table "PfItDetailAdjust" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "AdjRange" decimal(1, 0) default 0 not null,
  "AdjPerfEqAmt" decimal(16, 2) default 0 not null,
  "AdjPerfReward" decimal(16, 2) default 0 not null,
  "AdjPerfAmt" decimal(16, 2) default 0 not null,
  "AdjCntingCode" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfItDetailAdjust_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;




create table "PfReward" (
  "LogNo" decimal(11,0) not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(1, 0) default 0 not null,
  "PieceCode" varchar2(1),
  "ProdCode" varchar2(5),
  "Introducer" varchar2(6),
  "Coorgnizer" varchar2(6),
  "InterviewerA" varchar2(6),
  "InterviewerB" varchar2(6),
  "IntroducerBonus" decimal(16, 2) default 0 not null,
  "IntroducerBonusDate" decimal(8, 0) default 0 not null,
  "IntroducerAddBonus" decimal(16, 2) default 0 not null,
  "IntroducerAddBonusDate" decimal(8, 0) default 0 not null,
  "CoorgnizerBonus" decimal(16, 2) default 0 not null,
  "CoorgnizerBonusDate" decimal(8, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfReward_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;





create table "PfRewardMedia" (
  "BonusNo" decimal(11,0) not null,
  "BonusDate" decimal(8, 0) default 0 not null,
  "PerfDate" decimal(8, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "BormNo" decimal(3, 0) default 0 not null,
  "BonusType" decimal(1, 0) default 0 not null,
  "EmployeeNo" varchar2(6),
  "ProdCode" varchar2(5),
  "PieceCode" varchar2(1),
  "Bonus" decimal(14, 2) default 0 not null,
  "AdjustBonus" decimal(14, 2) default 0 not null,
  "AdjustBonusDate" decimal(8, 0) default 0 not null,
  "WorkMonth" decimal(6, 0) default 0 not null,
  "WorkSeason" decimal(5, 0) default 0 not null,
  "Remark" nvarchar2(50),
  "MediaFg" decimal(1, 0) default 0 not null,
  "MediaDate" decimal(8, 0) default 0 not null,
  "ManualFg" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "PfRewardMedia_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;



create table "PfSpecParms" (
  "ConditionCode" varchar2(1),
  "Condition" varchar2(6),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "PostAuthLog" (
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "AuthApplCode" varchar2(1),
  "CustNo" decimal(7, 0) default 0 not null,
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "AuthCode" varchar2(1),
  "FacmNo" decimal(3, 0) default 0 not null,
  "CustId" varchar2(10),
  "RepayAcctSeq" varchar2(2),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "StampCancelDate" decimal(8, 0) default 0 not null,
  "StampCode" varchar2(1),
  "PostMediaCode" varchar2(1),
  "AuthErrorCode" varchar2(2),
  "FileSeq" decimal(6, 0) default 0 not null,
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "TitaTxCd" varchar2(5),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);








create table "PostAuthLogHistory" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "AuthCode" varchar2(1),
  "AuthCreateDate" decimal(8, 0) default 0 not null,
  "AuthApplCode" varchar2(1),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "CustId" varchar2(10),
  "RepayAcctSeq" varchar2(2),
  "ProcessDate" decimal(8, 0) default 0 not null,
  "StampFinishDate" decimal(8, 0) default 0 not null,
  "StampCancelDate" decimal(8, 0) default 0 not null,
  "StampCode" varchar2(1),
  "PostMediaCode" varchar2(1),
  "AuthErrorCode" varchar2(2),
  "FileSeq" decimal(6, 0) default 0 not null,
  "PropDate" decimal(8, 0) default 0 not null,
  "RetrDate" decimal(8, 0) default 0 not null,
  "DeleteDate" decimal(8, 0) default 0 not null,
  "RelationCode" varchar2(2),
  "RelAcctName" nvarchar2(100),
  "RelationId" varchar2(10),
  "RelAcctBirthday" decimal(8, 0) default 0 not null,
  "RelAcctGender" varchar2(1),
  "AmlRsp" varchar2(1),
  "CreateEmpNo" varchar2(6),
  "CreateDate" timestamp,
  "LastUpdateEmpNo" varchar2(6),
  "LastUpdate" timestamp
);


create sequence "PostAuthLogHistory_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;






create table "PostDeductMedia" (
  "MediaDate" decimal(8, 0) default 0 not null,
  "MediaSeq" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayType" decimal(2, 0) default 0 not null,
  "RepayAmt" decimal(14, 0) default 0 not null,
  "ProcNoteCode" varchar2(2),
  "PostDepCode" varchar2(1),
  "OutsrcCode" varchar2(3),
  "DistCode" varchar2(4),
  "TransDate" decimal(8, 0) default 0 not null,
  "RepayAcctNo" varchar2(14),
  "PostUserNo" varchar2(20),
  "OutsrcRemark" nvarchar2(20),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" varchar2(6),
  "DetailSeq" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "ReltMain" (
  "CaseNo" decimal(7, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "ReltUKey" varchar2(32),
  "ReltCode" varchar2(2),
  "RemarkType" nvarchar2(1),
  "Reltmark" nvarchar2(100),
  "FinalFg" varchar2(1),
  "ApplDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "RepayActChangeLog" (
  "LogNo" decimal(11,0) not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "RepayCode" decimal(2, 0) default 0 not null,
  "RepayBank" varchar2(3),
  "PostDepCode" varchar2(1),
  "RepayAcct" varchar2(14),
  "Status" varchar2(1),
  "RelDy" decimal(8, 0) default 0 not null,
  "RelTxseq" varchar2(18),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


create sequence "RepayActChangeLog_SEQ" minvalue 1 maxvalue 2147483647 increment by 1 start with 1 nocache cycle;



create table "RptJcic" (
  "BranchNo" varchar2(4),
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "JcicName" nvarchar2(100),
  "JcicStatus" decimal(1, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "RptRelationCompany" (
  "CusId" nvarchar2(20),
  "CusSCD" nvarchar2(2),
  "ComNo" nvarchar2(10),
  "ComName" nvarchar2(50),
  "ComCRA" nvarchar2(18),
  "STSCD" nvarchar2(2),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "RptRelationFamily" (
  "CusId" nvarchar2(20),
  "CusSCD" nvarchar2(2),
  "RlbID" nvarchar2(20),
  "RlbName" nvarchar2(40),
  "FamilyCD" nvarchar2(3),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "RlbCusCCD" nvarchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "RptRelationSelf" (
  "CusId" nvarchar2(20),
  "CusName" nvarchar2(30),
  "STSCD" nvarchar2(2),
  "CusCCD" nvarchar2(1),
  "CusSCD" nvarchar2(2),
  "LAW001" nvarchar2(1),
  "LAW002" nvarchar2(1),
  "LAW003" nvarchar2(1),
  "LAW004" nvarchar2(1),
  "LAW005" nvarchar2(1),
  "LAW006" nvarchar2(1),
  "LAW007" nvarchar2(1),
  "LAW008" nvarchar2(1),
  "LAW009" nvarchar2(1),
  "LAW010" nvarchar2(1),
  "Mark" nvarchar2(10),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "SlipMedia" (
  "BranchNo" varchar2(4),
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" decimal(2, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "MediaSeq" decimal(3, 0) default 0 not null,
  "MediaSlipNo" varchar2(10),
  "Seq" decimal(3, 0) default 0 not null,
  "AcBookItem" nvarchar2(50),
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "AcNoItem" nvarchar2(40),
  "CurrencyCode" varchar2(3),
  "DbCr" varchar2(1),
  "TxAmt" decimal(16, 2) default 0 not null,
  "ReceiveCode" varchar2(15),
  "DeptCode" varchar2(6),
  "SlipRmk" nvarchar2(40),
  "CostMonth" varchar2(1),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "SlipMedia2022" (
  "AcBookCode" varchar2(3),
  "MediaSlipNo" varchar2(12),
  "Seq" decimal(5, 0) default 0 not null,
  "AcDate" decimal(8, 0) default 0 not null,
  "BatchNo" decimal(2, 0) default 0 not null,
  "MediaSeq" decimal(3, 0) default 0 not null,
  "AcNoCode" varchar2(11),
  "AcSubCode" varchar2(5),
  "DeptCode" varchar2(6),
  "DbCr" varchar2(1),
  "TxAmt" decimal(14, 2) default 0 not null,
  "SlipRmk" varchar2(80),
  "ReceiveCode" varchar2(15),
  "CostMonth" varchar2(2),
  "InsuNo" varchar2(10),
  "SalesmanCode" varchar2(12),
  "SalaryCode" varchar2(2),
  "CurrencyCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "CostUnit" varchar2(6),
  "SalesChannelType" varchar2(2),
  "IfrsType" varchar2(1),
  "RelationId" varchar2(10),
  "RelateCode" varchar2(3),
  "Ifrs17Group" varchar2(9),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "SpecInnReCheck" (
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "Remark" nvarchar2(300),
  "Cycle" decimal(2, 0) default 0 not null,
  "ReChkYearMonth" decimal(6, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "StgCdEmp" (
  "AGENT_CODE" varchar2(12),
  "COMM_LINE_CODE" varchar2(2),
  "COMM_LINE_TYPE" varchar2(1),
  "ORIG_INTRODUCER_ID" varchar2(12),
  "INTRODUCER_IND" varchar2(1),
  "REGISTER_LEVEL" varchar2(2),
  "REGISTER_DATE" varchar2(30),
  "CENTER_CODE" varchar2(6),
  "ADMINISTRAT_ID" varchar2(12),
  "INPUT_DATE" varchar2(30),
  "INPUT_USER" varchar2(8),
  "AG_STATUS_CODE" varchar2(1),
  "AG_STATUS_DATE" varchar2(30),
  "TRAN_DATE" varchar2(30),
  "TRAN_USER" varchar2(8),
  "RE_REGISTER_DATE" varchar2(30),
  "DIRECTOR_ID" varchar2(12),
  "DIRECTOR_ID_F" varchar2(12),
  "INTRODUCER_ID" varchar2(12),
  "INTRODUCER_ID_F" varchar2(12),
  "AG_LEVEL" varchar2(2),
  "LAST_LEVEL" varchar2(2),
  "LEVEL_DATE" varchar2(30),
  "TOP_LEVEL" varchar2(2),
  "OCCP_IND" varchar2(1),
  "QUOTA_AMT" varchar2(10),
  "APPL_TYPE" varchar2(1),
  "TAX_RATE" varchar2(9),
  "SOCIAL_INSU_CLASS" varchar2(5),
  "PROMOT_LEVEL_YM" varchar2(7),
  "DIRECTOR_YM" varchar2(7),
  "RECORD_DATE" varchar2(30),
  "EX_RECORD_DATE" varchar2(30),
  "EX_TR_DATE" varchar2(30),
  "EX_TR_IDENT" varchar2(16),
  "EX_TR_IDENT2" varchar2(9),
  "EX_TR_IDENT3" varchar2(12),
  "EX_TR_DATE3" varchar2(30),
  "REGISTER_BEFORE" varchar2(5),
  "DIRECTOR_AFTER" varchar2(5),
  "MEDICAL_CODE" varchar2(2),
  "EX_CHG_DATE" varchar2(30),
  "EX_DEL_DATE" varchar2(30),
  "APPL_CODE" varchar2(10),
  "FIRST_REG_DATE" varchar2(30),
  "AGIN_SOURCE" varchar2(3),
  "AGUI_CENTER" varchar2(9),
  "AGENT_ID" varchar2(10),
  "TOP_ID" varchar2(12),
  "AG_DEGREE" varchar2(2),
  "COLLECT_IND" varchar2(1),
  "AG_TYPE_1" varchar2(1),
  "EMPLOYEE_NO" varchar2(10),
  "CONTRACT_IND" varchar2(1),
  "CONTRACT_IND_YM" varchar2(7),
  "AG_TYPE_2" varchar2(1),
  "AG_TYPE_3" varchar2(1),
  "AG_TYPE_4" varchar2(1),
  "AGIN_IND1" varchar2(1),
  "AG_PO_IND" varchar2(1),
  "AG_DOC_IND" varchar2(1),
  "NEW_HIRE_TYPE" varchar2(1),
  "AG_CUR_IND" varchar2(1),
  "AG_SEND_TYPE" varchar2(3),
  "AG_SEND_NO" varchar2(100),
  "REGISTER_DATE_2" varchar2(30),
  "AG_RETURN_DATE" varchar2(30),
  "AG_TRANSFER_DATE_F" varchar2(30),
  "AG_TRANSFER_DATE" varchar2(30),
  "PROMOT_YM" varchar2(7),
  "PROMOT_YM_F" varchar2(7),
  "AG_POST_CHG_DATE" varchar2(30),
  "FAMILIES_TAX" varchar2(5),
  "AGENT_CODE_I" varchar2(12),
  "AG_LEVEL_SYS" varchar2(2),
  "AG_POST_IN" varchar2(6),
  "CENTER_CODE_ACC" varchar2(6),
  "EVALUE_IND" varchar2(1),
  "EVALUE_IND_1" varchar2(1),
  "BATCH_NO" varchar2(10),
  "EVALUE_YM" varchar2(7),
  "AG_TRANSFER_CODE" varchar2(2),
  "FULLNAME" nvarchar2(100),
  "BIRTH" varchar2(30),
  "EDUCATION" varchar2(1),
  "LR_IND" varchar2(1),
  "PROCESS_DATE" varchar2(30),
  "QUIT_DATE" varchar2(30),
  "CENTER_SHORT_NAME" nvarchar2(100),
  "CENTER_CODE_NAME" nvarchar2(100),
  "CENTER_CODE_1" varchar2(6),
  "CENTER_CODE_1_SHORT" nvarchar2(10),
  "CENTER_CODE_1_NAME" nvarchar2(100),
  "CENTER_CODE_2" varchar2(6),
  "CENTER_CODE_2_SHORT" nvarchar2(10),
  "CENTER_CODE_2_NAME" nvarchar2(100),
  "CENTER_CODE_ACC_1" varchar2(6),
  "CENTER_CODE_ACC_1_NAME" nvarchar2(100),
  "CENTER_CODE_ACC_2" varchar2(6),
  "CENTER_CODE_ACC_2_NAME" nvarchar2(100),
  "AG_POST" varchar2(2),
  "LEVEL_NAME_CHS" nvarchar2(10),
  "LR_SYSTEM_TYPE" varchar2(1),
  "SENIORITY_YY" varchar2(5),
  "SENIORITY_MM" varchar2(5),
  "SENIORITY_DD" varchar2(5),
  "AGLA_PROCESS_IND" varchar2(2),
  "STATUS_CODE" varchar2(1),
  "AGLA_CANCEL_REASON" varchar2(1),
  "IS_ANN_APPL_DATE" varchar2(30),
  "RECORD_DATE_C" varchar2(30),
  "STOP_REASON" varchar2(15),
  "STOP_STR_DATE" varchar2(30),
  "STOP_END_DATE" varchar2(30),
  "IFP_DATE" varchar2(30),
  "EFFECT_STR_DATE" varchar2(30),
  "EFFECT_END_DATE" varchar2(30),
  "ANN_APPL_DATE" varchar2(30),
  "CENTER_CODE_ACC_NAME" nvarchar2(20),
  "RE_HIRE_CODE" varchar2(1),
  "RSVD_ADMIN_CODE" varchar2(1),
  "ACCOUNT" varchar2(16),
  "PRP_DATE" varchar2(15),
  "ZIP" varchar2(10),
  "ADDRESS" nvarchar2(100),
  "PHONE_H" varchar2(30),
  "PHONE_C" varchar2(30),
  "SALES_QUAL_IND" varchar2(1),
  "AGSQ_START_DATE" varchar2(30),
  "PINYIN_NAME_INDI" nvarchar2(100)
);



create table "SystemParas" (
  "BusinessType" varchar2(2),
  "GraceDays" decimal(2, 0) default 0 not null,
  "AchAuthOneTime" varchar2(1),
  "AchDeductFlag" decimal(1, 0) default 0 not null,
  "AchDeductDD1" decimal(2, 0) default 0 not null,
  "AchDeductDD2" decimal(2, 0) default 0 not null,
  "AchDeductDD3" decimal(2, 0) default 0 not null,
  "AchDeductDD4" decimal(2, 0) default 0 not null,
  "AchDeductDD5" decimal(2, 0) default 0 not null,
  "AchSecondDeductDays" decimal(2, 0) default 0 not null,
  "AchDeductMethod" decimal(1, 0) default 0 not null,
  "PostDeductFlag" decimal(1, 0) default 0 not null,
  "PostDeductDD1" decimal(2, 0) default 0 not null,
  "PostDeductDD2" decimal(2, 0) default 0 not null,
  "PostDeductDD3" decimal(2, 0) default 0 not null,
  "PostDeductDD4" decimal(2, 0) default 0 not null,
  "PostDeductDD5" decimal(2, 0) default 0 not null,
  "PostSecondDeductDays" decimal(2, 0) default 0 not null,
  "PostDeductMethod" decimal(1, 0) default 0 not null,
  "LoanDeptCustNo" decimal(7, 0) default 0 not null,
  "NegDeptCustNo" decimal(7, 0) default 0 not null,
  "PerfBackRepayAmt" decimal(16, 2) default 0 not null,
  "PerfBackPeriodS" decimal(3, 0) default 0 not null,
  "PerfBackPeriodE" decimal(3, 0) default 0 not null,
  "AcctCode310A" decimal(3, 0) default 0 not null,
  "AcctCode310B" decimal(3, 0) default 0 not null,
  "AcctCode320A" decimal(3, 0) default 0 not null,
  "AcctCode320B" decimal(3, 0) default 0 not null,
  "AcctCode330A" decimal(3, 0) default 0 not null,
  "AcctCode330B" decimal(3, 0) default 0 not null,
  "ReduceAmtLimit" decimal(5, 0) default 0 not null,
  "PreRepayTerms" decimal(3, 0) default 0 not null,
  "PreRepayTermsBatch" decimal(3, 0) default 0 not null,
  "ShortPrinPercent" decimal(3, 0) default 0 not null,
  "ShortIntPercent" decimal(3, 0) default 0 not null,
  "AmlFg" decimal(1, 0) default 0 not null,
  "AmlUrl" nvarchar2(50),
  "PerfDate" decimal(8, 0) default 0 not null,
  "AcBookCode" varchar2(3),
  "AcSubBookCode" varchar2(3),
  "AcBookAdjDate" decimal(8, 0) default 0 not null,
  "EbsFg" varchar2(1),
  "EbsUrl" varchar2(100),
  "EbsAuth" varchar2(100),
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);



create table "TbJcicMu01" (
  "HeadOfficeCode" varchar2(3),
  "BranchCode" varchar2(4),
  "DataDate" decimal(8, 0) default 0 not null,
  "EmpId" varchar2(6),
  "Title" varchar2(50),
  "AuthQryType" varchar2(1),
  "QryUserId" varchar2(8),
  "AuthItemQuery" varchar2(1),
  "AuthItemReview" varchar2(1),
  "AuthItemOther" varchar2(1),
  "AuthStartDay" decimal(8, 0) default 0 not null,
  "AuthMgrIdS" varchar2(6),
  "AuthEndDay" decimal(8, 0) default 0 not null,
  "AuthMgrIdE" varchar2(6),
  "EmailAccount" varchar2(50),
  "ModifyUserId" varchar2(10),
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);







create table "TbJcicW020" (
  "QueryYm" varchar2(5),
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);




create table "TbJcicZZ50" (
  "QryStartDate" decimal(8, 0) default 0 not null,
  "QryEndDate" decimal(8, 0) default 0 not null,
  "OutJcictxtDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);





create table "YearlyHouseLoanInt" (
  "YearMonth" decimal(6, 0) default 0 not null,
  "CustNo" decimal(7, 0) default 0 not null,
  "FacmNo" decimal(3, 0) default 0 not null,
  "UsageCode" varchar2(2),
  "AcctCode" varchar2(3),
  "RepayCode" varchar2(2),
  "LoanAmt" decimal(16, 2) default 0 not null,
  "LoanBal" decimal(16, 2) default 0 not null,
  "FirstDrawdownDate" decimal(8, 0) default 0 not null,
  "MaturityDate" decimal(8, 0) default 0 not null,
  "YearlyInt" decimal(16, 2) default 0 not null,
  "HouseBuyDate" decimal(8, 0) default 0 not null,
  "CreateDate" timestamp,
  "CreateEmpNo" varchar2(6),
  "LastUpdate" timestamp,
  "LastUpdateEmpNo" varchar2(6)
);


